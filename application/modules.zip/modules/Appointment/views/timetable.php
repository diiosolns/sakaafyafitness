
			                            <div class="box box-default" style="margin-top: 15px;">
			                                <div class="box-header" style="cursor: move;">
			                                    <i class="fa fa-clock-o"></i>
			                                    <h4 class="box-title"><?php echo $this->lang->line('msg_weekly_schedule'); ?> (<?php echo $profileName;?>)</h4>
			                                </div><!-- /.box-header -->
			                                <div class="box-body">
			                                    <ul class="todo-list ui-sortable">
			                                        <li>
			                                            <span class="handle">
			                                                <i class="fa fa-ellipsis-v"></i>
			                                                <i class="fa fa-ellipsis-v"></i>
			                                            </span>  
			                                            <div class="icheckbox_minimal" aria-checked="false" aria-disabled="false" style="position: relative;"><input type="checkbox" value="" name="" style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins></div>                                            
			                                            <span class="text"><?php echo $this->lang->line('msg_mon'); ?></span>
			                                            <strong class="label label-info pull-right"><i class="fa fa-clock-o"></i>HRS</strong>
			                                            	<span class="text pull-right">(<?php echo $timetb->row()->monday;?>)</span>
			                                            <div class="tools">
			                                                <i class="fa fa-clock-o"></i>
			                                                <i class="fa fa-eye"></i>
			                                            </div>
			                                        </li>
			                                        <li>
			                                            <span class="handle">
			                                                <i class="fa fa-ellipsis-v"></i>
			                                                <i class="fa fa-ellipsis-v"></i>
			                                            </span>  
			                                            <div class="icheckbox_minimal" aria-checked="false" aria-disabled="false" style="position: relative;"><input type="checkbox" value="" name="" style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins></div>                                            
			                                            <span class="text"><?php echo $this->lang->line('msg_tues'); ?></span>
			                                            <strong class="label label-info pull-right"><i class="fa fa-clock-o"></i>HRS</strong>
			                                            	<span class="text pull-right">(<?php echo $timetb->row()->tuesday;?>)</span>
			                                            <div class="tools">
			                                                <i class="fa fa-clock-o"></i>
			                                                <i class="fa fa-eye"></i>
			                                            </div>
			                                        </li>
			                                        <li>
			                                            <span class="handle">
			                                                <i class="fa fa-ellipsis-v"></i>
			                                                <i class="fa fa-ellipsis-v"></i>
			                                            </span>  
			                                            <div class="icheckbox_minimal" aria-checked="false" aria-disabled="false" style="position: relative;"><input type="checkbox" value="" name="" style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins></div>                                            
			                                            <span class="text"><?php echo $this->lang->line('msg_wedness'); ?></span>
			                                            <strong class="label label-info pull-right"><i class="fa fa-clock-o"></i>HRS</strong>
			                                            	<span class="text pull-right">(<?php echo $timetb->row()->wednessday;?>)</span>
			                                            <div class="tools">
			                                                <i class="fa fa-clock-o"></i>
			                                                <i class="fa fa-eye"></i>
			                                            </div>
			                                        </li>
			                                        <li>
			                                            <span class="handle">
			                                                <i class="fa fa-ellipsis-v"></i>
			                                                <i class="fa fa-ellipsis-v"></i>
			                                            </span>  
			                                            <div class="icheckbox_minimal" aria-checked="false" aria-disabled="false" style="position: relative;"><input type="checkbox" value="" name="" style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins></div>                                            
			                                            <span class="text"><?php echo $this->lang->line('msg_thurs'); ?></span>
			                                            <strong class="label label-info pull-right"><i class="fa fa-clock-o"></i>HRS</strong>
			                                            	<span class="text pull-right">(<?php echo $timetb->row()->thursday;?>)</span>
			                                            <div class="tools">
			                                                <i class="fa fa-clock-o"></i>
			                                                <i class="fa fa-eye"></i>
			                                            </div>
			                                        </li>
			                                        <li>
			                                            <span class="handle">
			                                                <i class="fa fa-ellipsis-v"></i>
			                                                <i class="fa fa-ellipsis-v"></i>
			                                            </span>  
			                                            <div class="icheckbox_minimal" aria-checked="false" aria-disabled="false" style="position: relative;"><input type="checkbox" value="" name="" style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins></div>                                            
			                                            <span class="text"><?php echo $this->lang->line('msg_fri'); ?></span>
			                                            <strong class="label label-info pull-right"><i class="fa fa-clock-o"></i>HRS</strong>
			                                            	<span class="text pull-right">(<?php echo $timetb->row()->friday;?>)</span>
			                                            <div class="tools">
			                                                <i class="fa fa-clock-o"></i>
			                                                <i class="fa fa-eye"></i>
			                                            </div>
			                                        </li>
			                                        <li>
			                                            <span class="handle">
			                                                <i class="fa fa-ellipsis-v"></i>
			                                                <i class="fa fa-ellipsis-v"></i>
			                                            </span>  
			                                            <div class="icheckbox_minimal" aria-checked="false" aria-disabled="false" style="position: relative;"><input type="checkbox" value="" name="" style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins></div>                                            
			                                            <span class="text"><?php echo $this->lang->line('msg_satur'); ?></span>
			                                            <strong class="label label-info pull-right"><i class="fa fa-clock-o"></i>HRS</strong>
			                                            	<span class="text pull-right">(<?php echo $timetb->row()->saturday;?>)</span>
			                                            <div class="tools">
			                                                <i class="fa fa-clock-o"></i>
			                                                <i class="fa fa-eye"></i>
			                                            </div>
			                                        </li>
			                                        <li>
			                                            <span class="handle">
			                                                <i class="fa fa-ellipsis-v"></i>
			                                                <i class="fa fa-ellipsis-v"></i>
			                                            </span>  
			                                            <div class="icheckbox_minimal" aria-checked="false" aria-disabled="false" style="position: relative;"><input type="checkbox" value="" name="" style="position: absolute; opacity: 0;"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins></div>                                            
			                                            <span class="text"><?php echo $this->lang->line('msg_sun'); ?></span>
			                                            <strong class="label label-info pull-right"><i class="fa fa-clock-o"></i>HRS</strong>
			                                            	<span class="text pull-right">(<?php echo $timetb->row()->sunday;?>)</span>
			                                            <div class="tools">
			                                                <i class="fa fa-clock-o"></i>
			                                                <i class="fa fa-eye"></i>
			                                            </div>
			                                        </li>
			                                        		
			                                    </ul>
			                                </div><!-- /.box-body -->
			                            </div>

<!-- <?php echo $this->lang->line('msg_'); ?> -->