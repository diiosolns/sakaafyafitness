Hello, Dionizi France
/*xxxxxxxxx ASIDE xxxxxxxxxx*/
/*xxxxxxxxx END ASIDE xxxxx*/
xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
ASIDE
xxxxxxxxxxxxxxxxxxxxxx ENGLISH xxxxxxxxxxxxxxxxxx
$lang['msg_hello'] = 'Hello';

$lang['msg_active'] = 'Active';

$lang['msg_search_txt'] = 'Search...';

$lang['msg_dashboard'] = 'Dashboard';

$lang['msg_my_store'] = 'My Store';
$lang['msg_record_purchases'] = 'Record Purchases';
$lang['msg_available_items'] = 'Available Items';
$lang['msg_approve_items_orders'] = 'Approve Items Orders';
$lang['msg_transactions_approval'] = 'Transactions Approval';
$lang['msg_inventory_reports'] = 'Inventory Reports';
$lang['msg_inventory_approval'] = 'Inventory Approval';
$lang['msg_store_settings'] = 'Store Settings';

$lang['msg_production'] = 'Production';
$lang['msg_record_produced_items'] = 'Record Produced Items';
$lang['msg_available_products'] = 'Available Products';
$lang['msg_order_store_items'] = 'Order Store Items';
$lang['msg_other_production_expenses'] = 'Other Production Expenses';
$lang['msg_production_approval'] = 'Production Approval';
$lang['msg_production_reports'] = 'Production Reports';
$lang['msg_production_settings'] = 'Production Settings';

$lang['msg_sales'] = 'Sales';
$lang['msg_record_sales'] = 'Record Sales';
$lang['msg_my_transactions'] = 'My Transactions';
$lang['msg_transactions_aproooval'] = 'Transactions Aproooval';
$lang['msg_transactions_reports'] = 'Transactions Reports';

$lang['msg_manage_accounts'] = 'Manage Accounts';
$lang['msg_manage_users'] = 'Manage Users';
$lang['msg_change_password'] = 'Change Password';

$lang['msg_my_settings'] = 'mySettings';



xxxxxxxxxxxxxxxxxxxxxx SWAHILIxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
$lang['msg_hello'] = 'Habari';

$lang['msg_active'] = 'Active';

$lang['msg_search_txt'] = 'Tafuta...';

$lang['msg_dashboard'] = 'Dashibodi';

$lang['msg_my_store'] = 'Stoo Yangu';
$lang['msg_record_purchases'] = 'Rekodi Manunuzi';
$lang['msg_available_items'] = 'Vifaa Vilivyopo';
$lang['msg_approve_items_orders'] = 'Idhinisha Maombi ya Vifaa';
$lang['msg_transactions_approval'] = 'Idhinisha Miamara';
$lang['msg_inventory_reports'] = 'Ripoti za Mali (Vifaa)';
$lang['msg_inventory_approval'] = 'Idhinisha Mali (Vifaa)';
$lang['msg_store_settings'] = 'Mipangilio ya Stoo';

$lang['msg_'] = 'Uzalishaji';
$lang['msg_'] = 'Rekodi Bidhaa';
$lang['msg_'] = 'Bidhaa Zilizozalishwa';
$lang['msg_'] = 'Omba Vifaa Stoo';
$lang['msg_'] = 'Rekodi Matumizi Mengineyo';
$lang['msg_'] = 'Idhinisha Bidhaa';
$lang['msg_'] = 'Ripoti za Uzalshaji';
$lang['msg_'] = 'Mipangilio ya Uzalishaji';

$lang['msg_sales'] = 'Mauzo';
$lang['msg_record_sales'] = 'Rekodi Mauzo';
$lang['msg_my_transactions'] = 'Mauzo ya Siku';
$lang['msg_transactions_aproooval'] = 'Idhinisha Mauzo';
$lang['msg_transactions_reports'] = 'Ripoti za Mauzo';

$lang['msg_manage_accounts'] = 'Dhibiti Akaunti';
$lang['msg_manage_users'] = 'Dhibiti Watumiaji';
$lang['msg_change_password'] = 'Badilisha Neno la Siri';

$lang['msg_'] = 'Mipangilio';



//// display /////////
<?php echo $this->lang->line('msg_hello'); ?>                   

<?php echo $this->lang->line('msg_active'); ?>                    

<?php echo $this->lang->line('msg_search_txt'); ?>                   

<?php echo $this->lang->line('msg_dashboard'); ?>                   

<?php echo $this->lang->line('msg_my_store'); ?>                   
<?php echo $this->lang->line('msg_record_purchases'); ?>                   
<?php echo $this->lang->line('msg_available_items'); ?>                    
<?php echo $this->lang->line('msg_approve_items_orders'); ?>                    
<?php echo $this->lang->line('msg_transactions_approval'); ?>                   
<?php echo $this->lang->line('msg_inventory_reports'); ?>                   
<?php echo $this->lang->line('msg_inventory_approval'); ?>                 
<?php echo $this->lang->line('msg_store_settings'); ?>                 

<?php echo $this->lang->line('msg_production'); ?>                 
<?php echo $this->lang->line('msg_record_produced_items'); ?>                
<?php echo $this->lang->line('msg_available_products'); ?>               
<?php echo $this->lang->line('msg_order_store_items'); ?>                
<?php echo $this->lang->line('msg_other_production_expenses'); ?>                 
<?php echo $this->lang->line('msg_production_approval'); ?>                 
<?php echo $this->lang->line('msg_production_reports'); ?>                  
<?php echo $this->lang->line('msg_production_settings'); ?>                 

<?php echo $this->lang->line('msg_sales'); ?>                   
<?php echo $this->lang->line('msg_record_sales'); ?>                  
<?php echo $this->lang->line('msg_my_transactions'); ?>                 
<?php echo $this->lang->line('msg_transactions_aproooval'); ?>                
<?php echo $this->lang->line('msg_transactions_reports'); ?>                

<?php echo $this->lang->line('msg_manage_accounts'); ?>                  
<?php echo $this->lang->line('msg_manage_users'); ?>                  
<?php echo $this->lang->line('msg_change_password'); ?>               

<?php echo $this->lang->line('msg_my_settings'); ?>              
