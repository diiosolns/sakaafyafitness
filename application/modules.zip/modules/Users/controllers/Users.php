<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Users extends MX_Controller
{

function __construct() {
parent::__construct();
		$this->load->library(array('session'));
	    $this->load->helper('number');
		$this->load->helper('date');
		$this->load->helper('download');
		$this->load->helper('text');
		//My Modules
		$this->load->module('Profile');
		$this->load->module('Appointment');
		$this->load->module('Artical');
		$this->load->module('Admin');
		$this->load->module('Chat');
		$this->load->module('Home');
		$this->load->module('Users');
}


function index(){
	echo phpversion();
	echo "ACCESS FORBIDDEN";
}




function userReg(){
	$udata['name'] = $this->input->post('name', true);
	$udata['username'] = $this->input->post('username', true);
	$udata['email'] = $this->input->post('email', true);
	$udata['password'] = $this->input->post('password', true);
	$cpwrd = $this->input->post('cpassword', true);
	$udata['date'] = mdate('%d-%m-%Y');
	$udata['udate'] = mdate('%d-%m-%Y %H:%i:%s');
	$usernameVer    = $this->get_where_custom('username', $udata['username']);

	if ($udata['password'] == $cpwrd) {
		# code...
		if ($usernameVer->num_rows() == 0) {
			# code...
			$this->_insert($udata);
			$data['color'] = "green";
			$data['response'] = "Registration Complete.!";

			$user    = $this->get_where_custom('username', $udata['username'])->row() ;
			$newdata = array('user_id' =>(int)$user->id,
							'user_name'=> (string)$user->name,
							'user_username'=> (string)$user->username,
							'user_pwrd'=> (string)$user->password,
							'user_date'=> (string)$user->date,
							'user_role'=> (string)$user->role,
							'user_img'=> (string)$user->userimg,
							'user_online'=> (string)$user->online,
							'logged_in'=> (bool)true
							);
			$this->session->set_userdata($newdata);
			//update online status
			$onlinedata['online'] = 1;
			$this->users->_update($user->id,$onlinedata);
			redirect('Admin');
		} else {
			$data['color'] = "red";
			$data['response'] = "Registration Failed.! This username is arleady used. Please Choose another Username";
		}
		

	} else {
		# code...
		$data['color'] = "red";
		$data['response'] = "Registration Failed.! Password Does not Match.";
	}
	
	//echo $data['response'];
}



function addUser(){
	$saveBtn = $this->input->post('saveBtn', true);
	$udata['name'] = $this->input->post('name', true);
	$udata['username'] = $this->input->post('username', true);
	$udata['email'] = $this->input->post('email', true);
	$udata['phone'] = $this->input->post('phone', true);
	$udata['role'] = $this->input->post('role', true);
	$udata['password'] = $this->input->post('password', true);
	$cpwrd = $this->input->post('cpassword', true);
	$udata['date'] = mdate('%d-%m-%Y');
	$udata['udate'] = mdate('%d-%m-%Y %H:%i:%s');

	if (!$saveBtn == "") {
		# code...
		if ($udata['password'] == $cpwrd) {
			# code...
			$this->_insert($udata);
			$data['middle_m'] ="Admin";
	 		$data['mpanel_m'] = "Users";
	 		$data['mpanel_f'] = "addUser";
			$data['color'] = "green";
			$data['msg'] = '<div class="alert alert-success"><strong>Success!</strong> User Registration Completed Successifully.! User Default Password to login into Added User ccount to Confirm.</div>';
		} else {
			# code...
			$data['middle_m'] ="Admin";
	 		$data['mpanel_m'] = "Users";
	 		$data['mpanel_f'] = "addUser";
			$data['color'] = "red";
			$data['msg'] = '<div class="alert alert-danger"><strong>Success!</strong> Registration Failed. Password Does not Match.</div>';
		}
	} else {
		# code...
		$data['middle_m'] ="Admin";
	 	$data['mpanel_m'] = "Users";
	 	$data['mpanel_f'] = "addUser";
	 	$data['msg'] = "";
	}
	

	if ($this->session->userdata('logged_in')) {
		if ($this->session->userdata('user_role') == "Admin") {$data['middle_f'] = "adminm_container"; $this->load->view('Admin/index',$data); } else {  $data['middle_f'] = "m_container"; $this->load->view('Admin/index',$data); }
	} else {
		redirect('Home');
	}

}




function changePassword(){
	$id = $this->session->userdata('user_id');
	$data['userres'] = $this->get_where($id);
	$changeBtn = $this->input->post('changeBtn',true);

	$udata['password'] = $this->input->post('password',true);
	$udata['udate'] = mdate('%Y-%m-%d %H:%i:%s');
	$confpwrd = $this->input->post('password2',true);
	$cpword = $this->input->post('cpword',true);

	if ($changeBtn == "ok") {
		# code...
		if ($cpword == $data['userres']->row()->password) {
		# code...
		if ($udata['password'] == $confpwrd) {
			# code...
			//update password
			$this->_update($id, $udata);

			if ($this->session->userdata('logged_in')) {
				$data['color'] = "";
				$data['err'] = '<div class="alert alert-success alert-dismissable"> <i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> <b>Info!</b> Password Has Been Changed Successifully ! Use new Password During Login</div>';
				$data['middle_m'] ="Admin";
				$data['middle_f'] ="m_container";
			 	$data['mpanel_m'] = "Users";
				$data['mpanel_f'] = "changePwrd";
				$data['bfooter_m'] ="Home";
				$data['bfooter_f'] ="profileSlider";
				$this->load->view('Admin/index',$data);
				//if ($this->session->userdata('user_role') == "admin") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "store"){ $this->load->view('Inventory/index',$data); } else if ($this->session->userdata('user_role') == "baker"){ $this->load->view('Production/index',$data); } else if ($this->session->userdata('user_role') == "seller"){ $this->load->view('Sales/index',$data); } else { $this->load->view('index',$data); }
			} else {
				redirect('Home');
			}

		} else {
			# code...
			//password does not match
			if ($this->session->userdata('logged_in')) {
				$data['color'] = "";
				$data['err'] = '<div class="alert alert-danger alert-dismissable"> <i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> <b>Alert!</b> Password Change Failed ! Passwords Does no Match. Try Again </div>';
				$data['middle_m'] ="Admin";
				$data['middle_f'] ="m_container";
			 	$data['mpanel_m'] = "Users";
				$data['mpanel_f'] = "changePwrd";
				$data['bfooter_m'] ="Home";
				$data['bfooter_f'] ="profileSlider";

				$this->load->view('Admin/index',$data);
				//if ($this->session->userdata('user_role') == "admin") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "store"){ $this->load->view('Inventory/index',$data); } else if ($this->session->userdata('user_role') == "baker"){ $this->load->view('Production/index',$data); } else if ($this->session->userdata('user_role') == "seller"){ $this->load->view('Sales/index',$data); } else { $this->load->view('index',$data); }
			} else {
				redirect('Home');
			}
		}
		
	} else {
		# code...
		//The current password is incorrect
		if ($this->session->userdata('logged_in')) {
				$data['color'] = "";
				$data['err'] = '<div class="alert alert-danger alert-dismissable"> <i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> <b>Alert!</b> Password Change Failed ! The Current Password is Incorrect. Try Again </div>';
				$data['middle_m'] ="Admin";
				$data['middle_f'] ="m_container";
			 	$data['mpanel_m'] = "Users";
				$data['mpanel_f'] = "changePwrd";
				$data['bfooter_m'] ="Home";
				$data['bfooter_f'] ="profileSlider";

				$this->load->view('Admin/index',$data);
				//if ($this->session->userdata('user_role') == "admin") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "store"){ $this->load->view('Inventory/index',$data); } else if ($this->session->userdata('user_role') == "baker"){ $this->load->view('Production/index',$data); } else if ($this->session->userdata('user_role') == "seller"){ $this->load->view('Sales/index',$data); } else { $this->load->view('index',$data); }
			} else {
				redirect('Home');
			}
	}
	} else {
		# code...
		if ($this->session->userdata('logged_in')) {
				$data['color'] = "";
				$data['err'] = "";
				$data['middle_m'] ="Admin";
				$data['middle_f'] ="m_container";
			 	$data['mpanel_m'] = "Users";
				$data['mpanel_f'] = "changePwrd";
				$data['bfooter_m'] ="Home";
				$data['bfooter_f'] ="profileSlider";

				$this->load->view('Admin/index',$data);
				//if ($this->session->userdata('user_role') == "admin") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "store"){ $this->load->view('Inventory/index',$data); } else if ($this->session->userdata('user_role') == "baker"){ $this->load->view('Production/index',$data); } else if ($this->session->userdata('user_role') == "seller"){ $this->load->view('Sales/index',$data); } else { $this->load->view('index',$data); }
			} else {
				redirect('Home');
			}
	}

}



function manageUsers() {
	$deleteBtn = $this->input->post('deleteBtn', true);
	$data['userRes'] = $this->get('id');


	if (!$deleteBtn == "") {
		# code...
		$id = $deleteBtn;
		$this->_delete($id);

		$data['userRes'] = $this->get('id');

		$data['middle_m'] ="Admin";
		$data['middle_f'] ="m_container";
	 	$data['mpanel_m'] = "Users";
		$data['mpanel_f'] = "manageUsers";
		$data['color'] = "red";
		$data['msg'] ="";

	} else {
		# code...
		$data['middle_m'] ="Admin";
		$data['middle_f'] ="m_container";
	 	$data['mpanel_m'] = "Users";
		$data['mpanel_f'] = "manageUsers";
		$data['color'] = "red";
		$data['msg'] ="";
	}

	if ($this->session->userdata('logged_in')) {
		if ($this->session->userdata('user_role') == "Admin") {$data['middle_f'] = "adminm_container"; $this->load->view('Admin/index',$data); } else {  $data['middle_f'] = "m_container"; $this->load->view('Admin/index',$data); }
		//if ($this->session->userdata('user_role') == "admin") { $this->load->view('Admin/index',$data); } else { $this->load->view('Production/index',$data); }
	} else {
		//redirect('Home');
	}
	
}













/*====================== END HUDUMA FUNCTIONS ==============*/




//default codes

function get($order_by) {
$this->load->model('Mdl_users');
$query = $this->Mdl_users->get($order_by);
return $query;
}

function get_with_limit($limit, $offset, $order_by) {
$this->load->model('Mdl_users');
$query = $this->Mdl_users->get_with_limit($limit, $offset, $order_by);
return $query;
}

function get_where($id) {
$this->load->model('Mdl_users');
$query = $this->Mdl_users->get_where($id);
return $query;
}

function get_where_custom($col, $value) {
$this->load->model('Mdl_users');
$query = $this->Mdl_users->get_where_custom($col, $value);
return $query;
}

function _insert($data) {
$this->load->model('Mdl_users');
$this->Mdl_users->_insert($data);
}

function _update($id, $data) {
$this->load->model('Mdl_users');
$this->Mdl_users->_update($id, $data);
}

function _delete($id) {
$this->load->model('Mdl_users');
$this->Mdl_users->_delete($id);
}

function count_where($column, $value) {
$this->load->model('Mdl_users');
$count = $this->Mdl_users->count_where($column, $value);
return $count;
}

function count_all() {
$this->load->model('Mdl_users');
$count = $this->Mdl_users->count_all();
return $count;
}



function get_max() {
$this->load->model('Mdl_users');
$max_id = $this->Mdl_users->get_max();
return $max_id;
}

function _custom_query($mysql_query) {
$this->load->model('Mdl_users');
$query = $this->Mdl_users->_custom_query($mysql_query);
return $query;
}

}