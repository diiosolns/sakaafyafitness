PROFFESSIONAL
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Teacher">Teacher</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Doctor">Doctor</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Techinician">Techinician</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Animal Keeping">Animal Keeping</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Agriculturist">Agriculturist</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Lawyor">Lawyor</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Nurse">Nurse</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Burser">Burser</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Sychologist">Sychologist</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Mfasiri:">Mfasiri:</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Interpreter">Interpreter</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Journalist">Journalist</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Press">Press</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Master Ceremony (MC)">Master Ceremony (MC)</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Driver">Driver</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Dalali">Dalali</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Security Guard">Security Guard</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Other Works">Other Works</a></li>





INTERPRENOUR
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Archtect">Archtect</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Shop/ Market">Shop/ Market</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Packing">Packing</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Car Wash">Car Wash</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Garage">Garage</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Bar">Bar</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Saloon">Saloon</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Bakery">Bakery</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Tution Center">Tution Center</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Day care">Day care</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/School">School</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Guest House">Guest House</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Hotel">Hotel</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Cafe">Cafe</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Company">Company</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Butcher">Butcher</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Institute">Institute</a></li>
<li><a href="<?php echo base_url('Profile/viewProfiles/');?>cat/Other Business Works">Other Business Works</a></li>


<option value=''>Teacher</option>
		<option value='Mathematics'>Mathematics</option>
		<option value='Physics'>Physics</option>
		<option value='Chemistry'>Chemistry</option>
		<option value='Biology'>Biology</option>
		<option value='History'>History</option>
		<option value='Kiswahili'>Kiswahili</option>
		<option value='English'>English</option>
		<option value='Kiswahili for Foreigners'>Kiswahili for Foreigners</option>
		<option value='Geography'>Geography</option>
		<option value='Accounts'>Accounts</option>
		<option value='Uchumi'>Uchumi</option>
		<option value='Other Subjects'>Other Subjects</option>

<option value=''>Doctor</option>
		<option value='one Specialist'>None Specialist</option>
		<option value='Children'>Children</option>
		<option value='Mothers'>Mothers</option>
		<option value='Skin'>Skin</option>
		<option value='Bones'>Bones</option>
		<option value='Muscles'>Muscles</option>
		<option value='Hearts'>Hearts</option>
		<option value='Operations'>Operations</option>
		
<option value=''>Techinician</option>
		<option value='Water Pumps'>Water Pumps</option>
		<option value='Electronics'>Electronics</option>
		<option value='Mechanics'>Mechanics</option>
		<option value='Electrical'>Electrical</option>
		<option value='Clothes'>Clothes</option>

<option value=''>Animal Keeping</option>
		<option value='Beef'>Beef</option>
		<option value='Milk'>Milk</option>
		<option value='Chickens (Kuku)'>Chickens (Kuku)</option>
		
<option value=''>Agriculturist</option>
<option value=''>Lawyor</option>
<option value=''>Nurse</option>
<option value=''>Burser</option>
<option value=''>Sychologist</option>
<option value=''>Mfasiri:</option>
<option value=''>Interpreter</option>
<option value=''>Journalist</option>
<option value=''>Press</option>
<option value=''>Master Ceremony (MC)</option>
<option value=''>Driver</option>
<option value=''>Dalali</option>
<option value=''>Security Guard</option>
<option value=''>Other Works</option>





<option value=''>Archtect</option>
<option value=''>Shop/ Market</option>
		<option value='Clothes'>Clothes</option>
		<option value='Shoes'>Shoes</option>
		<option value='Electronics'>Electronics</option><option value='Others'>Others</option>
		
<option value=''>Packing</option>
<option value=''>Car Wash</option>
<option value=''>Garage</option>
<option value=''>Bar</option>
<option value=''>Saloon</option>
		<option value='Baba Shop'>Baba Shop</option>
		<option value='Ladies Saloon'>Ladies Saloon</option>
		
<option value=''>Bakery</option>
<option value=''>Tution Center</option>
<option value=''>Day care</option>
<option value=''>School</option>
		<option value='Primary'>Primary</option>
		<option value='Secondary'>Secondary</option>
	
<option value=''>Guest House</option>
<option value=''>Hotel</option>
<option value=''>Cafe</option>
<option value=''>Company</option>
<option value=''>Butcher</option>
<option value=''>Institute</option>
<option value=''>Other Business Works</option>





<option value=''>President</option>
<option value=''>Member of Pariament (MP)</option>
<option value=''>Diwani</option>
<option value=''>Chairman</option>
<option value=''>Periament Speaker</option>
<option value=''></option>
<option value=''></option>
<option value=''></option>





============X===============X====================
<a href="Teacher">Teacher</a>
<a href="Doctor">Doctor</a>
<a href="Diwani">Diwani</a>
<a href="Chairman">Chairman</a>
<a href="Lawyor">Lawyor</a>
<a href="Nurse">Nurse</a>
<a href="Burser">Burser</a>
<a href="Sychologist">Sychologist</a>
<a href="Mfasiri">Mfasiri</a>
<a href="Interpreter">Interpreter</a>
<a href="Journalist">Journalist</a>
<a href="Techinician">Techinician</a>
<a href="Agriculturist">Agriculturist</a>
<a href="Sychologist">Sychologist</a>
<a href="Mfasiri">Mfasiri</a>
<a href="Interpreter">Interpreter</a>
<a href="Journalist">Journalist</a>
<a href="Press">Press</a>
<a href="Driver">Driver</a>
<a href="Dalali">Dalali</a>
<a href="Archtect">Archtect</a>
<a href="Packing">Packing</a>
<a href="Garage">Garage</a>
<a href="Bar">Bar</a>
<a href="Saloon">Saloon</a>
<a href="Bakery">Bakery</a>
<a href="School">School</a>
<a href="Hotel">Hotel</a>
<a href="Cafe">Cafe</a>
<a href="Company">Company</a>
<a href="Butcher">Butcher</a>
<a href="Institute">Institute</a>
<a href="President">President</a>

<a href="Animal Keeping">Animal Keeping</a>
<a href="Master Ceremony (MC)">Master Ceremony (MC)</a>
<a href="Security Guard">Security Guard</a>
<a href="Other Works">Other Works</a>
<a href="Shop/ Market">Shop/ Market</a>
<a href="Car Wash">Car Wash</a>
<a href="Tution Center">Tution Center</a>
<a href="Day care">Day care</a>
<a href="Guest House">Guest House</a>
<a href="Other Business Works">Other Business Works</a>
<a href="Member of Pariament (MP)">Member of Pariament (MP)</a>
<a href="Periament Speaker">Periament Speaker</a>

===============================================