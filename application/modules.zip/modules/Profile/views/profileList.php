<style>
/*.imgcontainer {
    position: relative;
    width: 100%;
}*/

.image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
}

.middle {
  transition: .5s ease;
  opacity: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%)
}

.imgcontainer:hover .image {
  opacity: 0.3;
}

.imgcontainer:hover .middle {
  opacity: 1;
}

.text {
  /*background-color: #4CAF50;*/
  color: white;
  font-size: 16px;
  padding: 16px 32px;
}


/*========== pagination==========*/
.pagination {
    display: inline-block;
}

.pagination a {
    color: black;
    float: left;
    padding: 8px 16px;
    text-decoration: none;
    border: 1px solid #ddd;
}

.pagination a.active {
    background-color: #4CAF50;
    color: white;
    border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {background-color: #ddd;}

.pagination a:first-child {
    border-top-left-radius: 5px;
    border-bottom-left-radius: 5px;
}

.pagination a:last-child {
    border-top-right-radius: 5px;
    border-bottom-right-radius: 5px;
}
/*=============end pagnation ===*/
</style>


<section class="content" style="padding: 15px 2% 0 2%">
<div class="container">


  <div class="row">
    
  <form action="<?php echo base_url('Profile/viewSelectedProfile')?>" method="post">

    <?php foreach ($profileres->result() as $row): ?>
       <?php $imgUrl = 'assets/img/profile/0/'.$row->img; ?>
    <div class="col-md-3 " >
      <div class="card" style="padding: 10px 10px 10px 10px;">
      <div class="imgcontainer">
      <img src="<?php echo base_url($imgUrl);?>" alt="Avatar" class="image img-rounded" style="width:100%">
      <div class="middle">
        <div class="text">
          <button type="submit" name="viewBtn" value="<?php echo $row->id;?>" class="btn btn-info  btn-lg">View Profile</button>
        </div>
      </div>
      </div>
      <div class="card-block">
        <h4 class="card-title"><?php echo $row->profilename;?></h4>
        <span style="color: #ff3546;"><?php echo $row->type;?> </span><span style="color: blue;">| <?php echo $row->category;?> | <?php echo $row->subcategory;?></span> <br>
        <!-- <span><i><b>Phone #:</b> <?php echo $row->phone;?> | <?php echo $row->altphone;?></i></span><br> -->
        <span><i><b>E-mail:</b> <?php echo $row->email;?></i></span><br>
        <span><i><b>Location:</b> <?php echo $row->phyaddress;?></i></span><br>
        <!-- <a href="#" class="btn btn-primary">Go somewhere</a> -->
      </div>
      </div>
    </div>
    <?php endforeach; ?>

  </form>

    <div class="col-md-12 " >
      <div  style="margin: auto; text-align: center;">
          <?php if (isset($links)) { ?>
           <?php echo $links ?>
          <?php } ?>
      </div>
    </div>

    <!-- <div class="col-md-3" style="padding-bottom: 10px;">
      <div class="imgcontainer">
      <img src="<?php //echo base_url('assets/img/slider/slider_01.jpg');?>" alt="Avatar" class="image " style="width:100%">
      <div class="middle">
        <div class="text">
          <button type="submit" name="viewBtn" value="ok" class="btn btn-default  btn-lg">View Profile</button>
        </div>
      </div>
    </div>
    </div> -->

    

    
  </div>


</div>

</section>
 