<!-- <link rel="stylesheet" type="text/css" href="<?php //echo base_url('assets/css//normalize.css');?>" /> -->
<!-- <link rel="stylesheet" type="text/css" href="<?php //echo base_url('assets/css/demo.css');?>" /> -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/tabs.css');?>" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/tabstyles.css');?>" />
<script src="<?php echo base_url('assets/js/modernizr.custom.js');?>"></script>
<!--  search inputs top -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="<?php echo base_url('assets/js/myJs/profilesch.js');?>" type="text/javascript"></script> 

<!-- <?php echo $this->lang->line('msg_'); ?> -->

<style type="text/css">
.form-style-1 {
    margin:10px auto;
    max-width: 100%;
    padding: 20px 12px 10px 20px;
    font: 13px "Lucida Sans Unicode", "Lucida Grande", sans-serif;
}
.form-style-1 li {
    padding: 0;
    display: block;
    list-style: none;
    margin: 10px 0 0 0;
}
.form-style-1 label{
    margin:0 0 3px 0;
    padding:0px;
    display:block;
    font-weight: bold;
}
.form-style-1 input[type=text], 
.form-style-1 input[type=date],
.form-style-1 input[type=datetime],
.form-style-1 input[type=number],
.form-style-1 input[type=search],
.form-style-1 input[type=time],
.form-style-1 input[type=url],
.form-style-1 input[type=email],
textarea, 
select{
	background-color: #fff;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: bordfer-box;
    border:1px solid #BEBEBE;
    padding: 7px;
    margin:0px;
    -webkit-transition: all 0.30s ease-in-out;
    -moz-transition: all 0.30s ease-in-out;
    -ms-transition: all 0.30s ease-in-out;
    -o-transition: all 0.30s ease-in-out;
    outline: none;  
}
.form-style-1 input[type=text]:focus, 
.form-style-1 input[type=date]:focus,
.form-style-1 input[type=datetime]:focus,
.form-style-1 input[type=number]:focus,
.form-style-1 input[type=search]:focus,
.form-style-1 input[type=time]:focus,
.form-style-1 input[type=url]:focus,
.form-style-1 input[type=email]:focus,
.form-style-1 textarea:focus, 
.form-style-1 select:focus{
    -moz-box-shadow: 0 0 8px #88D5E9;
    -webkit-box-shadow: 0 0 8px #88D5E9;
    box-shadow: 0 0 8px #88D5E9;
    border: 1px solid #88D5E9;
}
.form-style-1 .field-divided{
    width: 49%;
}

.form-style-1 .field-long{
    width: 100%;
}
.form-style-1 .field-select{
    width: 100%;
}
.form-style-1 .field-textarea{
    height: 100px;
}
.form-style-1 input[type=submit], .form-style-1 input[type=button]{
    background: #4B99AD;
    padding: 8px 15px 8px 15px;
    border: none;
    color: #fff;
}
.form-style-1 input[type=submit]:hover, .form-style-1 input[type=button]:hover{
    background: #4691A4;
    box-shadow:none;
    -moz-box-shadow:none;
    -webkit-box-shadow:none;
}
.form-style-1 .required{
    color:red;
}
</style>



<section>
<br>
	<div  class="tabs tabs-style-iconbox" style="background-color: #F8F8F8;">
		<nav >
			<ul>
				<li class="tab-current" ><a href="#section-iconbox-1" class="fa fa-users"><b style="font-size: 22px;"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $this->lang->line('msg_nfd_profile'); ?></b></a></li>
				<li class=""><a href="#section-iconbox-2" class="fa fa-search"><b style="font-size: 22px;"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $this->lang->line('msg_nfd_search'); ?></b></a></li>
				<!-- <li class=""><a href="#section-iconbox-3" class="fa fa-upload"><span>Upload</span></a></li>
				<li class=""><a href="#section-iconbox-4" class="fa fa-coffee"><span>Work</span></a></li>
				<li class=""><a href="#section-iconbox-5" class="fa fa-config"><span>Settings</span></a></li> -->
			</ul>
		</nav>
		<div class="content-wrap">
			<section id="section-iconbox-1" class="content-current" >
				<br>
                <p><?php echo $this->lang->line('msg_nfd_nfd'); ?></p>
                <b>...</b>	
			</section>



			<section id="section-iconbox-2" class="">
             <div class="wow animated bounce">
			  <form class="form-style-1" action="<?php echo base_url('Profile/profileList')?>" method="post">
                <div  style="padding: 80px 20% 30px 20%;" class="row " >
                    <div class="col-md-4">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('msg_nfd_ptofile_type'); ?><span class="required">*</span></label>
                            <select class=" field-select" name="type" id="type" required="">
                                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_type'); ?></option>
                                <option value="PROFESSIONAL"><?php echo $this->lang->line('msg_professionals'); ?></option>
                                <option value="INTERPRENOUR"><?php echo $this->lang->line('msg_entrepreneurs'); ?></option>
                                <!-- <option value="BUSINESS MAN">BUSINESS MAN</option> -->
                                <!-- <option value="POLITICIAN">POLITICIAN</option> -->
                                <option value="OTHERS"><?php echo $this->lang->line('msg_others'); ?></option>
                              </select>
                        </div>
                    </div>
               
                    <div class="col-md-4">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('msg_nfd_profile_cat'); ?><span class="required">*</span></label>
                            <select class=" field-select" name="category" id="category" required="">
                                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_category'); ?></option>
                            </select>
                        </div>
                    </div>
                
                    <div class="col-md-4">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('msg_nfd_profile_subcat'); ?><span class="required">*</span></label>
                            <select class=" field-select" name="subcategory" id="subcategory" required="">
                                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_subcategory'); ?></option>
                            </select>
                        </div>
                    </div>


                    

                </div>

                <div class="row">
                    <div class="col-md-12 col-centered">
                      <button style="opacity: 0.9px !important;" type="submit" class="btn btn-danger btn-lg">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $this->lang->line('msg_nfd_searchBtb'); ?></b>&nbsp;&nbsp; <i class="fa fa-search"></i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button>
                    </div>
                </div>


              </form>

              <p>..</p>

              </div>

			</section>




			<!-- <section id="section-iconbox-3" class=""><p>3</p></section>
			<section id="section-iconbox-4" class=""><p>4</p></section>
			<section id="section-iconbox-5" class=""><p>5</p></section> -->
		</div><!-- /content -->
	</div><!-- /tabs -->
</section>




<!-- =============== scripts =============== -->
<script src="<?php echo base_url('assets/js/cbpFWTabs.js');?>"></script>
		<script>
			(function() {

				[].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
					new CBPFWTabs( el );
				});

			})();
</script>