<!-- <link rel="stylesheet" type="text/css" href="<?php //echo base_url('assets/css//normalize.css');?>" /> -->
<!-- <link rel="stylesheet" type="text/css" href="<?php //echo base_url('assets/css/demo.css');?>" /> -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/tabs.css');?>" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/tabstyles.css');?>" />
<script src="<?php echo base_url('assets/js/modernizr.custom.js');?>"></script>
<!--  search inputs top -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="<?php echo base_url('assets/js/myJs/profilesch.js');?>" type="text/javascript"></script> 


<style type="text/css">
.form-style-1 {
    margin:10px auto;
    max-width: 100%;
    padding: 20px 12px 10px 20px;
    font: 13px "Lucida Sans Unicode", "Lucida Grande", sans-serif;
}
.form-style-1 li {
    padding: 0;
    display: block;
    list-style: none;
    margin: 10px 0 0 0;
}
.form-style-1 label{
    margin:0 0 3px 0;
    padding:0px;
    display:block;
    font-weight: bold;
}
.form-style-1 input[type=text], 
.form-style-1 input[type=date],
.form-style-1 input[type=datetime],
.form-style-1 input[type=number],
.form-style-1 input[type=search],
.form-style-1 input[type=time],
.form-style-1 input[type=url],
.form-style-1 input[type=email],
textarea, 
select{
	background-color: #fff;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: bordfer-box;
    border:1px solid #BEBEBE;
    padding: 7px;
    margin:0px;
    -webkit-transition: all 0.30s ease-in-out;
    -moz-transition: all 0.30s ease-in-out;
    -ms-transition: all 0.30s ease-in-out;
    -o-transition: all 0.30s ease-in-out;
    outline: none;  
}
.form-style-1 input[type=text]:focus, 
.form-style-1 input[type=date]:focus,
.form-style-1 input[type=datetime]:focus,
.form-style-1 input[type=number]:focus,
.form-style-1 input[type=search]:focus,
.form-style-1 input[type=time]:focus,
.form-style-1 input[type=url]:focus,
.form-style-1 input[type=email]:focus,
.form-style-1 textarea:focus, 
.form-style-1 select:focus{
    -moz-box-shadow: 0 0 8px #88D5E9;
    -webkit-box-shadow: 0 0 8px #88D5E9;
    box-shadow: 0 0 8px #88D5E9;
    border: 1px solid #88D5E9;
}
.form-style-1 .field-divided{
    width: 49%;
}

.form-style-1 .field-long{
    width: 100%;
}
.form-style-1 .field-select{
    width: 100%;
}
.form-style-1 .field-textarea{
    height: 100px;
}
.form-style-1 input[type=submit], .form-style-1 input[type=button]{
    background: #4B99AD;
    padding: 8px 15px 8px 15px;
    border: none;
    color: #fff;
}
.form-style-1 input[type=submit]:hover, .form-style-1 input[type=button]:hover{
    background: #4691A4;
    box-shadow:none;
    -moz-box-shadow:none;
    -webkit-box-shadow:none;
}
.form-style-1 .required{
    color:red;
}
</style>



<section>
<br>
				<div  class="tabs tabs-style-iconbox" style="background-color: #F8F8F8;">
					<nav >
						<ul>
							<li class="tab-current" ><a href="#section-iconbox-1" class="fa fa-file"><b style="font-size: 22px;"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Create New Profile</b></a></li>
							<li class=""><a href="#section-iconbox-2" class="fa fa-user"><b style="font-size: 22px;"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;My Profile</b></a></li>
							<!-- <li class=""><a href="#section-iconbox-3" class="fa fa-upload"><span>Upload</span></a></li>
							<li class=""><a href="#section-iconbox-4" class="fa fa-coffee"><span>Work</span></a></li>
							<li class=""><a href="#section-iconbox-5" class="fa fa-config"><span>Settings</span></a></li> -->
						</ul>
					</nav>
					<div class="content-wrap">
						<section id="section-iconbox-1" class="content-current" >
					
						 <form class="form-style-1" action="<?php echo base_url('Profile/managemyProfiles')?>" method="post" enctype="multipart/form-data">
                                <div class="box-body">

                                <?php foreach ($editRes->result() as $row): ?>
                                <div class="row">
                                <div class="col-md-12">
                                 <b style="color: <?php echo $color;?>;"><?php echo $msg;?></b>

                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label>Profile Name<span class="required">*</span></label>
                                            <input type="text" class="form-control  field-long" name="pname" value="<?php echo $row->profilename;?>" placeholder="Enter Profile Name"  required="">
                                        </div>
                                      </div>
                                </div>
                               
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Profile Type<span class="required">*</span></label>
                                        <select class=" field-select" name="type" id="type" required="">
                                            <option value="<?php echo $row->type;?>"><?php echo $row->type;?></option>
                                            <option value="PROFESSIONAL">PROFESSIONAL</option>
                                            <option value="INTERPRENOUR">INTERPRENOUR</option>
                                            <option value="BUSINESS MAN">BUSINESS MAN</option>
                                            <option value="POLITICIAN">POLITICIAN</option>
                                            <option value="OTHERS">OTHERS</option>
                                        </select>
                                     </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Profile Category<span class="required">*</span></label>
                                        <select class="field-select" name="cat" id="category" required="">
                                            <option value="<?php echo $row->category;?>"><?php echo $row->category;?></option>
                                        </select>
                                     </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Profile Sub-Category<span class="required">*</span></label>
                                        <select class="form-control" name="subcat" id="subcategory" required="">
                                            <option value="<?php echo $row->subcategory;?>"><?php echo $row->subcategory;?></option>
                                        </select>
                                     </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label>Phone Number<span class="required">*</span></label>
                                            <input type="number"  class="field-long" name="phone" value="<?php echo $row->phone;?>" placeholder="Enter Phone Number"   required="">
                                        </div>
                                      </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label>Alt-Phone Number</label>
                                            <input type="number"  class="field-long" name="altphone" value="<?php echo $row->altphone;?>" placeholder="Enter Altenutive Phone Number"   >
                                        </div>
                                      </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-group field-select">
                                            <label>E-mail Address</label>
                                            <input type="email"  class="field-long" name="email" value="<?php echo $row->email;?>" placeholder="Enter E-mail Address"   required="">
                                        </div>
                                      </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label>Physical Address</label>
                                            <input type="text"  class="field-long" name="phyaddress" value="<?php echo $row->phyaddress;?>" placeholder="Enter Physical Address"   required="">
                                        </div>
                                      </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label>Profile Image</label>
                                            <input type="file"  class="form-control" name="img" accept=".gif, .jpg, .png" value="" placeholder="Select Image File"   required="">
                                        </div>
                                      </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label>Profile Description</label>
                                            <textarea name="desc" rows="5" class="field-long field-textarea"> <?php echo $row->availabletime;?></textarea>
                                        </div>
                                      </div>
                                </div>
                              
                                 <div class="col-md-12">
                                 <br>
                                 <b style="color: <?php echo $color;?>;"><?php echo $msg;?></b>
                                </div>
                                 </div>  

                                  <button type="submit" name="modifyBtn" value="<?php echo $row->id;?>" class="btn btn-info btn-lg pull-right">&nbsp;&nbsp;&nbsp;&nbsp;MODIFY &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button>
                                  <hr>
                                <?php endforeach; ?>
                                </div><!-- /.box-body -->
                               </form>  

						</section>





						<!-- <section id="section-iconbox-2" class="">
						<p>No Data !</p>
						<p>...</p>
						</section> -->


                        <section id="section-iconbox-2" class="">
                        
                            <!-- <div class="box box-info  " style="margin-top: 15px;"> -->
                                              <!--   <div class="box-header">
                                                    <h3 class="box-title"><b>Manage My Profiles</b></h3>
                                                </div> --><!-- /.box-header -->
                                                <div class="box-body padding" style="overflow-x:scroll; white-space: nowrap;">
                                                <form action="<?php echo base_url('Profile/managemyProfiles')?>" method="post">
                                                    <table class="table table-striped" >
                                                        <tbody><tr>
                                                            <th style="width: 10px">#</th>
                                                            <th>PROFILE NAME</th>
                                                            <th>TYPE</th>
                                                            <th>CATEGORY</th>
                                                            <th>SUB-CATEGORY</th> 
                                                            <th>PROFILE OWNER</th>
                                                            <th>TOOLS</th>
                                                            <th>LAST MODIFIED</th>
                                                        </tr>
                                                        <?php $index = 1;?>
                                                         <?php foreach ($profileRes->result() as $row): ?>
                                                            
                                                                <tr>
                                                                    <td><?php echo $index;?></td>
                                                                    <td><?php echo $row->profilename;?> </td>
                                                                    <td><?php echo $row->type;?> </td>
                                                                    <td><?php echo $row->category;?> </td>
                                                                    <td><?php echo $row->subcategory;?> </td>
                                                                    <td><?php echo modules::load('Users')->get_where_custom('id', $row->userid)->row()->name;?> </td>
                                                                    <td>
                                                                        <button type="submit" class="btn btn-default btn-xs " name="editBtn" value="<?php echo $row->id;?>" data-toggle="tooltip"  title="" data-original-title="Edit This Profile"><i class="fa fa-edit"></i></button>
                                                                        <button type="submit" class="btn btn-danger btn-xs " name="deleteBtn" value="<?php echo $row->id;?>" data-toggle="tooltip"  title="" data-original-title="Delete This Profile"><i class="fa fa-times"></i></button>
                                                                        <!-- <button type="submit" class="btn btn-success btn-xs"  name="newBtn" value="<?php echo $row->id;?>" data-toggle="tooltip" title="" data-original-title="Mark as NEW"><i class="fa fa-file"></i></button> 
                                                                        <button type="submit" class="btn btn-warning btn-xs"  name="oldBtn" value="<?php echo $row->id;?>" data-toggle="tooltip" title="" data-original-title="Mark as OLD"><i class="fa fa-file"></i></button> -->
                                                                    </td>
                                                                    <td><?php echo $row->udate;?> </td>
                                                                    <!-- <td><span class="label label-success">Online</span></td> -->
                                                                </tr>
                                                           
                                                        <?php $index ++;?>
                                                        <?php endforeach; ?>
                                                         
                                                    </tbody></table>
                                                    </form>
                                                    <br><br><br>
                                                </div><!-- /.box-body -->
                                            <!-- </div> -->


                        
                        </section>










						<!-- <section id="section-iconbox-3" class=""><p>3</p></section>
						<section id="section-iconbox-4" class=""><p>4</p></section>
						<section id="section-iconbox-5" class=""><p>5</p></section> -->
					</div><!-- /content -->
				</div><!-- /tabs -->
			</section>




<!-- =============== scripts =============== -->
<script src="<?php echo base_url('assets/js/cbpFWTabs.js');?>"></script>
		<script>
			(function() {

				[].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
					new CBPFWTabs( el );
				});

			})();
</script>