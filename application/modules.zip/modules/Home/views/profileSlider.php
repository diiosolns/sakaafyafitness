<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/tabs.css');?>" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/tabstyles.css');?>" />
<script src="<?php echo base_url('assets/js/modernizr.custom.js');?>"></script>
<!--  search inputs top -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="<?php echo base_url('assets/js/myJs/profilesch.js');?>" type="text/javascript"></script> 


<?php 
  $popularres = modules::load('Profile')->get('id');
  $newres = modules::load('Profile')->get('id');
?>

<!-- =================  SLIDING PROFILES ==================== -->

<section class="fullwidth wow animated fadeInUp" style="padding-top: 20px;">
  <div  class="tabs tabs-style-iconbox " style="background-color: #F8F8F8;" >
    <nav >
      <ul style="background-color1: #00C0EF; color: #fff;">
        <li class="tab-current" ><a href="#section-iconbox-3" class="fa fa-users"><b style="font-size: 32px; font-family: Arial,Helvetica Neue,Helvetica,sans-serif; "> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $this->lang->line('msg_popular_profiles'); ?></b></a></li>
        <li class=""><a href="#section-iconbox-4" class="fa fa-users"><b style="font-size: 32px; font-family: Arial,Helvetica Neue,Helvetica,sans-serif; "> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $this->lang->line('msg_new_profiles'); ?></b></a></li>
      </ul>
    </nav>

    <div class="content-wrap " >
      <section id="section-iconbox-3" class="content-current" >
        

        <div class="row">
         <div class="col-md-12">
            <div class="carousel carousel-showmanymoveone slide" id="carousel-tilenav" data-interval="false">
               <div class="carousel-inner">

                  <div class="item active">

                  <?php $index = 0;?>
                    <?php foreach ($popularres->result() as $row): ?>
                      <?php if (!($index > 19)) { ?>

                      <?php $profileUrl = 'Profile/viewProfiles/'.$row->id.'/'.$row->type.'/'.$row->category.'/'.$row->subcategory; ?>
                     <div class="col-xs-12 col-sm-6 col-md-3">
                     <div class="card hovercard " style="background-color: lightgray;" >
                      <div class="cardheader">
                        <!-- <h4>MY PROFILE TITLE</h4> -->
                       </div>
                         <div class="avatar">
                            <a  href="<?php echo base_url($profileUrl);?>" data-toggle="modal" data-target="#modal-profile">
                              <?php $imgUrl = 'assets/img/profile/0/'.$row->img;?>
                               <img alt="" src="<?php echo base_url($imgUrl)?>">
                            </a>
                           </div>
                         <div class="info">
                             <div class="title">
                                  <!-- <a target="_blank" href="<?php //echo base_url('#')?>"><?php echo $row->profilename?></a> -->
                                  <a target="_blank" href="<?php echo base_url($profileUrl);?>"><?php echo modules::load('Users')->get_where_custom('id', $row->userid)->row()->name;?></a>
                              </div>
                              <!-- <div style="padding: 20px 20px 20px 20px;">
                                <button type="button" class="btn btn-sm  btn-success btn-outline pull-left1">Chat <i class="fa fa-comment"></i></button>
                                <button type="button" class="btn btn-sm  btn-danger btn-outline pull-right1">Comment</button>
                              </div> -->
                              <div class="desc"><?php echo $row->type?></div>
                              <div class="desc"><?php echo $row->category?></div>
                              <div class="desc"><?php echo $row->subcategory?></div>
                              <div class="desc">(<?php echo $row->phone?> | <?php echo $row->altphone?>)</div>
                            </div>
                            <div class="bottom">
                                 <a class="btn btnrnd btn-primary btn-twitter btn-sm" target="_blamk" href="https://twitter.com/signup?lang=en">
                                     <i class="fa fa-twitter"></i>
                                    </a>
                                    <a class="btn btnrnd btn-danger btn-sm" rel="publisher" target="_blamk" href="https://plus.google.com/discover">
                                        <i class="fa fa-google-plus"></i>
                                    </a>
                                    <a class="btn btnrnd btn-primary btn-sm" rel="publisher" target="_blamk" href="https://www.facebook.com/">
                                      <i class="fa fa-facebook"></i>
                                    </a>
                                   <a class="btn btnrnd btn-warning btn-sm" rel="publisher" target="_blamk" href="<?php echo base_url($profileUrl);?>">
                                      <i class="fa fa-behance">H</i>
                                   </a>
                              </div>
                              <div>
                                <hr>
                              </div>
                       </div>
                     </div>

                    <?php 
                        if (($index == 3) | ($index == 7 )| ($index == 11 )| ($index == 15 )) {
                          # code...
                          echo '</div><div class="item">';
                        }
                     ?>

                     <?php } ?>
                     <?php  $index ++ ; ?>
                     <?php endforeach; ?>


                  </div>
                <!-- ============= all items ends here =========   -->
      

             </div> <!-- ============= end colourcel inner ============ -->

            </div >
             <div style="margin: 0 0 0 0 ;"> 
                  <a rel="nofollow" rel="noreferrer" class="left carousel-control" href="#carousel-tilenav" data-slide="prev"><i class="glyphicon glyphicon-chevron-left"></i></a>
                   <a rel="nofollow" rel="noreferrer" class="right carousel-control" href="#carousel-tilenav" data-slide="next"><i class="glyphicon glyphicon-chevron-right"></i></a>
              </div>
             </div>
          </div>

        </section>



      <section id="section-iconbox-4" class="">
        

        <div class="row">
         <div class="col-md-12">
            <div class="carousel carousel-showmanymoveone slide" id="carousel-tilenav2" data-interval="false">
               <div class="carousel-inner">

                  <div class="item active">

                  <?php $index = 0;?>
                    <?php foreach ($newres->result() as $row): ?>
                      <?php if (!($index > 19)) { ?>

                      <?php $profileUrl = 'Profile/viewProfiles/'.$row->id.'/'.$row->type.'/'.$row->category.'/'.$row->subcategory; ?>
                      
                     <div class="col-xs-12 col-sm-6 col-md-3">
                     <div class="card hovercard " style="background-color: lightgray;" >
                      <div style="padding-right: 20px;" class="cardheader">
                        <!-- <h4>MY PROFILE TITLE</h4> -->
                        <br>
                        <span s class="label label-success pull-right" >NEW</span>
                       </div>
                         <div class="avatar">
                            <a  href="<?php echo base_url($profileUrl);?>" data-toggle="modal" data-target="#modal-profile">
                              <?php $imgUrl = 'assets/img/profile/0/'.$row->img;?>
                               <img alt="" src="<?php echo base_url($imgUrl)?>">
                            </a>
                           </div>
                         <div class="info">
                             <div class="title">
                                  <!-- <a target="_blank" href="<?php //echo base_url('#')?>"><?php echo $row->profilename?></a> -->
                                  <a target="_blank" href="<?php echo base_url($profileUrl);?>"><?php echo modules::load('Users')->get_where_custom('id', $row->userid)->row()->name;?></a>
                              </div>
                              <!-- <div style="padding: 20px 20px 20px 20px;">
                                <button type="button" class="btn btn-sm  btn-success btn-outline pull-left1">Chat <i class="fa fa-comment"></i></button>
                                <button type="button" class="btn btn-sm  btn-danger btn-outline pull-right1">Comment</button>
                              </div> -->
                              <div class="desc"><?php echo $row->type?></div>
                              <div class="desc"><?php echo $row->category?></div>
                              <div class="desc"><?php echo $row->subcategory?></div>
                              <div class="desc">(<?php echo $row->phone?> | <?php echo $row->altphone?>)</div>
                            </div>
                            <div class="bottom">
                                 <a class="btn btnrnd btn-primary btn-twitter btn-sm" href="https://twitter.com/webmaniac">
                                     <i class="fa fa-twitter"></i>
                                    </a>
                                    <a class="btn btnrnd btn-danger btn-sm" rel="publisher" href="https://plus.google.com/+ahmshahnuralam">
                                        <i class="fa fa-google-plus"></i>
                                    </a>
                                    <a class="btn btnrnd btn-primary btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                      <i class="fa fa-facebook"></i>
                                    </a>
                                   <a class="btn btnrnd btn-warning btn-sm" rel="publisher" href="<?php echo base_url($profileUrl);?>">
                                      <i class="fa fa-behance">H</i>
                                   </a>
                              </div>
                              <div>
                                <hr>
                              </div>
                       </div>
                     </div>

                    <?php 
                        if (($index == 3) | ($index == 7 )| ($index == 11 )| ($index == 15 )) {
                          # code...
                          echo '</div><div class="item">';
                        }
                     ?>

                     <?php } ?>
                     <?php  $index ++ ; ?>
                     <?php endforeach; ?>


                  </div>
                <!-- ============= all items ends here =========   -->
      

             </div> <!-- ============= end colourcel inner ============ -->

            </div >
             <div style="margin: 0 0 0 0 ;"> 
                  <a rel="nofollow" rel="noreferrer" class="left carousel-control" href="#carousel-tilenav2" data-slide="prev"><i class="glyphicon glyphicon-chevron-left"></i></a>
                   <a rel="nofollow" rel="noreferrer" class="right carousel-control" href="#carousel-tilenav2" data-slide="next"><i class="glyphicon glyphicon-chevron-right"></i></a>
              </div>
             </div>
          </div>


      </section>

    </div><!-- /content -->
  </div><!-- /tabs -->


</section>



<!-- =============== scripts =============== -->
<script src="<?php echo base_url('assets/js/cbpFWTabs.js');?>"></script>
    <script>
      (function() {

        [].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
          new CBPFWTabs( el );
        });

      })();
</script>























<!-- 
<div class="container">
  <hr>
  <div class="col-md-12" style="text-align: center;">
    <h1>Popular Profiles/ New Profiles</h1>
  </div>
    
   

<div class="row">
   <div class="col-md-12">
      <div class="carousel carousel-showmanymoveone slide" id="carousel-tilenav" data-interval="false">
         <div class="carousel-inner">

            <div class="item active">
               <div class="col-xs-12 col-sm-6 col-md-3">
               <div class="card hovercard " style="background-color: lightgray;" >
                <div class="cardheader">
                  <h4>MY PROFILE TITLE</h4>
                 </div>
                   <div class="avatar">
                      <a href="" data-toggle="modal" data-target="#modal-profile">
                         <img alt="" src="<?php echo base_url('assets/img/profile/def.PNG')?>">
                      </a>
                     </div>
                   <div class="info">
                       <div class="title">
                            <a target="_blank" href="http://scripteden.com/">My Name</a>
                        </div>
                        <div style="padding: 20px 20px 20px 20px;">
                        <button type="button" class="btn btn-sm  btn-success btn-outline pull-left1">Chat <i class="fa fa-comment"></i></button>
                        <button type="button" class="btn btn-sm  btn-danger btn-outline pull-right1">Comment</button>
                      </div>
                      <div class="desc">Passionate designer</div>
                      <div class="desc">Curious developer</div>
                      <div class="desc">Tech geek</div>
                    </div>

                    <div class="bottom">
                           <a class="btn btnrnd btn-primary btn-twitter btn-sm" href="https://twitter.com/webmaniac">
                               <i class="fa fa-twitter"></i>
                              </a>
                              <a class="btn btnrnd btn-danger btn-sm" rel="publisher" href="https://plus.google.com/+ahmshahnuralam">
                                  <i class="fa fa-google-plus"></i>
                              </a>
                              <a class="btn btnrnd btn-primary btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-facebook"></i>
                              </a>
                             <a class="btn btnrnd btn-warning btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-behance"></i>
                             </a>
                    </div>

                    <div>
                      <hr>
                    </div>
             </div>

               </div>

                 <div class="col-xs-12 col-sm-6 col-md-3">
                  <div class="card hovercard " style="background-color: lightgray;" >
                      <div class="cardheader">
                        <h4>MY PROFILE TITLE</h4>
                       </div>
                     <div class="avatar">
                        <a href="" data-toggle="modal" data-target="#modal-profile">
                           <img alt="" src="<?php echo base_url('assets/img/profile/def.PNG')?>">
                        </a>
                       </div>
                     <div class="info">
                         <div class="title">
                              <a target="_blank" href="http://scripteden.com/">My Name</a>
                          </div>
                          <div style="padding: 20px 20px 20px 20px;">
                          <button type="button" class="btn btn-sm  btn-success btn-outline pull-left1">Chat <i class="fa fa-comment"></i></button>
                          <button type="button" class="btn btn-sm  btn-danger btn-outline pull-right1">Comment</button>
                        </div>
                        <div class="desc">Passionate designer</div>
                        <div class="desc">Curious developer</div>
                        <div class="desc">Tech geek</div>
                      </div>

                      <div class="bottom">
                             <a class="btn btnrnd btn-primary btn-twitter btn-sm" href="https://twitter.com/webmaniac">
                                 <i class="fa fa-twitter"></i>
                                </a>
                                <a class="btn btnrnd btn-danger btn-sm" rel="publisher" href="https://plus.google.com/+ahmshahnuralam">
                                    <i class="fa fa-google-plus"></i>
                                </a>
                                <a class="btn btnrnd btn-primary btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                  <i class="fa fa-facebook"></i>
                                </a>
                               <a class="btn btnrnd btn-warning btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                  <i class="fa fa-behance"></i>
                               </a>
                      </div>

                      <div>
                        <hr>
                      </div>
               </div>
               </div>

                 <div class="col-xs-12 col-sm-6 col-md-3">
                  <div class="card hovercard">
                    <div class="cardheader">
                     </div>
                   <div class="avatar">
                       <img alt="" src="<?php echo base_url('assets/img/profile/def.PNG')?>">
                     </div>
                   <div class="info">
                       <div class="title">
                            <a target="_blank" href="http://scripteden.com/">Script Eden</a>
                        </div>
                     <div class="desc">Passionate designer</div>
                         <div class="desc">Curious developer</div>
                             <div class="desc">Tech geek</div>
                           </div>
                         <div class="bottom">
                           <a class="btn btn-primary btn-twitter btn-sm" href="https://twitter.com/webmaniac">
                               <i class="fa fa-twitter"></i>
                              </a>
                              <a class="btn btn-danger btn-sm" rel="publisher" href="https://plus.google.com/+ahmshahnuralam">
                                  <i class="fa fa-google-plus"></i>
                              </a>
                              <a class="btn btn-primary btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-facebook"></i>
                              </a>
                             <a class="btn btn-warning btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-behance"></i>
                             </a>
                  </div>
                </div>
               </div>


                 <div class="col-xs-12 col-sm-6 col-md-3">
                  <div class="card hovercard">
                    <div class="cardheader">
                     </div>
                   <div class="avatar">
                       <img alt="" src="<?php echo base_url('assets/img/profile/def.PNG')?>">
                     </div>
                   <div class="info">
                       <div class="title">
                            <a target="_blank" href="http://scripteden.com/">Script Eden</a>
                        </div>
                     <div class="desc">Passionate designer</div>
                         <div class="desc">Curious developer</div>
                             <div class="desc">Tech geek</div>
                           </div>
                         <div class="bottom">
                           <a class="btn btn-primary btn-twitter btn-sm" href="https://twitter.com/webmaniac">
                               <i class="fa fa-twitter"></i>
                              </a>
                              <a class="btn btn-danger btn-sm" rel="publisher" href="https://plus.google.com/+ahmshahnuralam">
                                  <i class="fa fa-google-plus"></i>
                              </a>
                              <a class="btn btn-primary btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-facebook"></i>
                              </a>
                             <a class="btn btn-warning btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-behance"></i>
                             </a>
                  </div>
                </div>
               </div>

            </div>



            <div class="item">
                <div class="col-xs-12 col-sm-6 col-md-3">
                   <div class="card hovercard">
                <div class="cardheader">
                 </div>
               <div class="avatar">
                   <img alt="" src="<?php echo base_url('assets/img/profile/def.PNG')?>">
                 </div>
               <div class="info">
                   <div class="title">
                        <a target="_blank" href="http://scripteden.com/">Script Eden</a>
                    </div>
                 <div class="desc">Passionate designer</div>
                     <div class="desc">Curious developer</div>
                         <div class="desc">Tech geek</div>
                       </div>
                     <div class="bottom">
                       <a class="btn btn-primary btn-twitter btn-sm" href="https://twitter.com/webmaniac">
                           <i class="fa fa-twitter"></i>
                          </a>
                          <a class="btn btn-danger btn-sm" rel="publisher" href="https://plus.google.com/+ahmshahnuralam">
                              <i class="fa fa-google-plus"></i>
                          </a>
                          <a class="btn btn-primary btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                            <i class="fa fa-facebook"></i>
                          </a>
                         <a class="btn btn-warning btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                            <i class="fa fa-behance"></i>
                         </a>
                     </div>
                    </div>
               </div>

                 <div class="col-xs-12 col-sm-6 col-md-3">
                  <div class="card hovercard">
                    <div class="cardheader">
                     </div>
                   <div class="avatar">
                       <img alt="" src="<?php echo base_url('assets/img/profile/def.PNG')?>">
                     </div>
                   <div class="info">
                       <div class="title">
                            <a target="_blank" href="http://scripteden.com/">Script Eden</a>
                        </div>
                     <div class="desc">Passionate designer</div>
                         <div class="desc">Curious developer</div>
                             <div class="desc">Tech geek</div>
                           </div>
                         <div class="bottom">
                           <a class="btn btn-primary btn-twitter btn-sm" href="https://twitter.com/webmaniac">
                               <i class="fa fa-twitter"></i>
                              </a>
                              <a class="btn btn-danger btn-sm" rel="publisher" href="https://plus.google.com/+ahmshahnuralam">
                                  <i class="fa fa-google-plus"></i>
                              </a>
                              <a class="btn btn-primary btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-facebook"></i>
                              </a>
                             <a class="btn btn-warning btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-behance"></i>
                             </a>
                  </div>
                </div>
               </div>

                 <div class="col-xs-12 col-sm-6 col-md-3">
                  <div class="card hovercard">
                    <div class="cardheader">
                     </div>
                   <div class="avatar">
                       <img alt="" src="<?php echo base_url('assets/img/profile/def.PNG')?>">
                     </div>
                   <div class="info">
                       <div class="title">
                            <a target="_blank" href="http://scripteden.com/">Script Eden</a>
                        </div>
                     <div class="desc">Passionate designer</div>
                         <div class="desc">Curious developer</div>
                             <div class="desc">Tech geek</div>
                           </div>
                         <div class="bottom">
                           <a class="btn btn-primary btn-twitter btn-sm" href="https://twitter.com/webmaniac">
                               <i class="fa fa-twitter"></i>
                              </a>
                              <a class="btn btn-danger btn-sm" rel="publisher" href="https://plus.google.com/+ahmshahnuralam">
                                  <i class="fa fa-google-plus"></i>
                              </a>
                              <a class="btn btn-primary btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-facebook"></i>
                              </a>
                             <a class="btn btn-warning btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-behance"></i>
                             </a>
                  </div>
                </div>
               </div>


                 <div class="col-xs-12 col-sm-6 col-md-3">
                  <div class="card hovercard">
                    <div class="cardheader">
                     </div>
                   <div class="avatar">
                       <img alt="" src="<?php echo base_url('assets/img/profile/def.PNG')?>">
                     </div>
                   <div class="info">
                       <div class="title">
                            <a target="_blank" href="http://scripteden.com/">Script Eden</a>
                        </div>
                     <div class="desc">Passionate designer</div>
                         <div class="desc">Curious developer</div>
                             <div class="desc">Tech geek</div>
                           </div>
                         <div class="bottom">
                           <a class="btn btn-primary btn-twitter btn-sm" href="https://twitter.com/webmaniac">
                               <i class="fa fa-twitter"></i>
                              </a>
                              <a class="btn btn-danger btn-sm" rel="publisher" href="https://plus.google.com/+ahmshahnuralam">
                                  <i class="fa fa-google-plus"></i>
                              </a>
                              <a class="btn btn-primary btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-facebook"></i>
                              </a>
                             <a class="btn btn-warning btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-behance"></i>
                             </a>
                  </div>
                </div>
               </div>

            </div>




            <div class="item">
               <div class="col-xs-12 col-sm-6 col-md-3">
                   <div class="card hovercard">
                <div class="cardheader">
                 </div>
               <div class="avatar">
                   <img alt="" src="<?php echo base_url('assets/img/profile/def.PNG')?>">
                 </div>
               <div class="info">
                   <div class="title">
                        <a target="_blank" href="http://scripteden.com/">Script Eden</a>
                    </div>
                 <div class="desc">Passionate designer</div>
                     <div class="desc">Curious developer</div>
                         <div class="desc">Tech geek</div>
                       </div>
                     <div class="bottom">
                       <a class="btn btn-primary btn-twitter btn-sm" href="https://twitter.com/webmaniac">
                           <i class="fa fa-twitter"></i>
                          </a>
                          <a class="btn btn-danger btn-sm" rel="publisher" href="https://plus.google.com/+ahmshahnuralam">
                              <i class="fa fa-google-plus"></i>
                          </a>
                          <a class="btn btn-primary btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                            <i class="fa fa-facebook"></i>
                          </a>
                         <a class="btn btn-warning btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                            <i class="fa fa-behance"></i>
                         </a>
                     </div>
                    </div>
               </div>

                 <div class="col-xs-12 col-sm-6 col-md-3">
                  <div class="card hovercard">
                    <div class="cardheader">
                     </div>
                   <div class="avatar">
                       <img alt="" src="<?php echo base_url('assets/img/profile/def.PNG')?>">
                     </div>
                   <div class="info">
                       <div class="title">
                            <a target="_blank" href="http://scripteden.com/">Script Eden</a>
                        </div>
                     <div class="desc">Passionate designer</div>
                         <div class="desc">Curious developer</div>
                             <div class="desc">Tech geek</div>
                           </div>
                         <div class="bottom">
                           <a class="btn btn-primary btn-twitter btn-sm" href="https://twitter.com/webmaniac">
                               <i class="fa fa-twitter"></i>
                              </a>
                              <a class="btn btn-danger btn-sm" rel="publisher" href="https://plus.google.com/+ahmshahnuralam">
                                  <i class="fa fa-google-plus"></i>
                              </a>
                              <a class="btn btn-primary btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-facebook"></i>
                              </a>
                             <a class="btn btn-warning btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-behance"></i>
                             </a>
                  </div>
                </div>
               </div>

                 <div class="col-xs-12 col-sm-6 col-md-3">
                  <div class="card hovercard">
                    <div class="cardheader">
                     </div>
                   <div class="avatar">
                       <img alt="" src="<?php echo base_url('assets/img/profile/def.PNG')?>">
                     </div>
                   <div class="info">
                       <div class="title">
                            <a target="_blank" href="http://scripteden.com/">Script Eden</a>
                        </div>
                     <div class="desc">Passionate designer</div>
                         <div class="desc">Curious developer</div>
                             <div class="desc">Tech geek</div>
                           </div>
                         <div class="bottom">
                           <a class="btn btn-primary btn-twitter btn-sm" href="https://twitter.com/webmaniac">
                               <i class="fa fa-twitter"></i>
                              </a>
                              <a class="btn btn-danger btn-sm" rel="publisher" href="https://plus.google.com/+ahmshahnuralam">
                                  <i class="fa fa-google-plus"></i>
                              </a>
                              <a class="btn btn-primary btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-facebook"></i>
                              </a>
                             <a class="btn btn-warning btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-behance"></i>
                             </a>
                  </div>
                </div>
               </div>


                 <div class="col-xs-12 col-sm-6 col-md-3">
                  <div class="card hovercard">
                    <div class="cardheader">
                     </div>
                   <div class="avatar">
                       <img alt="" src="<?php echo base_url('assets/img/profile/def.PNG')?>">
                     </div>
                   <div class="info">
                       <div class="title">
                            <a target="_blank" href="http://scripteden.com/">Script Eden</a>
                        </div>
                     <div class="desc">Passionate designer</div>
                         <div class="desc">Curious developer</div>
                             <div class="desc">Tech geek</div>
                           </div>
                         <div class="bottom">
                           <a class="btn btn-primary btn-twitter btn-sm" href="https://twitter.com/webmaniac">
                               <i class="fa fa-twitter"></i>
                              </a>
                              <a class="btn btn-danger btn-sm" rel="publisher" href="https://plus.google.com/+ahmshahnuralam">
                                  <i class="fa fa-google-plus"></i>
                              </a>
                              <a class="btn btn-primary btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-facebook"></i>
                              </a>
                             <a class="btn btn-warning btn-sm" rel="publisher" href="https://plus.google.com/shahnuralam">
                                <i class="fa fa-behance"></i>
                             </a>
                  </div>
                </div>
               </div>

            </div>




            <div class="item">
               <div class="col-xs-12 col-sm-6 col-md-2">
                  <a rel="nofollow" rel="noreferrer"href="#"><img src="http://placehold.it/500/002040/eeeeee&text=4" class="img-responsive"></a>
                   <b>PANEL 4</b>
               </div>
            </div>
            <div class="item">
               <div class="col-xs-12 col-sm-6 col-md-2">
                  <a rel="nofollow" rel="noreferrer"href="#"><img src="http://placehold.it/500/0054A6/fff/&text=5" class="img-responsive"></a>
               </div>
            </div>
            <div class="item">
               <div class="col-xs-12 col-sm-6 col-md-2">
                  <a rel="nofollow" rel="noreferrer"href="#"><img src="http://placehold.it/500/002d5a/fff/&text=6" class="img-responsive"></a>
               </div>
            </div>
            <div class="item">
               <div class="col-xs-12 col-sm-6 col-md-2">
                  <a rel="nofollow" rel="noreferrer"href="#"><img src="http://placehold.it/500/eeeeee&text=7" class="img-responsive"></a>
               </div>
            </div>
            <div class="item">
               <div class="col-xs-12 col-sm-6 col-md-2">
                  <a rel="nofollow" rel="noreferrer"href="#"><img src="http://placehold.it/500/40a1ff/002040&text=8" class="img-responsive"></a>
               </div>
            </div>
         </div>

  </div >
   <div style="margin: 0 0 0 0 ;"> 
        <a rel="nofollow" rel="noreferrer" class="left carousel-control" href="#carousel-tilenav" data-slide="prev"><i class="glyphicon glyphicon-chevron-left"></i></a>
         <a rel="nofollow" rel="noreferrer" class="right carousel-control" href="#carousel-tilenav" data-slide="next"><i class="glyphicon glyphicon-chevron-right"></i></a>
    </div>
   </div>
</div>


  <br>
</div> -->
<!-- ====================== END SLIDING PROFILES ================= -->

















