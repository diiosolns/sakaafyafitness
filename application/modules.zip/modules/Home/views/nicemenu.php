
<!DOCTYPE html><html class=''>
<head><script src='//production-assets.codepen.io/assets/editor/live/console_runner-079c09a0e3b9ff743e39ee2d5637b9216b3545af0de366d4b9aad9dc87e26bfd.js'></script><script src='//production-assets.codepen.io/assets/editor/live/events_runner-73716630c22bbc8cff4bd0f07b135f00a0bdc5d14629260c3ec49e5606f98fdd.js'></script><script src='//production-assets.codepen.io/assets/editor/live/css_live_reload_init-2c0dc5167d60a5af3ee189d570b1835129687ea2a61bee3513dee3a50c115a77.js'></script><meta charset='UTF-8'><meta name="robots" content="noindex"><link rel="shortcut icon" type="image/x-icon" href="//production-assets.codepen.io/assets/favicon/favicon-8ea04875e70c4b0bb41da869e81236e54394d63638a1ef12fa558a4a835f1164.ico" /><link rel="mask-icon" type="" href="//production-assets.codepen.io/assets/favicon/logo-pin-f2d2b6d2c61838f7e76325261b7195c27224080bc099486ddd6dccb469b8e8e6.svg" color="#111" /><link rel="canonical" href="https://codepen.io/gabouh/pen/jGGNWd?depth=everything&limit=all&order=popularity&page=7&q=code+editor&show_forks=false" />


<style class="cp-pen-styles">@font-face{font-family:fontello;src:url(../fonts/fontello.eot?74298558);src:url(../fonts/fontello.eot?74298558#iefix) format('embedded-opentype'),url(../fonts/fontello.woff?74298558) format('woff'),url(../fonts/fontello.ttf?74298558) format('truetype'),url(../fonts/fontello.svg?74298558#fontello) format('svg');font-weight:400;font-style:normal}[class*=" icon-"]:before,[class^=icon-]:before{font-family:fontello;font-style:normal;font-weight:400;speak:none;display:inline-block;text-decoration:inherit;width:1em;margin-right:.2em;text-align:center;font-variant:normal;text-transform:none;line-height:1em;margin-left:.2em;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.icon-header:before{content:'\e800'}.icon-tag:before{content:'\e801'}.icon-link-outline:before{content:'\e802'}.icon-paragraph:before{content:'\e803'}.icon-info-circled:before{content:'\e804'}.icon-menu-outline:before{content:'\e805'}.icon-quote:before{content:'\e806'}.icon-th-list:before{content:'\e807'}.icon-table:before{content:'\e808'}.icon-down-open:before{content:'\e809'}.icon-squares:before{content:'\e80a'}.icon-minus-outline:before{content:'\e80b'}.icon-blank:before{content:'\e80c'}.icon-divide-outline:before{content:'\e80d'}.icon-pencil:before{content:'\e80e'}.icon-puzzle-outline:before{content:'\e80f'}.icon-docs:before{content:'\e810'}.icon-eye:before{content:'\e811'}.icon-picture:before{content:'\e812'}.icon-export:before{content:'\e813'}.icon-cog-outline:before{content:'\e814'}.icon-docs-1:before{content:'\e815'}.icon-publish:before{content:'\e816'}.icon-trash:before{content:'\e817'}.icon-doc-add:before{content:'\e818'}.icon-floppy-1:before{content:'\e819'}.icon-left-open:before{content:'\e81a'}.icon-down-open-1:before{content:'\e81b'}.icon-spin6:before{content:'\e81c'}.icon-laptop:before{content:'\e81d'}.icon-desktop:before{content:'\e81e'}.icon-tablet-1:before{content:'\e81f'}.icon-mobile:before{content:'\e820'}.icon-forward:before{content:'\e821'}.icon-reply:before{content:'\e822'}.icon-code:before{content:'\e823'}.icon-bucket:before{content:'\e824'}.icon-gauge:before{content:'\e825'}.icon-picture-outline:before{content:'\e826'}.icon-grid:before{content:'\e827'}.icon-video:before{content:'\e828'}.icon-medium:before{content:'\e829'}.icon-progress-0:before{content:'\e82a'}.icon-progress-2:before{content:'\e82b'}.icon-th-list-1:before{content:'\e82c'}.icon-window:before{content:'\e82d'}.icon-user:before{content:'\e82e'}.icon-dollar:before{content:'\e82f'}.icon-menu:before{content:'\e830'}.icon-google:before{content:'\e831'}.icon-check:before{content:'\e832'}.icon-arrow-combo:before{content:'\e833'}.icon-doc-text-inv:before{content:'\e834'}.icon-doc-landscape:before{content:'\e835'}.icon-newspaper:before{content:'\e836'}.icon-popup:before{content:'\e837'}.icon-lifebuoy:before{content:'\e838'}.icon-tools:before{content:'\e839'}.icon-newspaper-1:before{content:'\e83a'}.icon-columns:before{content:'\e83b'}.icon-progress-3:before{content:'\e83c'}.icon-angle-right:before{content:'\e83d'}.icon-cancel:before{content:'\e83e'}.icon-ok-outline:before{content:'\e83f'}.icon-color-adjust:before{content:'\e840'}.icon-pipette:before{content:'\e841'}.icon-align-left:before{content:'\e842'}.icon-align-center:before{content:'\e843'}.icon-align-right:before{content:'\e844'}.icon-scissors:before{content:'\e845'}.icon-bullseye:before{content:'\e846'}.icon-paste:before{content:'\e847'}.icon-database:before{content:'\e848'}.icon-up-open:before{content:'\e849'}.icon-down-open-2:before{content:'\e84a'}.icon-ccw:before{content:'\e84b'}.icon-cw:before{content:'\e84c'}.icon-resize-horizontal:before{content:'\e84d'}.icon-lock:before{content:'\e84e'}.icon-lock-open:before{content:'\e84f'}.icon-emo-thumbsup:before{content:'\e850'}.icon-resize-full-alt:before{content:'\e851'}.icon-plus-outline:before{content:'\e852'}.icon-cancel-circled:before{content:'\e853'}.icon-upload:before{content:'\e854'}.icon-folder-open:before{content:'\e855'}.icon-angle-double-right:before{content:'\e856'}.icon-download:before{content:'\e857'}.icon-brush-1:before{content:'\e858'}.icon-logout:before{content:'\e859'}.icon-group:before{content:'\e85a'}.icon-up-outline:before{content:'\e85b'}.sp-container{top:0;left:0;z-index:9999994;overflow:hidden}.sp-container.sp-flat{position:relative}.sp-container,.sp-container *{-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box}.sp-top{position:relative;width:100%;display:inline-block}.sp-top-inner{position:absolute;top:0;left:0;bottom:0;right:0}.sp-color{position:absolute;top:0;left:0;bottom:0;right:20%}.sp-hue{position:absolute;top:0;right:0;bottom:0;left:84%;height:100%}.sp-clear-enabled .sp-hue{top:33px;height:77.5%}.sp-fill{padding-top:80%}.sp-sat,.sp-val{position:absolute;top:0;left:0;right:0;bottom:0}.sp-alpha-enabled .sp-top{margin-bottom:18px}.sp-alpha-enabled .sp-alpha{display:block}.sp-alpha-handle{display:block!important;position:absolute;top:-4px;bottom:-4px;width:6px;left:50%;cursor:pointer;border:1px solid #000;background:#fff;opacity:.8}.sp-alpha{display:none;bottom:-17px;right:0;left:0;height:8px;padding-top:1px}.sp-alpha-inner{border:1px solid #333}.sp-clear{display:none}.sp-clear.sp-clear-display{background-position:center}.sp-clear-enabled .sp-clear{display:block;position:absolute;top:0;right:0;bottom:0;left:84%;height:28px}.sp-alpha,.sp-alpha-handle,.sp-clear,.sp-container,.sp-container button,.sp-container.sp-dragging .sp-input,.sp-dragger,.sp-preview,.sp-replacer,.sp-slider{-webkit-user-select:none;-moz-user-select:-moz-none;-o-user-select:none;-ms-user-select:none;user-select:none}.sp-container.sp-buttons-disabled .sp-button-container,.sp-container.sp-input-disabled .sp-input-container,.sp-container.sp-palette-buttons-disabled .sp-palette-button-container,.sp-initial-disabled .sp-initial,.sp-palette-disabled .sp-palette-container,.sp-palette-only .sp-picker-container{display:none}.sp-sat{background-image:-webkit-gradient(linear,0 0,100% 0,from(#fff),to(rgba(204,154,129,0)));background-image:-webkit-linear-gradient(left,#fff,rgba(204,154,129,0));background-image:-moz-linear-gradient(left,#fff,rgba(204,154,129,0));background-image:-o-linear-gradient(left,#fff,rgba(204,154,129,0));background-image:-ms-linear-gradient(left,#fff,rgba(204,154,129,0));background-image:linear-gradient(to right,#fff,rgba(204,154,129,0));-ms-filter:"progid:DXImageTransform.Microsoft.gradient(GradientType = 1, startColorstr=#FFFFFFFF, endColorstr=#00CC9A81)";filter:progid:DXImageTransform.Microsoft.gradient(GradientType=1, startColorstr='#FFFFFFFF', endColorstr='#00CC9A81')}.sp-val{background-image:-webkit-gradient(linear,0 100%,0 0,from(#000),to(rgba(204,154,129,0)));background-image:-webkit-linear-gradient(bottom,#000,rgba(204,154,129,0));background-image:-moz-linear-gradient(bottom,#000,rgba(204,154,129,0));background-image:-o-linear-gradient(bottom,#000,rgba(204,154,129,0));background-image:-ms-linear-gradient(bottom,#000,rgba(204,154,129,0));background-image:linear-gradient(to top,#000,rgba(204,154,129,0));-ms-filter:"progid:DXImageTransform.Microsoft.gradient(startColorstr=#00CC9A81, endColorstr=#FF000000)";filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#00CC9A81', endColorstr='#FF000000')}.sp-hue{background:-moz-linear-gradient(top,red 0,#ff0 17%,#0f0 33%,#0ff 50%,#00f 67%,#f0f 83%,red 100%);background:-ms-linear-gradient(top,red 0,#ff0 17%,#0f0 33%,#0ff 50%,#00f 67%,#f0f 83%,red 100%);background:-o-linear-gradient(top,red 0,#ff0 17%,#0f0 33%,#0ff 50%,#00f 67%,#f0f 83%,red 100%);background:-webkit-gradient(linear,left top,left bottom,from(red),color-stop(.17,#ff0),color-stop(.33,#0f0),color-stop(.5,#0ff),color-stop(.67,#00f),color-stop(.83,#f0f),to(red));background:-webkit-linear-gradient(top,red 0,#ff0 17%,#0f0 33%,#0ff 50%,#00f 67%,#f0f 83%,red 100%)}.sp-1{height:17%;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0000', endColorstr='#ffff00')}.sp-2{height:16%;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffff00', endColorstr='#00ff00')}.sp-3{height:17%;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#00ff00', endColorstr='#00ffff')}.sp-4{height:17%;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#00ffff', endColorstr='#0000ff')}.sp-5{height:16%;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#0000ff', endColorstr='#ff00ff')}.sp-6{height:17%;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff00ff', endColorstr='#ff0000')}.sp-hidden{display:none!important}.sp-cf:after,.sp-cf:before{content:"";display:table}.sp-cf:after{clear:both}@media (max-device-width:480px){.sp-color{right:40%}.sp-hue{left:63%}.sp-fill{padding-top:60%}}.sp-dragger{border-radius:5px;height:5px;width:5px;border:1px solid #fff;background:#000;cursor:pointer;position:absolute;top:0;left:0}.sp-slider{position:absolute;top:0;cursor:pointer;height:3px;left:-1px;right:-1px;border:1px solid #000;background:#fff;opacity:.8}.sp-container{border-radius:0;background-color:#1c2a33;padding:0;display:none}.sp-clear,.sp-color,.sp-container,.sp-container button,.sp-container input,.sp-hue{font:400 12px "Lucida Grande","Lucida Sans Unicode","Lucida Sans",Geneva,Verdana,sans-serif;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;-ms-box-sizing:border-box;box-sizing:border-box}.sp-top{margin-bottom:3px}.sp-clear,.sp-color,.sp-hue{border:1px solid #666}.sp-input-container{float:right;width:100px;margin-bottom:4px}.sp-initial-disabled .sp-input-container{width:100%}.sp-input{font-size:12px!important;padding:4px 5px;margin:5px 0 0;width:100%;background:#263845;color:#3b7694;border:1px solid #2f4555}.sp-input:focus{border:1px solid orange}.sp-input.sp-validation-error{border:1px solid red;background:#fdd}.sp-palette-container,.sp-picker-container{float:left;position:relative;padding:10px 10px 300px;margin-bottom:-290px}.sp-picker-container{width:172px;border-left:solid 1px #fff}.sp-palette-container{border-right:solid 1px #ccc}.sp-palette-only .sp-palette-container{border:0}.sp-palette .sp-thumb-el{display:block;position:relative;float:left;cursor:pointer}.sp-palette .sp-thumb-el.sp-thumb-active,.sp-palette .sp-thumb-el:hover{border-color:orange}.sp-initial{float:left;border:1px solid #333}.sp-initial span{width:30px;height:25px;border:none;display:block;float:left;margin:0}.sp-initial .sp-clear-display{background-position:center}.sp-button-container,.sp-palette-button-container{float:right}.sp-replacer{margin:0;overflow:hidden;cursor:pointer;padding:4px;display:inline-block;border:1px solid #91765d;background:#eee;color:#333;vertical-align:middle}.sp-replacer.sp-active,.sp-replacer:hover{border-color:#F0C49B;color:#111}.sp-replacer.sp-disabled{cursor:default;border-color:silver;color:silver}.sp-dd{padding:2px 0;height:16px;line-height:16px;float:left;font-size:10px}.sp-preview{width:25px;height:20px;border:1px solid #222;margin-right:5px;float:left;z-index:0}.sp-palette{max-width:220px}.sp-palette .sp-thumb-el{width:16px;height:16px;margin:2px 1px;border:1px solid #d0d0d0}.sp-container{padding-bottom:0}.sp-container button{background-color:#179ede;border-radius:2px;color:#fff;text-align:center;border:none;font-weight:400;padding:5px 10px;font-size:13px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;text-decoration:none;margin:5px 0}.sp-cancel:hover,.sp-container button:hover{background-color:#158ec7}.sp-cancel{display:none}.sp-palette span.sp-thumb-active,.sp-palette span:hover{border-color:#000}.sp-alpha,.sp-preview,.sp-thumb-el{position:relative;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAIAAADZF8uwAAAAGUlEQVQYV2M4gwH+YwCGIasIUwhT25BVBADtzYNYrHvv4gAAAABJRU5ErkJggg==)}.sp-alpha-inner,.sp-preview-inner,.sp-thumb-inner{display:block;position:absolute;top:0;left:0;bottom:0;right:0}.sp-palette .sp-thumb-inner{background-position:50% 50%;background-repeat:no-repeat}.sp-palette .sp-thumb-light.sp-thumb-active .sp-thumb-inner{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAIVJREFUeNpiYBhsgJFMffxAXABlN5JruT4Q3wfi/0DsT64h8UD8HmpIPCWG/KemIfOJCUB+Aoacx6EGBZyHBqI+WsDCwuQ9mhxeg2A210Ntfo8klk9sOMijaURm7yc1UP2RNCMbKE9ODK1HM6iegYLkfx8pligC9lCD7KmRof0ZhjQACDAAceovrtpVBRkAAAAASUVORK5CYII=)}.sp-palette .sp-thumb-dark.sp-thumb-active .sp-thumb-inner{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAadEVYdFNvZnR3YXJlAFBhaW50Lk5FVCB2My41LjEwMPRyoQAAAMdJREFUOE+tkgsNwzAMRMugEAahEAahEAZhEAqlEAZhEAohEAYh81X2dIm8fKpEspLGvudPOsUYpxE2BIJCroJmEW9qJ+MKaBFhEMNabSy9oIcIPwrB+afvAUFoK4H0tMaQ3XtlrggDhOVVMuT4E5MMG0FBbCEYzjYT7OxLEvIHQLY2zWwQ3D+9luyOQTfKDiFD3iUIfPk8VqrKjgAiSfGFPecrg6HN6m/iBcwiDAo7WiBeawa+Kwh7tZoSCGLMqwlSAzVDhoK+6vH4G0P5wdkAAAAASUVORK5CYII=)}.sp-clear-display{background-repeat:no-repeat;background-position:center;background-image:url(data:image/gif;base64,R0lGODlhFAAUAPcAAAAAAJmZmZ2dnZ6enqKioqOjo6SkpKWlpaampqenp6ioqKmpqaqqqqurq/Hx8fLy8vT09PX19ff39/j4+Pn5+fr6+vv7+wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAP8ALAAAAAAUABQAAAihAP9FoPCvoMGDBy08+EdhQAIJCCMybCDAAYUEARBAlFiQQoMABQhKUJBxY0SPICEYHBnggEmDKAuoPMjS5cGYMxHW3IiT478JJA8M/CjTZ0GgLRekNGpwAsYABHIypcAgQMsITDtWJYBR6NSqMico9cqR6tKfY7GeBCuVwlipDNmefAtTrkSzB1RaIAoXodsABiZAEFB06gIBWC1mLVgBa0AAOw==)}/*! normalize.css v3.0.1 | MIT License | git.io/normalize */html{font-family:sans-serif;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}body{margin:0}article,aside,details,figcaption,figure,footer,header,hgroup,main,nav,section,summary{display:block}audio,canvas,progress,video{display:inline-block;vertical-align:baseline}audio:not([controls]){display:none;height:0}[hidden],template{display:none}a{background:0 0}a:active,a:hover{outline:0}b,strong{font-weight:700}dfn{font-style:italic}h1{margin:.67em 0}mark{background:#ff0;color:#000}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sup{top:-.5em}sub{bottom:-.25em}img{border:0}svg:not(:root){overflow:hidden}hr{-moz-box-sizing:content-box;box-sizing:content-box;height:0}pre{overflow:auto}code,kbd,pre,samp{font-size:1em}button,input,optgroup,select,textarea{color:inherit;font:inherit;margin:0}button{overflow:visible}button,select{text-transform:none}button,html input[type=button],input[type=reset],input[type=submit]{-webkit-appearance:button;cursor:pointer}button[disabled],html input[disabled]{cursor:default}button::-moz-focus-inner,input::-moz-focus-inner{border:0;padding:0}input[type=checkbox],input[type=radio]{box-sizing:border-box;padding:0}input[type=number]::-webkit-inner-spin-button,input[type=number]::-webkit-outer-spin-button{height:auto}input[type=search]::-webkit-search-cancel-button,input[type=search]::-webkit-search-decoration{-webkit-appearance:none}textarea{overflow:auto}optgroup{font-weight:700}table{border-collapse:collapse;border-spacing:0}td,th{padding:0}@media print{*{text-shadow:none!important;color:#000!important;background:0 0!important;box-shadow:none!important}a,a:visited{text-decoration:underline}a[href]:after{content:" (" attr(href) ")"}abbr[title]:after{content:" (" attr(title) ")"}a[href^="javascript:"]:after,a[href^="#"]:after{content:""}blockquote,pre{border:1px solid #999;page-break-inside:avoid}thead{display:table-header-group}img,tr{page-break-inside:avoid}img{max-width:100%!important}h2,h3,p{orphans:3;widows:3}h2,h3{page-break-after:avoid}select{background:#fff!important}.navbar{display:none}.table td,.table th{background-color:#fff!important}.btn>.caret,.dropup>.btn>.caret{border-top-color:#000!important}.label{border:1px solid #000}.table{border-collapse:collapse!important}.table-bordered td,.table-bordered th{border:1px solid #ddd!important}}@font-face{font-family:'Glyphicons Halflings';src:url(../fonts/glyphicons-halflings-regular.eot);src:url(../fonts/glyphicons-halflings-regular.eot?#iefix) format('embedded-opentype'),url(../fonts/glyphicons-halflings-regular.woff) format('woff'),url(../fonts/glyphicons-halflings-regular.ttf) format('truetype'),url(../fonts/glyphicons-halflings-regular.svg#glyphicons_halflingsregular) format('svg')}.glyphicon{position:relative;top:1px;display:inline-block;font-family:'Glyphicons Halflings';font-style:normal;font-weight:400;line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.glyphicon-asterisk:before{content:"\2a"}.glyphicon-plus:before{content:"\2b"}.glyphicon-euro:before{content:"\20ac"}.glyphicon-minus:before{content:"\2212"}.glyphicon-cloud:before{content:"\2601"}.glyphicon-envelope:before{content:"\2709"}.glyphicon-pencil:before{content:"\270f"}.glyphicon-glass:before{content:"\e001"}.glyphicon-music:before{content:"\e002"}.glyphicon-search:before{content:"\e003"}.glyphicon-heart:before{content:"\e005"}.glyphicon-star:before{content:"\e006"}.glyphicon-star-empty:before{content:"\e007"}.glyphicon-user:before{content:"\e008"}.glyphicon-film:before{content:"\e009"}.glyphicon-th-large:before{content:"\e010"}.glyphicon-th:before{content:"\e011"}.glyphicon-th-list:before{content:"\e012"}.glyphicon-ok:before{content:"\e013"}.glyphicon-remove:before{content:"\e014"}.glyphicon-zoom-in:before{content:"\e015"}.glyphicon-zoom-out:before{content:"\e016"}.glyphicon-off:before{content:"\e017"}.glyphicon-signal:before{content:"\e018"}.glyphicon-cog:before{content:"\e019"}.glyphicon-trash:before{content:"\e020"}.glyphicon-home:before{content:"\e021"}.glyphicon-file:before{content:"\e022"}.glyphicon-time:before{content:"\e023"}.glyphicon-road:before{content:"\e024"}.glyphicon-download-alt:before{content:"\e025"}.glyphicon-download:before{content:"\e026"}.glyphicon-upload:before{content:"\e027"}.glyphicon-inbox:before{content:"\e028"}.glyphicon-play-circle:before{content:"\e029"}.glyphicon-repeat:before{content:"\e030"}.glyphicon-refresh:before{content:"\e031"}.glyphicon-list-alt:before{content:"\e032"}.glyphicon-lock:before{content:"\e033"}.glyphicon-flag:before{content:"\e034"}.glyphicon-headphones:before{content:"\e035"}.glyphicon-volume-off:before{content:"\e036"}.glyphicon-volume-down:before{content:"\e037"}.glyphicon-volume-up:before{content:"\e038"}.glyphicon-qrcode:before{content:"\e039"}.glyphicon-barcode:before{content:"\e040"}.glyphicon-tag:before{content:"\e041"}.glyphicon-tags:before{content:"\e042"}.glyphicon-book:before{content:"\e043"}.glyphicon-bookmark:before{content:"\e044"}.glyphicon-print:before{content:"\e045"}.glyphicon-camera:before{content:"\e046"}.glyphicon-font:before{content:"\e047"}.glyphicon-bold:before{content:"\e048"}.glyphicon-italic:before{content:"\e049"}.glyphicon-text-height:before{content:"\e050"}.glyphicon-text-width:before{content:"\e051"}.glyphicon-align-left:before{content:"\e052"}.glyphicon-align-center:before{content:"\e053"}.glyphicon-align-right:before{content:"\e054"}.glyphicon-align-justify:before{content:"\e055"}.glyphicon-list:before{content:"\e056"}.glyphicon-indent-left:before{content:"\e057"}.glyphicon-indent-right:before{content:"\e058"}.glyphicon-facetime-video:before{content:"\e059"}.glyphicon-picture:before{content:"\e060"}.glyphicon-map-marker:before{content:"\e062"}.glyphicon-adjust:before{content:"\e063"}.glyphicon-tint:before{content:"\e064"}.glyphicon-edit:before{content:"\e065"}.glyphicon-share:before{content:"\e066"}.glyphicon-check:before{content:"\e067"}.glyphicon-move:before{content:"\e068"}.glyphicon-step-backward:before{content:"\e069"}.glyphicon-fast-backward:before{content:"\e070"}.glyphicon-backward:before{content:"\e071"}.glyphicon-play:before{content:"\e072"}.glyphicon-pause:before{content:"\e073"}.glyphicon-stop:before{content:"\e074"}.glyphicon-forward:before{content:"\e075"}.glyphicon-fast-forward:before{content:"\e076"}.glyphicon-step-forward:before{content:"\e077"}.glyphicon-eject:before{content:"\e078"}.glyphicon-chevron-left:before{content:"\e079"}.glyphicon-chevron-right:before{content:"\e080"}.glyphicon-plus-sign:before{content:"\e081"}.glyphicon-minus-sign:before{content:"\e082"}.glyphicon-remove-sign:before{content:"\e083"}.glyphicon-ok-sign:before{content:"\e084"}.glyphicon-question-sign:before{content:"\e085"}.glyphicon-info-sign:before{content:"\e086"}.glyphicon-screenshot:before{content:"\e087"}.glyphicon-remove-circle:before{content:"\e088"}.glyphicon-ok-circle:before{content:"\e089"}.glyphicon-ban-circle:before{content:"\e090"}.glyphicon-arrow-left:before{content:"\e091"}.glyphicon-arrow-right:before{content:"\e092"}.glyphicon-arrow-up:before{content:"\e093"}.glyphicon-arrow-down:before{content:"\e094"}.glyphicon-share-alt:before{content:"\e095"}.glyphicon-resize-full:before{content:"\e096"}.glyphicon-resize-small:before{content:"\e097"}.glyphicon-exclamation-sign:before{content:"\e101"}.glyphicon-gift:before{content:"\e102"}.glyphicon-leaf:before{content:"\e103"}.glyphicon-fire:before{content:"\e104"}.glyphicon-eye-open:before{content:"\e105"}.glyphicon-eye-close:before{content:"\e106"}.glyphicon-warning-sign:before{content:"\e107"}.glyphicon-plane:before{content:"\e108"}.glyphicon-calendar:before{content:"\e109"}.glyphicon-random:before{content:"\e110"}.glyphicon-comment:before{content:"\e111"}.glyphicon-magnet:before{content:"\e112"}.glyphicon-chevron-up:before{content:"\e113"}.glyphicon-chevron-down:before{content:"\e114"}.glyphicon-retweet:before{content:"\e115"}.glyphicon-shopping-cart:before{content:"\e116"}.glyphicon-folder-close:before{content:"\e117"}.glyphicon-folder-open:before{content:"\e118"}.glyphicon-resize-vertical:before{content:"\e119"}.glyphicon-resize-horizontal:before{content:"\e120"}.glyphicon-hdd:before{content:"\e121"}.glyphicon-bullhorn:before{content:"\e122"}.glyphicon-bell:before{content:"\e123"}.glyphicon-certificate:before{content:"\e124"}.glyphicon-thumbs-up:before{content:"\e125"}.glyphicon-thumbs-down:before{content:"\e126"}.glyphicon-hand-right:before{content:"\e127"}.glyphicon-hand-left:before{content:"\e128"}.glyphicon-hand-up:before{content:"\e129"}.glyphicon-hand-down:before{content:"\e130"}.glyphicon-circle-arrow-right:before{content:"\e131"}.glyphicon-circle-arrow-left:before{content:"\e132"}.glyphicon-circle-arrow-up:before{content:"\e133"}.glyphicon-circle-arrow-down:before{content:"\e134"}.glyphicon-globe:before{content:"\e135"}.glyphicon-wrench:before{content:"\e136"}.glyphicon-tasks:before{content:"\e137"}.glyphicon-filter:before{content:"\e138"}.glyphicon-briefcase:before{content:"\e139"}.glyphicon-fullscreen:before{content:"\e140"}.glyphicon-dashboard:before{content:"\e141"}.glyphicon-paperclip:before{content:"\e142"}.glyphicon-heart-empty:before{content:"\e143"}.glyphicon-link:before{content:"\e144"}.glyphicon-phone:before{content:"\e145"}.glyphicon-pushpin:before{content:"\e146"}.glyphicon-usd:before{content:"\e148"}.glyphicon-gbp:before{content:"\e149"}.glyphicon-sort:before{content:"\e150"}.glyphicon-sort-by-alphabet:before{content:"\e151"}.glyphicon-sort-by-alphabet-alt:before{content:"\e152"}.glyphicon-sort-by-order:before{content:"\e153"}.glyphicon-sort-by-order-alt:before{content:"\e154"}.glyphicon-sort-by-attributes:before{content:"\e155"}.glyphicon-sort-by-attributes-alt:before{content:"\e156"}.glyphicon-unchecked:before{content:"\e157"}.glyphicon-expand:before{content:"\e158"}.glyphicon-collapse-down:before{content:"\e159"}.glyphicon-collapse-up:before{content:"\e160"}.glyphicon-log-in:before{content:"\e161"}.glyphicon-flash:before{content:"\e162"}.glyphicon-log-out:before{content:"\e163"}.glyphicon-new-window:before{content:"\e164"}.glyphicon-record:before{content:"\e165"}.glyphicon-save:before{content:"\e166"}.glyphicon-open:before{content:"\e167"}.glyphicon-saved:before{content:"\e168"}.glyphicon-import:before{content:"\e169"}.glyphicon-export:before{content:"\e170"}.glyphicon-send:before{content:"\e171"}.glyphicon-floppy-disk:before{content:"\e172"}.glyphicon-floppy-saved:before{content:"\e173"}.glyphicon-floppy-remove:before{content:"\e174"}.glyphicon-floppy-save:before{content:"\e175"}.glyphicon-floppy-open:before{content:"\e176"}.glyphicon-credit-card:before{content:"\e177"}.glyphicon-transfer:before{content:"\e178"}.glyphicon-cutlery:before{content:"\e179"}.glyphicon-header:before{content:"\e180"}.glyphicon-compressed:before{content:"\e181"}.glyphicon-earphone:before{content:"\e182"}.glyphicon-phone-alt:before{content:"\e183"}.glyphicon-tower:before{content:"\e184"}.glyphicon-stats:before{content:"\e185"}.glyphicon-sd-video:before{content:"\e186"}.glyphicon-hd-video:before{content:"\e187"}.glyphicon-subtitles:before{content:"\e188"}.glyphicon-sound-stereo:before{content:"\e189"}.glyphicon-sound-dolby:before{content:"\e190"}.glyphicon-sound-5-1:before{content:"\e191"}.glyphicon-sound-6-1:before{content:"\e192"}.glyphicon-sound-7-1:before{content:"\e193"}.glyphicon-copyright-mark:before{content:"\e194"}.glyphicon-registration-mark:before{content:"\e195"}.glyphicon-cloud-download:before{content:"\e197"}.glyphicon-cloud-upload:before{content:"\e198"}.glyphicon-tree-conifer:before{content:"\e199"}.glyphicon-tree-deciduous:before{content:"\e200"}*,:after,:before{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}html{font-size:10px;-webkit-tap-highlight-color:transparent}body{font-family:Roboto,Noto,'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:14px;line-height:1.42857143;color:#333;background-color:#fff}button,input,select,textarea{font-family:inherit;font-size:inherit;line-height:inherit}a{color:#179ede;text-decoration:none}a:focus,a:hover{color:#106d99;text-decoration:underline}a:focus{outline:dotted thin;outline:-webkit-focus-ring-color auto 5px;outline-offset:-2px}figure{margin:0}img{vertical-align:middle}.carousel-inner>.item>a>img,.carousel-inner>.item>img,.img-responsive,.thumbnail a>img,.thumbnail>img{display:block;max-width:100%;height:auto}.img-rounded{border-radius:6px}.img-thumbnail{padding:4px;line-height:1.42857143;background-color:#fff;border:1px solid #ddd;border-radius:4px;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;transition:all .2s ease-in-out;display:inline-block;max-width:100%;height:auto}.img-circle{border-radius:50%}hr{margin-top:20px;margin-bottom:20px;border:0;border-top:1px solid #eee}.sr-only{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);border:0}.sr-only-focusable:active,.sr-only-focusable:focus{position:static;width:auto;height:auto;margin:0;overflow:visible;clip:auto}.h1,.h2,.h3,.h4,.h5,.h6,h1,h2,h3,h4,h5,h6{font-family:inherit;font-weight:500;line-height:1.1;color:inherit}.h1 .small,.h1 small,.h2 .small,.h2 small,.h3 .small,.h3 small,.h4 .small,.h4 small,.h5 .small,.h5 small,.h6 .small,.h6 small,h1 .small,h1 small,h2 .small,h2 small,h3 .small,h3 small,h4 .small,h4 small,h5 .small,h5 small,h6 .small,h6 small{font-weight:400;line-height:1;color:#777}.h1,.h2,.h3,h1,h2,h3{margin-top:20px;margin-bottom:10px}.h1 .small,.h1 small,.h2 .small,.h2 small,.h3 .small,.h3 small,h1 .small,h1 small,h2 .small,h2 small,h3 .small,h3 small{font-size:65%}.h4,.h5,.h6,h4,h5,h6{margin-top:10px;margin-bottom:10px}.h4 .small,.h4 small,.h5 .small,.h5 small,.h6 .small,.h6 small,h4 .small,h4 small,h5 .small,h5 small,h6 .small,h6 small{font-size:75%}.h1,h1{font-size:36px}.h2,h2{font-size:30px}.h3,h3{font-size:24px}.h4,h4{font-size:18px}.h5,h5{font-size:14px}.h6,h6{font-size:12px}p{margin:0 0 10px}.lead{margin-bottom:20px;font-size:16px;font-weight:300;line-height:1.4}@media (min-width:768px){.lead{font-size:21px}}.small,small{font-size:85%}cite{font-style:normal}.mark,mark{background-color:#fcf8e3;padding:.2em}.text-left{text-align:left}.text-right{text-align:right}.text-center{text-align:center}.text-justify{text-align:justify}.text-nowrap{white-space:nowrap}.text-lowercase{text-transform:lowercase}.text-uppercase{text-transform:uppercase}.text-capitalize{text-transform:capitalize}.text-muted{color:#777}.text-primary{color:#179ede}a.text-primary:hover{color:#127db0}.text-success{color:#00b588}a.text-success:hover{color:#008261}.text-info{color:#39afe1}a.text-info:hover{color:#1e96c9}.text-warning{color:#8a6d3b}a.text-warning:hover{color:#66512c}.text-danger{color:#c0392b}a.text-danger:hover{color:#962d22}.bg-primary{color:#fff;background-color:#179ede}a.bg-primary:hover{background-color:#127db0}.bg-success{background-color:#00b588}a.bg-success:hover{background-color:#008261}.bg-info{background-color:#39afe1}a.bg-info:hover{background-color:#1e96c9}.bg-warning{background-color:#fcf8e3}a.bg-warning:hover{background-color:#f7ecb5}.bg-danger{background-color:#c0392b}a.bg-danger:hover{background-color:#962d22}.page-header{padding-bottom:9px;margin:40px 0 20px;border-bottom:1px solid #eee}ol,ul{margin-top:0;margin-bottom:10px}ol ol,ol ul,ul ol,ul ul{margin-bottom:0}.list-unstyled{padding-left:0;list-style:none}.list-inline{padding-left:0;list-style:none;margin-left:-5px}.list-inline>li{display:inline-block;padding-left:5px;padding-right:5px}dl{margin-top:0;margin-bottom:20px}dd,dt{line-height:1.42857143}dt{font-weight:700}dd{margin-left:0}@media (min-width:768px){.dl-horizontal dt{float:left;width:160px;clear:left;text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.dl-horizontal dd{margin-left:180px}}abbr[data-original-title],abbr[title]{cursor:help;border-bottom:1px dotted #777}.initialism{font-size:90%;text-transform:uppercase}blockquote{padding:10px 20px;margin:0 0 20px;font-size:17.5px;border-left:5px solid #eee}blockquote ol:last-child,blockquote p:last-child,blockquote ul:last-child{margin-bottom:0}blockquote .small,blockquote footer,blockquote small{display:block;font-size:80%;line-height:1.42857143;color:#777}blockquote .small:before,blockquote footer:before,blockquote small:before{content:'\2014 \00A0'}.blockquote-reverse,blockquote.pull-right{padding-right:15px;padding-left:0;border-right:5px solid #eee;border-left:0;text-align:right}.blockquote-reverse .small:before,.blockquote-reverse footer:before,.blockquote-reverse small:before,blockquote.pull-right .small:before,blockquote.pull-right footer:before,blockquote.pull-right small:before{content:''}.blockquote-reverse .small:after,.blockquote-reverse footer:after,.blockquote-reverse small:after,blockquote.pull-right .small:after,blockquote.pull-right footer:after,blockquote.pull-right small:after{content:'\00A0 \2014'}blockquote:after,blockquote:before{content:""}address{margin-bottom:20px;font-style:normal;line-height:1.42857143}code,kbd,pre,samp{font-family:Menlo,Monaco,Consolas,"Courier New",monospace}code{padding:2px 4px;font-size:90%;color:#c7254e;background-color:#f9f2f4;border-radius:4px}kbd{padding:2px 4px;font-size:90%;color:#fff;background-color:#333;border-radius:3px;box-shadow:inset 0 -1px 0 rgba(0,0,0,.25)}kbd kbd{padding:0;font-size:100%;box-shadow:none}pre{display:block;padding:9.5px;margin:0 0 10px;font-size:13px;line-height:1.42857143;word-break:break-all;word-wrap:break-word;color:#333;background-color:#f5f5f5;border:1px solid #ccc;border-radius:4px}pre code{padding:0;font-size:inherit;color:inherit;white-space:pre-wrap;background-color:transparent;border-radius:0}.pre-scrollable{max-height:340px;overflow-y:scroll}.container,.container-fluid{margin-right:auto;margin-left:auto;padding-left:15px;padding-right:15px}@media (min-width:768px){.container{width:750px}}@media (min-width:992px){.container{width:970px}}@media (min-width:1200px){.container{width:1170px}}.row{margin-left:-15px;margin-right:-15px}.col-lg-1,.col-lg-10,.col-lg-11,.col-lg-12,.col-lg-2,.col-lg-3,.col-lg-4,.col-lg-5,.col-lg-6,.col-lg-7,.col-lg-8,.col-lg-9,.col-md-1,.col-md-10,.col-md-11,.col-md-12,.col-md-2,.col-md-3,.col-md-4,.col-md-5,.col-md-6,.col-md-7,.col-md-8,.col-md-9,.col-sm-1,.col-sm-10,.col-sm-11,.col-sm-12,.col-sm-2,.col-sm-3,.col-sm-4,.col-sm-5,.col-sm-6,.col-sm-7,.col-sm-8,.col-sm-9,.col-xs-1,.col-xs-10,.col-xs-11,.col-xs-12,.col-xs-2,.col-xs-3,.col-xs-4,.col-xs-5,.col-xs-6,.col-xs-7,.col-xs-8,.col-xs-9{position:relative;min-height:1px;padding-left:15px;padding-right:15px}.col-xs-1,.col-xs-10,.col-xs-11,.col-xs-12,.col-xs-2,.col-xs-3,.col-xs-4,.col-xs-5,.col-xs-6,.col-xs-7,.col-xs-8,.col-xs-9{float:left}.col-xs-12{width:100%}.col-xs-11{width:91.66666667%}.col-xs-10{width:83.33333333%}.col-xs-9{width:75%}.col-xs-8{width:66.66666667%}.col-xs-7{width:58.33333333%}.col-xs-6{width:50%}.col-xs-5{width:41.66666667%}.col-xs-4{width:33.33333333%}.col-xs-3{width:25%}.col-xs-2{width:16.66666667%}.col-xs-1{width:8.33333333%}.col-xs-pull-12{right:100%}.col-xs-pull-11{right:91.66666667%}.col-xs-pull-10{right:83.33333333%}.col-xs-pull-9{right:75%}.col-xs-pull-8{right:66.66666667%}.col-xs-pull-7{right:58.33333333%}.col-xs-pull-6{right:50%}.col-xs-pull-5{right:41.66666667%}.col-xs-pull-4{right:33.33333333%}.col-xs-pull-3{right:25%}.col-xs-pull-2{right:16.66666667%}.col-xs-pull-1{right:8.33333333%}.col-xs-pull-0{right:auto}.col-xs-push-12{left:100%}.col-xs-push-11{left:91.66666667%}.col-xs-push-10{left:83.33333333%}.col-xs-push-9{left:75%}.col-xs-push-8{left:66.66666667%}.col-xs-push-7{left:58.33333333%}.col-xs-push-6{left:50%}.col-xs-push-5{left:41.66666667%}.col-xs-push-4{left:33.33333333%}.col-xs-push-3{left:25%}.col-xs-push-2{left:16.66666667%}.col-xs-push-1{left:8.33333333%}.col-xs-push-0{left:auto}.col-xs-offset-12{margin-left:100%}.col-xs-offset-11{margin-left:91.66666667%}.col-xs-offset-10{margin-left:83.33333333%}.col-xs-offset-9{margin-left:75%}.col-xs-offset-8{margin-left:66.66666667%}.col-xs-offset-7{margin-left:58.33333333%}.col-xs-offset-6{margin-left:50%}.col-xs-offset-5{margin-left:41.66666667%}.col-xs-offset-4{margin-left:33.33333333%}.col-xs-offset-3{margin-left:25%}.col-xs-offset-2{margin-left:16.66666667%}.col-xs-offset-1{margin-left:8.33333333%}.col-xs-offset-0{margin-left:0}@media (min-width:768px){.col-sm-1,.col-sm-10,.col-sm-11,.col-sm-12,.col-sm-2,.col-sm-3,.col-sm-4,.col-sm-5,.col-sm-6,.col-sm-7,.col-sm-8,.col-sm-9{float:left}.col-sm-12{width:100%}.col-sm-11{width:91.66666667%}.col-sm-10{width:83.33333333%}.col-sm-9{width:75%}.col-sm-8{width:66.66666667%}.col-sm-7{width:58.33333333%}.col-sm-6{width:50%}.col-sm-5{width:41.66666667%}.col-sm-4{width:33.33333333%}.col-sm-3{width:25%}.col-sm-2{width:16.66666667%}.col-sm-1{width:8.33333333%}.col-sm-pull-12{right:100%}.col-sm-pull-11{right:91.66666667%}.col-sm-pull-10{right:83.33333333%}.col-sm-pull-9{right:75%}.col-sm-pull-8{right:66.66666667%}.col-sm-pull-7{right:58.33333333%}.col-sm-pull-6{right:50%}.col-sm-pull-5{right:41.66666667%}.col-sm-pull-4{right:33.33333333%}.col-sm-pull-3{right:25%}.col-sm-pull-2{right:16.66666667%}.col-sm-pull-1{right:8.33333333%}.col-sm-pull-0{right:auto}.col-sm-push-12{left:100%}.col-sm-push-11{left:91.66666667%}.col-sm-push-10{left:83.33333333%}.col-sm-push-9{left:75%}.col-sm-push-8{left:66.66666667%}.col-sm-push-7{left:58.33333333%}.col-sm-push-6{left:50%}.col-sm-push-5{left:41.66666667%}.col-sm-push-4{left:33.33333333%}.col-sm-push-3{left:25%}.col-sm-push-2{left:16.66666667%}.col-sm-push-1{left:8.33333333%}.col-sm-push-0{left:auto}.col-sm-offset-12{margin-left:100%}.col-sm-offset-11{margin-left:91.66666667%}.col-sm-offset-10{margin-left:83.33333333%}.col-sm-offset-9{margin-left:75%}.col-sm-offset-8{margin-left:66.66666667%}.col-sm-offset-7{margin-left:58.33333333%}.col-sm-offset-6{margin-left:50%}.col-sm-offset-5{margin-left:41.66666667%}.col-sm-offset-4{margin-left:33.33333333%}.col-sm-offset-3{margin-left:25%}.col-sm-offset-2{margin-left:16.66666667%}.col-sm-offset-1{margin-left:8.33333333%}.col-sm-offset-0{margin-left:0}}@media (min-width:992px){.col-md-1,.col-md-10,.col-md-11,.col-md-12,.col-md-2,.col-md-3,.col-md-4,.col-md-5,.col-md-6,.col-md-7,.col-md-8,.col-md-9{float:left}.col-md-12{width:100%}.col-md-11{width:91.66666667%}.col-md-10{width:83.33333333%}.col-md-9{width:75%}.col-md-8{width:66.66666667%}.col-md-7{width:58.33333333%}.col-md-6{width:50%}.col-md-5{width:41.66666667%}.col-md-4{width:33.33333333%}.col-md-3{width:25%}.col-md-2{width:16.66666667%}.col-md-1{width:8.33333333%}.col-md-pull-12{right:100%}.col-md-pull-11{right:91.66666667%}.col-md-pull-10{right:83.33333333%}.col-md-pull-9{right:75%}.col-md-pull-8{right:66.66666667%}.col-md-pull-7{right:58.33333333%}.col-md-pull-6{right:50%}.col-md-pull-5{right:41.66666667%}.col-md-pull-4{right:33.33333333%}.col-md-pull-3{right:25%}.col-md-pull-2{right:16.66666667%}.col-md-pull-1{right:8.33333333%}.col-md-pull-0{right:auto}.col-md-push-12{left:100%}.col-md-push-11{left:91.66666667%}.col-md-push-10{left:83.33333333%}.col-md-push-9{left:75%}.col-md-push-8{left:66.66666667%}.col-md-push-7{left:58.33333333%}.col-md-push-6{left:50%}.col-md-push-5{left:41.66666667%}.col-md-push-4{left:33.33333333%}.col-md-push-3{left:25%}.col-md-push-2{left:16.66666667%}.col-md-push-1{left:8.33333333%}.col-md-push-0{left:auto}.col-md-offset-12{margin-left:100%}.col-md-offset-11{margin-left:91.66666667%}.col-md-offset-10{margin-left:83.33333333%}.col-md-offset-9{margin-left:75%}.col-md-offset-8{margin-left:66.66666667%}.col-md-offset-7{margin-left:58.33333333%}.col-md-offset-6{margin-left:50%}.col-md-offset-5{margin-left:41.66666667%}.col-md-offset-4{margin-left:33.33333333%}.col-md-offset-3{margin-left:25%}.col-md-offset-2{margin-left:16.66666667%}.col-md-offset-1{margin-left:8.33333333%}.col-md-offset-0{margin-left:0}}@media (min-width:1200px){.col-lg-1,.col-lg-10,.col-lg-11,.col-lg-12,.col-lg-2,.col-lg-3,.col-lg-4,.col-lg-5,.col-lg-6,.col-lg-7,.col-lg-8,.col-lg-9{float:left}.col-lg-12{width:100%}.col-lg-11{width:91.66666667%}.col-lg-10{width:83.33333333%}.col-lg-9{width:75%}.col-lg-8{width:66.66666667%}.col-lg-7{width:58.33333333%}.col-lg-6{width:50%}.col-lg-5{width:41.66666667%}.col-lg-4{width:33.33333333%}.col-lg-3{width:25%}.col-lg-2{width:16.66666667%}.col-lg-1{width:8.33333333%}.col-lg-pull-12{right:100%}.col-lg-pull-11{right:91.66666667%}.col-lg-pull-10{right:83.33333333%}.col-lg-pull-9{right:75%}.col-lg-pull-8{right:66.66666667%}.col-lg-pull-7{right:58.33333333%}.col-lg-pull-6{right:50%}.col-lg-pull-5{right:41.66666667%}.col-lg-pull-4{right:33.33333333%}.col-lg-pull-3{right:25%}.col-lg-pull-2{right:16.66666667%}.col-lg-pull-1{right:8.33333333%}.col-lg-pull-0{right:auto}.col-lg-push-12{left:100%}.col-lg-push-11{left:91.66666667%}.col-lg-push-10{left:83.33333333%}.col-lg-push-9{left:75%}.col-lg-push-8{left:66.66666667%}.col-lg-push-7{left:58.33333333%}.col-lg-push-6{left:50%}.col-lg-push-5{left:41.66666667%}.col-lg-push-4{left:33.33333333%}.col-lg-push-3{left:25%}.col-lg-push-2{left:16.66666667%}.col-lg-push-1{left:8.33333333%}.col-lg-push-0{left:auto}.col-lg-offset-12{margin-left:100%}.col-lg-offset-11{margin-left:91.66666667%}.col-lg-offset-10{margin-left:83.33333333%}.col-lg-offset-9{margin-left:75%}.col-lg-offset-8{margin-left:66.66666667%}.col-lg-offset-7{margin-left:58.33333333%}.col-lg-offset-6{margin-left:50%}.col-lg-offset-5{margin-left:41.66666667%}.col-lg-offset-4{margin-left:33.33333333%}.col-lg-offset-3{margin-left:25%}.col-lg-offset-2{margin-left:16.66666667%}.col-lg-offset-1{margin-left:8.33333333%}.col-lg-offset-0{margin-left:0}}table{background-color:transparent}th{text-align:left}.table{width:100%;max-width:100%;margin-bottom:20px}.table>tbody>tr>td,.table>tbody>tr>th,.table>tfoot>tr>td,.table>tfoot>tr>th,.table>thead>tr>td,.table>thead>tr>th{padding:8px;line-height:1.42857143;vertical-align:top;border-top:1px solid #ddd}.table>thead>tr>th{vertical-align:bottom;border-bottom:2px solid #ddd}.table>caption+thead>tr:first-child>td,.table>caption+thead>tr:first-child>th,.table>colgroup+thead>tr:first-child>td,.table>colgroup+thead>tr:first-child>th,.table>thead:first-child>tr:first-child>td,.table>thead:first-child>tr:first-child>th{border-top:0}.table>tbody+tbody{border-top:2px solid #ddd}.table .table{background-color:#fff}.table-condensed>tbody>tr>td,.table-condensed>tbody>tr>th,.table-condensed>tfoot>tr>td,.table-condensed>tfoot>tr>th,.table-condensed>thead>tr>td,.table-condensed>thead>tr>th{padding:5px}.table-bordered,.table-bordered>tbody>tr>td,.table-bordered>tbody>tr>th,.table-bordered>tfoot>tr>td,.table-bordered>tfoot>tr>th,.table-bordered>thead>tr>td,.table-bordered>thead>tr>th{border:1px solid #ddd}.table-bordered>thead>tr>td,.table-bordered>thead>tr>th{border-bottom-width:2px}.table-striped>tbody>tr:nth-child(odd)>td,.table-striped>tbody>tr:nth-child(odd)>th{background-color:#f9f9f9}.table-hover>tbody>tr:hover>td,.table-hover>tbody>tr:hover>th{background-color:#f5f5f5}table col[class*=col-]{position:static;float:none;display:table-column}table td[class*=col-],table th[class*=col-]{position:static;float:none;display:table-cell}.table>tbody>tr.active>td,.table>tbody>tr.active>th,.table>tbody>tr>td.active,.table>tbody>tr>th.active,.table>tfoot>tr.active>td,.table>tfoot>tr.active>th,.table>tfoot>tr>td.active,.table>tfoot>tr>th.active,.table>thead>tr.active>td,.table>thead>tr.active>th,.table>thead>tr>td.active,.table>thead>tr>th.active{background-color:#f5f5f5}.table-hover>tbody>tr.active:hover>td,.table-hover>tbody>tr.active:hover>th,.table-hover>tbody>tr:hover>.active,.table-hover>tbody>tr>td.active:hover,.table-hover>tbody>tr>th.active:hover{background-color:#e8e8e8}.table>tbody>tr.success>td,.table>tbody>tr.success>th,.table>tbody>tr>td.success,.table>tbody>tr>th.success,.table>tfoot>tr.success>td,.table>tfoot>tr.success>th,.table>tfoot>tr>td.success,.table>tfoot>tr>th.success,.table>thead>tr.success>td,.table>thead>tr.success>th,.table>thead>tr>td.success,.table>thead>tr>th.success{background-color:#00b588}.table-hover>tbody>tr.success:hover>td,.table-hover>tbody>tr.success:hover>th,.table-hover>tbody>tr:hover>.success,.table-hover>tbody>tr>td.success:hover,.table-hover>tbody>tr>th.success:hover{background-color:#009b75}.table>tbody>tr.info>td,.table>tbody>tr.info>th,.table>tbody>tr>td.info,.table>tbody>tr>th.info,.table>tfoot>tr.info>td,.table>tfoot>tr.info>th,.table>tfoot>tr>td.info,.table>tfoot>tr>th.info,.table>thead>tr.info>td,.table>thead>tr.info>th,.table>thead>tr>td.info,.table>thead>tr>th.info{background-color:#39afe1}.table-hover>tbody>tr.info:hover>td,.table-hover>tbody>tr.info:hover>th,.table-hover>tbody>tr:hover>.info,.table-hover>tbody>tr>td.info:hover,.table-hover>tbody>tr>th.info:hover{background-color:#23a6de}.table>tbody>tr.warning>td,.table>tbody>tr.warning>th,.table>tbody>tr>td.warning,.table>tbody>tr>th.warning,.table>tfoot>tr.warning>td,.table>tfoot>tr.warning>th,.table>tfoot>tr>td.warning,.table>tfoot>tr>th.warning,.table>thead>tr.warning>td,.table>thead>tr.warning>th,.table>thead>tr>td.warning,.table>thead>tr>th.warning{background-color:#fcf8e3}.table-hover>tbody>tr.warning:hover>td,.table-hover>tbody>tr.warning:hover>th,.table-hover>tbody>tr:hover>.warning,.table-hover>tbody>tr>td.warning:hover,.table-hover>tbody>tr>th.warning:hover{background-color:#faf2cc}.table>tbody>tr.danger>td,.table>tbody>tr.danger>th,.table>tbody>tr>td.danger,.table>tbody>tr>th.danger,.table>tfoot>tr.danger>td,.table>tfoot>tr.danger>th,.table>tfoot>tr>td.danger,.table>tfoot>tr>th.danger,.table>thead>tr.danger>td,.table>thead>tr.danger>th,.table>thead>tr>td.danger,.table>thead>tr>th.danger{background-color:#c0392b}.table-hover>tbody>tr.danger:hover>td,.table-hover>tbody>tr.danger:hover>th,.table-hover>tbody>tr:hover>.danger,.table-hover>tbody>tr>td.danger:hover,.table-hover>tbody>tr>th.danger:hover{background-color:#ab3326}@media screen and (max-width:767px){.table-responsive{width:100%;margin-bottom:15px;overflow-y:hidden;overflow-x:auto;-ms-overflow-style:-ms-autohiding-scrollbar;border:1px solid #ddd;-webkit-overflow-scrolling:touch}.table-responsive>.table{margin-bottom:0}.table-responsive>.table>tbody>tr>td,.table-responsive>.table>tbody>tr>th,.table-responsive>.table>tfoot>tr>td,.table-responsive>.table>tfoot>tr>th,.table-responsive>.table>thead>tr>td,.table-responsive>.table>thead>tr>th{white-space:nowrap}.table-responsive>.table-bordered{border:0}.table-responsive>.table-bordered>tbody>tr>td:first-child,.table-responsive>.table-bordered>tbody>tr>th:first-child,.table-responsive>.table-bordered>tfoot>tr>td:first-child,.table-responsive>.table-bordered>tfoot>tr>th:first-child,.table-responsive>.table-bordered>thead>tr>td:first-child,.table-responsive>.table-bordered>thead>tr>th:first-child{border-left:0}.table-responsive>.table-bordered>tbody>tr>td:last-child,.table-responsive>.table-bordered>tbody>tr>th:last-child,.table-responsive>.table-bordered>tfoot>tr>td:last-child,.table-responsive>.table-bordered>tfoot>tr>th:last-child,.table-responsive>.table-bordered>thead>tr>td:last-child,.table-responsive>.table-bordered>thead>tr>th:last-child{border-right:0}.table-responsive>.table-bordered>tbody>tr:last-child>td,.table-responsive>.table-bordered>tbody>tr:last-child>th,.table-responsive>.table-bordered>tfoot>tr:last-child>td,.table-responsive>.table-bordered>tfoot>tr:last-child>th{border-bottom:0}}fieldset{padding:0;margin:0;border:0;min-width:0}legend{display:block;width:100%;padding:0;margin-bottom:20px;font-size:21px;line-height:inherit;color:#333;border:0;border-bottom:1px solid #e5e5e5}label{display:inline-block;max-width:100%;margin-bottom:5px;font-weight:700}input[type=search]{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}input[type=checkbox],input[type=radio]{margin:4px 0 0;line-height:normal}input[type=file]{display:block}input[type=range]{display:block;width:100%}select[multiple],select[size]{height:auto}input[type=checkbox]:focus,input[type=radio]:focus,input[type=file]:focus{outline:dotted thin;outline:-webkit-focus-ring-color auto 5px;outline-offset:-2px}output{display:block;padding-top:7px;font-size:14px;line-height:1.42857143;color:#555}.form-control{display:block;width:100%;height:34px;padding:6px 12px;font-size:14px;line-height:1.42857143;color:#555;background-color:#fff;background-image:none;border:1px solid #ccc;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);box-shadow:inset 0 1px 1px rgba(0,0,0,.075);-webkit-transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s;-o-transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s;transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s}.form-control:focus{border-color:#66afe9;outline:0;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6)}.form-control::-moz-placeholder{color:#777;opacity:1}.form-control:-ms-input-placeholder{color:#777}.form-control::-webkit-input-placeholder{color:#777}.form-control[disabled],.form-control[readonly],fieldset[disabled] .form-control{cursor:not-allowed;background-color:#eee;opacity:1}textarea.form-control{height:auto}input[type=search]{-webkit-appearance:none}input[type=date],input[type=time],input[type=datetime-local],input[type=month]{line-height:34px;line-height:1.42857143 \0}input[type=date].input-sm,input[type=time].input-sm,input[type=datetime-local].input-sm,input[type=month].input-sm{line-height:30px}input[type=date].input-lg,input[type=time].input-lg,input[type=datetime-local].input-lg,input[type=month].input-lg{line-height:46px}.form-group{margin-bottom:15px}.checkbox,.radio{position:relative;display:block;min-height:20px;margin-top:10px;margin-bottom:10px}.checkbox label,.radio label{padding-left:20px;margin-bottom:0;font-weight:400;cursor:pointer}.checkbox input[type=checkbox],.checkbox-inline input[type=checkbox],.radio input[type=radio],.radio-inline input[type=radio]{position:absolute;margin-left:-20px}.checkbox+.checkbox,.radio+.radio{margin-top:-5px}.checkbox-inline,.radio-inline{display:inline-block;padding-left:20px;margin-bottom:0;vertical-align:middle;font-weight:400;cursor:pointer}.checkbox-inline+.checkbox-inline,.radio-inline+.radio-inline{margin-top:0;margin-left:10px}.checkbox-inline.disabled,.checkbox.disabled label,.radio-inline.disabled,.radio.disabled label,fieldset[disabled] .checkbox label,fieldset[disabled] .checkbox-inline,fieldset[disabled] .radio label,fieldset[disabled] .radio-inline,fieldset[disabled] input[type=checkbox],fieldset[disabled] input[type=radio],input[type=checkbox].disabled,input[type=checkbox][disabled],input[type=radio].disabled,input[type=radio][disabled]{cursor:not-allowed}.form-control-static{padding-top:7px;padding-bottom:7px;margin-bottom:0}.form-control-static.input-lg,.form-control-static.input-sm{padding-left:0;padding-right:0}.form-horizontal .form-group-sm .form-control,.input-sm{height:30px;padding:5px 10px;font-size:12px;line-height:1.5;border-radius:3px}select.input-sm{height:30px;line-height:30px}select[multiple].input-sm,textarea.input-sm{height:auto}.form-horizontal .form-group-lg .form-control,.input-lg{height:46px;padding:10px 16px;font-size:18px;line-height:1.33;border-radius:6px}select.input-lg{height:46px;line-height:46px}select[multiple].input-lg,textarea.input-lg{height:auto}.has-feedback{position:relative}.has-feedback .form-control{padding-right:42.5px}.form-control-feedback{position:absolute;top:25px;right:0;z-index:2;display:block;width:34px;height:34px;line-height:34px;text-align:center}.input-lg+.form-control-feedback{width:46px;height:46px;line-height:46px}.input-sm+.form-control-feedback{width:30px;height:30px;line-height:30px}.has-success .checkbox,.has-success .checkbox-inline,.has-success .control-label,.has-success .help-block,.has-success .radio,.has-success .radio-inline{color:#00b588}.has-success .form-control{border-color:#00b588;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);box-shadow:inset 0 1px 1px rgba(0,0,0,.075)}.has-success .form-control:focus{border-color:#008261;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #1cffc7;box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #1cffc7}.has-success .input-group-addon{color:#00b588;border-color:#00b588;background-color:#00b588}.has-success .form-control-feedback{color:#00b588}.has-warning .checkbox,.has-warning .checkbox-inline,.has-warning .control-label,.has-warning .help-block,.has-warning .radio,.has-warning .radio-inline{color:#8a6d3b}.has-warning .form-control{border-color:#8a6d3b;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);box-shadow:inset 0 1px 1px rgba(0,0,0,.075)}.has-warning .form-control:focus{border-color:#66512c;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #c0a16b;box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #c0a16b}.has-warning .input-group-addon{color:#8a6d3b;border-color:#8a6d3b;background-color:#fcf8e3}.has-warning .form-control-feedback{color:#8a6d3b}.has-error .checkbox,.has-error .checkbox-inline,.has-error .control-label,.has-error .help-block,.has-error .radio,.has-error .radio-inline{color:#c0392b}.has-error .form-control{border-color:#c0392b;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);box-shadow:inset 0 1px 1px rgba(0,0,0,.075)}.has-error .form-control:focus{border-color:#962d22;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #df7c72;box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #df7c72}.has-error .input-group-addon{color:#c0392b;border-color:#c0392b;background-color:#c0392b}.has-error .form-control-feedback{color:#c0392b}.has-feedback label.sr-only~.form-control-feedback{top:0}.help-block{display:block;margin-top:5px;margin-bottom:10px;color:#737373}@media (min-width:768px){.form-inline .form-group{display:inline-block;margin-bottom:0;vertical-align:middle}.form-inline .form-control{display:inline-block;width:auto;vertical-align:middle}.form-inline .input-group{display:inline-table;vertical-align:middle}.form-inline .input-group .form-control,.form-inline .input-group .input-group-addon,.form-inline .input-group .input-group-btn{width:auto}.form-inline .input-group>.form-control{width:100%}.form-inline .control-label{margin-bottom:0;vertical-align:middle}.form-inline .checkbox,.form-inline .radio{display:inline-block;margin-top:0;margin-bottom:0;vertical-align:middle}.form-inline .checkbox label,.form-inline .radio label{padding-left:0}.form-inline .checkbox input[type=checkbox],.form-inline .radio input[type=radio]{position:relative;margin-left:0}.form-inline .has-feedback .form-control-feedback{top:0}}.form-horizontal .checkbox,.form-horizontal .checkbox-inline,.form-horizontal .radio,.form-horizontal .radio-inline{margin-top:0;margin-bottom:0;padding-top:7px}.form-horizontal .checkbox,.form-horizontal .radio{min-height:27px}.form-horizontal .form-group{margin-left:-15px;margin-right:-15px}@media (min-width:768px){.form-horizontal .control-label{text-align:right;margin-bottom:0;padding-top:7px}}.form-horizontal .has-feedback .form-control-feedback{top:0;right:15px}@media (min-width:768px){.form-horizontal .form-group-lg .control-label{padding-top:14.3px}}@media (min-width:768px){.form-horizontal .form-group-sm .control-label{padding-top:6px}}.btn{display:inline-block;margin-bottom:0;font-weight:400;text-align:center;vertical-align:middle;cursor:pointer;background-image:none;border:1px solid transparent;white-space:nowrap;padding:6px 12px;font-size:14px;line-height:1.42857143;border-radius:4px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.btn.active:focus,.btn:active:focus,.btn:focus{outline:dotted thin;outline:-webkit-focus-ring-color auto 5px;outline-offset:-2px}.btn:focus,.btn:hover{color:#333;text-decoration:none}.btn.active,.btn:active{outline:0;background-image:none;-webkit-box-shadow:inset 0 3px 5px rgba(0,0,0,.125);box-shadow:inset 0 3px 5px rgba(0,0,0,.125)}.btn.disabled,.btn[disabled],fieldset[disabled] .btn{cursor:not-allowed;pointer-events:none;opacity:.65;filter:alpha(opacity=65);-webkit-box-shadow:none;box-shadow:none}.btn-default{color:#333;background-color:#fff;border-color:#ccc}.btn-default.active,.btn-default:active,.btn-default:focus,.btn-default:hover,.open>.dropdown-toggle.btn-default{color:#333;background-color:#e6e6e6;border-color:#adadad}.btn-default.active,.btn-default:active,.open>.dropdown-toggle.btn-default{background-image:none}.btn-default.disabled,.btn-default.disabled.active,.btn-default.disabled:active,.btn-default.disabled:focus,.btn-default.disabled:hover,.btn-default[disabled],.btn-default[disabled].active,.btn-default[disabled]:active,.btn-default[disabled]:focus,.btn-default[disabled]:hover,fieldset[disabled] .btn-default,fieldset[disabled] .btn-default.active,fieldset[disabled] .btn-default:active,fieldset[disabled] .btn-default:focus,fieldset[disabled] .btn-default:hover{background-color:#fff;border-color:#ccc}.btn-default .badge{color:#fff;background-color:#333}.btn-primary{color:#fff;background-color:#179ede;border-color:#158ec7}.btn-primary.active,.btn-primary:active,.btn-primary:focus,.btn-primary:hover,.open>.dropdown-toggle.btn-primary{color:#fff;background-color:#127db0;border-color:#0f668f}.btn-primary.active,.btn-primary:active,.open>.dropdown-toggle.btn-primary{background-image:none}.btn-primary.disabled,.btn-primary.disabled.active,.btn-primary.disabled:active,.btn-primary.disabled:focus,.btn-primary.disabled:hover,.btn-primary[disabled],.btn-primary[disabled].active,.btn-primary[disabled]:active,.btn-primary[disabled]:focus,.btn-primary[disabled]:hover,fieldset[disabled] .btn-primary,fieldset[disabled] .btn-primary.active,fieldset[disabled] .btn-primary:active,fieldset[disabled] .btn-primary:focus,fieldset[disabled] .btn-primary:hover{background-color:#179ede;border-color:#158ec7}.btn-primary .badge{color:#179ede;background-color:#fff}.btn-success{color:#fff;background-color:#00b588;border-color:#009b75}.btn-success.active,.btn-success:active,.btn-success:focus,.btn-success:hover,.open>.dropdown-toggle.btn-success{color:#fff;background-color:#008261;border-color:#005e47}.btn-success.active,.btn-success:active,.open>.dropdown-toggle.btn-success{background-image:none}.btn-success.disabled,.btn-success.disabled.active,.btn-success.disabled:active,.btn-success.disabled:focus,.btn-success.disabled:hover,.btn-success[disabled],.btn-success[disabled].active,.btn-success[disabled]:active,.btn-success[disabled]:focus,.btn-success[disabled]:hover,fieldset[disabled] .btn-success,fieldset[disabled] .btn-success.active,fieldset[disabled] .btn-success:active,fieldset[disabled] .btn-success:focus,fieldset[disabled] .btn-success:hover{background-color:#00b588;border-color:#009b75}.btn-success .badge{color:#00b588;background-color:#fff}.btn-info{color:#fff;background-color:#39afe1;border-color:#23a6de}.btn-info.active,.btn-info:active,.btn-info:focus,.btn-info:hover,.open>.dropdown-toggle.btn-info{color:#fff;background-color:#1e96c9;border-color:#1a7faa}.btn-info.active,.btn-info:active,.open>.dropdown-toggle.btn-info{background-image:none}.btn-info.disabled,.btn-info.disabled.active,.btn-info.disabled:active,.btn-info.disabled:focus,.btn-info.disabled:hover,.btn-info[disabled],.btn-info[disabled].active,.btn-info[disabled]:active,.btn-info[disabled]:focus,.btn-info[disabled]:hover,fieldset[disabled] .btn-info,fieldset[disabled] .btn-info.active,fieldset[disabled] .btn-info:active,fieldset[disabled] .btn-info:focus,fieldset[disabled] .btn-info:hover{background-color:#39afe1;border-color:#23a6de}.btn-info .badge{color:#39afe1;background-color:#fff}.btn-warning{color:#fff;background-color:#f0ad4e;border-color:#eea236}.btn-warning.active,.btn-warning:active,.btn-warning:focus,.btn-warning:hover,.open>.dropdown-toggle.btn-warning{color:#fff;background-color:#ec971f;border-color:#d58512}.btn-warning.active,.btn-warning:active,.open>.dropdown-toggle.btn-warning{background-image:none}.btn-warning.disabled,.btn-warning.disabled.active,.btn-warning.disabled:active,.btn-warning.disabled:focus,.btn-warning.disabled:hover,.btn-warning[disabled],.btn-warning[disabled].active,.btn-warning[disabled]:active,.btn-warning[disabled]:focus,.btn-warning[disabled]:hover,fieldset[disabled] .btn-warning,fieldset[disabled] .btn-warning.active,fieldset[disabled] .btn-warning:active,fieldset[disabled] .btn-warning:focus,fieldset[disabled] .btn-warning:hover{background-color:#f0ad4e;border-color:#eea236}.btn-warning .badge{color:#f0ad4e;background-color:#fff}.btn-danger{color:#fff;background-color:#c0392b;border-color:#ab3326}.btn-danger.active,.btn-danger:active,.btn-danger:focus,.btn-danger:hover,.open>.dropdown-toggle.btn-danger{color:#fff;background-color:#962d22;border-color:#79241b}.btn-danger.active,.btn-danger:active,.open>.dropdown-toggle.btn-danger{background-image:none}.btn-danger.disabled,.btn-danger.disabled.active,.btn-danger.disabled:active,.btn-danger.disabled:focus,.btn-danger.disabled:hover,.btn-danger[disabled],.btn-danger[disabled].active,.btn-danger[disabled]:active,.btn-danger[disabled]:focus,.btn-danger[disabled]:hover,fieldset[disabled] .btn-danger,fieldset[disabled] .btn-danger.active,fieldset[disabled] .btn-danger:active,fieldset[disabled] .btn-danger:focus,fieldset[disabled] .btn-danger:hover{background-color:#c0392b;border-color:#ab3326}.btn-danger .badge{color:#c0392b;background-color:#fff}.btn-link{color:#179ede;font-weight:400;cursor:pointer;border-radius:0}.btn-link,.btn-link:active,.btn-link[disabled],fieldset[disabled] .btn-link{background-color:transparent;-webkit-box-shadow:none;box-shadow:none}.btn-link,.btn-link:active,.btn-link:focus,.btn-link:hover{border-color:transparent}.btn-link:focus,.btn-link:hover{color:#106d99;text-decoration:underline;background-color:transparent}.btn-link[disabled]:focus,.btn-link[disabled]:hover,fieldset[disabled] .btn-link:focus,fieldset[disabled] .btn-link:hover{color:#777;text-decoration:none}.btn-group-lg>.btn,.btn-lg{padding:10px 16px;font-size:18px;line-height:1.33;border-radius:6px}.btn-group-sm>.btn,.btn-sm{padding:5px 10px;font-size:12px;line-height:1.5;border-radius:3px}.btn-group-xs>.btn,.btn-xs{padding:1px 5px;font-size:12px;line-height:1.5;border-radius:3px}.btn-block{display:block;width:100%}.btn-block+.btn-block{margin-top:5px}input[type=button].btn-block,input[type=reset].btn-block,input[type=submit].btn-block{width:100%}.fade{opacity:0;-webkit-transition:opacity .15s linear;-o-transition:opacity .15s linear;transition:opacity .15s linear}.fade.in{opacity:1}.collapse{display:none}.collapse.in{display:block}tr.collapse.in{display:table-row}tbody.collapse.in{display:table-row-group}.collapsing{position:relative;height:0;overflow:hidden;-webkit-transition:height .35s ease;-o-transition:height .35s ease;transition:height .35s ease}.caret{display:inline-block;width:0;height:0;margin-left:2px;vertical-align:middle;border-top:4px solid;border-right:4px solid transparent;border-left:4px solid transparent}.dropdown{position:relative}.dropdown-toggle:focus{outline:0}.dropdown-menu{position:absolute;top:100%;left:0;z-index:1000;display:none;float:left;min-width:160px;padding:5px 0;margin:2px 0 0;list-style:none;font-size:14px;text-align:left;background-color:#222;border:1px solid #ccc;border:1px solid rgba(0,0,0,.15);border-radius:4px;-webkit-box-shadow:0 6px 12px rgba(0,0,0,.175);box-shadow:0 6px 12px rgba(0,0,0,.175);background-clip:padding-box}.dropdown-menu.pull-right{right:0;left:auto}.dropdown-menu .divider{height:1px;margin:9px 0;overflow:hidden;background-color:#e5e5e5}.dropdown-menu>li>a{display:block;padding:3px 20px;clear:both;font-weight:400;line-height:1.42857143;color:#fff;white-space:nowrap}.dropdown-menu>li>a:focus,.dropdown-menu>li>a:hover{text-decoration:none;color:#262626;background-color:#f5f5f5}.dropdown-menu>.active>a,.dropdown-menu>.active>a:focus,.dropdown-menu>.active>a:hover{color:#fff;text-decoration:none;outline:0;background-color:#179ede}.dropdown-menu>.disabled>a,.dropdown-menu>.disabled>a:focus,.dropdown-menu>.disabled>a:hover{color:#777}.dropdown-menu>.disabled>a:focus,.dropdown-menu>.disabled>a:hover{text-decoration:none;background-color:transparent;background-image:none;filter:progid:DXImageTransform.Microsoft.gradient(enabled=false);cursor:not-allowed}.open>.dropdown-menu{display:block}.open>a{outline:0}.dropdown-menu-right{left:auto;right:0}.dropdown-menu-left{left:0;right:auto}.dropdown-header{display:block;padding:3px 20px;font-size:12px;line-height:1.42857143;color:#777;white-space:nowrap}.dropdown-backdrop{position:fixed;left:0;right:0;bottom:0;top:0;z-index:990}.pull-right>.dropdown-menu{right:0;left:auto}.dropup .caret,.navbar-fixed-bottom .dropdown .caret{border-top:0;border-bottom:4px solid;content:""}.dropup .dropdown-menu,.navbar-fixed-bottom .dropdown .dropdown-menu{top:auto;bottom:100%;margin-bottom:1px}@media (min-width:768px){.navbar-right .dropdown-menu{left:auto;right:0}.navbar-right .dropdown-menu-left{left:0;right:auto}}.btn-group,.btn-group-vertical{position:relative;display:inline-block;vertical-align:middle}.btn-group-vertical>.btn,.btn-group>.btn{position:relative;float:left}.btn-group-vertical>.btn.active,.btn-group-vertical>.btn:active,.btn-group-vertical>.btn:focus,.btn-group-vertical>.btn:hover,.btn-group>.btn.active,.btn-group>.btn:active,.btn-group>.btn:focus,.btn-group>.btn:hover{z-index:2}.btn-group-vertical>.btn:focus,.btn-group>.btn:focus{outline:0}.btn-group .btn+.btn,.btn-group .btn+.btn-group,.btn-group .btn-group+.btn,.btn-group .btn-group+.btn-group{margin-left:-1px}.btn-toolbar{margin-left:-5px}.btn-toolbar .btn-group,.btn-toolbar .input-group{float:left}.btn-toolbar>.btn,.btn-toolbar>.btn-group,.btn-toolbar>.input-group{margin-left:5px}.btn-group>.btn:not(:first-child):not(:last-child):not(.dropdown-toggle){border-radius:0}.btn-group>.btn:first-child{margin-left:0}.btn-group>.btn:first-child:not(:last-child):not(.dropdown-toggle){border-bottom-right-radius:0;border-top-right-radius:0}.btn-group>.btn:last-child:not(:first-child),.btn-group>.dropdown-toggle:not(:first-child){border-bottom-left-radius:0;border-top-left-radius:0}.btn-group>.btn-group{float:left}.btn-group>.btn-group:not(:first-child):not(:last-child)>.btn{border-radius:0}.btn-group>.btn-group:first-child>.btn:last-child,.btn-group>.btn-group:first-child>.dropdown-toggle{border-bottom-right-radius:0;border-top-right-radius:0}.btn-group>.btn-group:last-child>.btn:first-child{border-bottom-left-radius:0;border-top-left-radius:0}.btn-group .dropdown-toggle:active,.btn-group.open .dropdown-toggle{outline:0}.btn-group>.btn+.dropdown-toggle{padding-left:8px;padding-right:8px}.btn-group>.btn-lg+.dropdown-toggle{padding-left:12px;padding-right:12px}.btn-group.open .dropdown-toggle{-webkit-box-shadow:inset 0 3px 5px rgba(0,0,0,.125);box-shadow:inset 0 3px 5px rgba(0,0,0,.125)}.btn-group.open .dropdown-toggle.btn-link{-webkit-box-shadow:none;box-shadow:none}.btn .caret{margin-left:0}.btn-lg .caret{border-width:5px 5px 0}.dropup .btn-lg .caret{border-width:0 5px 5px}.btn-group-vertical>.btn,.btn-group-vertical>.btn-group,.btn-group-vertical>.btn-group>.btn{display:block;float:none;width:100%;max-width:100%}.btn-group-vertical>.btn-group>.btn{float:none}.btn-group-vertical>.btn+.btn,.btn-group-vertical>.btn+.btn-group,.btn-group-vertical>.btn-group+.btn,.btn-group-vertical>.btn-group+.btn-group{margin-top:-1px;margin-left:0}.btn-group-vertical>.btn:not(:first-child):not(:last-child){border-radius:0}.btn-group-vertical>.btn:first-child:not(:last-child){border-top-right-radius:4px;border-bottom-right-radius:0;border-bottom-left-radius:0}.btn-group-vertical>.btn:last-child:not(:first-child){border-bottom-left-radius:4px;border-top-right-radius:0;border-top-left-radius:0}.btn-group-vertical>.btn-group:not(:first-child):not(:last-child)>.btn{border-radius:0}.btn-group-vertical>.btn-group:first-child:not(:last-child)>.btn:last-child,.btn-group-vertical>.btn-group:first-child:not(:last-child)>.dropdown-toggle{border-bottom-right-radius:0;border-bottom-left-radius:0}.btn-group-vertical>.btn-group:last-child:not(:first-child)>.btn:first-child{border-top-right-radius:0;border-top-left-radius:0}.btn-group-justified{display:table;width:100%;table-layout:fixed;border-collapse:separate}.btn-group-justified>.btn,.btn-group-justified>.btn-group{float:none;display:table-cell;width:1%}.btn-group-justified>.btn-group .btn{width:100%}.btn-group-justified>.btn-group .dropdown-menu{left:auto}[data-toggle=buttons]>.btn>input[type=checkbox],[data-toggle=buttons]>.btn>input[type=radio]{position:absolute;z-index:-1;opacity:0;filter:alpha(opacity=0)}.input-group{position:relative;display:table;border-collapse:separate}.input-group[class*=col-]{float:none;padding-left:0;padding-right:0}.input-group .form-control{position:relative;z-index:2;float:left;width:100%;margin-bottom:0}.input-group-lg>.form-control,.input-group-lg>.input-group-addon,.input-group-lg>.input-group-btn>.btn{height:46px;padding:10px 16px;font-size:18px;line-height:1.33;border-radius:6px}select.input-group-lg>.form-control,select.input-group-lg>.input-group-addon,select.input-group-lg>.input-group-btn>.btn{height:46px;line-height:46px}select[multiple].input-group-lg>.form-control,select[multiple].input-group-lg>.input-group-addon,select[multiple].input-group-lg>.input-group-btn>.btn,textarea.input-group-lg>.form-control,textarea.input-group-lg>.input-group-addon,textarea.input-group-lg>.input-group-btn>.btn{height:auto}.input-group-sm>.form-control,.input-group-sm>.input-group-addon,.input-group-sm>.input-group-btn>.btn{height:30px;padding:5px 10px;font-size:12px;line-height:1.5;border-radius:3px}select.input-group-sm>.form-control,select.input-group-sm>.input-group-addon,select.input-group-sm>.input-group-btn>.btn{height:30px;line-height:30px}select[multiple].input-group-sm>.form-control,select[multiple].input-group-sm>.input-group-addon,select[multiple].input-group-sm>.input-group-btn>.btn,textarea.input-group-sm>.form-control,textarea.input-group-sm>.input-group-addon,textarea.input-group-sm>.input-group-btn>.btn{height:auto}.input-group .form-control,.input-group-addon,.input-group-btn{display:table-cell}.input-group .form-control:not(:first-child):not(:last-child),.input-group-addon:not(:first-child):not(:last-child),.input-group-btn:not(:first-child):not(:last-child){border-radius:0}.input-group-addon,.input-group-btn{width:1%;white-space:nowrap;vertical-align:middle}.input-group-addon{padding:6px 12px;font-size:14px;font-weight:400;line-height:1;color:#555;text-align:center;background-color:#eee;border:1px solid #ccc;border-radius:4px}.input-group-addon.input-sm{padding:5px 10px;font-size:12px;border-radius:3px}.input-group-addon.input-lg{padding:10px 16px;font-size:18px;border-radius:6px}.input-group-addon input[type=checkbox],.input-group-addon input[type=radio]{margin-top:0}.input-group .form-control:first-child,.input-group-addon:first-child,.input-group-btn:first-child>.btn,.input-group-btn:first-child>.btn-group>.btn,.input-group-btn:first-child>.dropdown-toggle,.input-group-btn:last-child>.btn-group:not(:last-child)>.btn,.input-group-btn:last-child>.btn:not(:last-child):not(.dropdown-toggle){border-bottom-right-radius:0;border-top-right-radius:0}.input-group-addon:first-child{border-right:0}.input-group .form-control:last-child,.input-group-addon:last-child,.input-group-btn:first-child>.btn-group:not(:first-child)>.btn,.input-group-btn:first-child>.btn:not(:first-child),.input-group-btn:last-child>.btn,.input-group-btn:last-child>.btn-group>.btn,.input-group-btn:last-child>.dropdown-toggle{border-bottom-left-radius:0;border-top-left-radius:0}.input-group-addon:last-child{border-left:0}.input-group-btn{position:relative;font-size:0;white-space:nowrap}.input-group-btn>.btn{position:relative}.input-group-btn>.btn+.btn{margin-left:-1px}.input-group-btn>.btn:active,.input-group-btn>.btn:focus,.input-group-btn>.btn:hover{z-index:2}.input-group-btn:first-child>.btn,.input-group-btn:first-child>.btn-group{margin-right:-1px}.input-group-btn:last-child>.btn,.input-group-btn:last-child>.btn-group{margin-left:-1px}.nav{margin-bottom:0;padding-left:0;list-style:none}.nav>li{position:relative;display:block}.nav>li>a{position:relative;display:block;padding:10px 15px}.nav>li>a:focus,.nav>li>a:hover{text-decoration:none;background-color:#eee}.nav>li.disabled>a{color:#777}.nav>li.disabled>a:focus,.nav>li.disabled>a:hover{color:#777;text-decoration:none;background-color:transparent;cursor:not-allowed}.nav .open>a,.nav .open>a:focus,.nav .open>a:hover{background-color:#eee;border-color:#179ede}.nav .nav-divider{height:1px;margin:9px 0;overflow:hidden;background-color:#e5e5e5}.nav>li>a>img{max-width:none}.nav-tabs{border-bottom:1px solid #ddd}.nav-tabs>li{float:left;margin-bottom:-1px}.nav-tabs>li>a{margin-right:2px;line-height:1.42857143;border:1px solid transparent;border-radius:4px 4px 0 0}.nav-tabs>li>a:hover{border-color:#eee #eee #ddd}.nav-tabs>li.active>a,.nav-tabs>li.active>a:focus,.nav-tabs>li.active>a:hover{color:#555;background-color:#fff;border:1px solid #ddd;border-bottom-color:transparent;cursor:default}.nav-tabs.nav-justified{width:100%;border-bottom:0}.nav-tabs.nav-justified>li{float:none}.nav-tabs.nav-justified>li>a{text-align:center;margin-bottom:5px}.nav-tabs.nav-justified>.dropdown .dropdown-menu{top:auto;left:auto}@media (min-width:768px){.nav-tabs.nav-justified>li{display:table-cell;width:1%}.nav-tabs.nav-justified>li>a{margin-bottom:0}}.nav-tabs.nav-justified>li>a{margin-right:0;border-radius:4px}.nav-tabs.nav-justified>.active>a,.nav-tabs.nav-justified>.active>a:focus,.nav-tabs.nav-justified>.active>a:hover{border:1px solid #ddd}@media (min-width:768px){.nav-tabs.nav-justified>li>a{border-bottom:1px solid #ddd;border-radius:4px 4px 0 0}.nav-tabs.nav-justified>.active>a,.nav-tabs.nav-justified>.active>a:focus,.nav-tabs.nav-justified>.active>a:hover{border-bottom-color:#fff}}.nav-pills>li{float:left}.nav-pills>li>a{border-radius:4px}.nav-pills>li+li{margin-left:2px}.nav-pills>li.active>a,.nav-pills>li.active>a:focus,.nav-pills>li.active>a:hover{color:#fff;background-color:#179ede}.nav-stacked>li{float:none}.nav-stacked>li+li{margin-top:2px;margin-left:0}.nav-justified{width:100%}.nav-justified>li{float:none}.nav-justified>li>a{text-align:center;margin-bottom:5px}.nav-justified>.dropdown .dropdown-menu{top:auto;left:auto}@media (min-width:768px){.nav-justified>li{display:table-cell;width:1%}.nav-justified>li>a{margin-bottom:0}}.nav-tabs-justified{border-bottom:0}.nav-tabs-justified>li>a{margin-right:0;border-radius:4px}.nav-tabs-justified>.active>a,.nav-tabs-justified>.active>a:focus,.nav-tabs-justified>.active>a:hover{border:1px solid #ddd}@media (min-width:768px){.nav-tabs-justified>li>a{border-bottom:1px solid #ddd;border-radius:4px 4px 0 0}.nav-tabs-justified>.active>a,.nav-tabs-justified>.active>a:focus,.nav-tabs-justified>.active>a:hover{border-bottom-color:#fff}}.tab-content>.tab-pane{display:none}.tab-content>.active{display:block}.nav-tabs .dropdown-menu{margin-top:-1px;border-top-right-radius:0;border-top-left-radius:0}.navbar{position:relative;min-height:50px;margin-bottom:0}@media (min-width:768px){.navbar{border-radius:0}}@media (min-width:768px){.navbar-header{float:left}}.navbar-collapse{overflow-x:visible;padding-right:15px;padding-left:15px;border-top:1px solid transparent;box-shadow:inset 0 1px 0 rgba(255,255,255,.1);-webkit-overflow-scrolling:touch}.navbar-collapse.in{overflow-y:auto}@media (min-width:768px){.navbar-collapse{width:auto;border-top:0;box-shadow:none}.navbar-collapse.collapse{display:block!important;height:auto!important;padding-bottom:0;overflow:visible!important}.navbar-collapse.in{overflow-y:visible}.navbar-fixed-bottom .navbar-collapse,.navbar-fixed-top .navbar-collapse,.navbar-static-top .navbar-collapse{padding-left:0;padding-right:0}}.navbar-fixed-bottom .navbar-collapse,.navbar-fixed-top .navbar-collapse{max-height:340px}@media (max-width:480px) and (orientation:landscape){.navbar-fixed-bottom .navbar-collapse,.navbar-fixed-top .navbar-collapse{max-height:200px}}.container-fluid>.navbar-collapse,.container-fluid>.navbar-header,.container>.navbar-collapse,.container>.navbar-header{margin-right:-15px;margin-left:-15px}@media (min-width:768px){.container-fluid>.navbar-collapse,.container-fluid>.navbar-header,.container>.navbar-collapse,.container>.navbar-header{margin-right:0;margin-left:0}}.navbar-static-top{z-index:1000;border-width:0 0 1px}@media (min-width:768px){.navbar-static-top{border-radius:0}}.navbar-fixed-bottom,.navbar-fixed-top{position:fixed;right:0;left:0;z-index:1030;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}@media (min-width:768px){.navbar-fixed-bottom,.navbar-fixed-top{border-radius:0}}.navbar-fixed-top{top:0;border-width:0 0 1px}.navbar-fixed-bottom{bottom:0;margin-bottom:0;border-width:1px 0 0}.navbar-brand{float:left;padding:15px;font-size:18px;line-height:20px;height:50px}.navbar-brand:focus,.navbar-brand:hover{text-decoration:none}@media (min-width:768px){.navbar>.container .navbar-brand,.navbar>.container-fluid .navbar-brand{margin-left:-15px}}.navbar-toggle{position:relative;float:right;margin-right:15px;padding:9px 10px;margin-top:8px;margin-bottom:8px;background-color:transparent;background-image:none;border:1px solid transparent;border-radius:4px}.navbar-toggle:focus{outline:0}.navbar-toggle .icon-bar{display:block;width:22px;height:2px;border-radius:1px}.navbar-toggle .icon-bar+.icon-bar{margin-top:4px}@media (min-width:768px){.navbar-toggle{display:none}}.navbar-nav{margin:7.5px -15px}.navbar-nav>li>a{padding-top:10px;padding-bottom:10px;line-height:20px}@media (max-width:767px){.navbar-nav .open .dropdown-menu{position:static;float:none;width:auto;margin-top:0;background-color:transparent;border:0;box-shadow:none}.navbar-nav .open .dropdown-menu .dropdown-header,.navbar-nav .open .dropdown-menu>li>a{padding:5px 15px 5px 25px}.navbar-nav .open .dropdown-menu>li>a{line-height:20px}.navbar-nav .open .dropdown-menu>li>a:focus,.navbar-nav .open .dropdown-menu>li>a:hover{background-image:none}}@media (min-width:768px){.navbar-nav{float:left;margin:0}.navbar-nav>li{float:left}.navbar-nav>li>a{padding-top:15px;padding-bottom:15px}.navbar-nav.navbar-right:last-child{margin-right:-15px}}@media (min-width:768px){.navbar-left{float:left!important}.navbar-right{float:right!important}}.navbar-form{margin:8px -15px;padding:10px 15px;border-top:1px solid transparent;border-bottom:1px solid transparent;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,.1),0 1px 0 rgba(255,255,255,.1);box-shadow:inset 0 1px 0 rgba(255,255,255,.1),0 1px 0 rgba(255,255,255,.1)}@media (min-width:768px){.navbar-form .form-group{display:inline-block;margin-bottom:0;vertical-align:middle}.navbar-form .form-control{display:inline-block;width:auto;vertical-align:middle}.navbar-form .input-group{display:inline-table;vertical-align:middle}.navbar-form .input-group .form-control,.navbar-form .input-group .input-group-addon,.navbar-form .input-group .input-group-btn{width:auto}.navbar-form .input-group>.form-control{width:100%}.navbar-form .control-label{margin-bottom:0;vertical-align:middle}.navbar-form .checkbox,.navbar-form .radio{display:inline-block;margin-top:0;margin-bottom:0;vertical-align:middle}.navbar-form .checkbox label,.navbar-form .radio label{padding-left:0}.navbar-form .checkbox input[type=checkbox],.navbar-form .radio input[type=radio]{position:relative;margin-left:0}.navbar-form .has-feedback .form-control-feedback{top:0}}@media (max-width:767px){.navbar-form .form-group{margin-bottom:5px}}@media (min-width:768px){.navbar-form{width:auto;border:0;margin-left:0;margin-right:0;padding-top:0;padding-bottom:0;-webkit-box-shadow:none;box-shadow:none}.navbar-form.navbar-right:last-child{margin-right:-15px}}.navbar-nav>li>.dropdown-menu{margin-top:0;border-top-right-radius:0;border-top-left-radius:0}.navbar-fixed-bottom .navbar-nav>li>.dropdown-menu{border-bottom-right-radius:0;border-bottom-left-radius:0}.navbar-btn{margin-top:8px;margin-bottom:8px}.navbar-btn.btn-sm{margin-top:10px;margin-bottom:10px}.navbar-btn.btn-xs{margin-top:14px;margin-bottom:14px}.navbar-text{margin-top:15px;margin-bottom:15px}@media (min-width:768px){.navbar-text{float:left;margin-left:15px;margin-right:15px}.navbar-text.navbar-right:last-child{margin-right:0}}.navbar-default{background-color:#f8f8f8;border-color:#e7e7e7}.navbar-default .navbar-brand{color:#777}.navbar-default .navbar-brand:focus,.navbar-default .navbar-brand:hover{color:#5e5e5e;background-color:transparent}.navbar-default .navbar-nav>li>a,.navbar-default .navbar-text{color:#777}.navbar-default .navbar-nav>li>a:focus,.navbar-default .navbar-nav>li>a:hover{color:#333;background-color:transparent}.navbar-default .navbar-nav>.active>a,.navbar-default .navbar-nav>.active>a:focus,.navbar-default .navbar-nav>.active>a:hover{color:#555;background-color:#e7e7e7}.navbar-default .navbar-nav>.disabled>a,.navbar-default .navbar-nav>.disabled>a:focus,.navbar-default .navbar-nav>.disabled>a:hover{color:#ccc;background-color:transparent}.navbar-default .navbar-toggle{border-color:#ddd}.navbar-default .navbar-toggle:focus,.navbar-default .navbar-toggle:hover{background-color:#ddd}.navbar-default .navbar-toggle .icon-bar{background-color:#888}.navbar-default .navbar-collapse,.navbar-default .navbar-form{border-color:#e7e7e7}.navbar-default .navbar-nav>.open>a,.navbar-default .navbar-nav>.open>a:focus,.navbar-default .navbar-nav>.open>a:hover{background-color:#e7e7e7;color:#555}@media (max-width:767px){.navbar-default .navbar-nav .open .dropdown-menu>li>a{color:#777}.navbar-default .navbar-nav .open .dropdown-menu>li>a:focus,.navbar-default .navbar-nav .open .dropdown-menu>li>a:hover{color:#333;background-color:transparent}.navbar-default .navbar-nav .open .dropdown-menu>.active>a,.navbar-default .navbar-nav .open .dropdown-menu>.active>a:focus,.navbar-default .navbar-nav .open .dropdown-menu>.active>a:hover{color:#555;background-color:#e7e7e7}.navbar-default .navbar-nav .open .dropdown-menu>.disabled>a,.navbar-default .navbar-nav .open .dropdown-menu>.disabled>a:focus,.navbar-default .navbar-nav .open .dropdown-menu>.disabled>a:hover{color:#ccc;background-color:transparent}}.navbar-default .navbar-link{color:#777}.navbar-default .navbar-link:hover{color:#333}.navbar-default .btn-link{color:#777}.navbar-default .btn-link:focus,.navbar-default .btn-link:hover{color:#333}.navbar-default .btn-link[disabled]:focus,.navbar-default .btn-link[disabled]:hover,fieldset[disabled] .navbar-default .btn-link:focus,fieldset[disabled] .navbar-default .btn-link:hover{color:#ccc}.navbar-inverse{background-color:#2c3033;border-color:#141618}.navbar-inverse .navbar-brand{color:#ccc}.navbar-inverse .navbar-brand:focus,.navbar-inverse .navbar-brand:hover{color:#fff;background-color:transparent}.navbar-inverse .navbar-nav>li>a,.navbar-inverse .navbar-text{color:#ccc}.navbar-inverse .navbar-nav>li>a:focus,.navbar-inverse .navbar-nav>li>a:hover{color:#fff;background-color:transparent}.navbar-inverse .navbar-nav>.active>a,.navbar-inverse .navbar-nav>.active>a:focus,.navbar-inverse .navbar-nav>.active>a:hover{color:#fff;background-color:#141618}.navbar-inverse .navbar-nav>.disabled>a,.navbar-inverse .navbar-nav>.disabled>a:focus,.navbar-inverse .navbar-nav>.disabled>a:hover{color:#444;background-color:transparent}.navbar-inverse .navbar-toggle{border-color:#333}.navbar-inverse .navbar-toggle:focus,.navbar-inverse .navbar-toggle:hover{background-color:#333}.navbar-inverse .navbar-toggle .icon-bar{background-color:#fff}.navbar-inverse .navbar-collapse,.navbar-inverse .navbar-form{border-color:#1b1e20}.navbar-inverse .navbar-nav>.open>a,.navbar-inverse .navbar-nav>.open>a:focus,.navbar-inverse .navbar-nav>.open>a:hover{background-color:#141618;color:#fff}@media (max-width:767px){.navbar-inverse .navbar-nav .open .dropdown-menu>.dropdown-header{border-color:#141618}.navbar-inverse .navbar-nav .open .dropdown-menu .divider{background-color:#141618}.navbar-inverse .navbar-nav .open .dropdown-menu>li>a{color:#ccc}.navbar-inverse .navbar-nav .open .dropdown-menu>li>a:focus,.navbar-inverse .navbar-nav .open .dropdown-menu>li>a:hover{color:#fff;background-color:transparent}.navbar-inverse .navbar-nav .open .dropdown-menu>.active>a,.navbar-inverse .navbar-nav .open .dropdown-menu>.active>a:focus,.navbar-inverse .navbar-nav .open .dropdown-menu>.active>a:hover{color:#fff;background-color:#141618}.navbar-inverse .navbar-nav .open .dropdown-menu>.disabled>a,.navbar-inverse .navbar-nav .open .dropdown-menu>.disabled>a:focus,.navbar-inverse .navbar-nav .open .dropdown-menu>.disabled>a:hover{color:#444;background-color:transparent}}.navbar-inverse .navbar-link{color:#ccc}.navbar-inverse .navbar-link:hover{color:#fff}.navbar-inverse .btn-link{color:#ccc}.navbar-inverse .btn-link:focus,.navbar-inverse .btn-link:hover{color:#fff}.navbar-inverse .btn-link[disabled]:focus,.navbar-inverse .btn-link[disabled]:hover,fieldset[disabled] .navbar-inverse .btn-link:focus,fieldset[disabled] .navbar-inverse .btn-link:hover{color:#444}.breadcrumb{padding:8px 15px;margin-bottom:20px;list-style:none;background-color:#f5f5f5;border-radius:4px}.breadcrumb>li{display:inline-block}.breadcrumb>li+li:before{content:"/\00a0";padding:0 5px;color:#ccc}.breadcrumb>.active{color:#777}.pagination{display:inline-block;padding-left:0;margin:20px 0;border-radius:4px}.pagination>li{display:inline}.pagination>li>a,.pagination>li>span{position:relative;float:left;padding:6px 12px;line-height:1.42857143;text-decoration:none;color:#179ede;background-color:#fff;border:1px solid #ddd;margin-left:-1px}.pagination>li:first-child>a,.pagination>li:first-child>span{margin-left:0;border-bottom-left-radius:4px;border-top-left-radius:4px}.pagination>li:last-child>a,.pagination>li:last-child>span{border-bottom-right-radius:4px;border-top-right-radius:4px}.pagination>li>a:focus,.pagination>li>a:hover,.pagination>li>span:focus,.pagination>li>span:hover{color:#106d99;background-color:#eee;border-color:#ddd}.pagination>.active>a,.pagination>.active>a:focus,.pagination>.active>a:hover,.pagination>.active>span,.pagination>.active>span:focus,.pagination>.active>span:hover{z-index:2;color:#fff;background-color:#179ede;border-color:#179ede;cursor:default}.pagination>.disabled>a,.pagination>.disabled>a:focus,.pagination>.disabled>a:hover,.pagination>.disabled>span,.pagination>.disabled>span:focus,.pagination>.disabled>span:hover{color:#777;background-color:#fff;border-color:#ddd;cursor:not-allowed}.pagination-lg>li>a,.pagination-lg>li>span{padding:10px 16px;font-size:18px}.pagination-lg>li:first-child>a,.pagination-lg>li:first-child>span{border-bottom-left-radius:6px;border-top-left-radius:6px}.pagination-lg>li:last-child>a,.pagination-lg>li:last-child>span{border-bottom-right-radius:6px;border-top-right-radius:6px}.pagination-sm>li>a,.pagination-sm>li>span{padding:5px 10px;font-size:12px}.pagination-sm>li:first-child>a,.pagination-sm>li:first-child>span{border-bottom-left-radius:3px;border-top-left-radius:3px}.pagination-sm>li:last-child>a,.pagination-sm>li:last-child>span{border-bottom-right-radius:3px;border-top-right-radius:3px}.pager{padding-left:0;margin:20px 0;list-style:none;text-align:center}.pager li{display:inline}.pager li>a,.pager li>span{display:inline-block;padding:5px 14px;background-color:#fff;border:1px solid #ddd;border-radius:15px}.pager li>a:focus,.pager li>a:hover{text-decoration:none;background-color:#eee}.pager .next>a,.pager .next>span{float:right}.pager .previous>a,.pager .previous>span{float:left}.pager .disabled>a,.pager .disabled>a:focus,.pager .disabled>a:hover,.pager .disabled>span{color:#777;background-color:#fff;cursor:not-allowed}.label{display:inline;padding:.2em .6em .3em;font-size:75%;font-weight:700;line-height:1;color:#fff;text-align:center;white-space:nowrap;vertical-align:baseline;border-radius:.25em}a.label:focus,a.label:hover{color:#fff;text-decoration:none;cursor:pointer}.label:empty{display:none}.btn .label{position:relative;top:-1px}.label-default{background-color:#777}.label-default[href]:focus,.label-default[href]:hover{background-color:#5e5e5e}.label-primary{background-color:#179ede}.label-primary[href]:focus,.label-primary[href]:hover{background-color:#127db0}.label-success{background-color:#00b588}.label-success[href]:focus,.label-success[href]:hover{background-color:#008261}.label-info{background-color:#39afe1}.label-info[href]:focus,.label-info[href]:hover{background-color:#1e96c9}.label-warning{background-color:#f0ad4e}.label-warning[href]:focus,.label-warning[href]:hover{background-color:#ec971f}.label-danger{background-color:#c0392b}.label-danger[href]:focus,.label-danger[href]:hover{background-color:#962d22}.badge{display:inline-block;min-width:10px;padding:3px 7px;font-size:12px;font-weight:700;color:#fff;line-height:1;vertical-align:baseline;white-space:nowrap;text-align:center;background-color:#777;border-radius:10px}.badge:empty{display:none}.btn .badge{position:relative;top:-1px}.btn-xs .badge{top:0;padding:1px 5px}a.badge:focus,a.badge:hover{color:#fff;text-decoration:none;cursor:pointer}.nav-pills>.active>a>.badge,a.list-group-item.active>.badge{color:#179ede;background-color:#fff}.nav-pills>li>a>.badge{margin-left:3px}.jumbotron{padding:30px;margin-bottom:30px;color:inherit;background-color:#eee}.jumbotron .h1,.jumbotron h1{color:inherit}.jumbotron p{margin-bottom:15px;font-size:21px;font-weight:200}.jumbotron>hr{border-top-color:#d5d5d5}.container .jumbotron{border-radius:6px}.jumbotron .container{max-width:100%}@media screen and (min-width:768px){.jumbotron{padding-top:48px;padding-bottom:48px}.container .jumbotron{padding-left:60px;padding-right:60px}.jumbotron .h1,.jumbotron h1{font-size:63px}}.thumbnail{display:block;padding:4px;margin-bottom:20px;line-height:1.42857143;background-color:#fff;border:1px solid #ddd;border-radius:4px;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;transition:all .2s ease-in-out}.thumbnail a>img,.thumbnail>img{margin-left:auto;margin-right:auto}a.thumbnail.active,a.thumbnail:focus,a.thumbnail:hover{border-color:#179ede}.thumbnail .caption{padding:9px;color:#333}.alert{padding:15px;margin-bottom:20px;border:1px solid transparent;border-radius:4px}.alert h4{margin-top:0;color:inherit}.alert .alert-link{font-weight:700}.alert>p,.alert>ul{margin-bottom:0}.alert>p+p{margin-top:5px}.alert-dismissable,.alert-dismissible{padding-right:35px}.alert-dismissable .close,.alert-dismissible .close{position:relative;top:-2px;right:-21px;color:inherit}.alert-success{background-color:#00b588;border-color:#00b588;color:#00b588}.alert-success hr{border-top-color:#009b75}.alert-success .alert-link{color:#008261}.alert-info{background-color:#39afe1;border-color:#39afe1;color:#39afe1}.alert-info hr{border-top-color:#23a6de}.alert-info .alert-link{color:#1e96c9}.alert-warning{background-color:#fcf8e3;border-color:#faebcc;color:#8a6d3b}.alert-warning hr{border-top-color:#f7e1b5}.alert-warning .alert-link{color:#66512c}.alert-danger{background-color:#c0392b;border-color:#c0392b;color:#c0392b}.alert-danger hr{border-top-color:#ab3326}.alert-danger .alert-link{color:#962d22}@-webkit-keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}@keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}.progress{overflow:hidden;height:20px;margin-bottom:20px;background-color:#f5f5f5;border-radius:4px;-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);box-shadow:inset 0 1px 2px rgba(0,0,0,.1)}.progress-bar{float:left;width:0;height:100%;font-size:12px;line-height:20px;color:#fff;text-align:center;background-color:#179ede;-webkit-box-shadow:inset 0 -1px 0 rgba(0,0,0,.15);box-shadow:inset 0 -1px 0 rgba(0,0,0,.15);-webkit-transition:width .6s ease;-o-transition:width .6s ease;transition:width .6s ease}.progress-bar-striped,.progress-striped .progress-bar{background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:-o-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-size:40px 40px}.progress-bar.active,.progress.active .progress-bar{-webkit-animation:progress-bar-stripes 2s linear infinite;-o-animation:progress-bar-stripes 2s linear infinite;animation:progress-bar-stripes 2s linear infinite}.progress-bar[aria-valuenow="1"],.progress-bar[aria-valuenow="2"]{min-width:30px}.progress-bar[aria-valuenow="0"]{color:#777;min-width:30px;background-color:transparent;background-image:none;box-shadow:none}.progress-bar-success{background-color:#00b588}.progress-striped .progress-bar-success{background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:-o-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent)}.progress-bar-info{background-color:#39afe1}.progress-striped .progress-bar-info{background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:-o-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent)}.progress-bar-warning{background-color:#f0ad4e}.progress-striped .progress-bar-warning{background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:-o-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent)}.progress-bar-danger{background-color:#c0392b}.progress-striped .progress-bar-danger{background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:-o-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent)}.media,.media-body{overflow:hidden;zoom:1}.media,.media .media{margin-top:15px}.media:first-child{margin-top:0}.media-object{display:block}.media-heading{margin:0 0 5px}.media>.pull-left{margin-right:10px}.media>.pull-right{margin-left:10px}.media-list{padding-left:0;list-style:none}.list-group{margin-bottom:20px;padding-left:0}.list-group-item{position:relative;display:block;padding:10px 15px;margin-bottom:-1px;background-color:#fff;border:1px solid #ddd}.list-group-item:first-child{border-top-right-radius:4px;border-top-left-radius:4px}.list-group-item:last-child{margin-bottom:0;border-bottom-right-radius:4px;border-bottom-left-radius:4px}.list-group-item>.badge{float:right}.list-group-item>.badge+.badge{margin-right:5px}a.list-group-item{color:#555}a.list-group-item .list-group-item-heading{color:#333}a.list-group-item:focus,a.list-group-item:hover{text-decoration:none;color:#555;background-color:#f5f5f5}.list-group-item.disabled,.list-group-item.disabled:focus,.list-group-item.disabled:hover{background-color:#eee;color:#777}.list-group-item.disabled .list-group-item-heading,.list-group-item.disabled:focus .list-group-item-heading,.list-group-item.disabled:hover .list-group-item-heading{color:inherit}.list-group-item.disabled .list-group-item-text,.list-group-item.disabled:focus .list-group-item-text,.list-group-item.disabled:hover .list-group-item-text{color:#777}.list-group-item.active,.list-group-item.active:focus,.list-group-item.active:hover{z-index:2;color:#fff;background-color:#179ede;border-color:#179ede}.list-group-item.active .list-group-item-heading,.list-group-item.active .list-group-item-heading>.small,.list-group-item.active .list-group-item-heading>small,.list-group-item.active:focus .list-group-item-heading,.list-group-item.active:focus .list-group-item-heading>.small,.list-group-item.active:focus .list-group-item-heading>small,.list-group-item.active:hover .list-group-item-heading,.list-group-item.active:hover .list-group-item-heading>.small,.list-group-item.active:hover .list-group-item-heading>small{color:inherit}.list-group-item.active .list-group-item-text,.list-group-item.active:focus .list-group-item-text,.list-group-item.active:hover .list-group-item-text{color:#c8e9f9}.list-group-item-success{color:#00b588;background-color:#00b588}a.list-group-item-success{color:#00b588}a.list-group-item-success .list-group-item-heading{color:inherit}a.list-group-item-success:focus,a.list-group-item-success:hover{color:#00b588;background-color:#009b75}a.list-group-item-success.active,a.list-group-item-success.active:focus,a.list-group-item-success.active:hover{color:#fff;background-color:#00b588;border-color:#00b588}.list-group-item-info{color:#39afe1;background-color:#39afe1}a.list-group-item-info{color:#39afe1}a.list-group-item-info .list-group-item-heading{color:inherit}a.list-group-item-info:focus,a.list-group-item-info:hover{color:#39afe1;background-color:#23a6de}a.list-group-item-info.active,a.list-group-item-info.active:focus,a.list-group-item-info.active:hover{color:#fff;background-color:#39afe1;border-color:#39afe1}.list-group-item-warning{color:#8a6d3b;background-color:#fcf8e3}a.list-group-item-warning{color:#8a6d3b}a.list-group-item-warning .list-group-item-heading{color:inherit}a.list-group-item-warning:focus,a.list-group-item-warning:hover{color:#8a6d3b;background-color:#faf2cc}a.list-group-item-warning.active,a.list-group-item-warning.active:focus,a.list-group-item-warning.active:hover{color:#fff;background-color:#8a6d3b;border-color:#8a6d3b}.list-group-item-danger{color:#c0392b;background-color:#c0392b}a.list-group-item-danger{color:#c0392b}a.list-group-item-danger .list-group-item-heading{color:inherit}a.list-group-item-danger:focus,a.list-group-item-danger:hover{color:#c0392b;background-color:#ab3326}a.list-group-item-danger.active,a.list-group-item-danger.active:focus,a.list-group-item-danger.active:hover{color:#fff;background-color:#c0392b;border-color:#c0392b}.list-group-item-heading{margin-top:0;margin-bottom:5px}.list-group-item-text{margin-bottom:0;line-height:1.3}.panel{margin-bottom:20px;background-color:#fff;border:1px solid transparent;border-radius:4px;-webkit-box-shadow:0 1px 1px rgba(0,0,0,.05);box-shadow:0 1px 1px rgba(0,0,0,.05)}.panel-body{padding:15px}.panel-heading{padding:10px 15px;border-bottom:1px solid transparent;border-top-right-radius:3px;border-top-left-radius:3px}.panel-heading>.dropdown .dropdown-toggle{color:inherit}.panel-title{margin-top:0;margin-bottom:0;font-size:16px;color:inherit}.panel-title>a{color:inherit}.panel-footer{padding:10px 15px;background-color:#f5f5f5;border-top:1px solid #ddd;border-bottom-right-radius:3px;border-bottom-left-radius:3px}.panel>.list-group{margin-bottom:0}.panel>.list-group .list-group-item{border-width:1px 0;border-radius:0}.panel>.list-group:first-child .list-group-item:first-child{border-top:0;border-top-right-radius:3px;border-top-left-radius:3px}.panel>.list-group:last-child .list-group-item:last-child{border-bottom:0;border-bottom-right-radius:3px;border-bottom-left-radius:3px}.list-group+.panel-footer,.panel-heading+.list-group .list-group-item:first-child{border-top-width:0}.panel>.panel-collapse>.table,.panel>.table,.panel>.table-responsive>.table{margin-bottom:0}.panel>.table-responsive:first-child>.table:first-child,.panel>.table:first-child{border-top-right-radius:3px;border-top-left-radius:3px}.panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child td:first-child,.panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child th:first-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child td:first-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child th:first-child,.panel>.table:first-child>tbody:first-child>tr:first-child td:first-child,.panel>.table:first-child>tbody:first-child>tr:first-child th:first-child,.panel>.table:first-child>thead:first-child>tr:first-child td:first-child,.panel>.table:first-child>thead:first-child>tr:first-child th:first-child{border-top-left-radius:3px}.panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child td:last-child,.panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child th:last-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child td:last-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child th:last-child,.panel>.table:first-child>tbody:first-child>tr:first-child td:last-child,.panel>.table:first-child>tbody:first-child>tr:first-child th:last-child,.panel>.table:first-child>thead:first-child>tr:first-child td:last-child,.panel>.table:first-child>thead:first-child>tr:first-child th:last-child{border-top-right-radius:3px}.panel>.table-responsive:last-child>.table:last-child,.panel>.table:last-child{border-bottom-right-radius:3px;border-bottom-left-radius:3px}.panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child td:first-child,.panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child th:first-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child td:first-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child th:first-child,.panel>.table:last-child>tbody:last-child>tr:last-child td:first-child,.panel>.table:last-child>tbody:last-child>tr:last-child th:first-child,.panel>.table:last-child>tfoot:last-child>tr:last-child td:first-child,.panel>.table:last-child>tfoot:last-child>tr:last-child th:first-child{border-bottom-left-radius:3px}.panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child td:last-child,.panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child th:last-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child td:last-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child th:last-child,.panel>.table:last-child>tbody:last-child>tr:last-child td:last-child,.panel>.table:last-child>tbody:last-child>tr:last-child th:last-child,.panel>.table:last-child>tfoot:last-child>tr:last-child td:last-child,.panel>.table:last-child>tfoot:last-child>tr:last-child th:last-child{border-bottom-right-radius:3px}.panel>.panel-body+.table,.panel>.panel-body+.table-responsive{border-top:1px solid #ddd}.panel>.table>tbody:first-child>tr:first-child td,.panel>.table>tbody:first-child>tr:first-child th{border-top:0}.panel>.table-bordered,.panel>.table-responsive>.table-bordered{border:0}.panel>.table-bordered>tbody>tr>td:first-child,.panel>.table-bordered>tbody>tr>th:first-child,.panel>.table-bordered>tfoot>tr>td:first-child,.panel>.table-bordered>tfoot>tr>th:first-child,.panel>.table-bordered>thead>tr>td:first-child,.panel>.table-bordered>thead>tr>th:first-child,.panel>.table-responsive>.table-bordered>tbody>tr>td:first-child,.panel>.table-responsive>.table-bordered>tbody>tr>th:first-child,.panel>.table-responsive>.table-bordered>tfoot>tr>td:first-child,.panel>.table-responsive>.table-bordered>tfoot>tr>th:first-child,.panel>.table-responsive>.table-bordered>thead>tr>td:first-child,.panel>.table-responsive>.table-bordered>thead>tr>th:first-child{border-left:0}.panel>.table-bordered>tbody>tr>td:last-child,.panel>.table-bordered>tbody>tr>th:last-child,.panel>.table-bordered>tfoot>tr>td:last-child,.panel>.table-bordered>tfoot>tr>th:last-child,.panel>.table-bordered>thead>tr>td:last-child,.panel>.table-bordered>thead>tr>th:last-child,.panel>.table-responsive>.table-bordered>tbody>tr>td:last-child,.panel>.table-responsive>.table-bordered>tbody>tr>th:last-child,.panel>.table-responsive>.table-bordered>tfoot>tr>td:last-child,.panel>.table-responsive>.table-bordered>tfoot>tr>th:last-child,.panel>.table-responsive>.table-bordered>thead>tr>td:last-child,.panel>.table-responsive>.table-bordered>thead>tr>th:last-child{border-right:0}.panel>.table-bordered>tbody>tr:first-child>td,.panel>.table-bordered>tbody>tr:first-child>th,.panel>.table-bordered>tbody>tr:last-child>td,.panel>.table-bordered>tbody>tr:last-child>th,.panel>.table-bordered>tfoot>tr:last-child>td,.panel>.table-bordered>tfoot>tr:last-child>th,.panel>.table-bordered>thead>tr:first-child>td,.panel>.table-bordered>thead>tr:first-child>th,.panel>.table-responsive>.table-bordered>tbody>tr:first-child>td,.panel>.table-responsive>.table-bordered>tbody>tr:first-child>th,.panel>.table-responsive>.table-bordered>tbody>tr:last-child>td,.panel>.table-responsive>.table-bordered>tbody>tr:last-child>th,.panel>.table-responsive>.table-bordered>tfoot>tr:last-child>td,.panel>.table-responsive>.table-bordered>tfoot>tr:last-child>th,.panel>.table-responsive>.table-bordered>thead>tr:first-child>td,.panel>.table-responsive>.table-bordered>thead>tr:first-child>th{border-bottom:0}.panel>.table-responsive{border:0;margin-bottom:0}.panel-group{margin-bottom:20px}.panel-group .panel{margin-bottom:0;border-radius:4px}.panel-group .panel+.panel{margin-top:5px}.panel-group .panel-heading{border-bottom:0}.panel-group .panel-heading+.panel-collapse>.panel-body{border-top:1px solid #ddd}.panel-group .panel-footer{border-top:0}.panel-group .panel-footer+.panel-collapse .panel-body{border-bottom:1px solid #ddd}.panel-default{border-color:#ddd}.panel-default>.panel-heading{color:#333;background-color:#f5f5f5;border-color:#ddd}.panel-default>.panel-heading+.panel-collapse>.panel-body{border-top-color:#ddd}.panel-default>.panel-heading .badge{color:#f5f5f5;background-color:#333}.panel-default>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#ddd}.panel-primary{border-color:#179ede}.panel-primary>.panel-heading{color:#fff;background-color:#179ede;border-color:#179ede}.panel-primary>.panel-heading+.panel-collapse>.panel-body{border-top-color:#179ede}.panel-primary>.panel-heading .badge{color:#179ede;background-color:#fff}.panel-primary>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#179ede}.panel-success{border-color:#00b588}.panel-success>.panel-heading{color:#fff;background-color:#00b588;border-color:#00b588}.panel-success>.panel-heading+.panel-collapse>.panel-body{border-top-color:#00b588}.panel-success>.panel-heading .badge{color:#00b588;background-color:#fff}.panel-success>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#00b588}.panel-info{border-color:#39afe1}.panel-info>.panel-heading{color:#fff;background-color:#39afe1;border-color:#39afe1}.panel-info>.panel-heading+.panel-collapse>.panel-body{border-top-color:#39afe1}.panel-info>.panel-heading .badge{color:#39afe1;background-color:#fff}.panel-info>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#39afe1}.panel-warning{border-color:#faebcc}.panel-warning>.panel-heading{color:#fff;background-color:#fcf8e3;border-color:#faebcc}.panel-warning>.panel-heading+.panel-collapse>.panel-body{border-top-color:#faebcc}.panel-warning>.panel-heading .badge{color:#fcf8e3;background-color:#fff}.panel-warning>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#faebcc}.panel-danger{border-color:#c0392b}.panel-danger>.panel-heading{color:#fff;background-color:#c0392b;border-color:#c0392b}.panel-danger>.panel-heading+.panel-collapse>.panel-body{border-top-color:#c0392b}.panel-danger>.panel-heading .badge{color:#c0392b;background-color:#fff}.panel-danger>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#c0392b}.embed-responsive{position:relative;display:block;height:0;padding:0;overflow:hidden}.embed-responsive .embed-responsive-item,.embed-responsive embed,.embed-responsive iframe,.embed-responsive object{position:absolute;top:0;left:0;bottom:0;height:100%;width:100%;border:0}.embed-responsive.embed-responsive-16by9{padding-bottom:56.25%}.embed-responsive.embed-responsive-4by3{padding-bottom:75%}.well{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px solid #e3e3e3;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.05);box-shadow:inset 0 1px 1px rgba(0,0,0,.05)}.well blockquote{border-color:#ddd;border-color:rgba(0,0,0,.15)}.well-lg{padding:24px;border-radius:6px}.well-sm{padding:9px;border-radius:3px}.close{float:right;font-size:21px;font-weight:700;line-height:1;color:#000;text-shadow:0 1px 0 #fff;opacity:.2;filter:alpha(opacity=20)}.close:focus,.close:hover{color:#000;text-decoration:none;cursor:pointer;opacity:.5;filter:alpha(opacity=50)}button.close{padding:0;cursor:pointer;background:0 0;border:0;-webkit-appearance:none}.modal-open{overflow:hidden}.modal{display:none;overflow:hidden;position:fixed;top:0;right:0;bottom:0;left:0;z-index:1050;-webkit-overflow-scrolling:touch;outline:0}.modal.fade .modal-dialog{-webkit-transform:translate3d(0,-25%,0);transform:translate3d(0,-25%,0);-webkit-transition:-webkit-transform .3s ease-out;-moz-transition:-moz-transform .3s ease-out;-o-transition:-o-transform .3s ease-out;transition:transform .3s ease-out}.modal.in .modal-dialog{-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}.modal-open .modal{overflow-x:hidden;overflow-y:auto}.modal-dialog{position:relative;width:auto;margin:10px}.modal-content{position:relative;background-clip:padding-box;outline:0}.modal-backdrop{position:fixed;top:0;right:0;bottom:0;left:0;z-index:1040;background-color:#000}.modal-backdrop.fade{opacity:0;filter:alpha(opacity=0)}.modal-backdrop.in{opacity:.5;filter:alpha(opacity=50)}.modal-header{padding:15px;border-bottom:1px solid #e5e5e5;min-height:16.43px}.modal-header .close{margin-top:-2px}.modal-title{margin:0;line-height:1.42857143}.modal-body{position:relative;padding:15px}.modal-footer{padding:15px;text-align:right;border-top:1px solid #e5e5e5}.modal-footer .btn+.btn{margin-left:5px;margin-bottom:0}.modal-footer .btn-group .btn+.btn{margin-left:-1px}.modal-footer .btn-block+.btn-block{margin-left:0}.modal-scrollbar-measure{position:absolute;top:-9999px;width:50px;height:50px;overflow:scroll}@media (min-width:768px){.modal-dialog{width:600px;margin:30px auto}.modal-content{-webkit-box-shadow:0 5px 15px rgba(0,0,0,.5);box-shadow:0 5px 15px rgba(0,0,0,.5)}.modal-sm{width:300px}}@media (min-width:992px){.modal-lg{width:80%}}.tooltip{position:absolute;display:block;visibility:visible;font-size:12px;line-height:1.4;opacity:0;filter:alpha(opacity=0)}.tooltip.in{opacity:.9;filter:alpha(opacity=90)}.tooltip.top{margin-top:-3px;padding:5px 0}.tooltip.right{margin-left:3px;padding:0 5px}.tooltip.bottom{margin-top:3px;padding:5px 0}.tooltip.left{margin-left:-3px;padding:0 5px}.tooltip-inner{max-width:200px;padding:3px 8px;color:#fff;text-align:center;text-decoration:none;background-color:#000;border-radius:4px}.tooltip-arrow{position:absolute;width:0;height:0;border-color:transparent;border-style:solid}.tooltip.top .tooltip-arrow{bottom:0;left:50%;margin-left:-5px;border-width:5px 5px 0;border-top-color:#000}.tooltip.top-left .tooltip-arrow{bottom:0;left:5px;border-width:5px 5px 0;border-top-color:#000}.tooltip.top-right .tooltip-arrow{bottom:0;right:5px;border-width:5px 5px 0;border-top-color:#000}.tooltip.right .tooltip-arrow{top:50%;left:0;margin-top:-5px;border-width:5px 5px 5px 0;border-right-color:#000}.tooltip.left .tooltip-arrow{top:50%;right:0;margin-top:-5px;border-width:5px 0 5px 5px;border-left-color:#000}.tooltip.bottom .tooltip-arrow{top:0;left:50%;margin-left:-5px;border-width:0 5px 5px;border-bottom-color:#000}.tooltip.bottom-left .tooltip-arrow{top:0;left:5px;border-width:0 5px 5px;border-bottom-color:#000}.tooltip.bottom-right .tooltip-arrow{top:0;right:5px;border-width:0 5px 5px;border-bottom-color:#000}.popover{position:absolute;top:0;left:0;z-index:1060;display:none;max-width:276px;padding:1px;text-align:left;background-color:#fff;background-clip:padding-box;border:1px solid #ccc;border:1px solid rgba(0,0,0,.2);border-radius:6px;-webkit-box-shadow:0 5px 10px rgba(0,0,0,.2);box-shadow:0 5px 10px rgba(0,0,0,.2);white-space:normal}.popover.top{margin-top:-10px}.popover.right{margin-left:10px}.popover.bottom{margin-top:10px}.popover.left{margin-left:-10px}.popover-title{margin:0;padding:8px 14px;font-size:14px;font-weight:400;line-height:18px;background-color:#f7f7f7;border-bottom:1px solid #ebebeb;border-radius:5px 5px 0 0}.popover-content{padding:9px 14px}.popover>.arrow,.popover>.arrow:after{position:absolute;display:block;width:0;height:0;border-color:transparent;border-style:solid}.popover>.arrow{border-width:11px}.popover>.arrow:after{border-width:10px;content:""}.popover.top>.arrow{left:50%;margin-left:-11px;border-bottom-width:0;border-top-color:#999;border-top-color:rgba(0,0,0,.25);bottom:-11px}.popover.top>.arrow:after{content:" ";bottom:1px;margin-left:-10px;border-bottom-width:0;border-top-color:#fff}.popover.right>.arrow{top:50%;left:-11px;margin-top:-11px;border-left-width:0;border-right-color:#999;border-right-color:rgba(0,0,0,.25)}.popover.right>.arrow:after{content:" ";left:1px;bottom:-10px;border-left-width:0;border-right-color:#fff}.popover.bottom>.arrow{left:50%;margin-left:-11px;border-top-width:0;border-bottom-color:#999;border-bottom-color:rgba(0,0,0,.25);top:-11px}.popover.bottom>.arrow:after{content:" ";top:1px;margin-left:-10px;border-top-width:0;border-bottom-color:#fff}.popover.left>.arrow{top:50%;right:-11px;margin-top:-11px;border-right-width:0;border-left-color:#999;border-left-color:rgba(0,0,0,.25)}.popover.left>.arrow:after{content:" ";right:1px;border-right-width:0;border-left-color:#fff;bottom:-10px}.carousel{position:relative}.carousel-inner{position:relative;overflow:hidden;width:100%}.carousel-inner>.item{display:none;position:relative;-webkit-transition:.6s ease-in-out left;-o-transition:.6s ease-in-out left;transition:.6s ease-in-out left}.carousel-inner>.item>a>img,.carousel-inner>.item>img{line-height:1}.carousel-inner>.active,.carousel-inner>.next,.carousel-inner>.prev{display:block}.carousel-inner>.active{left:0}.carousel-inner>.next,.carousel-inner>.prev{position:absolute;top:0;width:100%}.carousel-inner>.next{left:100%}.carousel-inner>.prev{left:-100%}.carousel-inner>.next.left,.carousel-inner>.prev.right{left:0}.carousel-inner>.active.left{left:-100%}.carousel-inner>.active.right{left:100%}.carousel-control{position:absolute;top:0;left:0;bottom:0;width:15%;opacity:.5;filter:alpha(opacity=50);font-size:20px;color:#fff;text-align:center;text-shadow:0 1px 2px rgba(0,0,0,.6)}.carousel-control.left{background-image:-webkit-linear-gradient(left,rgba(0,0,0,.5) 0,rgba(0,0,0,.0001) 100%);background-image:-o-linear-gradient(left,rgba(0,0,0,.5) 0,rgba(0,0,0,.0001) 100%);background-image:linear-gradient(to right,rgba(0,0,0,.5) 0,rgba(0,0,0,.0001) 100%);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#80000000', endColorstr='#00000000', GradientType=1)}.carousel-control.right{left:auto;right:0;background-image:-webkit-linear-gradient(left,rgba(0,0,0,.0001) 0,rgba(0,0,0,.5) 100%);background-image:-o-linear-gradient(left,rgba(0,0,0,.0001) 0,rgba(0,0,0,.5) 100%);background-image:linear-gradient(to right,rgba(0,0,0,.0001) 0,rgba(0,0,0,.5) 100%);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#00000000', endColorstr='#80000000', GradientType=1)}.carousel-control:focus,.carousel-control:hover{outline:0;color:#fff;text-decoration:none;opacity:.9;filter:alpha(opacity=90)}.carousel-control .glyphicon-chevron-left,.carousel-control .glyphicon-chevron-right,.carousel-control .icon-next,.carousel-control .icon-prev{position:absolute;top:50%;z-index:5;display:inline-block}.carousel-control .glyphicon-chevron-left,.carousel-control .icon-prev{left:50%;margin-left:-10px}.carousel-control .glyphicon-chevron-right,.carousel-control .icon-next{right:50%;margin-right:-10px}.carousel-control .icon-next,.carousel-control .icon-prev{width:20px;height:20px;margin-top:-10px;font-family:serif}.carousel-control .icon-prev:before{content:'\2039'}.carousel-control .icon-next:before{content:'\203a'}.carousel-indicators{position:absolute;bottom:10px;left:50%;z-index:15;width:60%;margin-left:-30%;padding-left:0;list-style:none;text-align:center}.carousel-indicators li{display:inline-block;width:10px;height:10px;margin:1px;text-indent:-999px;border:1px solid #fff;border-radius:10px;cursor:pointer;background-color:transparent}.carousel-indicators .active{margin:0;width:12px;height:12px;background-color:#fff}.carousel-caption{position:absolute;left:15%;right:15%;bottom:20px;z-index:10;padding-top:20px;padding-bottom:20px;color:#fff;text-align:center;text-shadow:0 1px 2px rgba(0,0,0,.6)}.carousel-caption .btn{text-shadow:none}@media screen and (min-width:768px){.carousel-control .glyphicon-chevron-left,.carousel-control .glyphicon-chevron-right,.carousel-control .icon-next,.carousel-control .icon-prev{width:30px;height:30px;margin-top:-15px;font-size:30px}.carousel-control .glyphicon-chevron-left,.carousel-control .icon-prev{margin-left:-15px}.carousel-control .glyphicon-chevron-right,.carousel-control .icon-next{margin-right:-15px}.carousel-caption{left:20%;right:20%;padding-bottom:30px}.carousel-indicators{bottom:20px}}.btn-group-vertical>.btn-group:after,.btn-group-vertical>.btn-group:before,.btn-toolbar:after,.btn-toolbar:before,.clearfix:after,.clearfix:before,.container-fluid:after,.container-fluid:before,.container:after,.container:before,.dl-horizontal dd:after,.dl-horizontal dd:before,.form-horizontal .form-group:after,.form-horizontal .form-group:before,.modal-footer:after,.modal-footer:before,.nav:after,.nav:before,.navbar-collapse:after,.navbar-collapse:before,.navbar-header:after,.navbar-header:before,.navbar:after,.navbar:before,.pager:after,.pager:before,.panel-body:after,.panel-body:before,.row:after,.row:before{content:" ";display:table}.btn-group-vertical>.btn-group:after,.btn-toolbar:after,.clearfix:after,.container-fluid:after,.container:after,.dl-horizontal dd:after,.form-horizontal .form-group:after,.modal-footer:after,.nav:after,.navbar-collapse:after,.navbar-header:after,.navbar:after,.pager:after,.panel-body:after,.row:after{clear:both}.center-block{display:block;margin-left:auto;margin-right:auto}.pull-right{float:right!important}.pull-left{float:left!important}.hide{display:none!important}.show{display:block!important}.invisible{visibility:hidden}.text-hide{font:0/0 a;color:transparent;text-shadow:none;background-color:transparent;border:0}.hidden{display:none!important;visibility:hidden!important}.affix{position:fixed;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}@-ms-viewport{width:device-width}.visible-lg,.visible-lg-block,.visible-lg-inline,.visible-lg-inline-block,.visible-md,.visible-md-block,.visible-md-inline,.visible-md-inline-block,.visible-print,.visible-print-block,.visible-print-inline,.visible-print-inline-block,.visible-sm,.visible-sm-block,.visible-sm-inline,.visible-sm-inline-block,.visible-xs,.visible-xs-block,.visible-xs-inline,.visible-xs-inline-block{display:none!important}@media (max-width:767px){.visible-xs{display:block!important}table.visible-xs{display:table}tr.visible-xs{display:table-row!important}td.visible-xs,th.visible-xs{display:table-cell!important}}@media (max-width:767px){.visible-xs-block{display:block!important}}@media (max-width:767px){.visible-xs-inline{display:inline!important}}@media (max-width:767px){.visible-xs-inline-block{display:inline-block!important}}@media (min-width:768px) and (max-width:991px){.visible-sm{display:block!important}table.visible-sm{display:table}tr.visible-sm{display:table-row!important}td.visible-sm,th.visible-sm{display:table-cell!important}}@media (min-width:768px) and (max-width:991px){.visible-sm-block{display:block!important}}@media (min-width:768px) and (max-width:991px){.visible-sm-inline{display:inline!important}}@media (min-width:768px) and (max-width:991px){.visible-sm-inline-block{display:inline-block!important}}@media (min-width:992px) and (max-width:1199px){.visible-md{display:block!important}table.visible-md{display:table}tr.visible-md{display:table-row!important}td.visible-md,th.visible-md{display:table-cell!important}}@media (min-width:992px) and (max-width:1199px){.visible-md-block{display:block!important}}@media (min-width:992px) and (max-width:1199px){.visible-md-inline{display:inline!important}}@media (min-width:992px) and (max-width:1199px){.visible-md-inline-block{display:inline-block!important}}@media (min-width:1200px){.visible-lg{display:block!important}table.visible-lg{display:table}tr.visible-lg{display:table-row!important}td.visible-lg,th.visible-lg{display:table-cell!important}}@media (min-width:1200px){.visible-lg-block{display:block!important}}@media (min-width:1200px){.visible-lg-inline{display:inline!important}}@media (min-width:1200px){.visible-lg-inline-block{display:inline-block!important}}@media (max-width:767px){.hidden-xs{display:none!important}}@media (min-width:768px) and (max-width:991px){.hidden-sm{display:none!important}}@media (min-width:992px) and (max-width:1199px){.hidden-md{display:none!important}}@media (min-width:1200px){.hidden-lg{display:none!important}}@media print{.visible-print{display:block!important}table.visible-print{display:table}tr.visible-print{display:table-row!important}td.visible-print,th.visible-print{display:table-cell!important}}@media print{.visible-print-block{display:block!important}}@media print{.visible-print-inline{display:inline!important}}@media print{.visible-print-inline-block{display:inline-block!important}}@media print{.hidden-print{display:none!important}}.alertify,.alertify-log,.alertify-show{-webkit-transition:all 500ms cubic-bezier(.175,.885,.32,1.275);-moz-transition:all 500ms cubic-bezier(.175,.885,.32,1.275);-ms-transition:all 500ms cubic-bezier(.175,.885,.32,1.275);-o-transition:all 500ms cubic-bezier(.175,.885,.32,1.275);transition:all 500ms cubic-bezier(.175,.885,.32,1.275)}.alertify-hide{-webkit-transition:all 250ms cubic-bezier(.6,-.28,.735,.045);-moz-transition:all 250ms cubic-bezier(.6,-.28,.735,.045);-ms-transition:all 250ms cubic-bezier(.6,-.28,.735,.045);-o-transition:all 250ms cubic-bezier(.6,-.28,.735,.045);transition:all 250ms cubic-bezier(.6,-.28,.735,.045)}.alertify-log-hide{-webkit-transition:all 500ms cubic-bezier(.6,-.28,.735,.045);-moz-transition:all 500ms cubic-bezier(.6,-.28,.735,.045);-ms-transition:all 500ms cubic-bezier(.6,-.28,.735,.045);-o-transition:all 500ms cubic-bezier(.6,-.28,.735,.045);transition:all 500ms cubic-bezier(.6,-.28,.735,.045)}.alertify-cover{position:fixed;z-index:99999;top:0;right:0;bottom:0;left:0;background-color:#fff;filter:alpha(opacity=0);opacity:0}.alertify-cover-hidden{display:none}.alertify{position:fixed;z-index:99999;top:50px;left:50%;width:550px;margin-left:-275px;opacity:1}.alertify-hidden{-webkit-transform:translate(0,-150px);-moz-transform:translate(0,-150px);-ms-transform:translate(0,-150px);-o-transform:translate(0,-150px);transform:translate(0,-150px);opacity:0;display:none}:root *>.alertify-hidden{display:block;visibility:hidden}.alertify-logs{position:fixed;z-index:5000;bottom:10px;right:10px;width:300px}.alertify-logs-hidden{display:none}.alertify-log{display:block;margin-top:10px;position:relative;right:-300px;opacity:0}.alertify-log-show{right:0;opacity:1}.alertify-log-hide{-webkit-transform:translate(300px,0);-moz-transform:translate(300px,0);-ms-transform:translate(300px,0);-o-transform:translate(300px,0);transform:translate(300px,0);opacity:0}.alertify-dialog{padding:25px}.alertify-resetFocus{border:0;clip:rect(0 0 0 0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.alertify-inner{text-align:center}.alertify-text{margin-bottom:15px;width:100%;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;font-size:100%}.alertify-button,.alertify-button:active,.alertify-button:hover,.alertify-button:visited{background:0 0;text-decoration:none;border:none;line-height:1.5;font-size:100%;display:inline-block;cursor:pointer;margin-left:5px}@media only screen and (max-width:680px){.alertify,.alertify-logs{width:90%;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.alertify{left:5%;margin:0}}.alertify,.alertify-log{font-family:sans-serif}.alertify{background:#FFF;border:10px solid #333;border:10px solid rgba(0,0,0,.7);border-radius:8px;box-shadow:0 3px 3px rgba(0,0,0,.3);-webkit-background-clip:padding;-moz-background-clip:padding;background-clip:padding-box}.alertify-text{border:1px solid #CCC;padding:10px;border-radius:4px}.alertify-button{border-radius:4px;color:#FFF;font-weight:700;padding:6px 15px;text-decoration:none;text-shadow:1px 1px 0 rgba(0,0,0,.5);box-shadow:inset 0 1px 0 0 rgba(255,255,255,.5);background-image:-webkit-linear-gradient(top,rgba(255,255,255,.3),rgba(255,255,255,0));background-image:-moz-linear-gradient(top,rgba(255,255,255,.3),rgba(255,255,255,0));background-image:-ms-linear-gradient(top,rgba(255,255,255,.3),rgba(255,255,255,0));background-image:-o-linear-gradient(top,rgba(255,255,255,.3),rgba(255,255,255,0));background-image:linear-gradient(top,rgba(255,255,255,.3),rgba(255,255,255,0))}.alertify-button:focus,.alertify-button:hover{outline:0;background-image:-webkit-linear-gradient(top,rgba(0,0,0,.1),rgba(0,0,0,0));background-image:-moz-linear-gradient(top,rgba(0,0,0,.1),rgba(0,0,0,0));background-image:-ms-linear-gradient(top,rgba(0,0,0,.1),rgba(0,0,0,0));background-image:-o-linear-gradient(top,rgba(0,0,0,.1),rgba(0,0,0,0));background-image:linear-gradient(top,rgba(0,0,0,.1),rgba(0,0,0,0))}.alertify-button:focus{box-shadow:0 0 15px #2B72D5}.alertify-button:active{position:relative;box-shadow:inset 0 2px 4px rgba(0,0,0,.15),0 1px 2px rgba(0,0,0,.05)}.alertify-button-cancel,.alertify-button-cancel:focus,.alertify-button-cancel:hover{background-color:#FE1A00;border:1px solid #D83526}.alertify-button-ok,.alertify-button-ok:focus,.alertify-button-ok:hover{background-color:#5CB811;border:1px solid #3B7808}.alertify-log{background:#1F1F1F;background:rgba(0,0,0,.9);padding:15px;border-radius:4px;color:#FFF;text-shadow:-1px -1px 0 rgba(0,0,0,.5)}.alertify-log-error{background:#FE1A00;background:rgba(254,26,0,.9)}.alertify-log-success{background:#5CB811;background:rgba(92,184,17,.9)}.mCustomScrollbar{-ms-touch-action:none;touch-action:none}.mCustomScrollbar.mCS_no_scrollbar{-ms-touch-action:auto;touch-action:auto}.mCustomScrollBox{position:relative;overflow:hidden;height:100%;max-width:100%;outline:0;direction:ltr}.mCSB_container{overflow:hidden;width:auto;height:auto}.mCSB_container.mCS_no_scrollbar_y.mCS_y_hidden{margin-right:0}.mCS-dir-rtl>.mCSB_inside>.mCSB_container{margin-right:0;margin-left:30px}.mCS-dir-rtl>.mCSB_inside>.mCSB_container.mCS_no_scrollbar_y.mCS_y_hidden{margin-left:0}.mCSB_scrollTools{position:absolute;width:16px;height:auto;left:auto;top:0;right:0;bottom:0}.mCSB_outside+.mCSB_scrollTools{right:-26px}.mCS-dir-rtl>.mCSB_inside>.mCSB_scrollTools,.mCS-dir-rtl>.mCSB_outside+.mCSB_scrollTools{right:auto;left:0}.mCS-dir-rtl>.mCSB_outside+.mCSB_scrollTools{left:-26px}.mCSB_scrollTools .mCSB_draggerContainer{position:absolute;top:0;left:0;bottom:0;right:0;height:auto}.mCSB_scrollTools a+.mCSB_draggerContainer{margin:20px 0}.mCSB_scrollTools .mCSB_draggerRail{height:100%;margin:0 auto;-webkit-border-radius:16px;-moz-border-radius:16px}.mCSB_scrollTools .mCSB_dragger{cursor:pointer;width:100%;height:30px;z-index:1}.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{position:relative;height:100%;margin:0 auto;-webkit-border-radius:16px;-moz-border-radius:16px;border-radius:16px;text-align:center}.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded .mCSB_dragger_bar,.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_dragger .mCSB_dragger_bar{width:12px}.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail{width:8px}.mCSB_scrollTools .mCSB_buttonDown,.mCSB_scrollTools .mCSB_buttonUp{display:block;position:absolute;height:20px;width:100%;overflow:hidden;margin:0 auto;cursor:pointer}.mCSB_scrollTools .mCSB_buttonDown{bottom:0}.mCSB_horizontal.mCSB_inside>.mCSB_container{margin-right:0;margin-bottom:30px}.mCSB_horizontal.mCSB_outside>.mCSB_container{min-height:100%}.mCSB_horizontal>.mCSB_container.mCS_no_scrollbar_x.mCS_x_hidden{margin-bottom:0}.mCSB_scrollTools.mCSB_scrollTools_horizontal{width:auto;height:16px;top:auto;right:0;bottom:0;left:0}.mCustomScrollBox+.mCSB_scrollTools+.mCSB_scrollTools.mCSB_scrollTools_horizontal,.mCustomScrollBox+.mCSB_scrollTools.mCSB_scrollTools_horizontal{bottom:-26px}.mCSB_scrollTools.mCSB_scrollTools_horizontal a+.mCSB_draggerContainer{margin:0 20px}.mCSB_scrollTools.mCSB_scrollTools_horizontal .mCSB_draggerRail{width:100%;height:2px;margin:7px 0}.mCSB_scrollTools.mCSB_scrollTools_horizontal .mCSB_dragger{width:30px;height:100%;left:0}.mCSB_scrollTools.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar{width:100%;height:4px;margin:6px auto}.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded .mCSB_dragger_bar,.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_dragger .mCSB_dragger_bar{height:12px;margin:2px auto}.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail{height:8px;margin:4px 0}.mCSB_scrollTools.mCSB_scrollTools_horizontal .mCSB_buttonLeft,.mCSB_scrollTools.mCSB_scrollTools_horizontal .mCSB_buttonRight{display:block;position:absolute;width:20px;height:100%;overflow:hidden;margin:0 auto;cursor:pointer}.mCSB_scrollTools.mCSB_scrollTools_horizontal .mCSB_buttonLeft{left:0}.mCSB_scrollTools.mCSB_scrollTools_horizontal .mCSB_buttonRight{right:0}.mCSB_container_wrapper{position:absolute;height:auto;width:auto;overflow:hidden;top:0;left:0;right:0;bottom:0;margin-right:30px;margin-bottom:30px}.mCSB_container_wrapper>.mCSB_container{padding-right:30px;padding-bottom:30px}.mCSB_vertical_horizontal>.mCSB_scrollTools.mCSB_scrollTools_vertical{bottom:20px}.mCSB_vertical_horizontal>.mCSB_scrollTools.mCSB_scrollTools_horizontal{right:20px}.mCSB_container_wrapper.mCS_no_scrollbar_x.mCS_x_hidden+.mCSB_scrollTools.mCSB_scrollTools_vertical{bottom:0}.mCS-dir-rtl>.mCustomScrollBox.mCSB_vertical_horizontal.mCSB_inside>.mCSB_scrollTools.mCSB_scrollTools_horizontal,.mCSB_container_wrapper.mCS_no_scrollbar_y.mCS_y_hidden+.mCSB_scrollTools~.mCSB_scrollTools.mCSB_scrollTools_horizontal{right:0}.mCS-dir-rtl>.mCustomScrollBox.mCSB_vertical_horizontal.mCSB_inside>.mCSB_scrollTools.mCSB_scrollTools_horizontal{left:20px}.mCS-dir-rtl>.mCustomScrollBox.mCSB_vertical_horizontal.mCSB_inside>.mCSB_container_wrapper.mCS_no_scrollbar_y.mCS_y_hidden+.mCSB_scrollTools~.mCSB_scrollTools.mCSB_scrollTools_horizontal{left:0}.mCS-dir-rtl>.mCSB_inside>.mCSB_container_wrapper{margin-right:0;margin-left:30px}.mCSB_container_wrapper.mCS_no_scrollbar_y.mCS_y_hidden>.mCSB_container{padding-right:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.mCSB_container_wrapper.mCS_no_scrollbar_x.mCS_x_hidden>.mCSB_container{padding-bottom:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.mCustomScrollBox.mCSB_vertical_horizontal.mCSB_inside>.mCSB_container_wrapper.mCS_no_scrollbar_y.mCS_y_hidden{margin-right:0;margin-left:0}.mCustomScrollBox.mCSB_vertical_horizontal.mCSB_inside>.mCSB_container_wrapper.mCS_no_scrollbar_x.mCS_x_hidden{margin-bottom:0}.mCSB_scrollTools,.mCSB_scrollTools .mCSB_buttonDown,.mCSB_scrollTools .mCSB_buttonLeft,.mCSB_scrollTools .mCSB_buttonRight,.mCSB_scrollTools .mCSB_buttonUp,.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{-webkit-transition:opacity .2s ease-in-out,background-color .2s ease-in-out;-moz-transition:opacity .2s ease-in-out,background-color .2s ease-in-out;-o-transition:opacity .2s ease-in-out,background-color .2s ease-in-out;transition:opacity .2s ease-in-out,background-color .2s ease-in-out}.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerRail,.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger_bar,.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerRail,.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger_bar{-webkit-transition:width .2s ease-out .2s,height .2s ease-out .2s,margin-left .2s ease-out .2s,margin-right .2s ease-out .2s,margin-top .2s ease-out .2s,margin-bottom .2s ease-out .2s,opacity .2s ease-in-out,background-color .2s ease-in-out;-moz-transition:width .2s ease-out .2s,height .2s ease-out .2s,margin-left .2s ease-out .2s,margin-right .2s ease-out .2s,margin-top .2s ease-out .2s,margin-bottom .2s ease-out .2s,opacity .2s ease-in-out,background-color .2s ease-in-out;-o-transition:width .2s ease-out .2s,height .2s ease-out .2s,margin-left .2s ease-out .2s,margin-right .2s ease-out .2s,margin-top .2s ease-out .2s,margin-bottom .2s ease-out .2s,opacity .2s ease-in-out,background-color .2s ease-in-out;transition:width .2s ease-out .2s,height .2s ease-out .2s,margin-left .2s ease-out .2s,margin-right .2s ease-out .2s,margin-top .2s ease-out .2s,margin-bottom .2s ease-out .2s,opacity .2s ease-in-out,background-color .2s ease-in-out}.mCSB_scrollTools{opacity:.75;filter:"alpha(opacity=75)";-ms-filter:"alpha(opacity=75)"}.mCS-autoHide>.mCustomScrollBox>.mCSB_scrollTools,.mCS-autoHide>.mCustomScrollBox~.mCSB_scrollTools{opacity:0;filter:"alpha(opacity=0)";-ms-filter:"alpha(opacity=0)"}.mCS-autoHide:hover>.mCustomScrollBox>.mCSB_scrollTools,.mCS-autoHide:hover>.mCustomScrollBox~.mCSB_scrollTools,.mCustomScrollBox:hover>.mCSB_scrollTools,.mCustomScrollBox:hover~.mCSB_scrollTools,.mCustomScrollbar>.mCustomScrollBox>.mCSB_scrollTools.mCSB_scrollTools_onDrag,.mCustomScrollbar>.mCustomScrollBox~.mCSB_scrollTools.mCSB_scrollTools_onDrag{opacity:1;filter:"alpha(opacity=100)";-ms-filter:"alpha(opacity=100)"}.mCSB_scrollTools .mCSB_draggerRail{background-color:#000;background-color:rgba(0,0,0,.4);filter:"alpha(opacity=40)";-ms-filter:"alpha(opacity=40)"}.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{background-color:#fff;background-color:rgba(255,255,255,.75);filter:"alpha(opacity=75)";-ms-filter:"alpha(opacity=75)"}.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar{background-color:#fff;background-color:rgba(255,255,255,.85);filter:"alpha(opacity=85)";-ms-filter:"alpha(opacity=85)"}.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar{background-color:#fff;background-color:rgba(255,255,255,.9);filter:"alpha(opacity=90)";-ms-filter:"alpha(opacity=90)"}.mCSB_scrollTools .mCSB_buttonDown,.mCSB_scrollTools .mCSB_buttonLeft,.mCSB_scrollTools .mCSB_buttonRight,.mCSB_scrollTools .mCSB_buttonUp{background-image:url(mCSB_buttons.png);background-repeat:no-repeat;opacity:.4;filter:"alpha(opacity=40)";-ms-filter:"alpha(opacity=40)"}.mCSB_scrollTools .mCSB_buttonUp{background-position:0 0}.mCSB_scrollTools .mCSB_buttonDown{background-position:0 -20px}.mCSB_scrollTools .mCSB_buttonLeft{background-position:0 -40px}.mCSB_scrollTools .mCSB_buttonRight{background-position:0 -56px}.mCSB_scrollTools .mCSB_buttonDown:hover,.mCSB_scrollTools .mCSB_buttonLeft:hover,.mCSB_scrollTools .mCSB_buttonRight:hover,.mCSB_scrollTools .mCSB_buttonUp:hover{opacity:.75;filter:"alpha(opacity=75)";-ms-filter:"alpha(opacity=75)"}.mCSB_scrollTools .mCSB_buttonDown:active,.mCSB_scrollTools .mCSB_buttonLeft:active,.mCSB_scrollTools .mCSB_buttonRight:active,.mCSB_scrollTools .mCSB_buttonUp:active{opacity:.9;filter:"alpha(opacity=90)";-ms-filter:"alpha(opacity=90)"}.mCS-dark.mCSB_scrollTools .mCSB_draggerRail{background-color:#000;background-color:rgba(0,0,0,.15)}.mCS-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.75)}.mCS-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar{background-color:rgba(0,0,0,.85)}.mCS-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar{background-color:rgba(0,0,0,.9)}.mCS-dark.mCSB_scrollTools .mCSB_buttonUp{background-position:-80px 0}.mCS-dark.mCSB_scrollTools .mCSB_buttonDown{background-position:-80px -20px}.mCS-dark.mCSB_scrollTools .mCSB_buttonLeft{background-position:-80px -40px}.mCS-dark.mCSB_scrollTools .mCSB_buttonRight{background-position:-80px -56px}.mCS-dark-2.mCSB_scrollTools .mCSB_draggerRail,.mCS-light-2.mCSB_scrollTools .mCSB_draggerRail{width:4px;background-color:#fff;background-color:rgba(255,255,255,.1);-webkit-border-radius:1px;-moz-border-radius:1px;border-radius:1px}.mCS-dark-2.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-light-2.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{width:4px;background-color:#fff;background-color:rgba(255,255,255,.75);-webkit-border-radius:1px;-moz-border-radius:1px;border-radius:1px}.mCS-dark-2.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-dark-2.mCSB_scrollTools_horizontal .mCSB_draggerRail,.mCS-light-2.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-light-2.mCSB_scrollTools_horizontal .mCSB_draggerRail{width:100%;height:4px;margin:6px auto}.mCS-light-2.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar{background-color:#fff;background-color:rgba(255,255,255,.85)}.mCS-light-2.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-light-2.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar{background-color:#fff;background-color:rgba(255,255,255,.9)}.mCS-light-2.mCSB_scrollTools .mCSB_buttonUp{background-position:-32px 0}.mCS-light-2.mCSB_scrollTools .mCSB_buttonDown{background-position:-32px -20px}.mCS-light-2.mCSB_scrollTools .mCSB_buttonLeft{background-position:-40px -40px}.mCS-light-2.mCSB_scrollTools .mCSB_buttonRight{background-position:-40px -56px}.mCS-dark-2.mCSB_scrollTools .mCSB_draggerRail{background-color:#000;background-color:rgba(0,0,0,.1);-webkit-border-radius:1px;-moz-border-radius:1px;border-radius:1px}.mCS-dark-2.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.75);-webkit-border-radius:1px;-moz-border-radius:1px;border-radius:1px}.mCS-dark-2.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.85)}.mCS-dark-2.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-dark-2.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.9)}.mCS-dark-2.mCSB_scrollTools .mCSB_buttonUp{background-position:-112px 0}.mCS-dark-2.mCSB_scrollTools .mCSB_buttonDown{background-position:-112px -20px}.mCS-dark-2.mCSB_scrollTools .mCSB_buttonLeft{background-position:-120px -40px}.mCS-dark-2.mCSB_scrollTools .mCSB_buttonRight{background-position:-120px -56px}.mCS-dark-thick.mCSB_scrollTools .mCSB_draggerRail,.mCS-light-thick.mCSB_scrollTools .mCSB_draggerRail{width:4px;background-color:#fff;background-color:rgba(255,255,255,.1);-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px}.mCS-dark-thick.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-light-thick.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{width:6px;background-color:#fff;background-color:rgba(255,255,255,.75);-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px}.mCS-dark-thick.mCSB_scrollTools_horizontal .mCSB_draggerRail,.mCS-light-thick.mCSB_scrollTools_horizontal .mCSB_draggerRail{width:100%;height:4px;margin:6px 0}.mCS-dark-thick.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-light-thick.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar{width:100%;height:6px;margin:5px auto}.mCS-light-thick.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar{background-color:#fff;background-color:rgba(255,255,255,.85)}.mCS-light-thick.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-light-thick.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar{background-color:#fff;background-color:rgba(255,255,255,.9)}.mCS-light-thick.mCSB_scrollTools .mCSB_buttonUp{background-position:-16px 0}.mCS-light-thick.mCSB_scrollTools .mCSB_buttonDown{background-position:-16px -20px}.mCS-light-thick.mCSB_scrollTools .mCSB_buttonLeft{background-position:-20px -40px}.mCS-light-thick.mCSB_scrollTools .mCSB_buttonRight{background-position:-20px -56px}.mCS-dark-thick.mCSB_scrollTools .mCSB_draggerRail{background-color:#000;background-color:rgba(0,0,0,.1);-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px}.mCS-dark-thick.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.75);-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px}.mCS-dark-thick.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.85)}.mCS-dark-thick.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-dark-thick.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.9)}.mCS-dark-thick.mCSB_scrollTools .mCSB_buttonUp{background-position:-96px 0}.mCS-dark-thick.mCSB_scrollTools .mCSB_buttonDown{background-position:-96px -20px}.mCS-dark-thick.mCSB_scrollTools .mCSB_buttonLeft{background-position:-100px -40px}.mCS-dark-thick.mCSB_scrollTools .mCSB_buttonRight{background-position:-100px -56px}.mCS-light-thin.mCSB_scrollTools .mCSB_draggerRail{background-color:#fff;background-color:rgba(255,255,255,.1)}.mCS-dark-thin.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-light-thin.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{width:2px}.mCS-dark-thin.mCSB_scrollTools_horizontal .mCSB_draggerRail,.mCS-light-thin.mCSB_scrollTools_horizontal .mCSB_draggerRail{width:100%}.mCS-dark-thin.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-light-thin.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar{width:100%;height:2px;margin:7px auto}.mCS-dark-thin.mCSB_scrollTools .mCSB_draggerRail{background-color:#000;background-color:rgba(0,0,0,.15)}.mCS-dark-thin.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.75)}.mCS-dark-thin.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.85)}.mCS-dark-thin.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-dark-thin.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.9)}.mCS-dark-thin.mCSB_scrollTools .mCSB_buttonUp{background-position:-80px 0}.mCS-dark-thin.mCSB_scrollTools .mCSB_buttonDown{background-position:-80px -20px}.mCS-dark-thin.mCSB_scrollTools .mCSB_buttonLeft{background-position:-80px -40px}.mCS-dark-thin.mCSB_scrollTools .mCSB_buttonRight{background-position:-80px -56px}.mCS-rounded.mCSB_scrollTools .mCSB_draggerRail{background-color:#fff;background-color:rgba(255,255,255,.15)}.mCS-rounded-dark.mCSB_scrollTools .mCSB_dragger,.mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_dragger,.mCS-rounded-dots.mCSB_scrollTools .mCSB_dragger,.mCS-rounded.mCSB_scrollTools .mCSB_dragger{height:14px}.mCS-rounded-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-rounded-dots.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-rounded.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{width:14px;margin:0 1px}.mCS-rounded-dark.mCSB_scrollTools_horizontal .mCSB_dragger,.mCS-rounded-dots-dark.mCSB_scrollTools_horizontal .mCSB_dragger,.mCS-rounded-dots.mCSB_scrollTools_horizontal .mCSB_dragger,.mCS-rounded.mCSB_scrollTools_horizontal .mCSB_dragger{width:14px}.mCS-rounded-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-rounded-dots-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-rounded-dots.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-rounded.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar{height:14px;margin:1px 0}.mCS-rounded-dark.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded .mCSB_dragger_bar,.mCS-rounded-dark.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_dragger .mCSB_dragger_bar,.mCS-rounded.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded .mCSB_dragger_bar,.mCS-rounded.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_dragger .mCSB_dragger_bar{width:16px;height:16px;margin:-1px 0}.mCS-rounded-dark.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,.mCS-rounded-dark.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail,.mCS-rounded.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,.mCS-rounded.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail{width:4px}.mCS-rounded-dark.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded .mCSB_dragger_bar,.mCS-rounded-dark.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_dragger .mCSB_dragger_bar,.mCS-rounded.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded .mCSB_dragger_bar,.mCS-rounded.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_dragger .mCSB_dragger_bar{height:16px;width:16px;margin:0 -1px}.mCS-rounded-dark.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,.mCS-rounded-dark.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail,.mCS-rounded.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,.mCS-rounded.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail{height:4px;margin:6px 0}.mCS-rounded.mCSB_scrollTools .mCSB_buttonUp{background-position:0 -72px}.mCS-rounded.mCSB_scrollTools .mCSB_buttonDown{background-position:0 -92px}.mCS-rounded.mCSB_scrollTools .mCSB_buttonLeft{background-position:0 -112px}.mCS-rounded.mCSB_scrollTools .mCSB_buttonRight{background-position:0 -128px}.mCS-rounded-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.75)}.mCS-rounded-dark.mCSB_scrollTools .mCSB_draggerRail{background-color:#000;background-color:rgba(0,0,0,.15)}.mCS-rounded-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar,.mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.85)}.mCS-rounded-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-rounded-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,.mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.9)}.mCS-rounded-dark.mCSB_scrollTools .mCSB_buttonUp{background-position:-80px -72px}.mCS-rounded-dark.mCSB_scrollTools .mCSB_buttonDown{background-position:-80px -92px}.mCS-rounded-dark.mCSB_scrollTools .mCSB_buttonLeft{background-position:-80px -112px}.mCS-rounded-dark.mCSB_scrollTools .mCSB_buttonRight{background-position:-80px -128px}.mCS-rounded-dots-dark.mCSB_scrollTools_vertical .mCSB_draggerRail,.mCS-rounded-dots.mCSB_scrollTools_vertical .mCSB_draggerRail{width:4px}.mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_draggerRail,.mCS-rounded-dots-dark.mCSB_scrollTools_horizontal .mCSB_draggerRail,.mCS-rounded-dots.mCSB_scrollTools .mCSB_draggerRail,.mCS-rounded-dots.mCSB_scrollTools_horizontal .mCSB_draggerRail{background-color:transparent;background-position:center}.mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_draggerRail,.mCS-rounded-dots.mCSB_scrollTools .mCSB_draggerRail{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAANElEQVQYV2NkIAAYiVbw//9/Y6DiM1ANJoyMjGdBbLgJQAX/kU0DKgDLkaQAvxW4HEvQFwCRcxIJK1XznAAAAABJRU5ErkJggg==);background-repeat:repeat-y;opacity:.3;filter:"alpha(opacity=30)";-ms-filter:"alpha(opacity=30)"}.mCS-rounded-dots-dark.mCSB_scrollTools_horizontal .mCSB_draggerRail,.mCS-rounded-dots.mCSB_scrollTools_horizontal .mCSB_draggerRail{height:4px;margin:6px 0;background-repeat:repeat-x}.mCS-rounded-dots.mCSB_scrollTools .mCSB_buttonUp{background-position:-16px -72px}.mCS-rounded-dots.mCSB_scrollTools .mCSB_buttonDown{background-position:-16px -92px}.mCS-rounded-dots.mCSB_scrollTools .mCSB_buttonLeft{background-position:-20px -112px}.mCS-rounded-dots.mCSB_scrollTools .mCSB_buttonRight{background-position:-20px -128px}.mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_draggerRail{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAALElEQVQYV2NkIAAYSVFgDFR8BqrBBEifBbGRTfiPZhpYjiQFBK3A6l6CvgAAE9kGCd1mvgEAAAAASUVORK5CYII=)}.mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_buttonUp{background-position:-96px -72px}.mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_buttonDown{background-position:-96px -92px}.mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_buttonLeft{background-position:-100px -112px}.mCS-rounded-dots-dark.mCSB_scrollTools .mCSB_buttonRight{background-position:-100px -128px}.mCS-3d-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-3d-thick-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-3d-thick.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-3d.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{background-repeat:repeat-y;background-image:-moz-linear-gradient(left,rgba(255,255,255,.5) 0,rgba(255,255,255,0) 100%);background-image:-webkit-gradient(linear,left top,right top,color-stop(0,rgba(255,255,255,.5)),color-stop(100%,rgba(255,255,255,0)));background-image:-webkit-linear-gradient(left,rgba(255,255,255,.5) 0,rgba(255,255,255,0) 100%);background-image:-o-linear-gradient(left,rgba(255,255,255,.5) 0,rgba(255,255,255,0) 100%);background-image:-ms-linear-gradient(left,rgba(255,255,255,.5) 0,rgba(255,255,255,0) 100%);background-image:linear-gradient(to right,rgba(255,255,255,.5) 0,rgba(255,255,255,0) 100%)}.mCS-3d-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-3d-thick-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-3d-thick.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-3d.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar{background-repeat:repeat-x;background-image:-moz-linear-gradient(top,rgba(255,255,255,.5) 0,rgba(255,255,255,0) 100%);background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgba(255,255,255,.5)),color-stop(100%,rgba(255,255,255,0)));background-image:-webkit-linear-gradient(top,rgba(255,255,255,.5) 0,rgba(255,255,255,0) 100%);background-image:-o-linear-gradient(top,rgba(255,255,255,.5) 0,rgba(255,255,255,0) 100%);background-image:-ms-linear-gradient(top,rgba(255,255,255,.5) 0,rgba(255,255,255,0) 100%);background-image:linear-gradient(to bottom,rgba(255,255,255,.5) 0,rgba(255,255,255,0) 100%)}.mCS-3d-dark.mCSB_scrollTools_vertical .mCSB_dragger,.mCS-3d.mCSB_scrollTools_vertical .mCSB_dragger{height:70px}.mCS-3d-dark.mCSB_scrollTools_horizontal .mCSB_dragger,.mCS-3d.mCSB_scrollTools_horizontal .mCSB_dragger{width:70px}.mCS-3d-dark.mCSB_scrollTools,.mCS-3d.mCSB_scrollTools{opacity:1;filter:"alpha(opacity=30)";-ms-filter:"alpha(opacity=30)"}.mCS-3d-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-3d-dark.mCSB_scrollTools .mCSB_draggerRail,.mCS-3d.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-3d.mCSB_scrollTools .mCSB_draggerRail{-webkit-border-radius:16px;-moz-border-radius:16px;border-radius:16px}.mCS-3d-dark.mCSB_scrollTools .mCSB_draggerRail,.mCS-3d.mCSB_scrollTools .mCSB_draggerRail{width:8px;background-color:#000;background-color:rgba(0,0,0,.2);box-shadow:inset 1px 0 1px rgba(0,0,0,.5),inset -1px 0 1px rgba(255,255,255,.2)}.mCS-3d-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-3d-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-3d-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,.mCS-3d-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar,.mCS-3d.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-3d.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-3d.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,.mCS-3d.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar{background-color:#555}.mCS-3d-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-3d.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{width:8px}.mCS-3d-dark.mCSB_scrollTools_horizontal .mCSB_draggerRail,.mCS-3d.mCSB_scrollTools_horizontal .mCSB_draggerRail{width:100%;height:8px;margin:4px 0;box-shadow:inset 0 1px 1px rgba(0,0,0,.5),inset 0 -1px 1px rgba(255,255,255,.2)}.mCS-3d-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-3d.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar{width:100%;height:8px;margin:4px auto}.mCS-3d.mCSB_scrollTools .mCSB_buttonUp{background-position:-32px -72px}.mCS-3d.mCSB_scrollTools .mCSB_buttonDown{background-position:-32px -92px}.mCS-3d.mCSB_scrollTools .mCSB_buttonLeft{background-position:-40px -112px}.mCS-3d.mCSB_scrollTools .mCSB_buttonRight{background-position:-40px -128px}.mCS-3d-dark.mCSB_scrollTools .mCSB_draggerRail{background-color:#000;background-color:rgba(0,0,0,.1);box-shadow:inset 1px 0 1px rgba(0,0,0,.1)}.mCS-3d-dark.mCSB_scrollTools_horizontal .mCSB_draggerRail{box-shadow:inset 0 1px 1px rgba(0,0,0,.1)}.mCS-3d-dark.mCSB_scrollTools .mCSB_buttonUp{background-position:-112px -72px}.mCS-3d-dark.mCSB_scrollTools .mCSB_buttonDown{background-position:-112px -92px}.mCS-3d-dark.mCSB_scrollTools .mCSB_buttonLeft{background-position:-120px -112px}.mCS-3d-dark.mCSB_scrollTools .mCSB_buttonRight{background-position:-120px -128px}.mCS-3d-thick-dark.mCSB_scrollTools,.mCS-3d-thick.mCSB_scrollTools{opacity:1;filter:"alpha(opacity=30)";-ms-filter:"alpha(opacity=30)"}.mCS-3d-thick-dark.mCSB_scrollTools,.mCS-3d-thick-dark.mCSB_scrollTools .mCSB_draggerContainer,.mCS-3d-thick.mCSB_scrollTools,.mCS-3d-thick.mCSB_scrollTools .mCSB_draggerContainer{-webkit-border-radius:7px;-moz-border-radius:7px;border-radius:7px}.mCS-3d-thick-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-3d-thick.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px}.mCSB_inside+.mCS-3d-thick-dark.mCSB_scrollTools_vertical,.mCSB_inside+.mCS-3d-thick.mCSB_scrollTools_vertical{right:1px}.mCS-3d-thick-dark.mCSB_scrollTools_vertical,.mCS-3d-thick.mCSB_scrollTools_vertical{box-shadow:inset 1px 0 1px rgba(0,0,0,.1),inset 0 0 14px rgba(0,0,0,.5)}.mCS-3d-thick-dark.mCSB_scrollTools_horizontal,.mCS-3d-thick.mCSB_scrollTools_horizontal{bottom:1px;box-shadow:inset 0 1px 1px rgba(0,0,0,.1),inset 0 0 14px rgba(0,0,0,.5)}.mCS-3d-thick-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-3d-thick.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{box-shadow:inset 1px 0 0 rgba(255,255,255,.4);width:12px;margin:2px;position:absolute;height:auto;top:0;bottom:0;left:0;right:0}.mCS-3d-thick-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-3d-thick.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar{box-shadow:inset 0 1px 0 rgba(255,255,255,.4)}.mCS-3d-thick.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-3d-thick.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-3d-thick.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,.mCS-3d-thick.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar{background-color:#555}.mCS-3d-thick-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-3d-thick.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar{height:12px;width:auto}.mCS-3d-thick.mCSB_scrollTools .mCSB_draggerContainer{background-color:#000;background-color:rgba(0,0,0,.05);box-shadow:inset 1px 1px 16px rgba(0,0,0,.1)}.mCS-3d-thick.mCSB_scrollTools .mCSB_draggerRail{background-color:transparent}.mCS-3d-thick.mCSB_scrollTools .mCSB_buttonUp{background-position:-32px -72px}.mCS-3d-thick.mCSB_scrollTools .mCSB_buttonDown{background-position:-32px -92px}.mCS-3d-thick.mCSB_scrollTools .mCSB_buttonLeft{background-position:-40px -112px}.mCS-3d-thick.mCSB_scrollTools .mCSB_buttonRight{background-position:-40px -128px}.mCS-3d-thick-dark.mCSB_scrollTools{box-shadow:inset 0 0 14px rgba(0,0,0,.2)}.mCS-3d-thick-dark.mCSB_scrollTools_horizontal{box-shadow:inset 0 1px 1px rgba(0,0,0,.1),inset 0 0 14px rgba(0,0,0,.2)}.mCS-3d-thick-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{box-shadow:inset 1px 0 0 rgba(255,255,255,.4),inset -1px 0 0 rgba(0,0,0,.2)}.mCS-3d-thick-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar{box-shadow:inset 0 1px 0 rgba(255,255,255,.4),inset 0 -1px 0 rgba(0,0,0,.2)}.mCS-3d-thick-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-3d-thick-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-3d-thick-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,.mCS-3d-thick-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar{background-color:#777}.mCS-3d-thick-dark.mCSB_scrollTools .mCSB_draggerContainer{background-color:#fff;background-color:rgba(0,0,0,.05);box-shadow:inset 1px 1px 16px rgba(0,0,0,.1)}.mCS-3d-thick-dark.mCSB_scrollTools .mCSB_draggerRail{background-color:transparent}.mCS-3d-thick-dark.mCSB_scrollTools .mCSB_buttonUp{background-position:-112px -72px}.mCS-3d-thick-dark.mCSB_scrollTools .mCSB_buttonDown{background-position:-112px -92px}.mCS-3d-thick-dark.mCSB_scrollTools .mCSB_buttonLeft{background-position:-120px -112px}.mCS-3d-thick-dark.mCSB_scrollTools .mCSB_buttonRight{background-position:-120px -128px}.mCSB_outside+.mCS-minimal-dark.mCSB_scrollTools_vertical,.mCSB_outside+.mCS-minimal.mCSB_scrollTools_vertical{right:0;margin:12px 0}.mCustomScrollBox.mCS-minimal+.mCSB_scrollTools+.mCSB_scrollTools.mCSB_scrollTools_horizontal,.mCustomScrollBox.mCS-minimal+.mCSB_scrollTools.mCSB_scrollTools_horizontal,.mCustomScrollBox.mCS-minimal-dark+.mCSB_scrollTools+.mCSB_scrollTools.mCSB_scrollTools_horizontal,.mCustomScrollBox.mCS-minimal-dark+.mCSB_scrollTools.mCSB_scrollTools_horizontal{bottom:0;margin:0 12px}.mCS-dir-rtl>.mCSB_outside+.mCS-minimal-dark.mCSB_scrollTools_vertical,.mCS-dir-rtl>.mCSB_outside+.mCS-minimal.mCSB_scrollTools_vertical{left:0;right:auto}.mCS-minimal-dark.mCSB_scrollTools .mCSB_draggerRail,.mCS-minimal.mCSB_scrollTools .mCSB_draggerRail{background-color:transparent}.mCS-minimal-dark.mCSB_scrollTools_vertical .mCSB_dragger,.mCS-minimal.mCSB_scrollTools_vertical .mCSB_dragger{height:50px}.mCS-minimal-dark.mCSB_scrollTools_horizontal .mCSB_dragger,.mCS-minimal.mCSB_scrollTools_horizontal .mCSB_dragger{width:50px}.mCS-minimal.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{background-color:#fff;background-color:rgba(255,255,255,.2);filter:"alpha(opacity=20)";-ms-filter:"alpha(opacity=20)"}.mCS-minimal.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-minimal.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar{background-color:#fff;background-color:rgba(255,255,255,.5);filter:"alpha(opacity=50)";-ms-filter:"alpha(opacity=50)"}.mCS-minimal-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.2);filter:"alpha(opacity=20)";-ms-filter:"alpha(opacity=20)"}.mCS-minimal-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-minimal-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.5);filter:"alpha(opacity=50)";-ms-filter:"alpha(opacity=50)"}.mCS-dark-3.mCSB_scrollTools .mCSB_draggerRail,.mCS-light-3.mCSB_scrollTools .mCSB_draggerRail{width:6px;background-color:#000;background-color:rgba(0,0,0,.2)}.mCS-dark-3.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-light-3.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{width:6px}.mCS-dark-3.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-dark-3.mCSB_scrollTools_horizontal .mCSB_draggerRail,.mCS-light-3.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-light-3.mCSB_scrollTools_horizontal .mCSB_draggerRail{width:100%;height:6px;margin:5px 0}.mCS-dark-3.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,.mCS-dark-3.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail,.mCS-light-3.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,.mCS-light-3.mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail{width:12px}.mCS-dark-3.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,.mCS-dark-3.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail,.mCS-light-3.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded+.mCSB_draggerRail,.mCS-light-3.mCSB_scrollTools_horizontal.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail{height:12px;margin:2px 0}.mCS-light-3.mCSB_scrollTools .mCSB_buttonUp{background-position:-32px -72px}.mCS-light-3.mCSB_scrollTools .mCSB_buttonDown{background-position:-32px -92px}.mCS-light-3.mCSB_scrollTools .mCSB_buttonLeft{background-position:-40px -112px}.mCS-light-3.mCSB_scrollTools .mCSB_buttonRight{background-position:-40px -128px}.mCS-dark-3.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.75)}.mCS-dark-3.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.85)}.mCS-dark-3.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-dark-3.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.9)}.mCS-dark-3.mCSB_scrollTools .mCSB_draggerRail{background-color:#000;background-color:rgba(0,0,0,.1)}.mCS-dark-3.mCSB_scrollTools .mCSB_buttonUp{background-position:-112px -72px}.mCS-dark-3.mCSB_scrollTools .mCSB_buttonDown{background-position:-112px -92px}.mCS-dark-3.mCSB_scrollTools .mCSB_buttonLeft{background-position:-120px -112px}.mCS-dark-3.mCSB_scrollTools .mCSB_buttonRight{background-position:-120px -128px}.mCS-inset-2-dark.mCSB_scrollTools .mCSB_draggerRail,.mCS-inset-2.mCSB_scrollTools .mCSB_draggerRail,.mCS-inset-3-dark.mCSB_scrollTools .mCSB_draggerRail,.mCS-inset-3.mCSB_scrollTools .mCSB_draggerRail,.mCS-inset-dark.mCSB_scrollTools .mCSB_draggerRail,.mCS-inset.mCSB_scrollTools .mCSB_draggerRail{width:12px;background-color:#000;background-color:rgba(0,0,0,.2)}.mCS-inset-2-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-inset-2.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-inset-3.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-inset-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-inset.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{width:6px;margin:3px 5px;position:absolute;height:auto;top:0;bottom:0;left:0;right:0}.mCS-inset-2-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-inset-2.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-inset-3-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-inset-3.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-inset-dark.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar,.mCS-inset.mCSB_scrollTools_horizontal .mCSB_dragger .mCSB_dragger_bar{height:6px;margin:5px 3px;position:absolute;width:auto;top:0;bottom:0;left:0;right:0}.mCS-inset-2-dark.mCSB_scrollTools_horizontal .mCSB_draggerRail,.mCS-inset-2.mCSB_scrollTools_horizontal .mCSB_draggerRail,.mCS-inset-3-dark.mCSB_scrollTools_horizontal .mCSB_draggerRail,.mCS-inset-3.mCSB_scrollTools_horizontal .mCSB_draggerRail,.mCS-inset-dark.mCSB_scrollTools_horizontal .mCSB_draggerRail,.mCS-inset.mCSB_scrollTools_horizontal .mCSB_draggerRail{width:100%;height:12px;margin:2px 0}.mCS-inset-2.mCSB_scrollTools .mCSB_buttonUp,.mCS-inset-3.mCSB_scrollTools .mCSB_buttonUp,.mCS-inset.mCSB_scrollTools .mCSB_buttonUp{background-position:-32px -72px}.mCS-inset-2.mCSB_scrollTools .mCSB_buttonDown,.mCS-inset-3.mCSB_scrollTools .mCSB_buttonDown,.mCS-inset.mCSB_scrollTools .mCSB_buttonDown{background-position:-32px -92px}.mCS-inset-2.mCSB_scrollTools .mCSB_buttonLeft,.mCS-inset-3.mCSB_scrollTools .mCSB_buttonLeft,.mCS-inset.mCSB_scrollTools .mCSB_buttonLeft{background-position:-40px -112px}.mCS-inset-2.mCSB_scrollTools .mCSB_buttonRight,.mCS-inset-3.mCSB_scrollTools .mCSB_buttonRight,.mCS-inset.mCSB_scrollTools .mCSB_buttonRight{background-position:-40px -128px}.mCS-inset-2-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar,.mCS-inset-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.75)}.mCS-inset-2-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar,.mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar,.mCS-inset-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.85)}.mCS-inset-2-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-inset-2-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,.mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,.mCS-inset-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-inset-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.9)}.mCS-inset-2-dark.mCSB_scrollTools .mCSB_draggerRail,.mCS-inset-3-dark.mCSB_scrollTools .mCSB_draggerRail,.mCS-inset-dark.mCSB_scrollTools .mCSB_draggerRail{background-color:#000;background-color:rgba(0,0,0,.1)}.mCS-inset-2-dark.mCSB_scrollTools .mCSB_buttonUp,.mCS-inset-3-dark.mCSB_scrollTools .mCSB_buttonUp,.mCS-inset-dark.mCSB_scrollTools .mCSB_buttonUp{background-position:-112px -72px}.mCS-inset-2-dark.mCSB_scrollTools .mCSB_buttonDown,.mCS-inset-3-dark.mCSB_scrollTools .mCSB_buttonDown,.mCS-inset-dark.mCSB_scrollTools .mCSB_buttonDown{background-position:-112px -92px}.mCS-inset-2-dark.mCSB_scrollTools .mCSB_buttonLeft,.mCS-inset-3-dark.mCSB_scrollTools .mCSB_buttonLeft,.mCS-inset-dark.mCSB_scrollTools .mCSB_buttonLeft{background-position:-120px -112px}.mCS-inset-2-dark.mCSB_scrollTools .mCSB_buttonRight,.mCS-inset-3-dark.mCSB_scrollTools .mCSB_buttonRight,.mCS-inset-dark.mCSB_scrollTools .mCSB_buttonRight{background-position:-120px -128px}.mCS-inset-2-dark.mCSB_scrollTools .mCSB_draggerRail,.mCS-inset-2.mCSB_scrollTools .mCSB_draggerRail{background-color:transparent;border-width:1px;border-style:solid;border-color:#fff;border-color:rgba(255,255,255,.2);-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.mCS-inset-2-dark.mCSB_scrollTools .mCSB_draggerRail{border-color:#000;border-color:rgba(0,0,0,.2)}.mCS-inset-3.mCSB_scrollTools .mCSB_draggerRail{background-color:#fff;background-color:rgba(255,255,255,.6)}.mCS-inset-3-dark.mCSB_scrollTools .mCSB_draggerRail{background-color:#000;background-color:rgba(0,0,0,.6)}.mCS-inset-3.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.75)}.mCS-inset-3.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.85)}.mCS-inset-3.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-inset-3.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar{background-color:#000;background-color:rgba(0,0,0,.9)}.mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{background-color:#fff;background-color:rgba(255,255,255,.75)}.mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger:hover .mCSB_dragger_bar{background-color:#fff;background-color:rgba(255,255,255,.85)}.mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar,.mCS-inset-3-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar{background-color:#fff;background-color:rgba(255,255,255,.9)}.pretty-checkbox{position:relative;display:inline-block}.pretty-checkbox>input[type=checkbox]{display:none}.pretty-checkbox>input[type=checkbox]:checked~label [class^=unch]{opacity:0}.pretty-checkbox>input[type=checkbox]:checked~label [class^=unch]:after,.pretty-checkbox>input[type=checkbox]:checked~label [class^=unch]:before{background-color:#fff}.pretty-checkbox>input[type=checkbox]:checked~label [class^=ch]{opacity:1}.pretty-checkbox>input[type=checkbox]:checked~label [class^=ch]:after,.pretty-checkbox>input[type=checkbox]:checked~label [class^=ch]:before{background-color:#fff}.pretty-checkbox>label{cursor:pointer;padding:0 0 13px 26px}.pretty-checkbox>label>span{display:block;position:absolute;left:0;transition-duration:.2s;background-color:#263845;height:23px;width:23px}.pretty-checkbox>label>.unch-top{border-top:3px solid #9b9c9e}.pretty-checkbox>label>.ch-top{border-top:3px solid #fff}.pretty-checkbox>label>.unch-right{border-right:3px solid #9b9c9e}.pretty-checkbox>label>.ch-right{border-right:3px solid #fff}.pretty-checkbox>label>.unch-left{border-left:3px solid #9b9c9e}.pretty-checkbox>label>.ch-left{border-left:3px solid #fff}.pretty-checkbox>label>.unch-bottom{border-bottom:3px solid #9b9c9e}.pretty-checkbox>label>.ch-bottom{border-bottom:3px solid #fff}.pretty-checkbox>label>.unch-all{border:3px solid #9b9c9e}.pretty-checkbox>label>.ch-all{border:3px solid #fff}.border-bottom-left{position:relative;border:none!important}.border-bottom-left:before{content:'';background:#9b9c9e;z-index:100;position:absolute;bottom:0;left:0;width:50%;height:3px}.border-bottom-left:after{content:'';background:#9b9c9e;z-index:100;position:absolute;bottom:0;left:0;height:50%;width:3px}.border-top-left{position:relative;border:none!important}.border-top-left:before{content:'';background:#9b9c9e;z-index:100;position:absolute;top:0;left:0;width:50%;height:3px}.border-top-left:after{content:'';background:#9b9c9e;z-index:100;position:absolute;top:0;left:0;height:50%;width:3px}.border-bottom-right{position:relative;border:none!important}.border-bottom-right:before{content:'';background:#9b9c9e;z-index:100;position:absolute;bottom:0;right:0;width:50%;height:3px}.border-bottom-right:after{content:'';background:#9b9c9e;z-index:100;position:absolute;bottom:0;right:0;height:50%;width:3px}.border-top-right{position:relative;border:none!important}.border-top-right:before{content:'';background:#9b9c9e;z-index:100;position:absolute;top:0;right:0;width:50%;height:3px}.border-top-right:after{content:'';background:#9b9c9e;z-index:100;position:absolute;top:0;right:0;height:50%;width:3px}.ui-slider{position:relative;text-align:left;background:#263845;border-radius:5px;margin:20px 0 11px}.ui-slider .ui-slider-handle.blow-up{width:1.7em;height:1.7em;top:-.8em}.ui-slider .ui-slider-handle{position:absolute;z-index:2;width:1.2em;height:1.2em;cursor:default;-ms-touch-action:none;touch-action:none;outline:0;background:#fff;transition:height .18s ease,width .18s ease,background-color .28s ease,border .18s ease}.ui-slider .ui-slider-range{position:absolute;z-index:1;font-size:.7em;display:block;border:0;background:#00b588;border-radius:5px}.ui-slider.ui-state-disabled .ui-slider-handle,.ui-slider.ui-state-disabled .ui-slider-range{-webkit-filter:inherit;filter:inherit}.ui-slider-horizontal{height:.6em;border-radius:3px}.ui-slider-horizontal .ui-slider-handle{top:-.3em;margin-left:-.1em;border-radius:50%;box-shadow:1px 1px 4px rgba(0,0,0,.8)}.ui-slider-horizontal .ui-slider-range{top:0;height:100%}.ui-slider-horizontal .ui-slider-range-min{left:0}.ui-slider-horizontal .ui-slider-range-max{right:0}.pretty-select{background:#263845;width:190px;border:1px solid #2f4555;color:#3b7694;height:35px;font-size:13px;float:right;padding-left:7px}.ui-selectmenu-menu{padding:0;margin:0;position:absolute;top:0;left:0;display:none;background:#263845}.ui-selectmenu-menu .select-search{max-width:178px;margin:10px;border-radius:0;border:none;background:#2f4555;color:#3b7694}.ui-selectmenu-menu .ui-menu{overflow:auto;overflow-x:hidden;padding-bottom:1px}.ui-selectmenu-menu .ui-menu .ui-selectmenu-optgroup{font-size:1em;font-weight:700;line-height:1.5;padding:2px .4em;margin:.5em 0 0;height:auto;border:0}.ui-selectmenu-open{display:block}.ui-selectmenu-button{background:#263845;color:#3b7694;float:left;height:28px;padding:6px 14px;margin-right:5px;border:none;border-radius-top-right:3px;border-radius-top-left:3px;box-shadow:inset 0 1px 0 rgba(255,255,255,.04);outline:0;display:inline-block;overflow:hidden;position:relative;text-decoration:none;cursor:pointer}.ui-selectmenu-button span.ui-icon{right:.5em;left:auto;margin-top:-8px;position:absolute;top:50%}.ui-selectmenu-button span.ui-selectmenu-text{text-align:left;display:block;line-height:1.4;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ui-icon{background-image:url(images/ui-icons_222222_256x240.png);width:16px;height:16px;display:block;text-indent:-999999;overflow:hidden;background-repeat:no-repeat}.ui-icon-triangle-1-s{background-position:-64px -16px}.ui-menu{padding:0}.ui-menu .ui-menu-item{position:relative;background:#263845;color:#3b7694;margin:0;padding:3px 10px;cursor:pointer;z-index:3;min-height:0;list-style-image:url(data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7)}li.ui-state-focus{background:#00b588!important;color:#fff!important}.toggle-slide{overflow:hidden;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;direction:ltr}.toggle-slide .toggle-blob,.toggle-slide .toggle-off,.toggle-slide .toggle-on{float:left}.toggle-slide .toggle-blob{position:relative;z-index:99;cursor:hand;cursor:-webkit-grab;cursor:grab}.toggle-light .toggle-slide{border-radius:9999px;box-shadow:0 0 0 1px #999}.toggle-light .toggle-on{text-indent:10px!important}.toggle-light .toggle-off{text-indent:20px!important}.toggle-light .toggle-off,.toggle-light .toggle-on{font-size:12px;font-weight:500}.toggle-light .toggle-on,.toggle-light .toggle-select .toggle-inner .active{background:#179ede;box-shadow:inset 2px 2px 6px rgba(0,0,0,.2);text-shadow:1px 1px rgba(0,0,0,.2);color:rgba(255,255,255,.8)}.toggle-light .toggle-off,.toggle-light .toggle-select .toggle-on{color:rgba(0,0,0,.6);text-shadow:0 1px rgba(255,255,255,.2);background:linear-gradient(#cfcfcf,#f5f5f5)}.toggle-light .toggle-blob{border-radius:50px;background:linear-gradient(#f5f5f5,#cfcfcf);box-shadow:1px 1px 2px #888}.toggle-light .toggle-blob:hover{background:linear-gradient(#e4e4e4,#f9f9f9)}#linker{position:absolute;z-index:15;width:400px;min-height:200px;background-color:#1c2a33;box-shadow:inset 0 0 1px rgba(255,255,255,.6),0 2px 10px rgba(0,0,0,.6);border:1px solid #1e2123;color:#3b7694}#linker>h3{border-bottom:1px solid #2f4555;margin:0;padding:15px;font-size:20px}#linker>h3:after,#linker>h3:before{content:" ";display:table}#linker>h3:after{clear:both}#linker>h3>span{margin-left:5px}#linker>h3>.fa{font-size:15px;padding-top:2px;color:#1e3c4b}#linker>h3>.fa:hover{cursor:pointer;-webkit-transform:scale(1.3);transform:scale(1.3)}#linker>ul{list-style:none;padding:10px 20px}#linker>ul>li{margin-bottom:10px;border:1px solid #2f4555;border-radius:3px;width:100%}#linker>ul>li:after,#linker>ul>li:before{content:" ";display:table}#linker>ul>li:after{clear:both}#linker>ul>li>.pull-left{width:10%;border-right:1px solid #2f4555;padding:10px;cursor:pointer;margin:0}#linker>ul>li>.pull-left>.radio-input{padding:20px 0 15px 2px}#linker>ul>li>.pull-left>.radio-input>input{outline:0;cursor:pointer}#linker>ul>li>.pull-right{width:90%;padding:10px}#linker>ul>li .title{margin-bottom:5px;font-size:13px}#linker>ul>li.disabled .pull-right{opacity:.4;pointer-events:none}#linker>ul>li.disabled .pull-right .form-control{display:none}#linker>ul>li.disabled .pull-right .title{padding-top:5px}#linker>ul>li.disabled .pull-left{padding:0 10px}#linker>ul>li.disabled .pull-left>.radio-input{padding:15px 0 10px 2px}#linker>ul .form-control{border-radius:0;background-color:#263845;color:#3b7694;border:1px solid #2f4555}#linker>ul .form-control::-moz-placeholder{color:#3b7694;opacity:1}#linker>ul .form-control:-ms-input-placeholder{color:#3b7694}#linker>ul .form-control::-webkit-input-placeholder{color:#3b7694}#description-container{position:absolute;top:110px;left:248px;background-color:#1c2a33;color:#3b7694;width:233px;padding:5px 10px;font-size:13px;z-index:10;border:3px solid #555;border-radius:2px;box-shadow:2px 2px 12px rgba(0,0,0,.7);text-align:center;-webkit-transition:opacity .1s ease-out;-o-transition:opacity .1s ease-out;transition:opacity .1s ease-out;pointer-events:none;display:none}#description-container:after,#description-container:before{right:100%;top:50%;border:solid transparent;content:" ";height:0;width:0;position:absolute;pointer-events:none}#description-container:after{border-right-color:#1c2a33;border-width:9px;margin-top:-9px}#description-container:before{border-right-color:#555;border-width:14px;margin-top:-14px}#navigation{text-align:center}#navigation .nav-item{display:inline-block;font-size:25px;color:#3b7694;padding:10px 12px;cursor:pointer}#navigation .nav-item.open{background-color:#253843;color:#3b7694}#navigation .panel-name{background-color:#253843;padding:10px;text-align:center;font-size:20px;text-transform:capitalize;color:#3b7694;position:relative;z-index:10;box-shadow:0 3px 1px -2px rgba(0,0,0,.14),0 2px 2px 0 rgba(0,0,0,.098),0 1px 5px 0 rgba(0,0,0,.084)}#navigation .breadcrumb{padding:10px 5px 5px;margin:0;text-align:center;background-color:#1c2a33}#navigation .breadcrumb>li>a{color:#3b7694;text-transform:uppercase;font-size:10px}#navigation .breadcrumb>li.active>a{font-weight:700;pointer-events:none;cursor:text}[bl-panels-accordion] .accordion-body{max-height:0;overflow:hidden;transition:max-height .7s cubic-bezier(.35,0,.25,1)}[bl-panels-accordion] .accordion-body canvas{display:none}[bl-panels-accordion] .open .accordion-body{max-height:600px}[bl-panels-accordion] .open .accordion-body canvas{display:inline-block}[bl-panels-accordion] .open .accordion-heading{background-color:#2f4555;margin-bottom:0}[bl-panels-accordion] .open .accordion-heading>i{-webkit-transform:rotate(180deg);transform:rotate(180deg)}.accordion-heading{background-color:#263845;color:#8da8b8;border-radius:3px;height:50px;font-size:14px;padding:15px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;margin:0 15px 5px;cursor:pointer;font-weight:500;line-height:20px}.accordion-heading>.icon{float:right;pointer-events:none;transition:-webkit-transform .7s ease;transition:transform .7s ease}.accordion-heading:hover{background-color:#2f4555}#elements-container{-webkit-flex:0 0 380px;-ms-flex:0 0 380px;flex:0 0 380px;height:100%;background:#1c2a33;box-shadow:1px 0 2px rgba(0,0,0,.5);z-index:9;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-transition:left .2s linear;-o-transition:left .2s linear;transition:left .2s linear;position:relative}#elements-container:after,#elements-container:before{content:" ";display:table}#elements-container:after{clear:both}#elements-container .panel-inner{width:calc(100% - 70px);height:100%;overflow:visible;float:left;position:relative}#elements-container .main-nav{width:70px;background:#09181f;float:left;height:100%;position:relative;padding-top:130px}#elements-container .main-nav>.selected-tab{width:100%;height:65px;position:absolute;background-color:#1c2a33;z-index:0;transition:-webkit-transform .3s ease-out;transition:transform .3s ease-out;-webkit-transform:translateY(9px);transform:translateY(9px)}#elements-container .main-nav>.selected-tab .bottom,#elements-container .main-nav>.selected-tab>.top{position:absolute;right:0;top:-7px;width:7px;height:7px;background-color:#1c2a33}#elements-container .main-nav>.selected-tab .bottom:after,#elements-container .main-nav>.selected-tab>.top:after{content:'';position:absolute;right:0;bottom:0;width:14px;height:14px;border-radius:7px;background-color:#09181f}#elements-container .main-nav>.selected-tab>.bottom{top:auto;bottom:-7px}#elements-container .main-nav>.selected-tab>.bottom:after{top:0;bottom:auto}#elements-container .main-nav .push-top{position:absolute;top:10px;width:100%}@media (max-height:650px){#elements-container .main-nav{padding-top:30px}#elements-container .main-nav .push-top{display:none}}#elements-container .main-nav .push-bottom{position:absolute;bottom:3%;width:100%}@media (max-height:800px){#elements-container .main-nav .push-bottom{display:none}}#elements-container .main-nav .push-bottom>.nav-item{font-size:20px;display:block;width:100%;margin-bottom:0;padding-bottom:5px;outline:0!important}#elements-container .main-nav .push-bottom>.nav-item:disabled{cursor:auto;color:#254a5d}#elements-container .main-nav .push-bottom>.nav-item>span{font-size:10px}#elements-container .main-nav .nav-item{background-color:transparent;color:#5d8397;border:none;font-size:25px;text-align:center;margin-bottom:10px;padding:15px 0;cursor:pointer;position:relative;z-index:1;line-height:1.4}#elements-container .main-nav .nav-item.active{color:#fff}#elements-container .main-nav .nav-item:hover{color:#8aa7b7}#elements-container .main-nav .nav-item>span{font-size:11px;display:block;font-weight:700;letter-spacing:.5px}#elements-container #el-panel-top{margin:20px 15px 15px}#elements-container #el-preview-container{background-color:#263845}#elements-container #panel-search{margin-bottom:10px}#elements-container #panel-search>.form-control{background-color:#263845;border:1px solid #2f4555;color:#3b7694;border-radius:3px;height:40px}#elements-container #panel-search>.form-control::-moz-placeholder{color:#3b7694;opacity:1}#elements-container #panel-search>.form-control:-ms-input-placeholder{color:#3b7694}#elements-container #panel-search>.form-control::-webkit-input-placeholder{color:#3b7694}#elements-container .device-switcher{position:absolute;background-color:#1c2a33;color:#3b7694;bottom:50px;width:100%;box-shadow:0 -10px 25px -15px rgba(0,0,0,.275);transition:all .65s cubic-bezier(.23,1,.32,1);z-index:100}#elements-container .device-switcher.ng-hide{-webkit-transform:translate(0,270px);transform:translate(0,270px)}#elements-container .device-switcher>.current-device{text-align:center;padding:25px 0}#elements-container .device-switcher>.current-device>.name{text-transform:capitalize}#elements-container .device-switcher>.current-device>i{font-size:45px}#elements-container .device-switcher>.devices{border-bottom:1px solid #2f4555;border-top:1px solid #2f4555}#elements-container .device-switcher>.devices:after,#elements-container .device-switcher>.devices:before{content:" ";display:table}#elements-container .device-switcher>.devices:after{clear:both}#elements-container .device-switcher>.devices>button{font-size:30px;width:25%;background-color:#263845;border:none;border-left:1px solid #2f4555;float:left;outline:0!important}#elements-container .device-switcher>.devices>button.active{background-color:#4a6d87!important;color:#5d9ebe}#elements-container .device-switcher>.devices>button:hover{background-color:#2f4555}#elements-container .bottom-navigation{color:#3b7694;font-size:24px;border-top:1px solid #2f4555;position:absolute;z-index:101;bottom:0;left:0;width:100%}#elements-container .bottom-navigation:after,#elements-container .bottom-navigation:before{content:" ";display:table}#elements-container .bottom-navigation:after{clear:both}#elements-container .bottom-navigation button{border:none;border-right:1px solid #2f4555;padding:5px 10px;display:block;float:left;cursor:pointer;background-color:#253843;outline:0!important}#elements-container .bottom-navigation button:hover{background-color:#263845}#elements-container .bottom-navigation button.active{background-color:#4a6d87!important;color:#5d9ebe}#elements-container .panel{height:calc(100% - 44px);width:100%;overflow:auto;background-color:#1c2a33;color:#3b7694;margin-bottom:0;position:absolute;top:0;left:0;transition:opacity .4s ease;z-index:99;opacity:0;-webkit-transform:translateX(-130%);transform:translateX(-130%)}#elements-container .panel.open{opacity:1;-webkit-transform:translateX(0);transform:translateX(0)}#elements-container #el-preview-container{width:100%;height:100px;overflow:hidden}#elements-container #elements-list{padding:0}#elements-container #elements-list .elements-box:first-of-type{margin-top:2px}#elements-container #elements-list .list-unstyled{padding:5px 15px;margin:0}#elements-container #elements-list .list-unstyled:after,#elements-container #elements-list .list-unstyled:before{content:" ";display:table}#elements-container #elements-list .list-unstyled:after{clear:both}#elements-container #elements-list li{width:calc(33.33% - 2px);height:84px;float:left;margin:1px}#elements-container #elements-list .el-list-item{background-color:#263845;font-weight:400;letter-spacing:.7px;transition:all 150ms ease-out;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;cursor:-webkit-grab;cursor:grab;border-radius:2px;text-align:center;height:100%;overflow:hidden;position:relative}#elements-container #elements-list .el-list-item>.text{color:#b1d2e5;padding:0 10px;height:50%;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center;text-transform:uppercase;font-size:10px}#elements-container #elements-list .el-list-item>.icon{padding-top:10px;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center;height:50%;color:#3b7694;font-size:26px;text-shadow:rgba(0,0,0,.3) 0 1px 1px}#elements-container #elements-list .el-list-item:hover{background-color:#385366}#elements-container #elements-panel{height:100%}#elements-container .elements-panel-heading{color:#3b7694;background-color:#1f2d38;text-transform:uppercase;box-shadow:inset 0 1px 0 rgba(255,255,255,.04);font-size:10px;padding:5px 10px;margin:0}#elements-container .elements-panel-heading .fa{float:right}@-moz-document url-prefix(){#elements-container .main-nav .nav-item>span{font-weight:500}}#text-toolbar{position:absolute;opacity:.95;height:45px;padding:7px;background:#1c2a33;border-radius:2px;z-index:6;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}#text-toolbar #icons-list{display:none;position:absolute;margin-top:50px;height:400px;background-color:#1c2a33;padding:5px;width:100%;left:0}#text-toolbar #icons-list>ul{max-height:345px;overflow:auto}#text-toolbar #icons-list>input{width:100%;background-color:#263845;color:#3b7694;padding:0 15px;border:none;outline:0;height:35px;vertical-align:middle;margin-bottom:10px}#text-toolbar #icons-list li>i{font-size:25px;width:25px;color:#3b7694;margin:6px}#text-toolbar #icons-list li>i:hover{-webkit-transform:scale(1.4);transform:scale(1.4);color:#fff}#text-toolbar #toolbar-size,#text-toolbar>#toolbar-font{background:#263845;float:left;height:30px;padding:4px 14px;margin-right:5px;border:none;color:#3b7694;border-radius:3px;box-shadow:inset 0 1px 0 rgba(255,255,255,.04);outline:0}#text-toolbar>#link-details{background:#1c2a33;padding:45px 15px 15px;display:block}#text-toolbar>#link-details>input{display:inline-block;width:43%}#text-toolbar>#link-details>input:first-of-type{margin-right:8px}#text-toolbar>#link-details>.btn{padding-top:7px;padding-bottom:7px;margin:0 0 4px 8px}#text-toolbar>#toolbar-style{float:left;height:30px}#text-toolbar>#toolbar-style>div{float:left;background:#263845;width:35px;height:100%;text-align:center;padding:6px;margin-right:2px;border:none;color:#3b7694;border-radius:3px;box-shadow:inset 0 1px 0 rgba(255,255,255,.04);outline:0;font:700 16px Arial,Helvetica,Tahoma,Verdana,Sans-Serif}#text-toolbar>#toolbar-style>div:hover{background-color:#2f4555}#text-toolbar>#toolbar-style .wrap-link,#text-toolbar>#toolbar-style>.align-left{margin-left:5.5px}#text-toolbar>#toolbar-style>.bold{margin-left:3px}#text-toolbar>#toolbar-style>.italic{font-style:italic}#text-toolbar>#toolbar-style>.underline{text-decoration:underline}#text-toolbar>#toolbar-style>.strike{text-decoration:line-through}#text-toolbar:hover{cursor:pointer}#fonts-modal .modal-content{border-radius:0}#fonts-modal .modal-content>.modal-header{padding-top:22px}#fonts-modal .modal-content>.modal-header>.close-modal{position:absolute;z-index:1010;top:-17px;right:-17px;font-size:1.6em}#fonts-modal .modal-content>.modal-header>.close-modal .fa-circle{color:#1c2a33}#fonts-modal .modal-content>.modal-header>.close-modal:hover{cursor:pointer;-webkit-transform:scale(1.12);transform:scale(1.12)}#fonts-modal .modal-content>.modal-header>.modal-title{padding-left:10px}#fonts-modal .modal-content>.modal-header>.pagi-container{margin-right:80px}#fonts-modal .modal-content>.modal-header>.pagi-container>.pagination{margin:0}#fonts-modal .modal-content>.modal-header>.pagi-container>.pagination>.disabled>span{background-color:transparent}#fonts-modal .modal-content>.modal-header>.pagi-container>.pagination>.active>span{background-color:#00b588;border-color:#00a57c}#fonts-modal .modal-content>.modal-header>.pagi-container>.pagination>li>a{color:#555;background-color:#f4f4f4}#fonts-modal .modal-content .fonts-list{padding:0}#fonts-modal .modal-content .fonts-list>li{list-style:none;display:inline-block;width:49.5%;padding:15px;margin-bottom:10px;background-color:#f1f1f1;-webkit-box-shadow:0 1px 1px #d0d0d0;box-shadow:0 1px 1px #d0d0d0;border-radius:3px}#fonts-modal .modal-content .fonts-list>li>.font-preview{margin-bottom:10px;font-size:22px;color:#555}#fonts-modal .modal-content .fonts-list>li>.font-details{font-family:Ubuntu!important;color:#333}#fonts-modal .modal-content .fonts-list>li:hover{cursor:pointer;background-color:#f9f9f9}#fonts-modal .modal-content .fonts-list>li:nth-child(odd){margin-right:13px}#context-menu{display:none;position:absolute;border-radius:4px;background-color:#1c2a33;color:#8aa7b7;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;width:240px;z-index:49}#context-menu>h5{color:#8aa7b7;margin:0 0 10px;text-transform:capitalize;border-bottom:1px solid #263845;font-size:13px}#context-menu>h5>.name{padding:12px 10px 10px;float:left}#context-menu>h5>.icon{padding:12px 10px 10px;float:right;border-left:1px solid #263845;height:100%}#context-menu>h5>.icon:hover{color:#fff;cursor:pointer}#context-menu>ul{margin-bottom:7px}#context-menu .separator{height:0;position:relative;border-top:1px solid #2f4555;margin:7px 5px;border-radius:2px;pointer-events:none;padding:0}#context-menu .disabled{color:#537587;pointer-events:none}#context-menu .disabled:hover{cursor:initial;background-color:#1c2a33}#context-menu li{font-size:13px;padding:3px 0 3px 25px}#context-menu li:after,#context-menu li:before{content:" ";display:table}#context-menu li:after{clear:both}#context-menu li .icon{padding-right:8px;margin-left:-25px}#context-menu li .icon-trash{padding-right:11px}#context-menu li>.command-name{float:left;padding-left:10px}#context-menu li>.command-keybind{float:right;color:#6a90a3;padding-right:10px;font-size:11px;font-weight:500}#context-menu li:hover{cursor:pointer;background-color:#253843}#code-editor-resize-overlay{width:100%;height:100%;z-index:999;left:0;top:0;display:none;position:absolute}#code-editor-wrapper{height:500px;z-index:99999;position:absolute;width:calc(100% - 440px);bottom:20px;left:400px;box-shadow:0 8px 10px -5px rgba(0,0,0,.14),0 16px 24px 2px rgba(0,0,0,.098),0 6px 30px 5px rgba(0,0,0,.8);border-radius:3px;display:none}#code-editor-wrapper .ui-resizable-se{position:absolute;right:-3px;bottom:-3px;cursor:se-resize;background-position:-64px -224px;background-image:url(images/ui-icons_ffffff_256x240.png)}#code-editor-wrapper .ui-resizable-e{cursor:e-resize;width:7px;right:-5px;top:0;height:100%;position:absolute}#code-editor-wrapper .ui-resizable-s{cursor:s-resize;height:7px;width:100%;bottom:-5px;left:0;position:absolute}#code-editor-wrapper #new-library-modal{margin-top:5%}#code-editor-wrapper.open{display:block;height:45%}#code-editor-wrapper>.code-editor{height:calc(100% - 30px);font-size:15px;width:100%}#code-editor-wrapper>.code-editor #jscript-code-editor{font-size:15px}#code-editor-wrapper>.code-editor .libraries-column,#code-editor-wrapper>.code-editor>.editor-column{height:100%}#code-editor-wrapper>.code-editor>.libraries-column{background-color:#1c2a33;color:#5d8397;padding:0}#code-editor-wrapper>.code-editor>.libraries-column>.body{height:100%;overflow:auto;padding:0 15px 15px}#code-editor-wrapper>.code-editor>.libraries-column>.body>.form-control{border-radius:0;background-color:#263845;border:1px solid #2f4555;color:#3b7694}#code-editor-wrapper>.code-editor>.libraries-column>.body>.form-control::-moz-placeholder{color:#3b7694;opacity:1}#code-editor-wrapper>.code-editor>.libraries-column>.body>.form-control:-ms-input-placeholder{color:#3b7694}#code-editor-wrapper>.code-editor>.libraries-column>.body>.form-control::-webkit-input-placeholder{color:#3b7694}#code-editor-wrapper>.code-editor>.libraries-column>.body .checkbox{font-size:13px;border-bottom:1px solid #2f4555;padding:0 15px 10px 20px;margin:5px -15px 15px}#code-editor-wrapper>.code-editor>.libraries-column>.body>h4{font-size:17px}#code-editor-wrapper>.code-editor>.libraries-column>.body>h4>.icon:hover{cursor:pointer;-webkit-transform:scale(1.2);transform:scale(1.2)}#code-editor-wrapper>.code-editor>.libraries-column .libraries-list{list-style:none;padding:0}#code-editor-wrapper>.code-editor>.libraries-column .libraries-list>li{padding:5px 10px;margin-bottom:5px;background-color:#263845;font-size:13px;border-radius:3px}#code-editor-wrapper>.code-editor>.libraries-column .libraries-list>li>.icon-link-outline{padding-right:5px;display:none}#code-editor-wrapper>.code-editor>.libraries-column .libraries-list>li>.lib-actions{display:inline-block;float:right}#code-editor-wrapper>.code-editor>.libraries-column .libraries-list>li>.lib-actions>.icon:hover{-webkit-transform:scale(1.2);transform:scale(1.2);color:#fff}#code-editor-wrapper>.code-editor>.libraries-column .libraries-list>li>.lib-actions>.icon:first-of-type{margin-right:5px}#code-editor-wrapper>.code-editor>.libraries-column .libraries-list>li:hover{cursor:pointer;background-color:#2f4555}#code-editor-wrapper>.code-editor>.libraries-column .libraries-list>li.attached{background-color:#416076;color:#fff}#code-editor-wrapper>.code-editor>.libraries-column .libraries-list>li.attached>.icon-link-outline{display:inline-block}#code-editor-wrapper>#editor-header{height:30px;background-color:#1c2a33;color:#3b7694;overflow:hidden;border-top-left-radius:3px;border-top-right-radius:3px;cursor:move}#code-editor-wrapper>#editor-header .pretty-select{background:#1c2a33;text-transform:capitalize;outline:0;border:none;border-right:1px solid #263845;height:29px}#code-editor-wrapper>#editor-header [bl-show-editor=js]{margin-right:130px}#code-editor-wrapper>#editor-header .btn-success{width:54px;text-align:center;border:none;background-color:#2f4555}#code-editor-wrapper>#editor-header .btn-success.active{background-color:#4a6d87}#code-editor-wrapper>#editor-header .btn{border-radius:0;height:100%;outline:0}#code-editor-wrapper>#editor-header .btn.with-icon{padding:0;border:none;background-color:#263845}#code-editor-wrapper>#editor-header .btn.with-icon:last-of-type{border-top-left-radius:3px}#code-editor-wrapper>#editor-header .icon{font-size:20px;width:25px;padding:5px;color:#3b7694}#code-editor-wrapper>#editor-header .icon:hover{cursor:pointer;color:#fff}#code-editor-wrapper.expanded{height:100%}.flyout-from-right{position:absolute;top:0;right:-100%;z-index:50;width:100%;height:100%;background-color:rgba(0,0,0,.7);-webkit-transition:all .2s linear;-o-transition:all .2s linear;transition:all .2s linear;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}.flyout-from-right .flyout-close{position:absolute;z-index:1010;left:-23px;font-size:44px;background-color:#fff;border-radius:50%;width:40px;height:40px}.flyout-from-right .flyout-close>.icon{position:absolute;top:-11px;left:-12px}.flyout-from-right .flyout-close:hover{cursor:pointer;-webkit-transform:scale(1.12);transform:scale(1.12)}.flyout-from-right>.flyout-content{background-color:#fff;position:absolute;right:0;-webkit-transition:top .45s linear;-o-transition:top .45s linear;transition:top .45s linear;-webkit-backface-visibility:hidden;backface-visibility:hidden}.flyout-from-right>.flyout-content.open{z-index:1001}.flyout-from-right>.flyout-content.closed{z-index:1000;top:-300%}.flyout-from-right>.flyout-content>.flyout-panel-toolbar{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;height:7%;background-color:#1c2a33;margin:0;text-align:center}.flyout-from-right>.flyout-content>.flyout-panel-toolbar .btn-primary{padding:8px 20px;border-radius:2px!important}.flyout-from-right>.flyout-content>.flyout-panel-toolbar>.inner{padding:13px 20px;display:inline-block}.flyout-from-right>.flyout-content>.flyout-panel-toolbar .back-icon{display:inline-block;height:100%;border-right:1px solid #2f4555;vertical-align:top;padding:16px 28px 0 25px;color:#fff;font-size:23px}.flyout-from-right>.flyout-content>.flyout-panel-toolbar .back-icon:hover{cursor:pointer;color:#a6a6a6}.flyout-from-right>.flyout-content>.flyout-panel-toolbar .btn{border-radius:0}.flyout-from-right>.flyout-content>.flyout-panel-toolbar .btn:first-of-type{margin-right:50px}.flyout-from-right>.flyout-content>.flyout-panel-toolbar .btn:last-of-type{margin-left:5px}.flyout-from-right>.flyout-content>.flyout-panel-toolbar .btn:active,.flyout-from-right>.flyout-content>.flyout-panel-toolbar .btn:focus,.flyout-from-right>.flyout-content>.flyout-panel-toolbar .btn:hover{outline:0}.flyout-from-right>.flyout-content>.flyout-panel-toolbar#theme-creator-toolbar .btn:first-of-type{margin-right:0}.flyout-from-right>.flyout-content>.flyout-panel-toolbar#theme-creator-toolbar .btn:nth-child(2){margin-right:50px}.flyout-from-right>.flyout-content>.flyout-panel-toolbar .error-message,.flyout-from-right>.flyout-content>.flyout-panel-toolbar .loader,.flyout-from-right>.flyout-content>.flyout-panel-toolbar .save-status{display:inline-block;color:#3b7694;margin-left:15px;vertical-align:middle}.flyout-from-right>.flyout-content>.flyout-panel-toolbar .error-message>.fa,.flyout-from-right>.flyout-content>.flyout-panel-toolbar .loader>.fa,.flyout-from-right>.flyout-content>.flyout-panel-toolbar .save-status>.fa{font-size:22px}.flyout-from-right>.flyout-content>.flyout-panel-toolbar input,.flyout-from-right>.flyout-content>.flyout-panel-toolbar select{background-color:#263845;border:1px solid #2f4555;color:#3b7694;padding:6px 12px;outline:0;vertical-align:middle}.flyout-from-right>.flyout-content>.flyout-panel-toolbar select{padding:7px 12px}.flyout-from-right.open{right:0}#export-panel .demo-overlay{position:absolute;top:0;left:0;width:100%;height:100%;z-index:1000;color:#fff;text-align:center;padding:0 30%}#export-panel .demo-overlay>p{position:relative;top:40%;font-size:15px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}#export-panel .inner-content{padding:15px 30px 5px}#export-panel .inner-content.demo{-webkit-filter:blur(1.3px);-moz-filter:blur(1.3px);-o-filter:blur(1.3px);-ms-filter:blur(1.3px);filter:blur(1.3px);opacity:.3}#export-panel .inner-content .css-column,#export-panel .inner-content .html-column,#export-panel .inner-content>.images-column{height:97%}#export-panel .inner-content .css-column>h2,#export-panel .inner-content .html-column>h2,#export-panel .inner-content>.images-column>h2{font-size:20px;height:30px;margin-top:0}#export-panel .inner-content .css-column>h2:after,#export-panel .inner-content .css-column>h2:before,#export-panel .inner-content .html-column>h2:after,#export-panel .inner-content .html-column>h2:before,#export-panel .inner-content>.images-column>h2:after,#export-panel .inner-content>.images-column>h2:before{content:" ";display:table}#export-panel .inner-content .css-column>h2:after,#export-panel .inner-content .html-column>h2:after,#export-panel .inner-content>.images-column>h2:after{clear:both}#export-panel .inner-content .css-column>h2>span,#export-panel .inner-content .html-column>h2>span,#export-panel .inner-content>.images-column>h2>span{float:left;margin-top:5px}#export-panel .inner-content .css-column>h2>.copy-confirmation,#export-panel .inner-content .html-column>h2>.copy-confirmation,#export-panel .inner-content>.images-column>h2>.copy-confirmation{float:right;color:#b3b3b3;font-size:13px;margin:7px 8px 0 0}#export-panel .inner-content .css-column>h2>.btn,#export-panel .inner-content .html-column>h2>.btn,#export-panel .inner-content>.images-column>h2>.btn{background-color:#ebebeb;border-radius:3px;border-color:#ebebeb;color:#9a9a9a;float:right;padding:4px 10px}#export-panel .inner-content .css-column>h2>.btn:active,#export-panel .inner-content .css-column>h2>.btn:focus,#export-panel .inner-content .html-column>h2>.btn:active,#export-panel .inner-content .html-column>h2>.btn:focus,#export-panel .inner-content>.images-column>h2>.btn:active,#export-panel .inner-content>.images-column>h2>.btn:focus{outline:0}#export-panel .inner-content>.images-column{overflow:auto}#export-panel .inner-content>.images-column li{width:100%;height:150px;background-repeat:no-repeat;background-position:center center;background-size:auto auto;-webkit-box-shadow:0 1px 5px 0 rgba(0,0,0,.3);box-shadow:0 1px 5px 0 rgba(0,0,0,.3);margin-bottom:15px;border-radius:3px;background-color:#eee}#export-panel .inner-content>.images-column li:hover{cursor:pointer}#export-panel>.flyout-panel-toolbar.demo{-webkit-filter:blur(.7px);-moz-filter:blur(.7px);-o-filter:blur(.7px);-ms-filter:blur(.7px);filter:blur(.7px);opacity:.4}#export-panel>.flyout-panel-toolbar>.center-block>select{text-transform:capitalize;margin-right:2px}#export-panel>.flyout-panel-toolbar>.center-block>.btn{border-radius:1px}#export-panel>.flyout-panel-toolbar>.center-block>.btn>.fa{margin-right:5px}#export-panel>.flyout-panel-toolbar>.center-block>.btn:first-of-type{margin-right:10px}#export-panel #css-export-preview,#export-panel #html-export-preview{height:92%;height:calc(100% - 30px);font-size:14px;-webkit-box-shadow:0 1px 5px 0 rgba(0,0,0,.3);box-shadow:0 1px 5px 0 rgba(0,0,0,.3);border-radius:3px}#export-panel #css-export-preview .ace_cursor,#export-panel #html-export-preview .ace_cursor{color:transparent}#templates-panel{background-color:#f5f5f5}#templates-panel .inner-content{padding:15px}#templates-panel #templates-list{height:100%;overflow:auto}#templates-panel #templates-list figure{margin-bottom:20px;-webkit-box-shadow:0 1px 2px rgba(0,0,0,.2);box-shadow:0 1px 2px rgba(0,0,0,.2);border-radius:4px;border:2px solid transparent}#templates-panel #templates-list figure>.img-responsive{border-top-right-radius:4px;border-top-left-radius:4px;width:100%}#templates-panel #templates-list figure:hover{cursor:pointer}#templates-panel #templates-list figure>figcaption{font-size:13px;border-top:1px solid #eee;text-align:center;padding:10px 5px;background-color:#fff;color:#777}#templates-panel #templates-list figure.active{border-color:#179ede}#templates-panel #templates-preview{height:100%;overflow:hidden}#templates-panel #templates-preview-iframe{width:100%;height:100%;border:none}#templates-panel .flyout-panel-toolbar{padding:15px;color:#e6e6e6}#templates-panel .flyout-panel-toolbar>.btn{margin-right:5px}#templates-panel .flyout-panel-toolbar>.btn:nth-child(4){margin-right:25px}#templates-panel .flyout-panel-toolbar>span{position:relative;top:3px;margin-right:10px}#bootstrap-theme-creator{background-color:#f5f5f5}#bootstrap-theme-creator #custom-less{position:absolute;z-index:1003;bottom:7%;left:5%;width:40%;border:5px solid #1c2a33;border-bottom:0;border-top-left-radius:4px;border-top-right-radius:4px;-webkit-transition:all .2s linear;-o-transition:all .2s linear;transition:all .2s linear}#bootstrap-theme-creator #custom-less.open{height:550px;border-width:5px}#bootstrap-theme-creator #custom-less.closed{height:0;overflow:hidden;border-width:0}#bootstrap-theme-creator #custom-less>.header{background-color:#1c2a33;text-align:center;color:#fff;padding:7px 0;height:34px;overflow:hidden}#bootstrap-theme-creator #custom-less>.header>.fa{float:right;margin-right:10px;color:#e6e6e6}#bootstrap-theme-creator #custom-less>.header>.fa:hover{cursor:pointer;-webkit-transform:scale(1.2);transform:scale(1.2)}#bootstrap-theme-creator #custom-less>#custom-less-editor{font-size:15px;height:calc(100% - 34px)}#bootstrap-theme-creator>.inner-content{height:93%}#bootstrap-theme-creator .mCSB_inside>.mCSB_container{margin-right:5px}#bootstrap-theme-creator .mCSB_draggerContainer{margin-left:11px}#bootstrap-theme-creator .mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{width:5px!important;background-color:#c8c8c8!important}#bootstrap-theme-creator .mCSB_scrollTools .mCSB_draggerRail{width:5px;background-color:#e6e6e6!important}#bootstrap-theme-creator label{color:#f7928f}#bootstrap-theme-creator .form-control{outline:0}#bootstrap-theme-creator>.inner-content .theme-creator-preview,#bootstrap-theme-creator>.inner-content .vars-groups-list,#bootstrap-theme-creator>.inner-content>.vars-values-list{border-right:10px solid #e6e6e6;height:100%;overflow:hidden;padding:10px 15px}#bootstrap-theme-creator>.inner-content>.vars-groups-list{padding:20px 0 0 25px}#bootstrap-theme-creator>.inner-content>.vars-values-list{padding:0}#bootstrap-theme-creator>.inner-content>.vars-values-list .mCSB_container{padding:15px}#bootstrap-theme-creator .vars-groups-list ul{margin-left:40px}#bootstrap-theme-creator .vars-groups-list ul>li{padding-bottom:3px;color:#f4645f;font-weight:600;font-size:14px;-webkit-transition:all .1s linear;-o-transition:all .1s linear;transition:all .1s linear;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}#bootstrap-theme-creator .vars-groups-list ul>li:hover{cursor:pointer;margin-left:10px;color:#ae110c}#bootstrap-theme-creator .vars-groups-list ul>li.active{margin-left:10px;color:#ae110c}#theme-creator-iframe{width:100%;height:100%;border:1px solid #eee;border-radius:3px}.modal-content{border-radius:0;border:0;-webkit-box-shadow:-14px 14px 0 0 rgba(0,0,0,.35);box-shadow:-14px 14px 0 0 rgba(0,0,0,.35);background-color:#F5F5F5}.modal-content .form-control{border-radius:3px;height:40px;background-color:#fff}.modal-content .modal-body{padding:10px 30px}.modal-content .modal-title{font-size:18px;color:#555;padding:0 15px}.modal-content label{font-weight:400;padding-top:9px}.modal-content .text-danger{margin-top:10px;text-align:center}.modal-content .modal-footer{background-color:#253845;border:none}.modal-content .modal-footer>.btn{-webkit-box-shadow:inset 0 -2px 0 rgba(0,0,0,.15);box-shadow:inset 0 -2px 0 rgba(0,0,0,.15);border-radius:0;border:none;font-size:15px;padding:10px 15px}#images-modal .btn-gradient-gray{color:#777;border:1px solid #d7dada;background-color:#f4f5f5;background-image:-webkit-gradient(linear,left top,left bottom,from(#f4f5f5),to(#dfdddd));background-image:-webkit-linear-gradient(top,#f4f5f5,#dfdddd);background-image:-moz-linear-gradient(top,#f4f5f5,#dfdddd);background-image:-ms-linear-gradient(top,#f4f5f5,#dfdddd);background-image:-o-linear-gradient(top,#f4f5f5,#dfdddd);background-image:linear-gradient(to bottom,#f4f5f5,#dfdddd);filter:progid:DXImageTransform.Microsoft.gradient(GradientType=0, startColorstr=#f4f5f5, endColorstr=#dfdddd)}#images-modal .btn-gradient-gray.active,#images-modal .btn-gradient-gray:hover{border:1px solid #bfc4c4;background-color:#d9dddd;background-image:-webkit-gradient(linear,left top,left bottom,from(#d9dddd),to(#c6c3c3));background-image:-webkit-linear-gradient(top,#d9dddd,#c6c3c3);background-image:-moz-linear-gradient(top,#d9dddd,#c6c3c3);background-image:-ms-linear-gradient(top,#d9dddd,#c6c3c3);background-image:-o-linear-gradient(top,#d9dddd,#c6c3c3);background-image:linear-gradient(to bottom,#d9dddd,#c6c3c3);filter:progid:DXImageTransform.Microsoft.gradient(GradientType=0, startColorstr=#d9dddd, endColorstr=#c6c3c3)}#images-modal .modal-dialog{width:65%}#images-modal .modal-header{background-color:#f1f1f1;padding:10px 15px}#images-modal .modal-header .close{padding-top:6px;font-size:25px;outline:0}#images-modal .modal-footer{border-top:1px solid #ddd;background-color:#f1f1f1}#images-modal .modal-footer>p{color:#555;margin:10px 0 0}#images-modal .modal-body{padding:0}#images-modal .modal-body .nav-tabs{padding-left:20px;background-color:#f1f1f1}#images-modal .modal-body .nav-tabs a{padding:5px 10px}#images-modal .modal-body>.modal-under-header{padding:10px 25px;color:#555;background-color:#f1f1f1}#images-modal .modal-body>.modal-under-header>p:first-of-type{margin-bottom:0}#images-modal .modal-body>.modal-under-header .btn{border-radius:1px;border:none;border-bottom:3px solid #127db0;margin-top:14px}#images-modal .modal-content{background-color:#fff}#images-modal #images-filter-bar{height:50px;border-bottom:1px solid #ddd;padding:10px 15px 0}#images-modal #images-filter-bar .checkbox-btn{display:inline-block;padding:3px 12px;outline:0}#images-modal #images-filter-bar .checkbox-btn>input{outline:0}#images-modal #images-filter-bar>.pull-right>input{height:30px;margin-left:7px;border:1px solid #d7dada;border-radius:3px;background:url(../images/search-icon.png) 8px no-repeat;padding-left:25px;vertical-align:middle;color:#555}#images-modal #images-filter-bar .btn{outline:0}#images-modal #url h2{text-align:center;color:#777;font-size:20px;margin:40px 0 30px}#images-modal #url>p{text-align:center;color:#777;margin:0}#images-modal #url>p:last-of-type{margin-bottom:30px}#images-modal #url>input{border:1px solid #d8d8d8;-webkit-box-shadow:none;box-shadow:none;border-radius:0;width:50%;margin:0 auto}#images-modal #url .checkbox{width:50%;margin:0 auto 30px;text-align:right;color:#777}#images-modal #url .checkbox label{padding-top:5px}#images-modal #url .checkbox input{margin:3px 0 0 -17px}#images-modal #images-cont{max-height:420px;overflow:auto}#images-modal #images-cont>.list-unstyled{padding:20px 5px}#images-modal #images-cont>.list-unstyled>li{height:194px}#images-modal #images-cont>.list-unstyled>li:hover{cursor:pointer}#images-modal #images-cont>.list-unstyled .img-wrapper{padding-bottom:100%;background-repeat:no-repeat;background-position:center center;background-color:#eee}#images-modal #images-cont>.list-unstyled .img-actions{display:none}#images-modal #images-cont>.list-unstyled .img-caption{text-align:center;padding:6px 0;color:#555;font-size:13px;margin-bottom:15px}#images-modal #images-cont>.list-unstyled .img-caption:after,#images-modal #images-cont>.list-unstyled .img-caption:before{content:" ";display:table}#images-modal #images-cont>.list-unstyled .img-caption:after{clear:both}#images-modal #images-cont>.list-unstyled>.selected>.img-wrapper{border:5px solid #179ede;border-top-right-radius:3px;border-top-left-radius:3px;padding-bottom:96%}#images-modal #images-cont>.list-unstyled>.selected .img-actions{display:block;float:right}#images-modal #images-cont>.list-unstyled>.selected .img-actions>.fa:hover{-webkit-transform:scale(1.3);transform:scale(1.3)}#images-modal #images-cont>.list-unstyled>.selected>.img-caption{padding:6px 7px;background-color:#179ede;color:#fff;border-bottom-right-radius:3px;border-bottom-left-radius:3px;text-align:none}#images-modal #images-cont>.list-unstyled>.selected>.img-caption>span{float:left}#images-modal #folders-cont{min-height:420px;height:auto;border-right:1px solid #ddd}#images-modal #folders-cont .list-unstyled{overflow-y:auto;max-height:250px}#images-modal #folders-cont .creating-folder{color:#fff;padding:10px;margin:0 -15px}#images-modal #folders-cont .creating-folder>input{display:inline-block;width:65%;height:20px;border-radius:0;border:1px solid #d7dada;-webkit-box-shadow:none;box-shadow:none}#images-modal #folders-cont .creating-folder>.btn-sm{height:20px;width:15%;border-radius:0;padding:0 5px;border:none;vertical-align:middle}#images-modal #folders-cont .creating-folder>.btn-success{border-bottom:2px solid #008261}#images-modal #folders-cont .creating-folder>.btn-success:active,#images-modal #folders-cont .creating-folder>.btn-success:focus,#images-modal #folders-cont .creating-folder>.btn-success:hover{background-color:#00aa80}#images-modal #folders-cont .creating-folder>.btn-danger{border-bottom:2px solid #962d22}#images-modal #folders-cont .creating-folder>.btn-danger:active,#images-modal #folders-cont .creating-folder>.btn-danger:focus,#images-modal #folders-cont .creating-folder>.btn-danger:hover{background-color:#b83729}#images-modal #folders-cont li{color:#555;padding:8px 30px}#images-modal #folders-cont li.active{background-color:#3db3eb!important;color:#fff}#images-modal #folders-cont li.active .delete-folder{display:block}#images-modal #folders-cont li:hover{cursor:pointer;background-color:#dff2fc}#images-modal #folders-cont li .delete-folder{display:none;padding-top:4px;color:#fff}#images-modal #folders-cont li .delete-folder:hover{-webkit-transform:scale(1.3);transform:scale(1.3)}#images-modal #folders-cont .add-folder-cont{position:absolute;bottom:0;right:0;left:0;margin-bottom:7px}#images-modal #folders-cont .add-folder-cont>.btn{border:none;border-radius:2px;width:90%;margin:0 auto;display:block}#images-modal #upload-container{height:350x}#images-modal #upload-container>.img-responsive{margin:0 auto}#images-modal #upload-container>h2{text-align:center;font-size:21px}#images-modal #upload-container>.btn{display:block;margin:0 auto;border-radius:3px;border:none;border-bottom:3px solid #008261}#images-modal #upload-container>.separator{border-top:1px solid #eee;color:#eee;margin:30px auto 15px;width:50%;text-align:center}#images-modal #upload-container>.separator>span{background-color:#fff;font-size:20px;position:relative;top:-15px;padding:0 15px}#publish-modal .demo .form-group,#publish-modal .demo .modal-body{cursor:no-drop!important}#publish-modal .demo .form-group .checkbox,#publish-modal .demo .form-group input{pointer-events:none}#publish-modal .demo-alert{margin:15px 0}#publish-modal .form-group{margin-bottom:5px}#publish-modal .checkbox{margin-top:33px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}#publish-modal .checkbox input{outline:0}#publish-modal .loader{font-size:55px;width:100%;height:100%;position:absolute;top:0;left:0;background-color:rgba(0,0,0,.7);color:#fff;display:none}#publish-modal .loader>.inner{position:relative;top:42%;left:45%}#publish-modal .loader .text{font-size:18px;font-weight:400;margin-left:-15px}#publish-modal .error{margin-top:25px;display:none}#install{background:#f6f5f2;overflow-y:auto}#install .update-container{text-align:center}#install .update-container .btn{width:30%;border-bottom:3px solid #008261}#install .update-container p{margin:20px 0}#install .update-container h2{color:#555}#install .logo{margin:30px auto;width:322px;height:auto}#install .admin-account .btn-success{margin-top:10px;border-radius:4px;border-color:#00b588;border-bottom:4px solid #008261}#install #loader{display:none;position:absolute;top:0;left:0;width:100%;height:100%;font-size:120px;background-color:rgba(0,0,0,.8);color:#fff;z-index:10000}#install #loader>.fa{position:relative;top:40%;left:45%}#install .step-panel{background:#fff;-webkit-box-shadow:1px 1px 2px 0 #d0d0d0;box-shadow:1px 1px 2px 0 #d0d0d0;padding:20px 30px;margin-top:50px}#install .step-panel .form-control{border-radius:0}#install h2{text-align:center}#install .manual-fill{margin-top:20px}#install .manual-fill input{margin-left:-2px;margin-right:8px}#install .manual-fill .btn-success{border-radius:0;border-bottom:4px solid #008261}#install .manual-fill .col-sm-6{padding:0}#install #site_description{padding-bottom:10px}#install #configuration .btn{margin-top:20px}#install #compat-check h4{margin-top:30px;text-align:center}#install #compat-check .btn{display:inline-block;margin-right:10px;margin-bottom:30px;border-radius:0}#install #compat-check p{margin:15px 0 25px;text-align:center}#install .table td,#install .table th{text-align:center}#install .danger{background:#c0392b;color:#fff;padding:5px}#install .success{background:#00b588;color:#fff;padding:5px}.alert{color:#fff;text-align:center}.wizard{display:block;width:100%;position:relative;padding:0}.wizard li{display:block;float:left;width:33%;text-align:center;padding-left:0}.wizard li a:hover{text-decoration:none}.wizard li:before{display:block;border-top:3px solid #55606E;content:"";font-size:0;overflow:hidden;position:relative;top:11px;right:1px;width:100%;z-index:1}.wizard li:first-child:before{left:50%;max-width:50%}.wizard li:last-child:before{max-width:50%;width:50%}.wizard li .title{color:#777;display:block;font-size:13px;line-height:15px;max-width:100%;position:relative;table-layout:fixed;text-align:center;top:20px;word-wrap:break-word;z-index:104}.wizard li .step{background:#7B909C;color:#fff;display:inline;font-size:15px;font-weight:700;padding:9px 13.5px;border:3px solid transparent;border-radius:50%;line-height:normal;position:relative;text-align:center;z-index:2}.wizard li.active .step{background:#179ede;color:#fff;font-weight:700;padding:9px 13.5px;font-size:15px;border-radius:50%;border:3px solid #55606E}.wizard li.active .title{color:#55606E}.animated{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-fill-mode:both;animation-fill-mode:both}@-webkit-keyframes fadeOut{0%{opacity:1}100%{opacity:0}}@keyframes fadeOut{0%{opacity:1}100%{opacity:0}}.fadeOut{-webkit-animation-name:fadeOut;animation-name:fadeOut}@-webkit-keyframes fadeOutDown{0%{opacity:1}100%{opacity:0;-webkit-transform:translate3d(0,100%,0);transform:translate3d(0,100%,0)}}@keyframes fadeOutDown{0%{opacity:1}100%{opacity:0;-webkit-transform:translate3d(0,100%,0);transform:translate3d(0,100%,0)}}.fadeOutDown{-webkit-animation-name:fadeOutDown;animation-name:fadeOutDown}@-webkit-keyframes fadeOutDownBig{0%{opacity:1}100%{opacity:0;-webkit-transform:translate3d(0,2000px,0);transform:translate3d(0,2000px,0)}}@-webkit-keyframes shake{0%,100%{-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}10%,30%,50%,70%,90%{-webkit-transform:translate3d(-10px,0,0);transform:translate3d(-10px,0,0)}20%,40%,60%,80%{-webkit-transform:translate3d(10px,0,0);transform:translate3d(10px,0,0)}}@keyframes shake{0%,100%{-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}10%,30%,50%,70%,90%{-webkit-transform:translate3d(-10px,0,0);transform:translate3d(-10px,0,0)}20%,40%,60%,80%{-webkit-transform:translate3d(10px,0,0);transform:translate3d(10px,0,0)}}.shake{-webkit-animation-name:shake;animation-name:shake}.animated.flip{-webkit-backface-visibility:visible;backface-visibility:visible;-webkit-animation-name:flip;animation-name:flip}@-webkit-keyframes flipInX{0%{-webkit-transform:perspective(400px) rotate3d(1,0,0,90deg);transform:perspective(400px) rotate3d(1,0,0,90deg);-webkit-transition-timing-function:ease-in;transition-timing-function:ease-in;opacity:0}40%{-webkit-transform:perspective(400px) rotate3d(1,0,0,-20deg);transform:perspective(400px) rotate3d(1,0,0,-20deg);-webkit-transition-timing-function:ease-in;transition-timing-function:ease-in}60%{-webkit-transform:perspective(400px) rotate3d(1,0,0,10deg);transform:perspective(400px) rotate3d(1,0,0,10deg);opacity:1}80%{-webkit-transform:perspective(400px) rotate3d(1,0,0,-5deg);transform:perspective(400px) rotate3d(1,0,0,-5deg)}100%{-webkit-transform:perspective(400px);transform:perspective(400px)}}@keyframes flipInX{0%{-webkit-transform:perspective(400px) rotate3d(1,0,0,90deg);transform:perspective(400px) rotate3d(1,0,0,90deg);-webkit-transition-timing-function:ease-in;transition-timing-function:ease-in;opacity:0}40%{-webkit-transform:perspective(400px) rotate3d(1,0,0,-20deg);transform:perspective(400px) rotate3d(1,0,0,-20deg);-webkit-transition-timing-function:ease-in;transition-timing-function:ease-in}60%{-webkit-transform:perspective(400px) rotate3d(1,0,0,10deg);transform:perspective(400px) rotate3d(1,0,0,10deg);opacity:1}80%{-webkit-transform:perspective(400px) rotate3d(1,0,0,-5deg);transform:perspective(400px) rotate3d(1,0,0,-5deg)}100%{-webkit-transform:perspective(400px);transform:perspective(400px)}}.flipInX{-webkit-backface-visibility:visible!important;backface-visibility:visible!important;-webkit-animation-name:flipInX;animation-name:flipInX}#login-page{background-color:#f2f2f2;height:100%;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;-webkit-align-items:center;-ms-flex-align:center;align-items:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center}#login-page .loader{position:absolute;width:100%;height:100%;background-color:rgba(0,0,0,.1);top:0;left:0;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-ms-flex-align:center;align-items:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center}#login-page .loader>i{font-size:85px;color:#1685C6}#login-page .alert{display:none}#login-page>.form-error{display:block;background-color:#c0392b;color:#fff;padding:12px 20px;position:absolute}#login-page .login-container{max-width:350px;font-family:'Open Sans',sans-serif}#login-page .login-container.wide{max-width:400px}#login-page .login-container p{color:#797979;text-align:center;font-size:13px;margin:5px 0 35px}#login-page .login-container .logo{width:200px;height:auto;margin:0 auto 30px;display:block}#login-page .login-container .login-btn{text-align:center}#login-page .login-container .login-btn>.btn{border:none;outline:0;border-radius:100px;padding:6px 30px;background-color:#1685C6;-webkit-transition:all .3s ease-in-out;-o-transition:all .3s ease-in-out;transition:all .3s ease-in-out}#login-page .login-container .login-btn>.btn:hover{background-color:#116698}#login-page .login-container .form-control{border-radius:0;border:none;outline:0;height:45px;font-size:16px;font-weight:600;letter-spacing:.5px}#login-page .login-container .form-control::-moz-placeholder{color:#94a4ae;opacity:1}#login-page .login-container .form-control:-ms-input-placeholder{color:#94a4ae}#login-page .login-container .form-control::-webkit-input-placeholder{color:#94a4ae}#login-page .login-container.loading{opacity:.5}.user-selectable{-webkit-user-select:initial;-moz-user-select:initial;-ms-user-select:initial;user-select:initial}#default-permissions-modal,#permissions-modal{text-transform:capitalize}#default-permissions-modal p,#permissions-modal p{text-transform:none;margin:10px 0 0 13px}#default-permissions-modal li,#permissions-modal li{margin-bottom:10px;padding-bottom:20px;border-bottom:1px solid #d5d5d5}#default-permissions-modal .toggle,#permissions-modal .toggle{display:inline-block}#default-permissions-modal .action-name,#permissions-modal .action-name{font-family:Roboto;font-size:16px;vertical-align:top;padding-top:3px;display:inline-block;width:30%}#default-permissions-modal .single-permission h4,#permissions-modal .single-permission h4{display:inline-block;width:30%}#default-permissions-modal .single-permission .toggle,#permissions-modal .single-permission .toggle{vertical-align:middle}#dashboard-container{height:calc(100% - 177px);width:100%;padding:20px 0 0;background-color:#f2f2f2;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;overflow:auto}#dashboard-container .table td,#dashboard-container .table th{text-align:center}#dashboard-container .checkbox-pull{margin:25px 0 0 17px}#dashboard-container .checkbox-pull input{outline:0}#dashboard-container .checkbox-pull label{padding:0}#dashboard-container .checkbox-pull .icheckbox_square-blue{margin-left:5px}#dashboard-container .pagi-container{margin-right:15px}#dashboard-container>.container{height:100%}#dashboard-container #no-projects{margin-top:50px}#dashboard-container .alert{margin:10px 0 20px}#dashboard-container .alert .close{margin-top:-2px}#dashboard-container #projects-list{list-style:none;padding:35px 0 0;height:100%}#dashboard-container #projects-list .spinner{position:absolute;top:0;font-size:25px;background-color:rgba(0,0,0,.5);width:100%;height:100%}#dashboard-container #projects-list figure{color:#555;margin-bottom:15px;cursor:pointer;background-color:#fff;border:1px solid #e5e5e5;box-shadow:0 1px 1px rgba(0,0,0,.04);transition:box-shadow .2s ease-in-out;border-radius:3px}#dashboard-container #projects-list figure:hover{box-shadow:0 3px 10px 2px rgba(204,204,204,.85)}#dashboard-container #projects-list figure .header{padding:8px}#dashboard-container #projects-list figure .header:after,#dashboard-container #projects-list figure .header:before{content:" ";display:table}#dashboard-container #projects-list figure .header:after{clear:both}#dashboard-container #projects-list figure .header>a{color:#007BE4}#dashboard-container #projects-list figure .header>.icheckbox_square-blue{float:right}#dashboard-container #projects-list figure .img-responsive{width:100%}#dashboard-container #projects-list figure>figcaption{padding:10px;background-color:#fff;font-weight:500;font-size:13px;border-bottom-right-radius:3px;border-bottom-left-radius:3px;border-top:1px solid #f2f2f2}#dashboard-container #projects-list figure>figcaption .name{float:left}#dashboard-container #projects-list figure>figcaption .name>.updated{color:rgba(102,102,102,.5);font-size:10px}#dashboard-container #projects-list figure>figcaption .name>h3{margin:0 0 1px;font-size:16px;font-weight:500}#dashboard-container #projects-list figure>figcaption .actions{float:right;padding-top:4px}#dashboard-container #projects-list figure>figcaption .actions>i{color:#179ede;margin-right:5px;font-size:19px}#dashboard-container #projects-list figure>figcaption .actions>i:hover{color:#127db0}#filter-bar{margin-top:50px;padding:25px 0;background-color:#253845;height:127px;color:#fff}#filter-bar .pull-right{padding-top:26px}#filter-bar .pull-right>.btn{border:none;border-bottom:3px solid #127db0}#filter-bar .form-group{display:block;float:left;margin-right:25px}#filter-bar .form-group>label{font-weight:500}#filter-bar .form-group>.form-control{-webkit-box-shadow:0 1px 2px rgba(0,0,0,.2);box-shadow:0 1px 2px rgba(0,0,0,.2);border:none;border-radius:5px;height:37px;line-height:34px}#project-name-modal .loader{font-size:30px;display:inline-block;padding:0 10px;vertical-align:bottom}#new-project-container{background-color:#f2f2f2;padding-top:112px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;overflow:auto;height:100%}#new-project-container>.container{padding-bottom:72px}#new-project-container .start-with-blank{margin-bottom:15px;border:none;border-bottom:3px solid #127db0;padding:10px 12px;border-radius:3px}#new-project-container h2{color:#4d4d4d;padding-bottom:5px;border-bottom:1px solid #ddd;margin-bottom:35px}#new-project-container .colors-container{background-color:#fff;border-radius:3px;-webkit-box-shadow:0 1px 2px rgba(0,0,0,.1);box-shadow:0 1px 2px rgba(0,0,0,.1)}#new-project-container .colors-container h4{margin:0;padding:10px 0 10px 20px;border-bottom:1px solid #eee;font-family:Roboto}#new-project-container .colors-container ul{padding:10px 20px}#new-project-container .colors-container li{display:inline-block;width:36.5px;height:36.5px;margin:0 10px 10px 0;border:3px solid transparent}#new-project-container .colors-container li:nth-child(5n){margin-right:0}#new-project-container .colors-container li:hover{cursor:pointer}#new-project-container .colors-container li.active{border-color:#158ec7}#new-project-container .categories-container{margin-top:17px;background-color:#fff;border-radius:3px;-webkit-box-shadow:0 1px 2px rgba(0,0,0,.1);box-shadow:0 1px 2px rgba(0,0,0,.1)}#new-project-container .categories-container h4{margin:0;padding:10px 0 10px 20px;border-bottom:1px solid #eee;font-family:Roboto}#new-project-container .categories-container li{padding:10px 15px;color:#777;border-bottom:1px solid #eee}#new-project-container .categories-container li:last-of-type{border-bottom-right-radius:6px;border-bottom-left-radius:6px}#new-project-container .categories-container li:hover{cursor:pointer;background-color:#6bc5f0;color:#fff}#new-project-container .categories-container li.active{background-color:#179ede;color:#fff}#new-project-container .no-results{text-align:center;font-size:22px;margin-top:15%}#new-project-container figure{padding:0 8px;margin-bottom:16px}#new-project-container figure>.img-responsive{-webkit-box-shadow:0 1px 2px rgba(0,0,0,.1);box-shadow:0 1px 2px rgba(0,0,0,.1)}#new-project-container figure>.img-responsive:hover{cursor:pointer}#new-project-container figure>figcaption{-webkit-box-shadow:0 1px 2px rgba(0,0,0,.1);box-shadow:0 1px 2px rgba(0,0,0,.1);border-top:1px solid #eee;text-align:center;padding:10px 5px;background-color:#fff;color:#777}#pages ul{text-align:center;margin-top:25px}#pages ul li{padding:10px 15px;background-color:#263845;margin:0 30px 5px;cursor:pointer;transition:background-color .3s ease;border-radius:3px;color:#9ab3c0;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-transform:capitalize}#pages ul li.active,#pages ul li.active:hover,#pages ul li:hover{background-color:#1b4f6b}#pages .page-settings{padding:20px 30px 0;margin-top:20px;border-top:1px solid #416076}#pages .page-settings label{color:#3b7694;font-size:13px;font-weight:400}#pages .page-settings .form-control{background-color:#263845;border:1px solid #2f4555;color:#3b7694}#pages .page-settings .form-control::-moz-placeholder{color:#3b7694;opacity:1}#pages .page-settings .form-control:-ms-input-placeholder{color:#3b7694}#pages .page-settings .form-control::-webkit-input-placeholder{color:#3b7694}#pages .action-buttons{margin:0 30px;font-size:18px;padding-top:5px}#pages .action-buttons:after,#pages .action-buttons:before{content:" ";display:table}#pages .action-buttons:after{clear:both}#pages .action-buttons button{cursor:pointer;padding:5px;border:1px solid #416076;background-color:#263845;border-radius:2px}#pages .action-buttons button:disabled{cursor:not-allowed;background-color:#1c2a33!important;border-color:#416076!important}#pages .action-buttons button:hover{border-color:#6e94af}#pages .buttons-bottom{text-align:center;margin:20px 0 10px}#pages .buttons-bottom .btn{border-radius:2px;padding:7px 10px}#themes .filters{margin:10px 20px}#themes .filters .search{margin-bottom:10px}#themes .filters .filter{display:inline-block;width:55%;margin-right:18px}#themes .filters .form-control{background-color:#263845;border:1px solid #2f4555;color:#3b7694;border-radius:3px;height:40px}#themes .filters .form-control::-moz-placeholder{color:#3b7694;opacity:1}#themes .filters .form-control:-ms-input-placeholder{color:#3b7694}#themes .filters .form-control::-webkit-input-placeholder{color:#3b7694}#themes .filters .btn{display:inline-block;background-color:#263845;border:1px solid #2f4555;height:40px;margin-top:-2px}#themes .filters .btn:first-of-type{margin-right:4px}#themes .filters .btn:active,#themes .filters .btn:focus,#themes .filters .btn:hover{color:#fff}#themes-list{margin:20px 20px 0}#themes-list h2{text-align:center;font-size:25px;font-weight:400}#themes-list .theme{margin-bottom:20px;border-bottom:1px solid #253843;cursor:pointer;position:relative}#themes-list .theme .delete-theme,#themes-list .theme .edit-theme{position:absolute;top:0;background-color:#263845;padding:5px;font-size:20px}#themes-list .theme .delete-theme:hover,#themes-list .theme .edit-theme:hover{background-color:#385366}#themes-list .theme .delete-theme{right:0}#themes-list .theme figure{border:2px solid transparent}#themes-list .theme figure.active{border-color:#179ede}#themes-list .theme figcaption{margin-top:8px;font-size:13px;padding:0 7px 10px;color:#5d8397}#settings{padding-top:20px}#settings .with-toggle>.label{padding:0;font-size:15px;font-weight:400}#settings .with-toggle>.toggle{vertical-align:bottom;margin-top:10px;width:80px}#settings .with-input>.label{padding:4px;font-size:15px;font-weight:400}#settings .with-input>.toggle{vertical-align:bottom;margin-top:10px;width:80px}#settings .setting{border-bottom:1px solid #416076;padding-bottom:5px}#settings .setting:last-of-type{border-bottom:none}#settings .settings-container{margin:15px 0}#settings .accordion-body{margin:0 30px}#settings .accordion-body p{font-size:13px;color:#2c5970;margin-top:10px}#settings .accordion-body .form-control{margin-top:6px;background-color:#263845;color:#3b7694;border:1px solid #2f4555}#settings .accordion-body .form-control::-moz-placeholder{color:#3b7694;opacity:1}#settings .accordion-body .form-control:-ms-input-placeholder{color:#3b7694}#settings .accordion-body .form-control::-webkit-input-placeholder{color:#3b7694}#inspector-filter-select{outline:0;height:35px;padding:0 10px;background-color:#263845;border:1px solid #2f4555;margin:13px;width:88%;border-radius:3px;color:#3b7694;text-transform:capitalize}#inspector-inner{overflow-y:auto;overflow-x:hidden;height:calc(100% - 50px)}#inspector{width:100%;height:100%;background:#1c2a33;color:#3b7694;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;position:relative;overflow:visible!important}#inspector .element-path{background-color:#2f4555;margin:15px;padding:10px;list-style:none}#inspector .element-path>li{display:inline-block;color:#5d8397;cursor:pointer}#inspector .element-path>li:hover .name{color:#8aa7b7}#inspector .element-path>li>i:before{width:.7em}#inspector .element-path>li.active{pointer-events:none;color:#8aa7b7;font-weight:500}#inspector .element-path>li.active>i{display:none}#inspector .sp-container{display:block;left:327px;position:fixed!important;min-width:434px}#inspector>#inspector-overlay{height:100%;position:absolute;background-color:rgba(0,0,0,.5);z-index:4;width:100%}#inspector>#inspector-overlay>.overlay-content{display:block;width:100%;padding:15px;font-size:17px;text-align:center;color:#fff;position:relative;top:calc(50% - 110px)}#inspector>#inspector-overlay>.overlay-content>i{display:block;font-size:45px}#inspector #background-arrow{left:309px;transition:none}#inspector .bl-panel-header{border-bottom:1px solid #263845;margin:-10px -10px 15px}#inspector .bl-panel-header>.name{padding:8px 0 8px 8px;float:left;font-size:14px}#inspector .bl-panel-header>.bl-panel-btns{padding:8px 12px;height:100%;border-left:1px solid #263845;float:right}#inspector .bl-panel-header>.bl-panel-btns:hover{background-color:#263845;cursor:pointer;border-top-right-radius:6px}#inspector #fill-color,#inspector #gradient,#inspector #image{width:30%;display:inline-block;height:60px;border:2px solid #3b7694;background-color:#263845;color:#3b7694;border-radius:3px;margin-right:5px;background-image:none;cursor:pointer}#inspector #fill-color>.background-box,#inspector #gradient>.background-box,#inspector #image>.background-box{width:100%;height:100%;text-align:center;padding:7px 0}#inspector #fill-color>.background-box>.icon,#inspector #gradient>.background-box>.icon,#inspector #image>.background-box>.icon{font-size:30px}#inspector #fill-color>.background-name,#inspector #gradient>.background-name,#inspector #image>.background-name{margin-top:5px;color:#3b7694;text-align:center;font-size:13px}#inspector #fill-color:hover,#inspector #gradient:hover,#inspector #image:hover{color:#4b93b7;border-color:#4b93b7}#inspector #gradient{margin-right:0}#inspector #background-flyout-panel{position:fixed;display:block;left:327px;top:130px;width:261px;background-color:#1c2a33;padding:10px;border-radius:6px;z-index:5;-webkit-box-shadow:-1px 0 2px rgba(0,0,0,.5);box-shadow:-1px 0 2px rgba(0,0,0,.5)}#inspector #background-flyout-panel .btn-block{border-radius:2px;border:none;outline:0;box-shadow:0 5px #27496d;margin:-5px 0 15px}#inspector #background-flyout-panel .btn-block:active,#inspector #background-flyout-panel .btn-block:focus,#inspector #background-flyout-panel .btn-block:hover{background-color:#158ec7}#inspector #background-flyout-panel #gradientPresets,#inspector #background-flyout-panel #texturePresets{display:none}#inspector #background-flyout-panel h5{color:#9b9c9e;background-color:#fff;margin:10px -10px;padding:10px}#inspector #background-flyout-panel #img-positioning{padding:0 10px}#inspector #background-flyout-panel #img-positioning h5{margin:0 -10px}#inspector #background-flyout-panel #img-positioning h6{text-align:center;margin:0 0 10px}#inspector #background-flyout-panel #img-positioning input{outline:0}#inspector #background-flyout-panel #img-positioning>.pull-right{width:80px}#inspector #background-flyout-panel #img-positioning .radio{margin:0}#inspector #background-flyout-panel #img-positioning .alignment-box{width:24px;height:24px;background-color:#263845;border-radius:3px;display:inline-block}#inspector #background-flyout-panel #img-positioning .alignment-box:hover{background-color:#00b588;cursor:pointer}#inspector #background-flyout-panel #img-positioning .alignment-box.active{background-color:#00b588}#inspector #background-flyout-panel #img-positioning .alignment-box:nth-child(2),#inspector #background-flyout-panel #img-positioning .alignment-box:nth-child(5),#inspector #background-flyout-panel #img-positioning .alignment-box:nth-child(8){margin:0 4px}#inspector .img-presets-list{list-style:none;padding:0;max-height:190px;overflow:hidden}#inspector .img-presets-list li{display:inline-block;padding:5px}#inspector .img-presets-list li>.preset{border:1px solid #179ede;width:50px;height:50px}#inspector .img-presets-list li>.preset:hover{cursor:pointer;border:2px solid #00b588}#inspector #el-font-weight-button{margin:0 0 0 5px}#inspector label{font-size:12px;vertical-align:sub;margin:6px 5px 0 0}#inspector #shadows-panel #shadow-knob-container{margin-bottom:8px}#inspector #shadows-panel .slider-group>.range-slider{width:70%;display:inline-block}#inspector #shadows-panel .slider-group .ui-slider{margin-top:5px}#inspector #shadows-panel .slider-group .slider-label{font-size:13px}#inspector #shadows-panel .slider-group>.pretty-input{width:20%;display:inline-block;padding:0;text-align:center;margin:0 0 -19px 16px;height:25px;border-radius:3px}#inspector #shadows-panel .ui-selectmenu-button{width:97px!important;display:inline-block;margin-top:8px}#inspector #shadows-panel .ui-selectmenu-button:last-of-type{margin-right:0}#inspector #shadows-panel .color-picker-trigger{width:188px;display:inline-block;margin:0 0 4px 15px;border-radius:3px;height:50px}#inspector #visibility{text-align:center;margin:5px 0 20px}#inspector #visibility>.list-inline{display:block;padding:0;margin-left:3px}#inspector #visibility>.list-inline>li{font-size:20px;background-color:#263845;padding:5px 10px;border-radius:3px;border:1px solid transparent}#inspector #visibility>.list-inline>li.disabled{color:#3b7694;background-color:#2a2a2a;border:1px solid #000;border-right:1px solid #353535;border-bottom:1px solid #353535;border-radius:3px}#inspector #visibility>.list-inline>li:hover{cursor:pointer}#inspector #attributes-panel .btn-block{margin-top:15px;border-radius:0;border-bottom:3px solid #106d99}#inspector #attributes-panel input,#inspector .pretty-input{background-color:#263845;border:1px solid #2f4555;color:#3b7694;display:inline-block;width:190px;height:35px;vertical-align:middle;padding-left:10px}#inspector #custom-attributes>.form-group>label{text-transform:capitalize}#inspector #custom-attributes>.form-group select,#inspector #custom-attributes>.form-group>input{float:right}#inspector #custom-attributes .long-name{float:none;display:block;width:100%;margin-bottom:10px}#inspector #border-box .color-picker-trigger{width:58%;float:left;height:35px;margin:5px 7px 15px 0;border-width:6px;border-style:solid;background:#263845;opacity:.7}#inspector #border-box #border-style{width:38.4%;margin:5px 0 15px;height:35px}#inspector .icon-box{width:30px;height:28px;text-align:center;font-weight:700;padding:5px;font-size:14px;margin-right:3px;background:#263845;float:left;border-radius:2px}#inspector .icon-box:hover{cursor:pointer;background:#243542}#inspector .icon-box.active{color:#00b588}#inspector h3{margin:0;text-align:center;color:#9b9c9e;padding:10px 0;font-size:21px}#inspector .color-picker-trigger{width:100%;height:35px;background-image:url(../images/transparent.png);cursor:pointer}#inspector #text-box>.btn-group-vertical>.btn-group,#inspector #text-box>.btn-toolbar,#inspector #text-box>.clearfix,#inspector #text-box>.container,#inspector #text-box>.container-fluid,#inspector #text-box>.dl-horizontal dd,#inspector #text-box>.form-horizontal .form-group,#inspector #text-box>.modal-footer,#inspector #text-box>.nav,#inspector #text-box>.navbar,#inspector #text-box>.navbar-collapse,#inspector #text-box>.navbar-header,#inspector #text-box>.pager,#inspector #text-box>.panel-body,#inspector #text-box>.row{margin:5px 0}#inspector #text-box>.btn-group-vertical>.btn-group .icon-box:last-of-type,#inspector #text-box>.btn-toolbar .icon-box:last-of-type,#inspector #text-box>.clearfix .icon-box:last-of-type,#inspector #text-box>.container .icon-box:last-of-type,#inspector #text-box>.container-fluid .icon-box:last-of-type,#inspector #text-box>.dl-horizontal dd .icon-box:last-of-type,#inspector #text-box>.form-horizontal .form-group .icon-box:last-of-type,#inspector #text-box>.modal-footer .icon-box:last-of-type,#inspector #text-box>.nav .icon-box:last-of-type,#inspector #text-box>.navbar .icon-box:last-of-type,#inspector #text-box>.navbar-collapse .icon-box:last-of-type,#inspector #text-box>.navbar-header .icon-box:last-of-type,#inspector #text-box>.pager .icon-box:last-of-type,#inspector #text-box>.panel-body .icon-box:last-of-type,#inspector #text-box>.row .icon-box:last-of-type{margin-right:0}#inspector #text-box>.btn-group-vertical>.btn-group:first-of-type,#inspector #text-box>.btn-toolbar:first-of-type,#inspector #text-box>.clearfix:first-of-type,#inspector #text-box>.container-fluid:first-of-type,#inspector #text-box>.container:first-of-type,#inspector #text-box>.dl-horizontal dd:first-of-type,#inspector #text-box>.form-horizontal .form-group:first-of-type,#inspector #text-box>.modal-footer:first-of-type,#inspector #text-box>.nav:first-of-type,#inspector #text-box>.navbar-collapse:first-of-type,#inspector #text-box>.navbar-header:first-of-type,#inspector #text-box>.navbar:first-of-type,#inspector #text-box>.pager:first-of-type,#inspector #text-box>.panel-body:first-of-type,#inspector #text-box>.row:first-of-type{margin-bottom:10px;margin-top:0}#inspector #text-box .italic{font-style:italic}#inspector #text-box .underline{text-decoration:underline}#inspector #text-box .strike{text-decoration:line-through}#inspector #text-box .overline{text-decoration:overline}#inspector #border-style,#inspector #border-width{width:60%;float:left;height:30px;margin-top:15px;background-color:#263845;border:none;outline:0;border-radius:2px;text-align:center;font-weight:700;font-size:13px}#inspector #el-font-size{width:35%;float:left;height:28px;background-color:#263845;border:none;outline:0;border-radius:2px;text-align:center;font-weight:700;font-size:13px;color:#3b7694;margin-right:11px}#inspector #el-font-style-box{margin-bottom:15px!important}#inspector #more-fonts{background:#263845;padding:8.4px 15px;text-align:center;font-size:20px;box-shadow:inset 0 1px 0 rgba(255,255,255,.04)}#inspector #more-fonts:hover{cursor:pointer}#inspector #el-font-family-button{height:45px;padding-top:11px;font-size:16px;font-weight:700;text-shadow:0 1px 2px #000}#inspector #el-font-weight-menu{overflow:auto}#inspector #el-font-weight-menu>.ui-menu-item{font-size:12px}#inspector #border-style{padding-left:7px}#inspector #border-width{width:35%;margin-right:9px}#inspector .radius-boxes>.big-box{height:95px!important}#inspector .radius-boxes>.small-boxes{padding:0}#inspector .radius-boxes>.small-boxes>input{width:64px!important;margin-bottom:5px;height:45px}#inspector .radius-boxes>.small-boxes>input:nth-child(1),#inspector .radius-boxes>.small-boxes>input:nth-child(3){margin-right:2px}#inspector .input-boxes{text-align:center;height:112.5px}#inspector .input-boxes>.small-boxes>.row{height:35px}#inspector .input-boxes>.small-boxes>.row input,#inspector .input-boxes>.small-boxes>.row>.col-sm-6{height:100%}#inspector .input-boxes>.small-boxes>.row>div{margin:4px 0;padding:0}#inspector .input-boxes>.small-boxes>.row>div:first-of-type{padding-right:2px}#inspector .input-boxes>.small-boxes>.row>div:last-of-type{padding-left:2px}#inspector .input-boxes .big-box{height:100%;padding:0 5px 0 0}#inspector .input-boxes .big-box>input{height:100%}#inspector .input-boxes .big-box input,#inspector .input-boxes .small-boxes input{width:100%;background:#263845;border:1px solid #2f4555;padding:4px;text-align:center;font-size:13px}#el-class{min-height:35px;background-color:#263845;cursor:text;border:1px solid #2f4555;color:#3b7694;display:inline-block;width:190px;vertical-align:middle;padding:1px 5px;float:right}#el-class>#addclass-flyout{margin-bottom:6px;height:22px}#el-class>#addclass-flyout>#addclass-input{border:1px solid #2f4555;border-radius:0;width:70%;height:100%;outline:0}#el-class>#addclass-flyout>.btn{border-radius:0;height:100%;padding:0 6px}#el-class>.list-unstyled{padding:1px 5px}#el-class>.list-unstyled>li{background:#179ede;cursor:default;margin-bottom:3px;font-size:75%;font-family:Helvetica;color:#f2f2f2;margin-right:3px;border-radius:0}#el-class>.list-unstyled>li .icon{padding-left:5px}#el-class>.list-unstyled>li .icon:hover{cursor:pointer}.arrow-up{position:absolute;right:12px;top:-13px;width:0;height:0;border-left:15px solid transparent;border-right:15px solid transparent;border-bottom:15px solid #1c2a33}.arrow-right{width:0;height:0;border-top:18px solid transparent;border-bottom:18px solid transparent;position:fixed;border-right:18px solid #1c2a33;display:none;-webkit-transition:all .4s ease-in-out;-o-transition:all .4s ease-in-out;transition:all .4s ease-in-out;z-index:10}#edit-columns{background-color:#263845;color:#fff;text-align:center;position:absolute;z-index:10;margin:10px 0 0 10px;-webkit-transition:height .2s linear;-o-transition:height .2s linear;transition:height .2s linear;pointer-events:all;text-transform:uppercase;font-size:14px;height:0;width:0;overflow:hidden;box-shadow:inset 0 0 2px rgba(255,255,255,.1),0 0 10px 0 rgba(0,0,0,.5);border-radius:2px;left:5px}#edit-columns>.icon{padding-right:4px;font-size:15px;top:1.2px;position:relative}#edit-columns:hover{cursor:pointer;background-color:#141d24}#row-editor{position:absolute;background-color:#263845;color:#fff;z-index:8;border-bottom-right-radius:4px;border-bottom-left-radius:4px;display:none;box-shadow:inset 0 0 2px rgba(255,255,255,.1),0 0 10px 0 rgba(0,0,0,.5);-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}#row-editor>.column-controls-footer{padding:10px;background-color:#1c2a33;border-bottom-right-radius:4px;border-bottom-left-radius:4px}#row-editor>.column-controls-footer>.close-row-editor{float:left;font-size:17px;margin:7px 0 0 3px;color:#458aae}#row-editor>.column-controls-footer>.close-row-editor:hover{cursor:pointer;-webkit-transform:scale(1.1);transform:scale(1.1)}#row-editor>.row-presets{padding:12px}#row-editor>.row-presets>.btn{background-color:#385366;border-color:transparent;color:#458aae;margin-top:5px}#row-editor>.row-presets>.btn:hover{background-color:#179ede;color:#fff}#row-editor .row-preset{display:inline-block;height:40px;width:40px;background-color:#2f4555;border-radius:3px;padding:4px;margin-right:5px}#row-editor .row-preset>div{height:100%;background-color:#3b7694;display:inline-block;border-right:1px solid #2f4555;border-left:1px solid #2f4555;border-radius:1px}#row-editor .row-preset>div:last-of-type{border-right:none}#row-editor .row-preset>div:first-of-type{border-left:none}#row-editor .row-preset .row-preset-12{width:100%}#row-editor .row-preset .row-preset-11{width:91.6666667%}#row-editor .row-preset .row-preset-10{width:83.3333333%}#row-editor .row-preset .row-preset-9{width:75%}#row-editor .row-preset .row-preset-8{width:66.6666667%}#row-editor .row-preset .row-preset-7{width:58.3333333%}#row-editor .row-preset .row-preset-6{width:50%}#row-editor .row-preset .row-preset-5{width:41.6666667%}#row-editor .row-preset .row-preset-4{width:33.3333333%}#row-editor .row-preset .row-preset-3{width:25%}#row-editor .row-preset .row-preset-2{width:16.6666667%}#row-editor .row-preset .row-preset-1{width:8.3333333%}#row-editor .row-preset:hover{cursor:pointer;-webkit-transform:scale(1.1);transform:scale(1.1)}#row-editor>.column-controls{padding:0;width:101%;border-bottom:1px solid #375364}#row-editor>.column-controls:after,#row-editor>.column-controls:before{content:" ";display:table}#row-editor>.column-controls:after{clear:both}#row-editor .col-control{font-size:18px;display:inline-block;position:relative;padding:5px 0}#row-editor .col-control>.delete-column{width:90%;text-align:center;display:inline-block;padding:4px 0;margin-left:5%;vertical-align:top}#row-editor .col-control>.delete-column.first{width:75%;margin-left:15%}#row-editor .col-control>.delete-column.last{width:75%;margin-left:10%}#row-editor .col-control>.delete-column:hover{cursor:pointer;background-color:#179ede;border-radius:3px}#row-editor .col-control>.add-column{position:absolute;top:0;right:-25px;z-index:100;padding:5px 18px 4px;margin-top:4px}#row-editor .col-control>.add-column.first{left:0;width:30px;padding-left:8px;padding-right:8px;border-top-left-radius:0!important;border-bottom-left-radius:0!important}#row-editor .col-control>.add-column.last{right:0;width:30px;padding-left:8px;padding-right:8px;border-top-right-radius:0!important;border-bottom-right-radius:0!important}#row-editor .col-control>.add-column:hover{background-color:#179ede;cursor:pointer;border-radius:3px}.tet-row>div:empty{height:50px}#elements-container .bottom-navigation button{width:25%}.flyout-from-right>.flyout-content{width:80%;height:90%;left:10%}.flyout-from-right>.flyout-content.open{top:5%}.flyout-from-right>.flyout-content>.inner-content{height:calc(100% - 58px)}.flyout-from-right .flyout-close{top:-11px}#export-panel>.flyout-panel-toolbar{height:58px;padding:11px 0 0}#alertify{border:none;background-color:#1b4f6b;color:#fff;max-width:350px;font-weight:500;top:calc(50% - 133px)}#alertify .alertify-button{border:none;box-shadow:none;text-shadow:none;background-image:none;width:calc(50% - 10px)}#alertify .alertify-button-cancel{background-color:#205e7f}#alertify .alertify-button-cancel:hover{background-color:#256d94}#alertify .alertify-button-ok{background-color:#179ede}#alertify .alertify-button-ok:hover{background-color:#158ec7}#alertify-cover{background-color:rgba(0,0,0,.5);opacity:1}.icon-spin{-webkit-animation:icon-spin 2s infinite linear;animation:icon-spin 2s infinite linear}@-webkit-keyframes icon-spin{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}100%{-webkit-transform:rotate(359deg);transform:rotate(359deg)}}@keyframes icon-spin{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}100%{-webkit-transform:rotate(359deg);transform:rotate(359deg)}}#not-found .align{width:30%;margin:0 auto;position:relative;top:20%;text-align:center}#not-found h1{font-size:90px;letter-spacing:2px;text-align:center;margin-bottom:40px}#not-found h2{text-align:center;margin-bottom:20px}#not-found p{font-size:17px;margin-bottom:40px}#not-found .btn{border-bottom:4px solid #127db0;border-radius:0}#not-found .icon{padding-right:10px}.scale-iframe{width:150%!important;height:150%!important;border:none;-moz-transform:scale(.66);-moz-transform-origin:0 0;-o-transform:scale(.66);-o-transform-origin:0 0;-webkit-transform:scale(.66);transform:scale(.66);-webkit-transform-origin:0 0;transform-origin:0 0}#architect footer{position:fixed;bottom:0;width:100%;padding:20px;background-color:#253845;border-top:4px solid #131d24}#architect footer:after,#architect footer:before{content:" ";display:table}#architect footer:after{clear:both}#architect footer>.copyright{float:right;font-size:15px}#drag-helper{background-color:#263845;color:#3b7694;border:1px solid #2f4555;padding:8px;border-radius:4px}.tooltip{z-index:100}#preview-closer{background-color:#555;position:absolute;bottom:0;left:0;padding:10px 15px;border-radius:4px}#preview-closer>.icon{color:#eee;font-size:30px}#preview-closer:hover{background-color:#3c3c3c;cursor:pointer}#preview-frame{width:100%;height:100%;border:none;position:absolute;top:0;left:0}#theme-loading{position:absolute;width:100%;height:100%;background-color:rgba(0,0,0,.9);z-index:4;top:0}#theme-loading>span{position:absolute;color:#fff;font-size:30px;top:50%;text-align:center;width:100%}.pricing-table>.panel-heading{text-align:center;text-transform:uppercase;font-weight:700}.pricing-table>.panel-body{background-color:#555;color:#fff;text-align:center}.pricing-table>.panel-body .price{font-size:40px;display:inline-block}.pricing-table>.panel-body .price>.dollar-sign{vertical-align:super;font-size:16px}.pricing-table>.panel-body .time-period{color:#777;font-size:15px;font-weight:lighter}.pricing-table .list-group{padding:0 15px}.pricing-table .list-group>.list-group-item{border-style:dotted;text-align:center;color:grey}.pricing-table .list-group>.list-group-item>.icon{font-size:13px;margin-right:5px}.pricing-table>.btn{display:block;text-transform:uppercase;margin:30px auto 20px;padding:13px 35px;border-radius:4px}#save-status{margin-left:0;margin-right:0!important}#save-status>#save-saved{color:#555}#save-status>#save-saving{color:#9d9d9d}#save-status .spinner{position:absolute;font-size:70px;padding:20% 37%;width:90%;height:100%;overflow:hidden;background-color:rgba(0,0,0,.5);color:#fff;pointer-events:none;top:0;display:none}.navbar{font-size:14px;background-color:#1c2a33;border:none;z-index:20;max-height:53px;color:#5d8397}.navbar #account-actions{margin-left:25px}.navbar #account-actions>.username{display:inline-block}.navbar #account-actions .icon-logout{color:#c0392b}.navbar #account-actions .icon-logout:hover{cursor:pointer;color:#962d22}@media (max-width:1410px){.navbar .hide-on-small-screens{display:none}}.navbar .nav-locales{margin-right:25%!important}.navbar .nav-locales li{padding:9px;cursor:pointer}.navbar .nav-locales li:hover{background-color:#151f26}.navbar .nav-locales li.active{background-color:#131c23}.navbar .logo{width:125px;height:auto;padding-top:9px;margin-left:45px}.navbar .navbar-brand{border-right:solid 1px #393f44;font-size:26px;padding:13px 20px 20px}.navbar .navbar-tabs>li{border-right:solid 1px #2e4554}.navbar .navbar-tabs>li:nth-child(1){border-left:solid 1px #2e4554}.navbar .navbar-tabs>li.active>a,.navbar .navbar-tabs>li.active>a:active,.navbar .navbar-tabs>li.active>a:focus,.navbar .navbar-tabs>li.active>a:hover{background-color:#263845}@media (min-width:1090px){.navbar .navbar-tabs>li{display:block}}.navbar .dash-nav-tabs{text-transform:capitalize;margin-left:5%}.navbar .dash-nav-tabs .icon{padding-right:3px}.navbar .navbar-right{height:50px}.navbar .navbar-btn{border-radius:0}.navbar .navbar-btn .icon{padding-right:5px}.mCSB_inside>.mCSB_container{margin-right:0}.mCSB_draggerContainer{margin-left:8px}.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar{width:7px!important;background-color:#4a6d87!important}.mCSB_scrollTools .mCSB_draggerRail{width:7px;background-color:#2f4555!important;border-radius:0}body,html{max-width:100%}#viewport,body,html{height:100%;overflow:hidden}#view{transition:opacity .3s ease-in-out;height:100%}#view.loading{opacity:.4;pointer-events:none;cursor:wait}#viewport{display:-webkit-flex;display:-ms-flexbox;display:flex;position:relative;transition:right .3s ease;right:0}.el-description{font-size:12px;margin:3px 0;font-weight:400;display:none}#iframe{display:block;width:100%;height:100%;margin:0 auto;position:relative;z-index:2;-webkit-transition:all .4s ease-in-out;-o-transition:all .4s ease-in-out;transition:all .4s ease-in-out;box-shadow:0 0 10px #666}#iframe.full-width{width:100%}#iframe.xs-width{width:480px}#iframe.sm-width{width:768px}#iframe.md-width{width:992px}.sidebar-toggler{position:absolute;width:10px;height:30px;top:43%;z-index:4;background-color:#454342}.sidebar-toggler>.toggler-carret{width:0;height:0;border:3px solid transparent;margin-top:-3px;position:relative;top:50%}.sidebar-toggler.left{right:0;margin-right:-11px;border-top-right-radius:6px;border-bottom-right-radius:6px}.sidebar-toggler.left .toggler-carret{border-right:3px solid rgba(255,255,255,.7);border-left:none;left:2px}.sidebar-toggler.right{left:0;margin-left:-11px;border-top-left-radius:6px;border-bottom-left-radius:6px}.sidebar-toggler.right .toggler-carret{border-left:3px solid rgba(255,255,255,.7);border-right:none;right:-4px}.sidebar-toggler:hover{cursor:pointer;background-color:#5f5c5b}.panel-subheading{padding-bottom:3px;margin-bottom:5px;color:#9b9c9e;text-align:left;font-size:14px}.panel-subheading>.icon{float:right}.panel-box{padding:15px 20px}.panel-box .panel-box{padding:0}#editor{height:350px;margin-top:70px}.sp-container{position:absolute!important;-webkit-transition:all .4s ease-in-out;-o-transition:all .4s ease-in-out;transition:all .4s ease-in-out;-webkit-box-shadow:-1px 0 2px rgba(0,0,0,.5);box-shadow:-1px 0 2px rgba(0,0,0,.5)}.resizing-columns{cursor:w-resize;pointer-events:all!important}#resize-handles{z-index:1000}#resize-handles .drag-handle{width:11px;height:11px;display:block;position:absolute;border:1px solid #179ede;background-color:#fff;-webkit-box-shadow:0 0 5px 0 rgba(0,0,0,.5);box-shadow:0 0 5px 0 rgba(0,0,0,.5);z-index:1000;pointer-events:all;border-radius:50%}#resize-handles .nw-handle{top:-7px;left:-7px}#resize-handles .nw-handle:hover{cursor:nw-resize}#resize-handles .n-handle{top:-7px;right:50%}#resize-handles .n-handle:hover{cursor:n-resize}#resize-handles .ne-handle{top:-7px;right:-7px}#resize-handles .ne-handle:hover{cursor:ne-resize}#resize-handles .e-handle{top:40%;right:-7px}#resize-handles .e-handle:hover{cursor:e-resize}#resize-handles .se-handle{bottom:-5px;right:-7px}#resize-handles .se-handle:hover{cursor:se-resize}#resize-handles .s-handle{bottom:-5px;right:50%}#resize-handles .s-handle:hover{cursor:s-resize}#resize-handles .sw-handle{bottom:-5px;left:-7px}#resize-handles .sw-handle:hover{cursor:sw-resize}#resize-handles .w-handle{top:40%;left:-7px}#resize-handles .w-handle:hover{cursor:w-resize}#middle{-webkit-flex:1 1 auto;-ms-flex:1 1 auto;flex:1 1 auto;height:100%;-webkit-transition:all .2s linear;-o-transition:all .2s linear;transition:all .2s linear;overflow:hidden}#middle #hover-box,#middle #select-box{border:1px solid #179ede;position:absolute;margin-left:6px;padding:5px;pointer-events:none;display:none;z-index:7}#middle #hover-box #hover-box-actions,#middle #hover-box #select-box-actions,#middle #select-box #hover-box-actions,#middle #select-box #select-box-actions{color:#fff;background-color:#179ede;padding:1px 5px 2px;font-size:16px;top:-27px;left:0;position:absolute;text-align:center;overflow:hidden;max-height:30px;pointer-events:all;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;white-space:nowrap}#middle #hover-box #hover-box-actions .icon:hover,#middle #hover-box #select-box-actions .icon:hover,#middle #select-box #hover-box-actions .icon:hover,#middle #select-box #select-box-actions .icon:hover{cursor:pointer;color:#eee}#middle #hover-box #hover-box-actions .icon:first-of-type,#middle #hover-box #select-box-actions .icon:first-of-type,#middle #select-box #hover-box-actions .icon:first-of-type,#middle #select-box #select-box-actions .icon:first-of-type{margin-left:10px}#middle #hover-box #hover-box-actions,#middle #select-box #hover-box-actions{border-bottom:1px solid #179ede;left:-1px}#middle #hover-box{z-index:6}#middle #highlights{position:absolute;height:100%;width:100%}#middle #highlights.row-editor-open>#hover-box{display:none;visibility:hidden}#middle #highlights.row-editor-open>#select-box{border:4px solid #404040;border-top-right-radius:3px;border-top-left-radius:3px}#middle #highlights.row-editor-open>#select-box>#column-resizers{display:block}#middle #highlights.row-editor-open>#select-box #select-box-actions{background-color:#404040}#middle #highlights.row-editor-open>#edit-columns{height:0!important;padding:0!important}#middle #select-box{border:2px solid #179ede}#middle #select-box>#column-resizers{height:115%;margin:-9px;display:none}#middle #select-box>#column-resizers>.column-resizer{display:inline-block;position:absolute;height:100%;width:2px;background-color:#1c2a33;margin-left:-6px;top:0}#middle #select-box>#column-resizers .col-dragger{position:relative;width:20px;background-color:#263845;border-radius:3px;text-align:center;color:#fff;pointer-events:all;top:10px;right:9px;height:calc(100% - 20px);box-shadow:inset 0 0 2px rgba(255,255,255,.1),0 0 10px 0 rgba(0,0,0,.5)}#middle #select-box>#column-resizers .col-dragger>.icon{position:relative;top:30%}#middle #select-box>#column-resizers .col-dragger:hover{background-color:#179ede;cursor:col-resize;color:#fff}#middle .element-tag{font-size:14px;text-transform:uppercase;overflow:hidden;pointer-events:none}#frame-wrapper{height:100%;position:relative;background-image:linear-gradient(45deg,rgba(0,0,0,.05) 25%,rgba(0,0,0,0) 25%,rgba(0,0,0,0) 75%,rgba(0,0,0,.05) 75%,rgba(0,0,0,.05)),linear-gradient(45deg,rgba(0,0,0,.05) 25%,rgba(0,0,0,0) 25%,rgba(0,0,0,0) 75%,rgba(0,0,0,.05) 75%,rgba(0,0,0,.05));background-image:-webkit-linear-gradient(45deg,rgba(0,0,0,.05) 25%,rgba(0,0,0,0) 25%,rgba(0,0,0,0) 75%,rgba(0,0,0,.05) 75%,rgba(0,0,0,.05)),-webkit-linear-gradient(45deg,rgba(0,0,0,.05) 25%,rgba(0,0,0,0) 25%,rgba(0,0,0,0) 75%,rgba(0,0,0,.05) 75%,rgba(0,0,0,.05));background-size:48px 48px;background-position:0 0,24px 24px}#frame-overlay{position:absolute;width:100%;height:100%;top:0;z-index:3;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.ui-draggable-dragging{z-index:1000}img.ui-draggable-dragging{width:7%}.container.ui-draggable-dragging{min-height:50px}.container.ui-draggable-dragging:empty{border:1px dashed gray}</style></head><body>
<!--http://architect-lite.vebto.com-->
<div id="splash">
     <div id="splash-spinner"></div>
</div>
<div style="height: 100%" ng-controller="BuilderController" class="ng-scope">
<section class="clearfix" id="viewport">
		<div class="flyout-from-right closed">
			<div class="flyout-content ng-scope open" id="export-panel">
				<div class="flyout-close" title="Close Panel">
					<i class="icon icon-cancel-circled"></i>
				</div><!-- ngIf: isDemo -->
				<div class="demo-overlay ng-scope">
					<p class="alert alert-info">Export functionality is disabled on demo site. Normally you would be able to export an entire project, a single page or image(s) in a .zip file or copy any of the pages markup or styles into clipboard.</p>
				</div><!-- end ngIf: isDemo -->
				<div class="row inner-content demo">
					<div class="images-column hidden">
						<h2><span class="ng-binding">Images</span></h2>
						<ul class="list-unstyled">
							<!-- ngRepeat: url in images -->
						</ul>
					</div>
					<div class="html-column col-md-6">
						<h2><span class="ng-binding">markup</span> <button class="btn btn-default ng-binding" id="copy-html">Copy To Clipboard</button></h2>
						<div class=" ace_editor ace-chrome" id="html-export-preview">
							<textarea class="ace_text-input" spellcheck="false" style="opacity: 0; height: 17px; width: 7.70313px; left: 53px; top: 0px;" wrap="off"></textarea>
							<div class="ace_gutter">
								<div class="ace_layer ace_gutter-layer ace_folding-enabled" style="margin-top: 0px; height: 779px; width: 49px;">
									<div class="ace_gutter-cell" style="height: 17px;">
										1
									</div>
									<div class="ace_gutter-cell" style="height: 17px;">
										2<span class="ace_fold-widget ace_start ace_open" style="height: 17px;"></span>
									</div>
									<div class="ace_gutter-cell" style="height: 17px;">
										3
									</div>
									<div class="ace_gutter-cell" style="height: 17px;">
										4<span class="ace_fold-widget ace_start ace_open" style="height: 17px;"></span>
									</div>
									<div class="ace_gutter-cell" style="height: 17px;">
										5
									</div>
									<div class="ace_gutter-cell" style="height: 17px;">
										6
									</div>
									<div class="ace_gutter-cell" style="height: 17px;">
										7
									</div>
									<div class="ace_gutter-cell" style="height: 17px;">
										8
									</div>
									<div class="ace_gutter-cell" style="height: 17px;">
										9
									</div>
									<div class="ace_gutter-cell" style="height: 17px;">
										10
									</div>
								</div>
								<div class="ace_gutter-active-line" style="top: 0px; height: 17px;"></div>
							</div>
							<div class="ace_scroller" style="left: 49px; right: 0px; bottom: 0px;">
								<div class="ace_content" style="margin-top: 0px; width: 674px; height: 779px; margin-left: 0px;">
									<div class="ace_layer ace_print-margin-layer">
										<div class="ace_print-margin" style="left: 620.25px; visibility: hidden;"></div>
									</div>
									<div class="ace_layer ace_marker-layer">
										<div class="ace_active-line" style="height:17px;top:0px;left:0;right:0;"></div>
									</div>
									<div class="ace_layer ace_text-layer" style="padding: 0px 4px;">
										<div class="ace_line" style="height:17px">
											<span class="ace_xml-pe ace_doctype ace_xml"><!</span><span class="ace_xml-pe ace_doctype ace_xml">DOCTYPE</span><span class="ace_text ace_whitespace ace_xml"> </span><span class="ace_xml-pe ace_xml">html</span><span class="ace_xml-pe ace_doctype ace_xml">></span>
										</div>
										<div class="ace_line" style="height:17px">
											<span class="ace_meta ace_tag ace_punctuation ace_tag-open ace_xml"><</span><span class="ace_meta ace_tag ace_tag-name ace_xml">html</span><span class="ace_meta ace_tag ace_punctuation ace_tag-close ace_xml">></span>
										</div>
										<div class="ace_line" style="height:17px"></div>
										<div class="ace_line" style="height:17px">
											<span class="ace_meta ace_tag ace_punctuation ace_tag-open ace_xml"><</span><span class="ace_meta ace_tag ace_tag-name ace_xml">head</span><span class="ace_meta ace_tag ace_punctuation ace_tag-close ace_xml">></span>
										</div>
										<div class="ace_line" style="height:17px">
											<span class="ace_text ace_xml">    </span><span class="ace_meta ace_tag ace_punctuation ace_tag-open ace_xml"><</span><span class="ace_meta ace_tag ace_tag-name ace_xml">title</span><span class="ace_meta ace_tag ace_punctuation ace_tag-close ace_xml">></span><span class="ace_meta ace_tag ace_punctuation ace_end-tag-open ace_xml"></</span><span class="ace_meta ace_tag ace_tag-name ace_xml">title</span><span class="ace_meta ace_tag ace_punctuation ace_tag-close ace_xml">></span>
										</div>
										<div class="ace_line" style="height:17px">
											<span class="ace_meta ace_tag ace_punctuation ace_end-tag-open ace_xml"></</span><span class="ace_meta ace_tag ace_tag-name ace_xml">head</span><span class="ace_meta ace_tag ace_punctuation ace_tag-close ace_xml">></span>
										</div>
										<div class="ace_line" style="height:17px"></div>
										<div class="ace_line" style="height:17px">
											<span class="ace_meta ace_tag ace_punctuation ace_tag-open ace_xml"><</span><span class="ace_meta ace_tag ace_tag-name ace_xml">body</span><span class="ace_meta ace_tag ace_punctuation ace_tag-close ace_xml">></span><span class="ace_meta ace_tag ace_punctuation ace_end-tag-open ace_xml"></</span><span class="ace_meta ace_tag ace_tag-name ace_xml">body</span><span class="ace_meta ace_tag ace_punctuation ace_tag-close ace_xml">></span>
										</div>
										<div class="ace_line" style="height:17px"></div>
										<div class="ace_line" style="height:17px">
											<span class="ace_meta ace_tag ace_punctuation ace_end-tag-open ace_xml"></</span><span class="ace_meta ace_tag ace_tag-name ace_xml">html</span><span class="ace_meta ace_tag ace_punctuation ace_tag-close ace_xml">></span>
										</div>
									</div>
									<div class="ace_layer ace_marker-layer"></div>
									<div class="ace_layer ace_cursor-layer ace_hidden-cursors">
										<div class="ace_cursor" style="left: 4px; top: 0px; width: 7.70313px; height: 17px;"></div>
									</div>
								</div>
							</div>
							<div class="ace_scrollbar ace_scrollbar-v" style="display: none; width: 22px; bottom: 0px;">
								<div class="ace_scrollbar-inner" style="width: 22px; height: 170px;"></div>
							</div>
							<div class="ace_scrollbar ace_scrollbar-h" style="display: none; height: 22px; left: 49px; right: 0px;">
								<div class="ace_scrollbar-inner" style="height: 22px; width: 723px;"></div>
							</div>
							<div style="height: auto; width: auto; top: -100px; left: -100px; visibility: hidden; position: fixed; white-space: pre; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; overflow: hidden;">
								<div style="height: auto; width: auto; top: -100px; left: -100px; visibility: hidden; position: fixed; white-space: pre; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; overflow: visible;"></div>
								<div style="height: auto; width: auto; top: -100px; left: -100px; visibility: hidden; position: fixed; white-space: pre; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; overflow: visible;">
									X
								</div>
							</div>
						</div>
					</div>
					<div class="css-column col-md-6">
						<h2><span class="ng-binding">style</span> <button class="btn btn-default ng-binding" id="copy-css">Copy To Clipboard</button></h2>
						<div class=" ace_editor ace-chrome" id="css-export-preview">
							<textarea class="ace_text-input" spellcheck="false" style="opacity: 0; height: 17px; width: 7.70313px; left: 45px; top: 0px;" wrap="off"></textarea>
							<div class="ace_gutter">
								<div class="ace_layer ace_gutter-layer ace_folding-enabled" style="margin-top: 0px; height: 779px; width: 41px;">
									<div class="ace_gutter-cell" style="height: 17px;">
										1
									</div>
								</div>
								<div class="ace_gutter-active-line" style="top: 0px; height: 17px;"></div>
							</div>
							<div class="ace_scroller" style="left: 41px; right: 0px; bottom: 0px;">
								<div class="ace_content" style="margin-top: 0px; width: 682px; height: 779px; margin-left: 0px;">
									<div class="ace_layer ace_print-margin-layer">
										<div class="ace_print-margin" style="left: 620.25px; visibility: hidden;"></div>
									</div>
									<div class="ace_layer ace_marker-layer">
										<div class="ace_active-line" style="height:17px;top:0px;left:0;right:0;"></div>
									</div>
									<div class="ace_layer ace_text-layer" style="padding: 0px 4px;">
										<div class="ace_line" style="height:17px"></div>
									</div>
									<div class="ace_layer ace_marker-layer"></div>
									<div class="ace_layer ace_cursor-layer ace_hidden-cursors">
										<div class="ace_cursor" style="left: 4px; top: 0px; width: 7.70313px; height: 17px;"></div>
									</div>
								</div>
							</div>
							<div class="ace_scrollbar ace_scrollbar-v" style="display: none; width: 22px; bottom: 0px;">
								<div class="ace_scrollbar-inner" style="width: 22px; height: 17px;"></div>
							</div>
							<div class="ace_scrollbar ace_scrollbar-h" style="display: none; height: 22px; left: 41px; right: 0px;">
								<div class="ace_scrollbar-inner" style="height: 22px; width: 723px;"></div>
							</div>
							<div style="height: auto; width: auto; top: -100px; left: -100px; visibility: hidden; position: fixed; white-space: pre; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; overflow: hidden;">
								<div style="height: auto; width: auto; top: -100px; left: -100px; visibility: hidden; position: fixed; white-space: pre; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; overflow: visible;"></div>
								<div style="height: auto; width: auto; top: -100px; left: -100px; visibility: hidden; position: fixed; white-space: pre; font-style: inherit; font-variant: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; overflow: visible;">
									X
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row flyout-panel-toolbar demo">
					<div class="center-block">
						<button class="btn btn-primary ng-binding"><i class="icon icon-download"></i> Download as ZIP file</button>
					</div>
				</div>
			</div>
		</div>
		<div id="description-container"></div>
		<aside class="ng-scope" id="elements-container">
			<section class="ng-scope" id="elements-panel">
				<div class="main-nav">
					<div class="selected-tab">
						<span class="top"></span><span class="bottom"></span>
					</div>
					<div class="nav-item" data-name="elements">
						<i class="icon icon-puzzle-outline"></i> <span class="ng-binding">Elements</span>
					</div>
					<div class="nav-item" data-name="inspector">
						<i class="icon icon-brush-1"></i> <span class="ng-binding">Inspector</span>
					</div>
					<div class="nav-item" data-name="pages">
						<i class="icon icon-docs"></i> <span class="ng-binding">Pages</span>
					</div>
					<div class="nav-item" data-name="settings">
						<i class="icon icon-cog-outline"></i> <span class="ng-binding">Settings</span>
					</div>
					<div class="nav-item">
						<i class="icon icon-code"></i> <span class="ng-binding">Code Edtr</span>
					</div>
					<div class="push-bottom">
						<button class="nav-item" disabled="disabled"><i class="icon icon-reply"></i> <span class="ng-binding">Undo</span></button> <button class="nav-item" disabled="disabled"><i class="icon icon-forward"></i> <span class="ng-binding">Redo</span></button>
					</div>
				</div>
				<div class="panel-inner">
					<div class="panel mCustomScrollbar _mCS_1 mCS-autoHide mCS_no_scrollbar open" data-name="elements">
						<div class="mCustomScrollBox mCS-light-thin mCSB_vertical mCSB_inside" id="mCSB_1" tabindex="0">
							<div class="mCSB_container mCS_y_hidden mCS_no_scrollbar_y" dir="ltr" id="mCSB_1_container" style="position:relative; top:0; left:0;">
								<section id="el-panel-top">
									<div class="panel-heading-input" id="panel-search">
										<input class="form-control ng-pristine ng-untouched ng-valid" id="el-search" placeholder="Search Elements..." type="text">
									</div><!-- ngIf: settings.get('showElementPreview') -->
								</section>
								<div id="elements-list">
									<div class="elements-box accordion-item open" id="components">
										<h3 class="accordion-heading ng-binding">Components <i class="icon icon-down-open-1"></i></h3>
										<div class="accordion-body">
											<ul class="list-unstyled">
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="progress bar">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-progress-2"></i>
														</div>
														<div class="text">
															Progress Bar
														</div>
														<p class="el-description">Provide up-to-date feedback on the progress of a workflow or action with simple yet flexible progress bar.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="list group">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-th-list-1"></i>
														</div>
														<div class="text">
															List Group
														</div>
														<p class="el-description">Flexible component to display lists of simple or complex items.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="panel">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-window"></i>
														</div>
														<div class="text">
															Panel
														</div>
														<p class="el-description">A simple panel box to put other components in.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="material box">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-medium"></i>
														</div>
														<div class="text">
															Material Box
														</div>
														<p class="el-description"></p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="pricing table">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-dollar"></i>
														</div>
														<div class="text">
															Pricing Table
														</div>
														<p class="el-description"></p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="jumbotron">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-header"></i>
														</div>
														<div class="text">
															Jumbotron
														</div>
														<p class="el-description"></p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="user profile">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-user"></i>
														</div>
														<div class="text">
															User Profile
														</div>
														<p class="el-description"></p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="skills list">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-tools"></i>
														</div>
														<div class="text">
															Skills List
														</div>
														<p class="el-description"></p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="services list">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-lifebuoy"></i>
														</div>
														<div class="text">
															Services List
														</div>
														<p class="el-description"></p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="image header">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-picture-outline"></i>
														</div>
														<div class="text">
															Image Header
														</div>
														<p class="el-description"></p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="navbar">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-menu"></i>
														</div>
														<div class="text">
															Navbar
														</div>
														<p class="el-description"></p>
													</div>
												</li>
											</ul>
										</div>
									</div>
									<div class="elements-box accordion-item" id="layout">
										<h3 class="accordion-heading ng-binding">Layout <i class="icon icon-down-open-1"></i></h3>
										<div class="accordion-body">
											<ul class="list-unstyled">
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="container">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-squares"></i>
														</div>
														<div class="text">
															Container
														</div>
														<p class="el-description">Main layout container. All other elements should always be put inside this one unless you want them to be full width (hero unit, slider, jumbotron etc).</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="row">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-minus-outline"></i>
														</div>
														<div class="text">
															Row
														</div>
														<p class="el-description">Contains and allows management of columns.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="well">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-bucket"></i>
														</div>
														<div class="text">
															Well
														</div>
														<p class="el-description">A simple container with inset effect.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="base" data-name="divider">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-divide-outline"></i>
														</div>
														<div class="text">
															Divider
														</div>
														<p class="el-description">A horizontal line to separate content.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="base" data-name="div container">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-blank"></i>
														</div>
														<div class="text">
															Div Container
														</div>
														<p class="el-description">Generic container for other elements.</p>
													</div>
												</li>
											</ul>
										</div>
									</div>
									<div class="elements-box accordion-item" id="media">
										<h3 class="accordion-heading ng-binding">Media <i class="icon icon-down-open-1"></i></h3>
										<div class="accordion-body">
											<ul class="list-unstyled">
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="image">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-picture-outline"></i>
														</div>
														<div class="text">
															Image
														</div>
														<p class="el-description">A simple image with changeable url.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="responsive video">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-video"></i>
														</div>
														<div class="text">
															Responsive Video
														</div>
														<p class="el-description">Video embed that will scale depending on screen size.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="image grid">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-grid"></i>
														</div>
														<div class="text">
															Image Grid
														</div>
														<p class="el-description">Multiple images with spacing.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="media object">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-newspaper-1"></i>
														</div>
														<div class="text">
															Media Object
														</div>
														<p class="el-description">Media Object</p>
													</div>
												</li>
											</ul>
										</div>
									</div>
									<div class="elements-box accordion-item" id="typography">
										<h3 class="accordion-heading ng-binding">Typography <i class="icon icon-down-open-1"></i></h3>
										<div class="accordion-body">
											<ul class="list-unstyled">
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="page header">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-header"></i>
														</div>
														<div class="text">
															Page Header
														</div>
														<p class="el-description">A simple shell for an h1 to space out and segment sections of content on a page. It can utilize small element, as well as most other components.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="label">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-tag"></i>
														</div>
														<div class="text">
															Label
														</div>
														<p class="el-description"></p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="base,bootstrap" data-name="link">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-link-outline"></i>
														</div>
														<div class="text">
															Link
														</div>
														<p class="el-description"></p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="base" data-name="paragraph">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-paragraph"></i>
														</div>
														<div class="text">
															Paragraph
														</div>
														<p class="el-description">A simple paragraph of editable text.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="base" data-name="marked text">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-info-circled"></i>
														</div>
														<div class="text">
															Marked Text
														</div>
														<p class="el-description">Text highlighted due to its relevance.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="base" data-name="definition list">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-menu-outline"></i>
														</div>
														<div class="text">
															Definition List
														</div>
														<p class="el-description">Association list consisting of zero or more name-value groups.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="base" data-name="blockqoute">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-quote"></i>
														</div>
														<div class="text">
															Blockqoute
														</div>
														<p class="el-description">A section quoted from another source.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="base" data-name="unordered list">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-th-list"></i>
														</div>
														<div class="text">
															Undordered List
														</div>
														<p class="el-description">Unordered list consisting of list items.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="base" data-name="heading">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-header"></i>
														</div>
														<div class="text">
															Heading
														</div>
														<p class="el-description">A basic heading element.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="base" data-name="table">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-table"></i>
														</div>
														<div class="text">
															Table
														</div>
														<p class="el-description"></p>
													</div>
												</li>
											</ul>
										</div>
									</div>
									<div class="elements-box accordion-item" id="buttons">
										<h3 class="accordion-heading ng-binding">Buttons <i class="icon icon-down-open-1"></i></h3>
										<div class="accordion-body">
											<ul class="list-unstyled">
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="button group">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-columns"></i>
														</div>
														<div class="text">
															Button Group
														</div>
														<p class="el-description">Styled group of buttons.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="button toolbar">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-progress-3"></i>
														</div>
														<div class="text">
															Button Toolbar
														</div>
														<p class="el-description"></p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="base" data-name="button">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-doc-landscape"></i>
														</div>
														<div class="text">
															Button
														</div>
														<p class="el-description">A simple button.</p>
													</div>
												</li>
											</ul>
										</div>
									</div>
									<div class="elements-box accordion-item" id="forms">
										<h3 class="accordion-heading ng-binding">Forms <i class="icon icon-down-open-1"></i></h3>
										<div class="accordion-body">
											<ul class="list-unstyled">
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="input field">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-progress-0"></i>
														</div>
														<div class="text">
															Input Field
														</div>
														<p class="el-description">A text field for user input.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="text area">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-doc-landscape"></i>
														</div>
														<div class="text">
															Text Area
														</div>
														<p class="el-description">A text area for user input with multiple rows.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="checkbox">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-check"></i>
														</div>
														<div class="text">
															Checkbox
														</div>
														<p class="el-description"></p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="input group">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-popup"></i>
														</div>
														<div class="text">
															Input Group
														</div>
														<p class="el-description">Text field with an addon on either side.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="form group">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-menu"></i>
														</div>
														<div class="text">
															Form Group
														</div>
														<p class="el-description">A container for label and form item.</p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="select">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-arrow-combo"></i>
														</div>
														<div class="text">
															Select
														</div>
														<p class="el-description"></p>
													</div>
												</li>
												<li class="ui-draggable ui-draggable-handle" data-frameworks="bootstrap" data-name="form">
													<div class="el-list-item">
														<div class="icon">
															<i class="icon icon-newspaper"></i>
														</div>
														<div class="text">
															Form
														</div>
														<p class="el-description"></p>
													</div>
												</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
							<div class="mCSB_scrollTools mCSB_1_scrollbar mCS-light-thin mCSB_scrollTools_vertical" id="mCSB_1_scrollbar_vertical" style="display: none;">
								<div class="mCSB_draggerContainer">
									<div class="mCSB_dragger" id="mCSB_1_dragger_vertical" oncontextmenu="return false;" style="position: absolute; min-height: 30px; height: 0px; top: 0px;">
										<div class="mCSB_dragger_bar" style="line-height: 30px;"></div>
									</div>
									<div class="mCSB_draggerRail"></div>
								</div>
							</div>
						</div>
					</div>
					<aside class="panel ng-scope" data-name="inspector" id="inspector">
						<input id="color-picker" style="display: none;">
						<div class="sp-container sp-light sp-flat sp-alpha-enabled sp-palette-buttons-disabled sp-initial-disabled hidden">
							<div class="sp-palette-container">
								<div class="sp-palette sp-thumb sp-cf">
									<div class="sp-cf sp-palette-row sp-palette-row-0">
										<span class="sp-thumb-el sp-thumb-light" data-color="rgb(210, 77, 87)" title="rgb(210, 77, 87)"><span class="sp-thumb-inner" style="background-color:rgb(210, 77, 87);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(242, 38, 19)" title="rgb(242, 38, 19)"><span class="sp-thumb-inner" style="background-color:rgb(242, 38, 19);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(217, 30, 24)" title="rgb(217, 30, 24)"><span class="sp-thumb-inner" style="background-color:rgb(217, 30, 24);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(150, 40, 27)" title="rgb(150, 40, 27)"><span class="sp-thumb-inner" style="background-color:rgb(150, 40, 27);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(239, 72, 54)" title="rgb(239, 72, 54)"><span class="sp-thumb-inner" style="background-color:rgb(239, 72, 54);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(214, 69, 65)" title="rgb(214, 69, 65)"><span class="sp-thumb-inner" style="background-color:rgb(214, 69, 65);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(192, 57, 43)" title="rgb(192, 57, 43)"><span class="sp-thumb-inner" style="background-color:rgb(192, 57, 43);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(207, 0, 15)" title="rgb(207, 0, 15)"><span class="sp-thumb-inner" style="background-color:rgb(207, 0, 15);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(231, 76, 60)" title="rgb(231, 76, 60)"><span class="sp-thumb-inner" style="background-color:rgb(231, 76, 60);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(219, 10, 91)" title="rgb(219, 10, 91)"><span class="sp-thumb-inner" style="background-color:rgb(219, 10, 91);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(246, 71, 71)" title="rgb(246, 71, 71)"><span class="sp-thumb-inner" style="background-color:rgb(246, 71, 71);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(241, 169, 160)" title="rgb(241, 169, 160)"><span class="sp-thumb-inner" style="background-color:rgb(241, 169, 160);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(210, 82, 127)" title="rgb(210, 82, 127)"><span class="sp-thumb-inner" style="background-color:rgb(210, 82, 127);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(224, 130, 131)" title="rgb(224, 130, 131)"><span class="sp-thumb-inner" style="background-color:rgb(224, 130, 131);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(246, 36, 89)" title="rgb(246, 36, 89)"><span class="sp-thumb-inner" style="background-color:rgb(246, 36, 89);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(226, 106, 106)" title="rgb(226, 106, 106)"><span class="sp-thumb-inner" style="background-color:rgb(226, 106, 106);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(220, 198, 224)" title="rgb(220, 198, 224)"><span class="sp-thumb-inner" style="background-color:rgb(220, 198, 224);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(102, 51, 153)" title="rgb(102, 51, 153)"><span class="sp-thumb-inner" style="background-color:rgb(102, 51, 153);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(103, 65, 114)" title="rgb(103, 65, 114)"><span class="sp-thumb-inner" style="background-color:rgb(103, 65, 114);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(174, 168, 211)" title="rgb(174, 168, 211)"><span class="sp-thumb-inner" style="background-color:rgb(174, 168, 211);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(145, 61, 136)" title="rgb(145, 61, 136)"><span class="sp-thumb-inner" style="background-color:rgb(145, 61, 136);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(154, 18, 179)" title="rgb(154, 18, 179)"><span class="sp-thumb-inner" style="background-color:rgb(154, 18, 179);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(191, 85, 236)" title="rgb(191, 85, 236)"><span class="sp-thumb-inner" style="background-color:rgb(191, 85, 236);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(190, 144, 212)" title="rgb(190, 144, 212)"><span class="sp-thumb-inner" style="background-color:rgb(190, 144, 212);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(142, 68, 173)" title="rgb(142, 68, 173)"><span class="sp-thumb-inner" style="background-color:rgb(142, 68, 173);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(155, 89, 182)" title="rgb(155, 89, 182)"><span class="sp-thumb-inner" style="background-color:rgb(155, 89, 182);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(68, 108, 179)" title="rgb(68, 108, 179)"><span class="sp-thumb-inner" style="background-color:rgb(68, 108, 179);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(228, 241, 254)" title="rgb(228, 241, 254)"><span class="sp-thumb-inner" style="background-color:rgb(228, 241, 254);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(65, 131, 215)" title="rgb(65, 131, 215)"><span class="sp-thumb-inner" style="background-color:rgb(65, 131, 215);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(89, 171, 227)" title="rgb(89, 171, 227)"><span class="sp-thumb-inner" style="background-color:rgb(89, 171, 227);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(129, 207, 224)" title="rgb(129, 207, 224)"><span class="sp-thumb-inner" style="background-color:rgb(129, 207, 224);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(82, 179, 217)" title="rgb(82, 179, 217)"><span class="sp-thumb-inner" style="background-color:rgb(82, 179, 217);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(197, 239, 247)" title="rgb(197, 239, 247)"><span class="sp-thumb-inner" style="background-color:rgb(197, 239, 247);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(34, 167, 240)" title="rgb(34, 167, 240)"><span class="sp-thumb-inner" style="background-color:rgb(34, 167, 240);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(52, 152, 219)" title="rgb(52, 152, 219)"><span class="sp-thumb-inner" style="background-color:rgb(52, 152, 219);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(44, 62, 80)" title="rgb(44, 62, 80)"><span class="sp-thumb-inner" style="background-color:rgb(44, 62, 80);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(25, 181, 254)" title="rgb(25, 181, 254)"><span class="sp-thumb-inner" style="background-color:rgb(25, 181, 254);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(51, 110, 123)" title="rgb(51, 110, 123)"><span class="sp-thumb-inner" style="background-color:rgb(51, 110, 123);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(34, 49, 63)" title="rgb(34, 49, 63)"><span class="sp-thumb-inner" style="background-color:rgb(34, 49, 63);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(107, 185, 240)" title="rgb(107, 185, 240)"><span class="sp-thumb-inner" style="background-color:rgb(107, 185, 240);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(30, 139, 195)" title="rgb(30, 139, 195)"><span class="sp-thumb-inner" style="background-color:rgb(30, 139, 195);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(58, 83, 155)" title="rgb(58, 83, 155)"><span class="sp-thumb-inner" style="background-color:rgb(58, 83, 155);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(52, 73, 94)" title="rgb(52, 73, 94)"><span class="sp-thumb-inner" style="background-color:rgb(52, 73, 94);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(103, 128, 159)" title="rgb(103, 128, 159)"><span class="sp-thumb-inner" style="background-color:rgb(103, 128, 159);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(37, 116, 169)" title="rgb(37, 116, 169)"><span class="sp-thumb-inner" style="background-color:rgb(37, 116, 169);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(31, 58, 147)" title="rgb(31, 58, 147)"><span class="sp-thumb-inner" style="background-color:rgb(31, 58, 147);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(137, 196, 244)" title="rgb(137, 196, 244)"><span class="sp-thumb-inner" style="background-color:rgb(137, 196, 244);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(75, 119, 190)" title="rgb(75, 119, 190)"><span class="sp-thumb-inner" style="background-color:rgb(75, 119, 190);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(92, 151, 191)" title="rgb(92, 151, 191)"><span class="sp-thumb-inner" style="background-color:rgb(92, 151, 191);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(78, 205, 196)" title="rgb(78, 205, 196)"><span class="sp-thumb-inner" style="background-color:rgb(78, 205, 196);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(162, 222, 208)" title="rgb(162, 222, 208)"><span class="sp-thumb-inner" style="background-color:rgb(162, 222, 208);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(135, 211, 124)" title="rgb(135, 211, 124)"><span class="sp-thumb-inner" style="background-color:rgb(135, 211, 124);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(144, 198, 149)" title="rgb(144, 198, 149)"><span class="sp-thumb-inner" style="background-color:rgb(144, 198, 149);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(38, 166, 91)" title="rgb(38, 166, 91)"><span class="sp-thumb-inner" style="background-color:rgb(38, 166, 91);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(3, 201, 169)" title="rgb(3, 201, 169)"><span class="sp-thumb-inner" style="background-color:rgb(3, 201, 169);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(104, 195, 163)" title="rgb(104, 195, 163)"><span class="sp-thumb-inner" style="background-color:rgb(104, 195, 163);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(101, 198, 187)" title="rgb(101, 198, 187)"><span class="sp-thumb-inner" style="background-color:rgb(101, 198, 187);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(27, 188, 155)" title="rgb(27, 188, 155)"><span class="sp-thumb-inner" style="background-color:rgb(27, 188, 155);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(27, 163, 156)" title="rgb(27, 163, 156)"><span class="sp-thumb-inner" style="background-color:rgb(27, 163, 156);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(102, 204, 153)" title="rgb(102, 204, 153)"><span class="sp-thumb-inner" style="background-color:rgb(102, 204, 153);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(54, 215, 183)" title="rgb(54, 215, 183)"><span class="sp-thumb-inner" style="background-color:rgb(54, 215, 183);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(200, 247, 197)" title="rgb(200, 247, 197)"><span class="sp-thumb-inner" style="background-color:rgb(200, 247, 197);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(134, 226, 213)" title="rgb(134, 226, 213)"><span class="sp-thumb-inner" style="background-color:rgb(134, 226, 213);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(46, 204, 113)" title="rgb(46, 204, 113)"><span class="sp-thumb-inner" style="background-color:rgb(46, 204, 113);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(22, 160, 133)" title="rgb(22, 160, 133)"><span class="sp-thumb-inner" style="background-color:rgb(22, 160, 133);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(63, 195, 128)" title="rgb(63, 195, 128)"><span class="sp-thumb-inner" style="background-color:rgb(63, 195, 128);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(1, 152, 117)" title="rgb(1, 152, 117)"><span class="sp-thumb-inner" style="background-color:rgb(1, 152, 117);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(3, 166, 120)" title="rgb(3, 166, 120)"><span class="sp-thumb-inner" style="background-color:rgb(3, 166, 120);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(77, 175, 124)" title="rgb(77, 175, 124)"><span class="sp-thumb-inner" style="background-color:rgb(77, 175, 124);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(42, 187, 155)" title="rgb(42, 187, 155)"><span class="sp-thumb-inner" style="background-color:rgb(42, 187, 155);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(0, 177, 106)" title="rgb(0, 177, 106)"><span class="sp-thumb-inner" style="background-color:rgb(0, 177, 106);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(30, 130, 76)" title="rgb(30, 130, 76)"><span class="sp-thumb-inner" style="background-color:rgb(30, 130, 76);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(4, 147, 114)" title="rgb(4, 147, 114)"><span class="sp-thumb-inner" style="background-color:rgb(4, 147, 114);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(38, 194, 129)" title="rgb(38, 194, 129)"><span class="sp-thumb-inner" style="background-color:rgb(38, 194, 129);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(253, 227, 167)" title="rgb(253, 227, 167)"><span class="sp-thumb-inner" style="background-color:rgb(253, 227, 167);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(248, 148, 6)" title="rgb(248, 148, 6)"><span class="sp-thumb-inner" style="background-color:rgb(248, 148, 6);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(235, 149, 50)" title="rgb(235, 149, 50)"><span class="sp-thumb-inner" style="background-color:rgb(235, 149, 50);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(232, 126, 4)" title="rgb(232, 126, 4)"><span class="sp-thumb-inner" style="background-color:rgb(232, 126, 4);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(244, 179, 80)" title="rgb(244, 179, 80)"><span class="sp-thumb-inner" style="background-color:rgb(244, 179, 80);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(242, 120, 75)" title="rgb(242, 120, 75)"><span class="sp-thumb-inner" style="background-color:rgb(242, 120, 75);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(235, 151, 78)" title="rgb(235, 151, 78)"><span class="sp-thumb-inner" style="background-color:rgb(235, 151, 78);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(245, 171, 53)" title="rgb(245, 171, 53)"><span class="sp-thumb-inner" style="background-color:rgb(245, 171, 53);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(211, 84, 0)" title="rgb(211, 84, 0)"><span class="sp-thumb-inner" style="background-color:rgb(211, 84, 0);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(243, 156, 18)" title="rgb(243, 156, 18)"><span class="sp-thumb-inner" style="background-color:rgb(243, 156, 18);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(249, 105, 14)" title="rgb(249, 105, 14)"><span class="sp-thumb-inner" style="background-color:rgb(249, 105, 14);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(249, 191, 59)" title="rgb(249, 191, 59)"><span class="sp-thumb-inner" style="background-color:rgb(249, 191, 59);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(242, 121, 53)" title="rgb(242, 121, 53)"><span class="sp-thumb-inner" style="background-color:rgb(242, 121, 53);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(230, 126, 34)" title="rgb(230, 126, 34)"><span class="sp-thumb-inner" style="background-color:rgb(230, 126, 34);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(236, 236, 236)" title="rgb(236, 236, 236)"><span class="sp-thumb-inner" style="background-color:rgb(236, 236, 236);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(108, 122, 137)" title="rgb(108, 122, 137)"><span class="sp-thumb-inner" style="background-color:rgb(108, 122, 137);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(210, 215, 211)" title="rgb(210, 215, 211)"><span class="sp-thumb-inner" style="background-color:rgb(210, 215, 211);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(238, 238, 238)" title="rgb(238, 238, 238)"><span class="sp-thumb-inner" style="background-color:rgb(238, 238, 238);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(189, 195, 199)" title="rgb(189, 195, 199)"><span class="sp-thumb-inner" style="background-color:rgb(189, 195, 199);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(236, 240, 241)" title="rgb(236, 240, 241)"><span class="sp-thumb-inner" style="background-color:rgb(236, 240, 241);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(149, 165, 166)" title="rgb(149, 165, 166)"><span class="sp-thumb-inner" style="background-color:rgb(149, 165, 166);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(218, 223, 225)" title="rgb(218, 223, 225)"><span class="sp-thumb-inner" style="background-color:rgb(218, 223, 225);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(171, 183, 183)" title="rgb(171, 183, 183)"><span class="sp-thumb-inner" style="background-color:rgb(171, 183, 183);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(242, 241, 239)" title="rgb(242, 241, 239)"><span class="sp-thumb-inner" style="background-color:rgb(242, 241, 239);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(191, 191, 191)" title="rgb(191, 191, 191)"><span class="sp-thumb-inner" style="background-color:rgb(191, 191, 191);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(230, 226, 175)" title="rgb(230, 226, 175)"><span class="sp-thumb-inner" style="background-color:rgb(230, 226, 175);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(167, 163, 126)" title="rgb(167, 163, 126)"><span class="sp-thumb-inner" style="background-color:rgb(167, 163, 126);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(239, 236, 202)" title="rgb(239, 236, 202)"><span class="sp-thumb-inner" style="background-color:rgb(239, 236, 202);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(4, 99, 128)" title="rgb(4, 99, 128)"><span class="sp-thumb-inner" style="background-color:rgb(4, 99, 128);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(0, 47, 47)" title="rgb(0, 47, 47)"><span class="sp-thumb-inner" style="background-color:rgb(0, 47, 47);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(70, 137, 102)" title="rgb(70, 137, 102)"><span class="sp-thumb-inner" style="background-color:rgb(70, 137, 102);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(255, 240, 165)" title="rgb(255, 240, 165)"><span class="sp-thumb-inner" style="background-color:rgb(255, 240, 165);"></span></span><span class="sp-thumb-el sp-thumb-light" data-color="rgb(255, 176, 59)" title="rgb(255, 176, 59)"><span class="sp-thumb-inner" style="background-color:rgb(255, 176, 59);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(182, 73, 38)" title="rgb(182, 73, 38)"><span class="sp-thumb-inner" style="background-color:rgb(182, 73, 38);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(142, 40, 0)" title="rgb(142, 40, 0)"><span class="sp-thumb-inner" style="background-color:rgb(142, 40, 0);"></span></span><span class="sp-thumb-el sp-thumb-dark" data-color="rgb(30, 30, 32)" title="rgb(30, 30, 32)"><span class="sp-thumb-inner" style="background-color:rgb(30, 30, 32);"></span></span>
									</div>
									<div class="sp-cf sp-palette-row sp-palette-row-selection"></div>
								</div>
								<div class="sp-palette-button-container sp-cf">
									<button class="sp-palette-toggle" type="button">less</button>
								</div>
							</div>
							<div class="sp-picker-container">
								<div class="sp-top sp-cf">
									<div class="sp-fill"></div>
									<div class="sp-top-inner">
										<div class="sp-color" style="background-color: rgb(255, 0, 0);">
											<div class="sp-sat">
												<div class="sp-val">
													<div class="sp-dragger" style="display: block; top: 140px; left: -5px;"></div>
												</div>
											</div>
										</div>
										<div class="sp-clear sp-clear-display" style="display: none;" title="Clear Color Selection"></div>
										<div class="sp-hue">
											<div class="sp-slider" style="display: block; top: -3px;"></div>
										</div>
									</div>
									<div class="sp-alpha">
										<div class="sp-alpha-inner" style="background: linear-gradient(to right, rgba(0, 0, 0, 0), rgb(0, 0, 0));">
											<div class="sp-alpha-handle" style="display: block; left: 169px;"></div>
										</div>
									</div>
								</div>
								<div class="sp-input-container sp-cf">
									<input class="sp-input" spellcheck="false" type="text">
								</div>
								<div class="sp-initial sp-thumb sp-cf"></div>
								<div class="sp-button-container sp-cf">
									<a class="sp-cancel" href="#">cancel</a><button class="sp-choose" type="button">choose</button>
								</div>
							</div>
						</div>
						<div class="" id="inspector-overlay">
							<div class="overlay-content ng-binding">
								<i class="icon icon-brush-1"></i> To edit styles, please select an element from the right.
							</div>
						</div>
						<section class="mCustomScrollbar _mCS_2 mCS-autoHide mCS_no_scrollbar" id="inspector-inner">
							<div class="mCustomScrollBox mCS-light-thin mCSB_vertical mCSB_inside" id="mCSB_2" tabindex="0">
								<div class="mCSB_container mCS_y_hidden mCS_no_scrollbar_y" dir="ltr" id="mCSB_2_container" style="position:relative; top:0; left:0;">
									<ol class="element-path">
										<!-- ngRepeat: el in selected.path -->
									</ol>
									<div class="inspector-panel accordion-item open ng-scope" id="attributes-panel">
										<h4 class="accordion-heading ng-binding">Attributes <i class="icon icon-down-open-1"></i></h4>
										<div class="accordion-body">
											<div class="panel-box">
												<div id="custom-attributes">
													<div id="visibility">
														<ul class="list-unstyled list-inline">
															<li data-original-title="visible on mobile" data-placement="top" data-size="xs" data-toggle="tooltip" title=""><i class="icon icon-mobile"></i></li>
															<li data-original-title="visible on tablet" data-placement="top" data-size="sm" data-toggle="tooltip" title=""><i class="icon icon-tablet-1"></i></li>
															<li data-original-title="visible on laptop" data-placement="top" data-size="md" data-toggle="tooltip" title=""><i class="icon icon-laptop"></i></li>
															<li data-original-title="visible on desktop" data-placement="top" data-size="lg" data-toggle="tooltip" title=""><i class="icon icon-desktop"></i></li>
														</ul>
													</div><!-- ngRepeat: (name, config) in customAttributes -->
												</div>
												<div class="form-group">
													<label class="ng-binding" for="el-id">Float</label> <select class="pretty-select ng-pristine ng-untouched ng-valid" id="el-float">
														<option value="? string: ?">
														</option>
														<option class="ng-binding" value="none">
															None
														</option>
														<option class="ng-binding" value="pull-left">
															Left
														</option>
														<option class="ng-binding" value="center-block">
															Center
														</option>
														<option class="ng-binding" value="pull-right">
															Right
														</option>
													</select>
												</div>
												<div class="form-group">
													<label class="ng-binding" for="el-id">Id</label> <input class="pull-right ng-pristine ng-untouched ng-valid" id="el-id" type="text">
												</div>
												<div class="clearfix form-group">
													<label class="ng-binding" for="el-id">Class</label>
													<div id="el-class">
														<ul class="list-unstyled list-inline">
															<!-- ngRepeat: class in attributes.class -->
														</ul>
														<div class="hidden" id="addclass-flyout">
															<input class="ng-pristine ng-untouched ng-valid" id="addclass-input" type="text"> <button class="btn btn-sm btn-success add-class"><i class="icon icon-ok-outline"></i></button>
														</div>
													</div>
												</div>
												<div class="ng-scope">
													<!-- ngIf: selected.isImage -->
												</div>
											</div>
										</div>
									</div>
									<section class="inspector-panel accordion-item ng-scope" id="background-panel">
										<h4 class="accordion-heading ng-binding">Background <i class="icon icon-down-open-1"></i></h4>
										<div class="accordion-body">
											<div class="panel-box">
												<div class="color-picker-trigger" data-controls="properties.color" id="fill-color">
													<div class="background-box">
														<i class="icon icon-color-adjust"></i>
													</div>
													<div class="background-name ng-binding">
														Color
													</div>
												</div>
												<div id="image">
													<div class="background-box">
														<i class="icon icon-picture-outline"></i>
													</div>
													<div class="background-name ng-binding">
														Image
													</div>
												</div>
												<div id="gradient">
													<div class="background-box">
														<i class="icon icon-pipette"></i>
													</div>
													<div class="background-name ng-binding">
														Gradient
													</div>
												</div>
											</div>
										</div>
										<div class="hidden" id="background-flyout-panel">
											<div class="bl-panel-header clearfix">
												<div class="name ng-binding">
													Background
												</div>
												<div class="bl-panel-btns">
													<i class="icon icon-cancel"></i>
												</div>
											</div>
											<div class="ng-scope">
												<button class="btn btn-primary btn-block ng-binding" style="overflow: hidden;" type="button">Upload Image<input class="btn btn-primary btn-block ng-binding" style="width: 1px; height: 1px; opacity: 0; position: absolute; padding: 0px; margin: 0px; overflow: hidden;" type="file"></button>
											</div>
											<div id="texturePresets">
												<h5 class="ng-binding">Textures</h5>
												<div class="img-presets-list mCustomScrollbar _mCS_3 mCS-autoHide mCS_no_scrollbar" style="margin-left: 2em">
													<div class="mCustomScrollBox mCS-light-thin mCSB_vertical mCSB_inside" id="mCSB_3" style="max-height: 190px;" tabindex="0">
														<div class="mCSB_container mCS_y_hidden mCS_no_scrollbar_y" dir="ltr" id="mCSB_3_container" style="position:relative; top:0; left:0;">
															<!-- ngRepeat: texture in textures track by $index -->
															<ul>
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/0.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/1.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/2.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/3.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/4.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/5.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/6.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/7.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/8.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/9.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/10.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/11.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/12.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/13.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/14.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/15.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/16.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/17.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/18.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/19.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/20.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/21.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/22.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/23.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/24.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/25.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/26.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: url("public/images/textures/27.png");"></div>
																</li><!-- end ngRepeat: texture in textures track by $index -->
															</ul>
														</div>
														<div class="mCSB_scrollTools mCSB_3_scrollbar mCS-light-thin mCSB_scrollTools_vertical" id="mCSB_3_scrollbar_vertical" style="display: none;">
															<div class="mCSB_draggerContainer">
																<div class="mCSB_dragger" id="mCSB_3_dragger_vertical" oncontextmenu="return false;" style="position: absolute; min-height: 30px; top: 0px;">
																	<div class="mCSB_dragger_bar" style="line-height: 30px;"></div>
																</div>
																<div class="mCSB_draggerRail"></div>
															</div>
														</div>
													</div>
												</div>
												<div id="image-properties">
													<h5 class="ng-binding">Image Properties</h5>
													<div class="clearfix" id="img-positioning">
														<div class="pull-left">
															<h6 class="ng-binding">Repeat</h6>
															<ul class="list-unstyled">
																<li>
																	<div class="radio">
																		<label class="ng-binding"><input class="ng-pristine ng-untouched ng-valid" name="11" type="radio" value="no-repeat">None</label>
																	</div>
																</li>
																<li>
																	<div class="radio">
																		<label class="ng-binding"><input class="ng-pristine ng-untouched ng-valid" name="12" type="radio" value="repeat-x">Horizontal</label>
																	</div>
																</li>
																<li>
																	<div class="radio">
																		<label class="ng-binding"><input class="ng-pristine ng-untouched ng-valid" name="13" type="radio" value="repeat-y">Vertical</label>
																	</div>
																</li>
																<li>
																	<div class="radio">
																		<label class="ng-binding"><input checked="checked" class="ng-pristine ng-untouched ng-valid" name="14" type="radio" value="repeat">All</label>
																	</div>
																</li>
															</ul>
														</div>
														<div class="pull-right">
															<h6 class="ng-binding">Alignment</h6>
															<div id="alignment">
																<div class="alignment-box"></div>
																<div class="alignment-box"></div>
																<div class="alignment-box"></div>
																<div class="alignment-box"></div>
																<div class="alignment-box active"></div>
																<div class="alignment-box"></div>
																<div class="alignment-box"></div>
																<div class="alignment-box"></div>
																<div class="alignment-box"></div>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div id="gradientPresets">
												<h5 class="ng-binding">gradients</h5>
												<div class="img-presets-list mCustomScrollbar _mCS_4 mCS-autoHide mCS_no_scrollbar" style="margin-left: 2em">
													<div class="mCustomScrollBox mCS-light-thin mCSB_vertical mCSB_inside" id="mCSB_4" style="max-height: 190px;" tabindex="0">
														<div class="mCSB_container mCS_y_hidden mCS_no_scrollbar_y" dir="ltr" id="mCSB_4_container" style="position:relative; top:0; left:0;">
															<!-- ngRepeat: gradient in gradients track by $index -->
															<ul>
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(to right, rgb(149, 149, 149) 0%, rgb(13, 13, 13) 46%, rgb(1, 1, 1) 50%, rgb(10, 10, 10) 53%, rgb(78, 78, 78) 76%, rgb(56, 56, 56) 87%, rgb(27, 27, 27) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(to right, rgb(255, 0, 0) 0%, rgb(255, 255, 0) 50%, rgb(255, 0, 0) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(to right, rgb(246, 248, 249) 0%, rgb(229, 235, 238) 50%, rgb(215, 222, 227) 51%, rgb(245, 247, 249) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(to right, rgb(0, 128, 128) 0%, rgb(255, 255, 255) 25%, rgb(5, 193, 255) 50%, rgb(255, 255, 255) 75%, rgb(0, 87, 87) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(to right, rgb(255, 0, 0) 0%, rgb(0, 0, 0) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(rgb(147, 206, 222) 0%, rgb(117, 189, 209) 41%, rgb(73, 165, 191) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(to right, rgb(248, 255, 232) 0%, rgb(227, 245, 171) 33%, rgb(183, 223, 45) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(to right, rgb(184, 225, 252) 0%, rgb(169, 210, 243) 10%, rgb(144, 186, 228) 25%, rgb(144, 188, 234) 37%, rgb(144, 191, 240) 50%, rgb(107, 168, 229) 51%, rgb(162, 218, 245) 83%, rgb(189, 243, 253) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(to right, rgb(240, 183, 161) 0%, rgb(140, 51, 16) 50%, rgb(117, 34, 1) 51%, rgb(191, 110, 78) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(to right, rgb(255, 0, 0) 0%, rgb(255, 255, 0) 25%, rgb(5, 193, 255) 50%, rgb(255, 255, 0) 75%, rgb(255, 0, 0) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(to right, rgb(255, 183, 107) 0%, rgb(255, 167, 61) 50%, rgb(255, 124, 0) 51%, rgb(255, 127, 4) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(to right, rgb(255, 255, 0) 0%, rgb(5, 193, 255) 50%, rgb(255, 255, 0) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(rgb(254, 191, 1) 0%, rgb(254, 191, 1) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(rgb(252, 255, 244) 0%, rgb(233, 233, 206) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(rgb(73, 192, 240) 0%, rgb(44, 175, 227) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(rgb(204, 0, 0) 0%, rgb(204, 0, 0) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(rgb(115, 136, 10) 0%, rgb(115, 136, 10) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(rgb(98, 125, 77) 0%, rgb(31, 59, 8) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(rgb(184, 198, 223) 0%, rgb(109, 136, 183) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(rgb(157, 213, 58) 0%, rgb(161, 213, 79) 50%, rgb(128, 194, 23) 51%, rgb(124, 188, 10) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(rgb(184, 198, 223) 0%, rgb(109, 136, 183) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(rgb(255, 48, 25) 0%, rgb(207, 4, 4) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(rgb(229, 112, 231) 0%, rgb(200, 94, 199) 47%, rgb(168, 73, 163) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
																<li class="ng-scope">
																	<div class="preset" style="background-image: linear-gradient(rgb(255, 255, 255) 0%, rgb(243, 243, 243) 50%, rgb(237, 237, 237) 51%, rgb(255, 255, 255) 100%);"></div>
																</li><!-- end ngRepeat: gradient in gradients track by $index -->
															</ul>
														</div>
														<div class="mCSB_scrollTools mCSB_4_scrollbar mCS-light-thin mCSB_scrollTools_vertical" id="mCSB_4_scrollbar_vertical" style="display: none;">
															<div class="mCSB_draggerContainer">
																<div class="mCSB_dragger" id="mCSB_4_dragger_vertical" oncontextmenu="return false;" style="position: absolute; min-height: 30px; top: 0px;">
																	<div class="mCSB_dragger_bar" style="line-height: 30px;"></div>
																</div>
																<div class="mCSB_draggerRail"></div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</section>
									<section class="inspector-panel accordion-item ng-scope" id="shadows-panel">
										<div class="">
											<h4 class="accordion-heading ng-binding">Shadows <i class="icon icon-down-open-1"></i></h4>
											<div class="accordion-body">
												<div class="panel-box clearfix">
													<div id="shadow-knob-container">
														<div style="display:inline;width:60px;height:60px;">
															<canvas height="60" width="60"></canvas><input style="width: 34px; height: 20px; position: absolute; vertical-align: middle; margin-top: 20px; margin-left: -47px; border: 0px; background: none; font-style: normal; font-variant: normal; font-weight: bold; font-stretch: normal; font-size: 12px; line-height: normal; font-family: Arial; text-align: center; color: rgb(0, 181, 136); padding: 0px; -webkit-appearance: none;" type="text" value="0">
														</div>
														<div class="color-picker-trigger" data-controls="props.color" data-original-title="Shadow Color" data-placement="top" data-toggle="tooltip" style="background: url("public/images/transparent.png");" title=""></div>
													</div>
													<div class="slider-group">
														<div class="range-slider">
															<div class="slider-label ng-binding">
																Distance
															</div>
															<div class="ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all">
																<div class="ui-slider-range ui-widget-header ui-corner-all ui-slider-range-min" style="width: 0%;"></div><span class="ui-slider-handle ui-state-default ui-corner-all" style="left: 0%;" tabindex="0"></span>
															</div>
														</div><input class="pretty-input ng-pristine ng-untouched ng-valid" type="text">
													</div>
													<div class="slider-group">
														<div class="range-slider">
															<div class="slider-label ng-binding">
																Blur
															</div>
															<div class="ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all">
																<div class="ui-slider-range ui-widget-header ui-corner-all ui-slider-range-min" style="width: 0%;"></div><span class="ui-slider-handle ui-state-default ui-corner-all" style="left: 0%;" tabindex="0"></span>
															</div>
														</div><input class="pretty-input ng-pristine ng-untouched ng-valid" type="text">
													</div><!-- ngIf: props.type == 'boxShadow' -->
													<div class="slider-group ng-scope">
														<div class="range-slider">
															<div class="slider-label ng-binding">
																Spread
															</div>
															<div class="ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all">
																<div class="ui-slider-range ui-widget-header ui-corner-all ui-slider-range-min" style="width: 0%;"></div><span class="ui-slider-handle ui-state-default ui-corner-all" style="left: 0%;" tabindex="0"></span>
															</div>
														</div><input class="pretty-input ng-pristine ng-untouched ng-valid" type="text">
													</div><!-- end ngIf: props.type == 'boxShadow' -->
													<select data-width="100%" id="ui-id-1" style="display: none;">
														<option class="ng-binding" value="boxShadow">
															Box
														</option>
														<option class="ng-binding" value="textShadow">
															Text
														</option>
													</select><span aria-activedescendant="ui-id-2" aria-autocomplete="list" aria-disabled="false" aria-expanded="false" aria-haspopup="true" aria-labelledby="ui-id-2" aria-owns="ui-id-1-menu" class="ui-selectmenu-button ui-widget ui-state-default ui-corner-all" id="ui-id-1-button" role="combobox" style="width: 100%;" tabindex="0"><span class="ui-icon ui-icon-triangle-1-s"></span><span class="ui-selectmenu-text">box</span></span> <!-- ngIf: props.type == 'boxShadow' --><select class="ng-scope" data-width="100%" id="ui-id-4" style="display: none;">
														<option selected value="">
															Outter
														</option>
														<option class="ng-binding" value="inset">
															inner
														</option>
													</select><span aria-autocomplete="list" aria-expanded="false" aria-haspopup="true" aria-owns="ui-id-4-menu" class="ui-selectmenu-button ui-widget ui-state-default ui-corner-all" id="ui-id-4-button" role="combobox" style="width: 100%;" tabindex="0"><span class="ui-icon ui-icon-triangle-1-s"></span><span class="ui-selectmenu-text">Outter</span></span><!-- end ngIf: props.type == 'boxShadow' -->
												</div>
											</div>
										</div>
									</section>
									<section class="ng-scope">
										<div class="inspector-panel accordion-item" id="padding-panel">
											<h4 class="accordion-heading ng-binding">Padding <i class="icon icon-down-open-1"></i></h4>
											<div class="accordion-body">
												<div class="clearfix panel-box">
													<div class="checkboxes clearfix">
														<div class="pretty-checkbox pull-left ng-scope">
															<input id="padding.all" type="checkbox"><label for="padding.all"><span class="ch-all"></span><span class="unch-all"></span></label>
														</div>
														<div class="pull-right ng-scope">
															<div class="pretty-checkbox">
																<input id="padding.top" type="checkbox"><label for="padding.top"><span class="ch-top"></span><span class="unch-top"></span></label>
															</div>
															<div class="pretty-checkbox">
																<input id="padding.right" type="checkbox"><label for="padding.right"><span class="ch-right"></span><span class="unch-right"></span></label>
															</div>
															<div class="pretty-checkbox">
																<input id="padding.bottom" type="checkbox"><label for="padding.bottom"><span class="ch-bottom"></span><span class="unch-bottom"></span></label>
															</div>
															<div class="pretty-checkbox">
																<input id="padding.left" type="checkbox"><label for="padding.left"><span class="ch-left"></span><span class="unch-left"></span></label>
															</div>
														</div>
													</div>
													<div class="ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all">
														<div class="ui-slider-range ui-widget-header ui-corner-all ui-slider-range-min" style="width: 0%;"></div><span class="ui-slider-handle ui-state-default ui-corner-all" style="left: 0%;" tabindex="0"></span>
													</div>
													<div class="clearfix input-boxes">
														<div class="big-box col-sm-6 ng-scope">
															<input class="ng-pristine ng-untouched ng-valid">
														</div>
														<div class="small-boxes col-sm-6 ng-scope">
															<div class="row">
																<input class="ng-pristine ng-untouched ng-valid">
															</div>
															<div class="row">
																<div class="col-sm-6">
																	<input class="ng-pristine ng-untouched ng-valid">
																</div>
																<div class="col-sm-6">
																	<input class="ng-pristine ng-untouched ng-valid">
																</div>
															</div>
															<div class="row">
																<input class="ng-pristine ng-untouched ng-valid">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="inspector-panel accordion-item" id="margin-panel">
											<h4 class="accordion-heading ng-binding">Margin <i class="icon icon-down-open-1"></i></h4>
											<div class="accordion-body clearfix">
												<div class="panel-body">
													<section class="checkboxes clearfix">
														<div class="pretty-checkbox pull-left ng-scope">
															<input id="margin.all" type="checkbox"><label for="margin.all"><span class="ch-all"></span><span class="unch-all"></span></label>
														</div>
														<div class="pull-right ng-scope">
															<div class="pretty-checkbox">
																<input id="margin.top" type="checkbox"><label for="margin.top"><span class="ch-top"></span><span class="unch-top"></span></label>
															</div>
															<div class="pretty-checkbox">
																<input id="margin.right" type="checkbox"><label for="margin.right"><span class="ch-right"></span><span class="unch-right"></span></label>
															</div>
															<div class="pretty-checkbox">
																<input id="margin.bottom" type="checkbox"><label for="margin.bottom"><span class="ch-bottom"></span><span class="unch-bottom"></span></label>
															</div>
															<div class="pretty-checkbox">
																<input id="margin.left" type="checkbox"><label for="margin.left"><span class="ch-left"></span><span class="unch-left"></span></label>
															</div>
														</div>
													</section>
													<div class="ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all">
														<div class="ui-slider-range ui-widget-header ui-corner-all ui-slider-range-min" style="width: 0%;"></div><span class="ui-slider-handle ui-state-default ui-corner-all" style="left: 0%;" tabindex="0"></span>
													</div>
													<div class="clearfix input-boxes">
														<div class="big-box col-sm-6 ng-scope">
															<input class="ng-pristine ng-untouched ng-valid">
														</div>
														<div class="small-boxes col-sm-6 ng-scope">
															<div class="row">
																<input class="ng-pristine ng-untouched ng-valid">
															</div>
															<div class="row">
																<div class="col-sm-6">
																	<input class="ng-pristine ng-untouched ng-valid">
																</div>
																<div class="col-sm-6">
																	<input class="ng-pristine ng-untouched ng-valid">
																</div>
															</div>
															<div class="row">
																<input class="ng-pristine ng-untouched ng-valid">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</section><!-- text style box starts -->
									<section class="inspector-panel accordion-item ng-scope" id="text-panel">
										<h4 class="accordion-heading ng-binding">Text Style <i class="icon icon-down-open-1"></i></h4>
										<div class="accordion-body">
											<div class="clearfix panel-box" id="text-box">
												<div class="clearfix">
													<select class="pull-left" data-width="200" id="el-font-family" style="display: none;">
														<option value="">
															Font
														</option><!-- ngRepeat: font in textStyles.baseFonts -->
														<option class="ng-binding ng-scope" data-font-family="Impact, Charcoal, sans-serif" value="Impact, Charcoal, sans-serif">
															Impact
														</option><!-- end ngRepeat: font in textStyles.baseFonts -->
														<option class="ng-binding ng-scope" data-font-family=""Comic Sans MS", cursive, sans-serif" value=""Comic Sans MS", cursive, sans-serif">
															Comic Sans
														</option><!-- end ngRepeat: font in textStyles.baseFonts -->
														<option class="ng-binding ng-scope" data-font-family=""Arial Black", Gadget, sans-serif" value=""Arial Black", Gadget, sans-serif">
															Arial Black
														</option><!-- end ngRepeat: font in textStyles.baseFonts -->
														<option class="ng-binding ng-scope" data-font-family="Century Gothic, sans-serif" value="Century Gothic, sans-serif">
															Century Gothic
														</option><!-- end ngRepeat: font in textStyles.baseFonts -->
														<option class="ng-binding ng-scope" data-font-family=""Courier New", Courier, monospace" value=""Courier New", Courier, monospace">
															Courier New
														</option><!-- end ngRepeat: font in textStyles.baseFonts -->
														<option class="ng-binding ng-scope" data-font-family=""Lucida Sans Unicode", "Lucida Grande", sans-serif" value=""Lucida Sans Unicode", "Lucida Grande", sans-serif">
															Lucida Sans
														</option><!-- end ngRepeat: font in textStyles.baseFonts -->
														<option class="ng-binding ng-scope" data-font-family=""Times New Roman", Times, serif" value=""Times New Roman", Times, serif">
															Times New Roman
														</option><!-- end ngRepeat: font in textStyles.baseFonts -->
														<option class="ng-binding ng-scope" data-font-family=""Lucida Console", Monaco, monospace" value=""Lucida Console", Monaco, monospace">
															Lucida Console
														</option><!-- end ngRepeat: font in textStyles.baseFonts -->
														<option class="ng-binding ng-scope" data-font-family=""Andele Mono", monospace, sans-serif" value=""Andele Mono", monospace, sans-serif">
															Andele Mono
														</option><!-- end ngRepeat: font in textStyles.baseFonts -->
														<option class="ng-binding ng-scope" data-font-family="Verdana, Geneva, sans-serif" value="Verdana, Geneva, sans-serif">
															Verdana
														</option><!-- end ngRepeat: font in textStyles.baseFonts -->
														<option class="ng-binding ng-scope" data-font-family=""Helvetica Neue", Helvetica, Arial, sans-serif" value=""Helvetica Neue", Helvetica, Arial, sans-serif">
															Helvetica Neue
														</option><!-- end ngRepeat: font in textStyles.baseFonts -->
													</select><span aria-autocomplete="list" aria-expanded="false" aria-haspopup="true" aria-owns="el-font-family-menu" class="ui-selectmenu-button ui-widget ui-state-default ui-corner-all" id="el-font-family-button" role="combobox" style="width: 200px;" tabindex="0"><span class="ui-icon ui-icon-triangle-1-s"></span><span class="ui-selectmenu-text">Font</span></span>
													<div class="pull-right" data-target="#fonts-modal" data-toggle="modal" id="more-fonts">
														<i class="icon icon-google"></i>
													</div>
												</div>
												<div class="clearfix">
													<div class="icon-box italic">
														I
													</div>
													<div class="icon-box underline">
														U
													</div>
													<div class="icon-box strike">
														S
													</div>
													<div class="icon-box overline">
														O
													</div><select class="form-control" data-width="66" id="el-font-weight" style="display: none;">
														<!-- ngRepeat: weight in textStyles.fontWeights -->
														<option class="ng-binding ng-scope" data-font-weight="100" value="100">
															100
														</option><!-- end ngRepeat: weight in textStyles.fontWeights -->
														<option class="ng-binding ng-scope" data-font-weight="200" value="200">
															200
														</option><!-- end ngRepeat: weight in textStyles.fontWeights -->
														<option class="ng-binding ng-scope" data-font-weight="300" value="300">
															300
														</option><!-- end ngRepeat: weight in textStyles.fontWeights -->
														<option class="ng-binding ng-scope" data-font-weight="400" value="400">
															400
														</option><!-- end ngRepeat: weight in textStyles.fontWeights -->
														<option class="ng-binding ng-scope" data-font-weight="500" value="500">
															500
														</option><!-- end ngRepeat: weight in textStyles.fontWeights -->
														<option class="ng-binding ng-scope" data-font-weight="600" value="600">
															600
														</option><!-- end ngRepeat: weight in textStyles.fontWeights -->
														<option class="ng-binding ng-scope" data-font-weight="700" value="700">
															700
														</option><!-- end ngRepeat: weight in textStyles.fontWeights -->
														<option class="ng-binding ng-scope" data-font-weight="800" value="800">
															800
														</option><!-- end ngRepeat: weight in textStyles.fontWeights -->
														<option class="ng-binding ng-scope" data-font-weight="900" value="900">
															900
														</option><!-- end ngRepeat: weight in textStyles.fontWeights -->
														<option class="ng-binding ng-scope" data-font-weight="bold" value="bold">
															bold
														</option><!-- end ngRepeat: weight in textStyles.fontWeights -->
														<option class="ng-binding ng-scope" data-font-weight="bolder" value="bolder">
															bolder
														</option><!-- end ngRepeat: weight in textStyles.fontWeights -->
														<option class="ng-binding ng-scope" data-font-weight="light" value="light">
															light
														</option><!-- end ngRepeat: weight in textStyles.fontWeights -->
														<option class="ng-binding ng-scope" data-font-weight="lighter" value="lighter">
															lighter
														</option><!-- end ngRepeat: weight in textStyles.fontWeights -->
														<option class="ng-binding ng-scope" data-font-weight="normal" value="normal">
															normal
														</option><!-- end ngRepeat: weight in textStyles.fontWeights -->
													</select><span aria-autocomplete="list" aria-expanded="false" aria-haspopup="true" aria-owns="el-font-weight-menu" class="ui-selectmenu-button ui-widget ui-state-default ui-corner-all" id="el-font-weight-button" role="combobox" style="width: 66px;" tabindex="0"><span class="ui-icon ui-icon-triangle-1-s"></span><span class="ui-selectmenu-text"> </span></span>
												</div>
												<div class="clearfix" id="el-font-style-box">
													<div class="pull-left">
														<input class="form-control pull-left ng-pristine ng-untouched ng-valid" id="el-font-size" type="text">
														<div class="pull-right">
															<div class="icon-box">
																<i class="icon icon-align-left"></i>
															</div>
															<div class="icon-box">
																<i class="icon icon-align-center"></i>
															</div>
															<div class="icon-box">
																<i class="icon icon-align-right"></i>
															</div>
														</div>
													</div>
												</div>
												<div class="clearfix">
													<div class="color-picker-trigger" data-controls="inspector.styles.text.color" data-original-title="" style="background:" title=""></div>
												</div>
											</div>
										</div>
									</section><!-- text style box ends -->
									<!-- border box starts -->
									<section class="ng-scope" id="border-box">
										<div class="inspector-panel accordion-item" id="border-panel">
											<h4 class="accordion-heading ng-binding">Border <i class="icon icon-down-open-1"></i></h4>
											<div class="accordion-body">
												<div class="panel-box">
													<section class="checkboxes clearfix">
														<div class="pretty-checkbox pull-left ng-scope">
															<input id="borderWidth.all" type="checkbox"><label for="borderWidth.all"><span class="ch-all"></span><span class="unch-all"></span></label>
														</div>
														<div class="pull-right ng-scope">
															<div class="pretty-checkbox">
																<input id="borderWidth.top" type="checkbox"><label for="borderWidth.top"><span class="ch-top"></span><span class="unch-top"></span></label>
															</div>
															<div class="pretty-checkbox">
																<input id="borderWidth.right" type="checkbox"><label for="borderWidth.right"><span class="ch-right"></span><span class="unch-right"></span></label>
															</div>
															<div class="pretty-checkbox">
																<input id="borderWidth.bottom" type="checkbox"><label for="borderWidth.bottom"><span class="ch-bottom"></span><span class="unch-bottom"></span></label>
															</div>
															<div class="pretty-checkbox">
																<input id="borderWidth.left" type="checkbox"><label for="borderWidth.left"><span class="ch-left"></span><span class="unch-left"></span></label>
															</div>
														</div>
													</section>
													<div class="ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all">
														<div class="ui-slider-range ui-widget-header ui-corner-all ui-slider-range-min" style="width: 0%;"></div><span class="ui-slider-handle ui-state-default ui-corner-all" style="left: 0%;" tabindex="0"></span>
													</div>
													<div class="clearfix">
														<div class="color-picker-trigger" data-controls="inspector.styles.border.color" data-original-title="" title=""></div><select class="ng-pristine ng-untouched ng-valid" id="border-style">
															<option value="? undefined:undefined ?">
															</option>
															<option class="ng-binding" value="none">
																None
															</option>
															<option class="ng-binding" value="solid">
																Solide
															</option>
															<option class="ng-binding" value="dashed">
																Dashed
															</option>
															<option class="ng-binding" value="dotted">
																dotted
															</option>
															<option class="ng-binding" value="double">
																Double
															</option>
															<option class="ng-binding" value="groove">
																Groove
															</option>
															<option class="ng-binding" value="ridge">
																Ridge
															</option>
															<option class="ng-binding" value="inset">
																Inset
															</option>
															<option class="ng-binding" value="outset">
																Outset
															</option>
														</select>
													</div>
													<div class="clearfix input-boxes">
														<div class="big-box col-sm-6 ng-scope">
															<input class="ng-pristine ng-untouched ng-valid">
														</div>
														<div class="small-boxes col-sm-6 ng-scope">
															<div class="row">
																<input class="ng-pristine ng-untouched ng-valid">
															</div>
															<div class="row">
																<div class="col-sm-6">
																	<input class="ng-pristine ng-untouched ng-valid">
																</div>
																<div class="col-sm-6">
																	<input class="ng-pristine ng-untouched ng-valid">
																</div>
															</div>
															<div class="row">
																<input class="ng-pristine ng-untouched ng-valid">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="inspector-panel accordion-item" id="border-radius-panel">
											<h4 class="accordion-heading ng-binding">Border Roundness <i class="icon icon-down-open-1"></i></h4>
											<div class="accordion-body">
												<div class="panel-box clearfix" id="borderRadius-box">
													<section class="checkboxes clearfix">
														<div class="pretty-checkbox pull-left">
															<input id="borderRadius.all" type="checkbox"> <label for="borderRadius.all"><span class="ch-all"></span><span class="unch-all"></span></label>
														</div>
														<div class="pull-right">
															<div class="pretty-checkbox">
																<input id="borderRadius.top" type="checkbox"> <label for="borderRadius.top"><span class="ch-top border-top-left"></span><span class="unch-top border-top-left"></span></label>
															</div>
															<div class="pretty-checkbox">
																<input id="borderRadius.bottom" type="checkbox"> <label for="borderRadius.bottom"><span class="ch-bottom border-bottom-left"></span><span class="unch-bottom border-bottom-left"></span></label>
															</div>
															<div class="pretty-checkbox">
																<input id="borderRadius.right" type="checkbox"> <label for="borderRadius.right"><span class="ch-right border-top-right"></span><span class="unch-right border-top-right"></span></label>
															</div>
															<div class="pretty-checkbox">
																<input id="borderRadius.left" type="checkbox"> <label for="borderRadius.left"><span class="ch-left border-bottom-right"></span><span class="unch-left border-bottom-right"></span></label>
															</div>
														</div>
													</section>
													<div class="ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all">
														<div class="ui-slider-range ui-widget-header ui-corner-all ui-slider-range-min" style="width: 0%;"></div><span class="ui-slider-handle ui-state-default ui-corner-all" style="left: 0%;" tabindex="0"></span>
													</div>
													<div class="clearfix input-boxes radius-boxes">
														<div class="big-box col-sm-6">
															<input class="ng-pristine ng-untouched ng-valid">
														</div>
														<div class="small-boxes col-sm-6">
															<input class="ng-pristine ng-untouched ng-valid"> <input class="ng-pristine ng-untouched ng-valid"> <input class="ng-pristine ng-untouched ng-valid"> <input class="ng-pristine ng-untouched ng-valid">
														</div>
													</div>
												</div>
											</div>
										</div>
									</section><!-- /border box ends -->
									<div class="arrow-right hidden" id="color-picker-arrow"></div>
									<div class="arrow-right" id="background-arrow"></div>
								</div>
								<div class="mCSB_scrollTools mCSB_2_scrollbar mCS-light-thin mCSB_scrollTools_vertical" id="mCSB_2_scrollbar_vertical" style="display: none;">
									<div class="mCSB_draggerContainer">
										<div class="mCSB_dragger" id="mCSB_2_dragger_vertical" oncontextmenu="return false;" style="position: absolute; min-height: 30px; display: block; height: 0px; max-height: 868px; top: 0px;">
											<div class="mCSB_dragger_bar" style="line-height: 30px;"></div>
										</div>
										<div class="mCSB_draggerRail"></div>
									</div>
								</div>
							</div>
						</section>
						<div class="ui-selectmenu-menu ui-front">
							<ul aria-activedescendant="ui-id-2" aria-disabled="false" aria-hidden="true" aria-labelledby="ui-id-1-button" class="ui-menu ui-widget ui-widget-content ui-corner-bottom" id="ui-id-1-menu" role="listbox" tabindex="0">
								<li class="ui-menu-item ui-state-focus" id="ui-id-2" role="option" tabindex="-1">box</li>
								<li class="ui-menu-item" id="ui-id-3" role="option" tabindex="-1">text</li>
							</ul>
						</div>
						<div class="ui-selectmenu-menu ui-front">
							<ul aria-hidden="true" aria-labelledby="el-font-family-button" class="ui-menu ui-widget ui-widget-content ui-corner-bottom" id="el-font-family-menu" role="listbox" tabindex="0"></ul>
						</div>
						<div class="ui-selectmenu-menu ui-front">
							<ul aria-hidden="true" aria-labelledby="el-font-weight-button" class="ui-menu ui-widget ui-widget-content ui-corner-bottom" id="el-font-weight-menu" role="listbox" tabindex="0"></ul>
						</div>
						<div class="ui-selectmenu-menu ui-front">
							<ul aria-hidden="true" aria-labelledby="ui-id-4-button" class="ui-menu ui-widget ui-widget-content ui-corner-bottom" id="ui-id-4-menu" role="listbox" tabindex="0"></ul>
						</div>
					</aside>
					<div class="panel mCustomScrollbar _mCS_5 mCS-autoHide mCS_no_scrollbar ng-scope" data-name="pages" id="pages">
						<div class="mCustomScrollBox mCS-light-thin mCSB_vertical mCSB_inside" id="mCSB_5" tabindex="0">
							<div class="mCSB_container mCS_y_hidden mCS_no_scrollbar_y" dir="ltr" id="mCSB_5_container" style="position:relative; top:0; left:0;">
								<ul class="list-unstyled">
									<!-- ngRepeat: page in project.active.pages track by $index -->
									<li class="ng-scope active" style=""><span class="name ng-binding">index</span></li><!-- end ngRepeat: page in project.active.pages track by $index -->
								</ul>
								<div class="action-buttons">
									<button data-original-title="" title=""><i class="icon icon-doc-add"></i></button>
									<div class="pull-right">
										<button data-original-title="" title=""><i class="icon icon-floppy-1"></i></button> <button data-original-title="" disabled="disabled" title=""><i class="icon icon-trash"></i></button> <button data-original-title="" title=""><i class="icon icon-docs-1"></i></button>
									</div>
								</div>
								<div class="page-settings">
									<div class="form-group">
										<label class="ng-binding" for="page-name">Page Name</label> <input class="form-control ng-pristine ng-untouched ng-valid" id="page-name" type="text">
									</div>
									<div class="form-group">
										<label class="ng-binding" for="page-title">Page Title (to appear on the browser tab)</label> <input class="form-control ng-pristine ng-untouched ng-valid" id="page-title" type="text">
									</div>
									<div class="form-group">
										<label class="ng-binding" for="page-description">Page Description (meta tag)</label> 
										<textarea class="form-control ng-pristine ng-untouched ng-valid" id="page-description" rows="5"></textarea>
									</div>
									<div class="form-group">
										<label class="ng-binding" for="page-tags">Page Tags (separate with comma)</label> 
										<textarea class="form-control ng-pristine ng-untouched ng-valid" id="page-tags" rows="5"></textarea>
									</div>
								</div>
								<div class="buttons-bottom">
									<button class="btn btn-danger ng-binding">Empty Project</button>
								</div>
							</div>
							<div class="mCSB_scrollTools mCSB_5_scrollbar mCS-light-thin mCSB_scrollTools_vertical" id="mCSB_5_scrollbar_vertical" style="display: none;">
								<div class="mCSB_draggerContainer">
									<div class="mCSB_dragger" id="mCSB_5_dragger_vertical" oncontextmenu="return false;" style="position: absolute; min-height: 30px; height: 0px; top: 0px;">
										<div class="mCSB_dragger_bar" style="line-height: 30px;"></div>
									</div>
									<div class="mCSB_draggerRail"></div>
								</div>
							</div>
						</div>
					</div>
					<div class="panel ng-scope" data-name="settings" id="settings">
						<div class="categories">
							<!-- ngRepeat: (category, categorySettings) in settings.all -->
							<div class="accordion-item ng-scope">
								<div class="accordion-heading ng-binding">
									Content Boxes <i class="icon icon-down-open-1"></i>
								</div>
								<div class="accordion-body">
									<div class="settings-container">
										<!-- ngRepeat: setting in categorySettings -->
										<div class="form-group setting ng-scope">
											<!-- ngIf: isBoolean(setting.value) -->
											<div class="with-toggle ng-scope">
												<div class="label ng-binding">
													Enable Hover Box:
												</div>
												<div class="toggle toggle-light" data-name="enableHoverBox" style="height: 30px;">
													<div class="toggle-slide">
														<div class="toggle-inner" style="width: 130px; margin-left: 0px;">
															<div class="toggle-on active" style="height: 30px; width: 65px; text-indent: -15px; line-height: 30px;">
																Yes
															</div>
															<div class="toggle-blob" style="height: 30px; width: 30px; margin-left: -15px;"></div>
															<div class="toggle-off" style="height: 30px; width: 65px; margin-left: -15px; text-indent: 15px; line-height: 30px;">
																No
															</div>
														</div>
													</div>
												</div>
												<p class="ng-binding">Show/Hide box that appears when hovering over elements in the builder.</p>
											</div><!-- end ngIf: isBoolean(setting.value) -->
											<!-- ngIf: !isBoolean(setting.value) -->
										</div><!-- end ngRepeat: setting in categorySettings -->
										<div class="form-group setting ng-scope">
											<!-- ngIf: isBoolean(setting.value) -->
											<div class="with-toggle ng-scope">
												<div class="label ng-binding">
													Enable Select Box:
												</div>
												<div class="toggle toggle-light" data-name="enableSelectBox" style="height: 30px;">
													<div class="toggle-slide">
														<div class="toggle-inner" style="width: 130px; margin-left: 0px;">
															<div class="toggle-on active" style="height: 30px; width: 65px; text-indent: -15px; line-height: 30px;">
																Yes
															</div>
															<div class="toggle-blob" style="height: 30px; width: 30px; margin-left: -15px;"></div>
															<div class="toggle-off" style="height: 30px; width: 65px; margin-left: -15px; text-indent: 15px; line-height: 30px;">
																No
															</div>
														</div>
													</div>
												</div>
												<p class="ng-binding">Show/Hide box that appears when clicking an element in the builder.</p>
											</div><!-- end ngIf: isBoolean(setting.value) -->
											<!-- ngIf: !isBoolean(setting.value) -->
										</div><!-- end ngRepeat: setting in categorySettings -->
										<div class="form-group setting ng-scope">
											<!-- ngIf: isBoolean(setting.value) -->
											<div class="with-toggle ng-scope">
												<div class="label ng-binding">
													Show Width And Height Handles:
												</div>
												<div class="toggle toggle-light" data-name="showWidthAndHeightHandles" style="height: 30px;">
													<div class="toggle-slide">
														<div class="toggle-inner" style="width: 130px; margin-left: 0px;">
															<div class="toggle-on active" style="height: 30px; width: 65px; text-indent: -15px; line-height: 30px;">
																Yes
															</div>
															<div class="toggle-blob" style="height: 30px; width: 30px; margin-left: -15px;"></div>
															<div class="toggle-off" style="height: 30px; width: 65px; margin-left: -15px; text-indent: 15px; line-height: 30px;">
																No
															</div>
														</div>
													</div>
												</div>
												<p class="ng-binding">Show/Hide circle handles used to change elements width and height by dragging them.</p>
											</div><!-- end ngIf: isBoolean(setting.value) -->
											<!-- ngIf: !isBoolean(setting.value) -->
										</div><!-- end ngRepeat: setting in categorySettings -->
									</div>
								</div>
							</div><!-- end ngRepeat: (category, categorySettings) in settings.all -->
							<div class="accordion-item ng-scope open">
								<div class="accordion-heading ng-binding">
									Auto Save <i class="icon icon-down-open-1"></i>
								</div>
								<div class="accordion-body">
									<div class="settings-container">
										<!-- ngRepeat: setting in categorySettings -->
										<div class="form-group setting ng-scope">
											<!-- ngIf: isBoolean(setting.value) -->
											<div class="with-toggle ng-scope">
												<div class="label ng-binding">
													Enable Auto Save:
												</div>
												<div class="toggle toggle-light" data-name="enableAutoSave" style="height: 30px;">
													<div class="toggle-slide">
														<div class="toggle-inner" style="width: 130px; margin-left: 0px;">
															<div class="toggle-on active" style="height: 30px; width: 65px; text-indent: -15px; line-height: 30px;">
																Yes
															</div>
															<div class="toggle-blob" style="height: 30px; width: 30px; margin-left: -15px;"></div>
															<div class="toggle-off" style="height: 30px; width: 65px; margin-left: -15px; text-indent: 15px; line-height: 30px;">
																No
															</div>
														</div>
													</div>
												</div>
												<p class="ng-binding">Enable/Disable automatic saving when changes are made to the project or page. This may cause some delays on Firefox and Internet Explorer browsers.</p>
											</div><!-- end ngIf: isBoolean(setting.value) -->
											<!-- ngIf: !isBoolean(setting.value) -->
										</div><!-- end ngRepeat: setting in categorySettings -->
										<div class="form-group setting ng-scope">
											<!-- ngIf: isBoolean(setting.value) -->
											<!-- ngIf: !isBoolean(setting.value) -->
											<div class="with-input ng-scope">
												<div class="label ng-binding">
													Auto Save Delay:
												</div><input class="form-control ng-pristine ng-untouched ng-valid" type="text">
												<p class="ng-binding">How long (in miliseconds) to wait before auto saving after changes are made.</p>
											</div><!-- end ngIf: !isBoolean(setting.value) -->
										</div><!-- end ngRepeat: setting in categorySettings -->
									</div>
								</div>
							</div><!-- end ngRepeat: (category, categorySettings) in settings.all -->
							<div class="accordion-item ng-scope">
								<div class="accordion-heading ng-binding">
									Panels <i class="icon icon-down-open-1"></i>
								</div>
								<div class="accordion-body">
									<div class="settings-container">
										<!-- ngRepeat: setting in categorySettings -->
										<div class="form-group setting ng-scope">
											<!-- ngIf: isBoolean(setting.value) -->
											<div class="with-toggle ng-scope">
												<div class="label ng-binding">
													Show Element Preview:
												</div>
												<div class="toggle toggle-light" data-name="showElementPreview" style="height: 30px;">
													<div class="toggle-slide">
														<div class="toggle-inner" style="width: 130px; margin-left: -50px;">
															<div class="toggle-on" style="height: 30px; width: 65px; text-indent: -15px; line-height: 30px;">
																Yes
															</div>
															<div class="toggle-blob" style="height: 30px; width: 30px; margin-left: -15px;"></div>
															<div class="toggle-off active" style="height: 30px; width: 65px; margin-left: -15px; text-indent: 15px; line-height: 30px;">
																No
															</div>
														</div>
													</div>
												</div>
												<p class="ng-binding">Should element preview container be visible in elements panel.</p>
											</div><!-- end ngIf: isBoolean(setting.value) -->
											<!-- ngIf: !isBoolean(setting.value) -->
										</div><!-- end ngRepeat: setting in categorySettings -->
									</div>
								</div>
							</div><!-- end ngRepeat: (category, categorySettings) in settings.all -->
							<div class="accordion-item ng-scope">
								<div class="accordion-heading ng-binding">
									Elements <i class="icon icon-down-open-1"></i>
								</div>
								<div class="accordion-body">
									<div class="settings-container">
										<!-- ngRepeat: setting in categorySettings -->
										<div class="form-group setting ng-scope">
											<!-- ngIf: isBoolean(setting.value) -->
											<div class="with-toggle ng-scope">
												<div class="label ng-binding">
													Enable Free Element Dragging:
												</div>
												<div class="toggle toggle-light" data-name="enableFreeElementDragging" style="height: 30px;">
													<div class="toggle-slide">
														<div class="toggle-inner" style="width: 130px; margin-left: -50px;">
															<div class="toggle-on" style="height: 30px; width: 65px; text-indent: -15px; line-height: 30px;">
																Yes
															</div>
															<div class="toggle-blob" style="height: 30px; width: 30px; margin-left: -15px;"></div>
															<div class="toggle-off active" style="height: 30px; width: 65px; margin-left: -15px; text-indent: 15px; line-height: 30px;">
																No
															</div>
														</div>
													</div>
												</div>
												<p class="ng-binding">When this is enabled you will be able to drag elements anywhere on the screen without any restrictions. Elements will be positioned absolutely so you should not use columns or rows with this mode. To use, first select an element then drag.</p>
											</div><!-- end ngIf: isBoolean(setting.value) -->
											<!-- ngIf: !isBoolean(setting.value) -->
										</div><!-- end ngRepeat: setting in categorySettings -->
									</div>
								</div>
							</div><!-- end ngRepeat: (category, categorySettings) in settings.all -->
						</div>
					</div>
					<section>
						<div class="device-switcher ng-hide">
							<div class="devices">
								<button><i class="icon icon-mobile"></i></button> <button><i class="icon icon-tablet-1"></i></button> <button><i class="icon icon-laptop"></i></button> <button class="active"><i class="icon icon-desktop"></i></button>
							</div>
							<div class="current-device">
								<i class="icon icon-desktop"></i>
								<div class="name ng-binding">
									desktop
								</div>
								<div class="size ng-binding">
									1200px and Larger
								</div>
							</div>
						</div>
						<div class="bottom-navigation">
							<button data-original-title="" title=""><i class="icon icon-eye"></i></button> <button data-original-title="" title=""><i class="icon icon-export"></i></button> <button data-original-title="" title=""><i class="icon icon-mobile"></i></button> <button data-original-title="" title=""><i class="icon icon-floppy-1"></i></button>
						</div>
					</section>
				</div>
			</section>
		</aside>
		<div id="middle">
			<div class="ng-scope ng-hide" id="context-menu">
				<h5 class="clearfix"><span class="name ng-binding"></span><i class="icon icon-cancel"></i></h5>
				<ul class="list-unstyled">
					<!-- ngIf: selected.isTable -->
					<!-- ngIf: selected.isTable -->
					<!-- ngIf: selected.isTable -->
					<!-- ngIf: selected.isTable -->
					<!-- ngIf: selected.isTable -->
					<li>
						<div class="command-name ng-binding">
							<i class="icon icon-up-outline"></i> Select Parent
						</div>
					</li>
					<li>
						<div class="command-name ng-binding">
							<i class="icon icon-bullseye"></i> Wrap in Transparent Div
						</div>
					</li>
					<li class="separator"></li>
					<li>
						<div class="command-name ng-binding">
							<i class="icon icon-scissors"></i> Cut
						</div>
						<div class="command-keybind">
							Ctrl+X
						</div>
					</li>
					<li>
						<div class="command-name ng-binding">
							<i class="icon icon-docs"></i> Copy
						</div>
						<div class="command-keybind">
							Ctrl+C
						</div>
					</li>
					<li class="disabled">
						<div class="command-name ng-binding">
							<i class="icon icon-paste"></i> Paste
						</div>
						<div class="command-keybind">
							Ctrl+V
						</div>
					</li>
					<li>
						<div class="command-name ng-binding">
							<i class="icon icon-trash"></i> Delete
						</div>
						<div class="command-keybind">
							Del
						</div>
					</li>
					<li>
						<div class="command-name ng-binding">
							<i class="icon icon-database"></i> Duplicate
						</div>
					</li>
					<li class="separator"></li>
					<li>
						<div class="command-name ng-binding">
							<i class="icon icon-up-open"></i> Move Up
						</div>
						<div class="command-keybind">
							↑
						</div>
					</li>
					<li>
						<div class="command-name ng-binding">
							<i class="icon icon-down-open"></i> Move Down
						</div>
						<div class="command-keybind">
							↓
						</div>
					</li>
					<li class="separator"></li>
					<li class="disabled">
						<div class="command-name ng-binding">
							<i class="icon icon-reply"></i> Undo
						</div>
						<div class="command-keybind">
							Ctrl+Z
						</div>
					</li>
					<li class="disabled">
						<div class="command-name ng-binding">
							<i class="icon icon-forward"></i> Redo
						</div>
						<div class="command-keybind">
							Ctrl+Y
						</div>
					</li>
					<li class="separator"></li>
					<li>
						<div class="command-name ng-binding">
							View Source
						</div>
					</li>
				</ul>
			</div>
			<div id="frame-wrapper">
				<section id="highlights">
					<div class="hidden ng-scope" id="linker">
						<h3 class="ng-binding">Link For: <span class="ng-binding"></span> <i class="fa pull-right fa-times"></i></h3>
						<ul>
							<li class="disabled">
								<label class="pull-left"></label>
								<div class="radio-input">
									<label class="pull-left"><input class="ng-pristine ng-untouched ng-valid" name="23" type="radio" value="url"></label>
								</div>
								<div class="pull-right">
									<div class="title ng-binding">
										Website URL
									</div>
									<div class="body">
										<input class="form-control ng-pristine ng-untouched ng-valid" placeholder="http://www.google.com" type="text">
									</div>
								</div>
							</li>
							<li class="disabled">
								<label class="pull-left"></label>
								<div class="radio-input">
									<label class="pull-left"><input class="ng-pristine ng-untouched ng-valid" name="24" type="radio" value="page"></label>
								</div>
								<div class="pull-right">
									<div class="title ng-binding">
										Page
									</div>
									<div class="body">
										<select class="form-control ng-pristine ng-untouched ng-valid">
											<option class="ng-binding" value="">
												Selct a Page
											</option><!-- ngRepeat: page in project.active.pages -->
											<option class="ng-binding ng-scope" style="" value="index">
												Index
											</option><!-- end ngRepeat: page in project.active.pages -->
										</select>
									</div>
								</div>
							</li>
							<li class="disabled">
								<label class="pull-left"></label>
								<div class="radio-input">
									<label class="pull-left"><input class="ng-pristine ng-untouched ng-valid" name="25" type="radio" value="download"></label>
								</div>
								<div class="pull-right">
									<div class="title ng-binding">
										Download
									</div>
									<div class="body">
										<input class="form-control ng-pristine ng-untouched ng-valid" placeholder="https://www.google.com/images/srpr/logo11w.png" type="text">
									</div>
								</div>
							</li>
							<li class="disabled">
								<label class="pull-left"></label>
								<div class="radio-input">
									<label class="pull-left"><input class="ng-pristine ng-untouched ng-valid" name="26" type="radio" value="email"></label>
								</div>
								<div class="pull-right">
									<div class="title ng-binding">
										Email Address
									</div>
									<div class="body">
										<input class="form-control ng-pristine ng-untouched ng-valid" placeholder="vebtolabs@gmail.com" type="text">
									</div>
								</div>
							</li>
						</ul>
					</div>
					<div id="hover-box" style="display: none;">
						<div id="hover-box-actions">
							<span class="element-tag">#</span>
						</div>
					</div>
					<div class="" id="select-box" style="display: none;">
						<div class="" id="select-box-actions">
							<span class="element-tag"></span> <!-- ngIf: !selected.element.hideEditIcon --><i class="icon icon-pencil ng-scope" data-action="edit"></i><!-- end ngIf: !selected.element.hideEditIcon -->
							 <i class="icon icon-lock-open" data-action="lock"></i> <i class="icon icon-trash" data-action="delete"></i>
						</div>
						<div id="column-resizers"></div>
						<div class="" id="resize-handles">
							<span class="drag-handle nw-handle" data-direction="nw"></span> <span class="drag-handle n-handle" data-direction="n"></span> <span class="drag-handle ne-handle" data-direction="ne"></span> <span class="drag-handle e-handle" data-direction="e"></span> <span class="drag-handle se-handle" data-direction="se"></span> <span class="drag-handle s-handle" data-direction="s"></span> <span class="drag-handle sw-handle" data-direction="sw"></span> <span class="drag-handle w-handle" data-direction="w"></span>
						</div>
					</div>
					<div id="edit-columns">
						<i class="icon icon-cog-outline"></i> <span class="ng-binding">Edit Columns</span>
					</div>
					<div id="row-editor">
						<div class="column-controls"></div>
						<div class="row-presets clearfix">
							<button class="btn btn-sm btn-default equalize-columns pull-left ng-binding">Make columns equal width</button>
							<div class="pull-right">
								<div class="row-preset" data-original-title="" data-preset="12" title="">
									<div class="row-preset-12"></div>
								</div>
								<div class="row-preset" data-original-title="" data-preset="6,6" title="">
									<div class="row-preset-6"></div>
									<div class="row-preset-6"></div>
								</div>
								<div class="row-preset" data-original-title="" data-preset="3,6,3" title="">
									<div class="row-preset-3"></div>
									<div class="row-preset-6"></div>
									<div class="row-preset-3"></div>
								</div>
								<div class="row-preset" data-original-title="" data-preset="4,4,4" title="">
									<div class="row-preset-4"></div>
									<div class="row-preset-4"></div>
									<div class="row-preset-4"></div>
								</div>
								<div class="row-preset" data-original-title="" data-preset="3,3,3,3" title="">
									<div class="row-preset-3"></div>
									<div class="row-preset-3"></div>
									<div class="row-preset-3"></div>
									<div class="row-preset-3"></div>
								</div>
								<div class="row-preset" data-original-title="" data-preset="3,9" title="">
									<div class="row-preset-3"></div>
									<div class="row-preset-9"></div>
								</div>
								<div class="row-preset" data-original-title="" data-preset="9,3" title="">
									<div class="row-preset-9"></div>
									<div class="row-preset-3"></div>
								</div>
								<div class="row-preset" data-original-title="" data-preset="2,2,2,2,2,2" title="">
									<div class="row-preset-2"></div>
									<div class="row-preset-2"></div>
									<div class="row-preset-2"></div>
									<div class="row-preset-2"></div>
									<div class="row-preset-2"></div>
									<div class="row-preset-2"></div>
								</div>
								<div class="row-preset" data-original-title="" data-preset="6,2,4" title="">
									<div class="row-preset-6"></div>
									<div class="row-preset-2"></div>
									<div class="row-preset-4"></div>
								</div>
								<div class="row-preset" data-original-title="" data-preset="4,2,6" title="">
									<div class="row-preset-4"></div>
									<div class="row-preset-2"></div>
									<div class="row-preset-6"></div>
								</div>
							</div>
						</div>
						<div class="column-controls-footer clearfix">
							<i class="icon icon-cancel close-row-editor"></i> <button class="btn btn-sm btn-primary pull-right save-and-close-row-editor ng-binding">Save & Close</button>
						</div>
					</div>
					<div class="ng-scope hidden" id="text-toolbar">
						<select data-width="120" id="toolbar-size" style="display: none;">
							<option value="">
								Size
							</option><!-- ngRepeat: num in fontSizes -->
							<option class="ng-binding ng-scope" data-font-size="8" value="8">
								8
							</option><!-- end ngRepeat: num in fontSizes -->
							<option class="ng-binding ng-scope" data-font-size="9" value="9">
								9
							</option><!-- end ngRepeat: num in fontSizes -->
							<option class="ng-binding ng-scope" data-font-size="10" value="10">
								10
							</option><!-- end ngRepeat: num in fontSizes -->
							<option class="ng-binding ng-scope" data-font-size="11" value="11">
								11
							</option><!-- end ngRepeat: num in fontSizes -->
							<option class="ng-binding ng-scope" data-font-size="12" value="12">
								12
							</option><!-- end ngRepeat: num in fontSizes -->
							<option class="ng-binding ng-scope" data-font-size="14" value="14">
								14
							</option><!-- end ngRepeat: num in fontSizes -->
							<option class="ng-binding ng-scope" data-font-size="16" value="16">
								16
							</option><!-- end ngRepeat: num in fontSizes -->
							<option class="ng-binding ng-scope" data-font-size="18" value="18">
								18
							</option><!-- end ngRepeat: num in fontSizes -->
							<option class="ng-binding ng-scope" data-font-size="20" value="20">
								20
							</option><!-- end ngRepeat: num in fontSizes -->
							<option class="ng-binding ng-scope" data-font-size="22" value="22">
								22
							</option><!-- end ngRepeat: num in fontSizes -->
							<option class="ng-binding ng-scope" data-font-size="24" value="24">
								24
							</option><!-- end ngRepeat: num in fontSizes -->
							<option class="ng-binding ng-scope" data-font-size="26" value="26">
								26
							</option><!-- end ngRepeat: num in fontSizes -->
							<option class="ng-binding ng-scope" data-font-size="28" value="28">
								28
							</option><!-- end ngRepeat: num in fontSizes -->
							<option class="ng-binding ng-scope" data-font-size="36" value="36">
								36
							</option><!-- end ngRepeat: num in fontSizes -->
							<option class="ng-binding ng-scope" data-font-size="48" value="48">
								48
							</option><!-- end ngRepeat: num in fontSizes -->
							<option class="ng-binding ng-scope" data-font-size="72" value="72">
								72
							</option><!-- end ngRepeat: num in fontSizes -->
						</select><span aria-autocomplete="list" aria-expanded="false" aria-haspopup="true" aria-owns="toolbar-size-menu" class="ui-selectmenu-button ui-widget ui-state-default ui-corner-all" id="toolbar-size-button" role="combobox" style="width: 120px;" tabindex="0"><span class="ui-icon ui-icon-triangle-1-s"></span><span class="ui-selectmenu-text">Size</span></span> <select data-width="150" id="toolbar-font" style="display: none;">
							<option value="">
								Font
							</option><!-- ngRepeat: font in baseFonts -->
							<option class="ng-binding ng-scope" data-font-family="Impact, Charcoal, sans-serif" value="Impact">
								Impact
							</option><!-- end ngRepeat: font in baseFonts -->
							<option class="ng-binding ng-scope" data-font-family=""Comic Sans MS", cursive, sans-serif" value="Comic Sans">
								Comic Sans
							</option><!-- end ngRepeat: font in baseFonts -->
							<option class="ng-binding ng-scope" data-font-family=""Arial Black", Gadget, sans-serif" value="Arial Black">
								Arial Black
							</option><!-- end ngRepeat: font in baseFonts -->
							<option class="ng-binding ng-scope" data-font-family="Century Gothic, sans-serif" value="Century Gothic">
								Century Gothic
							</option><!-- end ngRepeat: font in baseFonts -->
							<option class="ng-binding ng-scope" data-font-family=""Courier New", Courier, monospace" value="Courier New">
								Courier New
							</option><!-- end ngRepeat: font in baseFonts -->
							<option class="ng-binding ng-scope" data-font-family=""Lucida Sans Unicode", "Lucida Grande", sans-serif" value="Lucida Sans">
								Lucida Sans
							</option><!-- end ngRepeat: font in baseFonts -->
							<option class="ng-binding ng-scope" data-font-family=""Times New Roman", Times, serif" value="Times New Roman">
								Times New Roman
							</option><!-- end ngRepeat: font in baseFonts -->
							<option class="ng-binding ng-scope" data-font-family=""Lucida Console", Monaco, monospace" value="Lucida Console">
								Lucida Console
							</option><!-- end ngRepeat: font in baseFonts -->
							<option class="ng-binding ng-scope" data-font-family=""Andele Mono", monospace, sans-serif" value="Andele Mono">
								Andele Mono
							</option><!-- end ngRepeat: font in baseFonts -->
							<option class="ng-binding ng-scope" data-font-family="Verdana, Geneva, sans-serif" value="Verdana">
								Verdana
							</option><!-- end ngRepeat: font in baseFonts -->
							<option class="ng-binding ng-scope" data-font-family=""Helvetica Neue", Helvetica, Arial, sans-serif" value="Helvetica Neue">
								Helvetica Neue
							</option><!-- end ngRepeat: font in baseFonts -->
						</select><span aria-autocomplete="list" aria-expanded="false" aria-haspopup="true" aria-owns="toolbar-font-menu" class="ui-selectmenu-button ui-widget ui-state-default ui-corner-all" id="toolbar-font-button" role="combobox" style="width: 150px;" tabindex="0"><span class="ui-icon ui-icon-triangle-1-s"></span><span class="ui-selectmenu-text">Font</span></span>
						<div id="toolbar-style">
							<div class="bold">
								B
							</div>
							<div class="italic">
								I
							</div>
							<div class="underline">
								U
							</div>
							<div class="strike">
								S
							</div>
							<div class="wrap-link">
								<i class="icon icon-link-outline"></i>
							</div>
							<div class="align-left">
								<i class="icon icon-align-left"></i>
							</div>
							<div class="align-center">
								<i class="icon icon-align-center"></i>
							</div>
							<div class="align-right">
								<i class="icon icon-align-right"></i>
							</div>
							<div class="show-icons-list">
								<i class="icon icon-emo-thumbsup"></i>
							</div>
							<section id="icons-list">
								<div class="arrow-up"></div><input class="ng-pristine ng-untouched ng-valid" placeholder="Search for icons" type="text">
								<ul class="list-unstyled list-inline">
									<!-- ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-glass"><i class="fa fa-glass"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-music"><i class="fa fa-music"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-search"><i class="fa fa-search"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-envelope-o"><i class="fa fa-envelope-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-heart"><i class="fa fa-heart"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-star"><i class="fa fa-star"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-star-o"><i class="fa fa-star-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-user"><i class="fa fa-user"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-film"><i class="fa fa-film"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-th-large"><i class="fa fa-th-large"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-th"><i class="fa fa-th"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-th-list"><i class="fa fa-th-list"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-check"><i class="fa fa-check"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-times"><i class="fa fa-times"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-search-plus"><i class="fa fa-search-plus"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-search-minus"><i class="fa fa-search-minus"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-power-off"><i class="fa fa-power-off"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-signal"><i class="fa fa-signal"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-cog"><i class="fa fa-cog"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-trash-o"><i class="fa fa-trash-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-home"><i class="fa fa-home"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-file-o"><i class="fa fa-file-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-clock-o"><i class="fa fa-clock-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-road"><i class="fa fa-road"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-download"><i class="fa fa-download"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-arrow-circle-o-down"><i class="fa fa-arrow-circle-o-down"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-arrow-circle-o-up"><i class="fa fa-arrow-circle-o-up"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-inbox"><i class="fa fa-inbox"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-play-circle-o"><i class="fa fa-play-circle-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-repeat"><i class="fa fa-repeat"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-refresh"><i class="fa fa-refresh"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-list-alt"><i class="fa fa-list-alt"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-lock"><i class="fa fa-lock"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-flag"><i class="fa fa-flag"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-headphones"><i class="fa fa-headphones"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-volume-off"><i class="fa fa-volume-off"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-volume-down"><i class="fa fa-volume-down"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-volume-up"><i class="fa fa-volume-up"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-qrcode"><i class="fa fa-qrcode"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-barcode"><i class="fa fa-barcode"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-tag"><i class="fa fa-tag"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-tags"><i class="fa fa-tags"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-book"><i class="fa fa-book"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-bookmark"><i class="fa fa-bookmark"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-print"><i class="fa fa-print"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-camera"><i class="fa fa-camera"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-font"><i class="fa fa-font"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-bold"><i class="fa fa-bold"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-italic"><i class="fa fa-italic"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-text-height"><i class="fa fa-text-height"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-text-width"><i class="fa fa-text-width"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-align-left"><i class="fa fa-align-left"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-align-center"><i class="fa fa-align-center"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-align-right"><i class="fa fa-align-right"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-align-justify"><i class="fa fa-align-justify"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-list"><i class="fa fa-list"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-outdent"><i class="fa fa-outdent"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-indent"><i class="fa fa-indent"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-video-camera"><i class="fa fa-video-camera"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-picture-o"><i class="fa fa-picture-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-pencil"><i class="fa fa-pencil"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-map-marker"><i class="fa fa-map-marker"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-adjust"><i class="fa fa-adjust"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-tint"><i class="fa fa-tint"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-pencil-square-o"><i class="fa fa-pencil-square-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-share-square-o"><i class="fa fa-share-square-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-check-square-o"><i class="fa fa-check-square-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-arrows"><i class="fa fa-arrows"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-step-backward"><i class="fa fa-step-backward"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-fast-backward"><i class="fa fa-fast-backward"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-backward"><i class="fa fa-backward"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-play"><i class="fa fa-play"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-pause"><i class="fa fa-pause"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-stop"><i class="fa fa-stop"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-forward"><i class="fa fa-forward"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-fast-forward"><i class="fa fa-fast-forward"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-step-forward"><i class="fa fa-step-forward"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-eject"><i class="fa fa-eject"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-chevron-left"><i class="fa fa-chevron-left"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-chevron-right"><i class="fa fa-chevron-right"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-plus-circle"><i class="fa fa-plus-circle"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-minus-circle"><i class="fa fa-minus-circle"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-times-circle"><i class="fa fa-times-circle"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-check-circle"><i class="fa fa-check-circle"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-question-circle"><i class="fa fa-question-circle"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-info-circle"><i class="fa fa-info-circle"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-crosshairs"><i class="fa fa-crosshairs"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-times-circle-o"><i class="fa fa-times-circle-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-check-circle-o"><i class="fa fa-check-circle-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-ban"><i class="fa fa-ban"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-arrow-left"><i class="fa fa-arrow-left"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-arrow-right"><i class="fa fa-arrow-right"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-arrow-up"><i class="fa fa-arrow-up"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-arrow-down"><i class="fa fa-arrow-down"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-share"><i class="fa fa-share"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-expand"><i class="fa fa-expand"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-compress"><i class="fa fa-compress"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-plus"><i class="fa fa-plus"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-minus"><i class="fa fa-minus"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-asterisk"><i class="fa fa-asterisk"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-exclamation-circle"><i class="fa fa-exclamation-circle"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-gift"><i class="fa fa-gift"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-leaf"><i class="fa fa-leaf"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-fire"><i class="fa fa-fire"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-eye"><i class="fa fa-eye"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-eye-slash"><i class="fa fa-eye-slash"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-exclamation-triangle"><i class="fa fa-exclamation-triangle"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-plane"><i class="fa fa-plane"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-calendar"><i class="fa fa-calendar"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-random"><i class="fa fa-random"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-comment"><i class="fa fa-comment"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-magnet"><i class="fa fa-magnet"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-chevron-up"><i class="fa fa-chevron-up"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-chevron-down"><i class="fa fa-chevron-down"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-retweet"><i class="fa fa-retweet"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-shopping-cart"><i class="fa fa-shopping-cart"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-folder"><i class="fa fa-folder"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-folder-open"><i class="fa fa-folder-open"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-arrows-v"><i class="fa fa-arrows-v"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-arrows-h"><i class="fa fa-arrows-h"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-bar-chart-o"><i class="fa fa-bar-chart-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-twitter-square"><i class="fa fa-twitter-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-facebook-square"><i class="fa fa-facebook-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-camera-retro"><i class="fa fa-camera-retro"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-key"><i class="fa fa-key"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-cogs"><i class="fa fa-cogs"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-comments"><i class="fa fa-comments"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-thumbs-o-up"><i class="fa fa-thumbs-o-up"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-thumbs-o-down"><i class="fa fa-thumbs-o-down"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-star-half"><i class="fa fa-star-half"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-heart-o"><i class="fa fa-heart-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-sign-out"><i class="fa fa-sign-out"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-linkedin-square"><i class="fa fa-linkedin-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-thumb-tack"><i class="fa fa-thumb-tack"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-external-link"><i class="fa fa-external-link"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-sign-in"><i class="fa fa-sign-in"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-trophy"><i class="fa fa-trophy"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-github-square"><i class="fa fa-github-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-upload"><i class="fa fa-upload"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-lemon-o"><i class="fa fa-lemon-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-phone"><i class="fa fa-phone"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-square-o"><i class="fa fa-square-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-bookmark-o"><i class="fa fa-bookmark-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-phone-square"><i class="fa fa-phone-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-twitter"><i class="fa fa-twitter"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-facebook"><i class="fa fa-facebook"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-github"><i class="fa fa-github"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-unlock"><i class="fa fa-unlock"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-credit-card"><i class="fa fa-credit-card"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-rss"><i class="fa fa-rss"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-hdd-o"><i class="fa fa-hdd-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-bullhorn"><i class="fa fa-bullhorn"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-bell"><i class="fa fa-bell"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-certificate"><i class="fa fa-certificate"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-hand-o-right"><i class="fa fa-hand-o-right"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-hand-o-left"><i class="fa fa-hand-o-left"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-hand-o-up"><i class="fa fa-hand-o-up"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-hand-o-down"><i class="fa fa-hand-o-down"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-arrow-circle-left"><i class="fa fa-arrow-circle-left"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-arrow-circle-right"><i class="fa fa-arrow-circle-right"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-arrow-circle-up"><i class="fa fa-arrow-circle-up"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-arrow-circle-down"><i class="fa fa-arrow-circle-down"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-globe"><i class="fa fa-globe"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-wrench"><i class="fa fa-wrench"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-tasks"><i class="fa fa-tasks"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-filter"><i class="fa fa-filter"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-briefcase"><i class="fa fa-briefcase"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-arrows-alt"><i class="fa fa-arrows-alt"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-users"><i class="fa fa-users"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-link"><i class="fa fa-link"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-cloud"><i class="fa fa-cloud"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-flask"><i class="fa fa-flask"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-scissors"><i class="fa fa-scissors"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-files-o"><i class="fa fa-files-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-paperclip"><i class="fa fa-paperclip"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-floppy-o"><i class="fa fa-floppy-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-square"><i class="fa fa-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-bars"><i class="fa fa-bars"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-list-ul"><i class="fa fa-list-ul"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-list-ol"><i class="fa fa-list-ol"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-strikethrough"><i class="fa fa-strikethrough"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-underline"><i class="fa fa-underline"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-table"><i class="fa fa-table"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-magic"><i class="fa fa-magic"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-truck"><i class="fa fa-truck"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-pinterest"><i class="fa fa-pinterest"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-pinterest-square"><i class="fa fa-pinterest-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-google-plus-square"><i class="fa fa-google-plus-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-google-plus"><i class="fa fa-google-plus"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-money"><i class="fa fa-money"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-caret-down"><i class="fa fa-caret-down"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-caret-up"><i class="fa fa-caret-up"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-caret-left"><i class="fa fa-caret-left"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-caret-right"><i class="fa fa-caret-right"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-columns"><i class="fa fa-columns"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-sort"><i class="fa fa-sort"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-sort-desc"><i class="fa fa-sort-desc"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-sort-asc"><i class="fa fa-sort-asc"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-envelope"><i class="fa fa-envelope"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-linkedin"><i class="fa fa-linkedin"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-undo"><i class="fa fa-undo"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-gavel"><i class="fa fa-gavel"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-tachometer"><i class="fa fa-tachometer"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-comment-o"><i class="fa fa-comment-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-comments-o"><i class="fa fa-comments-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-bolt"><i class="fa fa-bolt"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-sitemap"><i class="fa fa-sitemap"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-umbrella"><i class="fa fa-umbrella"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-clipboard"><i class="fa fa-clipboard"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-lightbulb-o"><i class="fa fa-lightbulb-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-exchange"><i class="fa fa-exchange"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-cloud-download"><i class="fa fa-cloud-download"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-cloud-upload"><i class="fa fa-cloud-upload"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-user-md"><i class="fa fa-user-md"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-stethoscope"><i class="fa fa-stethoscope"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-suitcase"><i class="fa fa-suitcase"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-bell-o"><i class="fa fa-bell-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-coffee"><i class="fa fa-coffee"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-cutlery"><i class="fa fa-cutlery"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-file-text-o"><i class="fa fa-file-text-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-building-o"><i class="fa fa-building-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-hospital-o"><i class="fa fa-hospital-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-ambulance"><i class="fa fa-ambulance"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-medkit"><i class="fa fa-medkit"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-fighter-jet"><i class="fa fa-fighter-jet"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-beer"><i class="fa fa-beer"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-h-square"><i class="fa fa-h-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-plus-square"><i class="fa fa-plus-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-angle-double-left"><i class="fa fa-angle-double-left"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-angle-double-right"><i class="fa fa-angle-double-right"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-angle-double-up"><i class="fa fa-angle-double-up"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-angle-double-down"><i class="fa fa-angle-double-down"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-angle-left"><i class="fa fa-angle-left"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-angle-right"><i class="fa fa-angle-right"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-angle-up"><i class="fa fa-angle-up"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-angle-down"><i class="fa fa-angle-down"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-desktop"><i class="fa fa-desktop"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-laptop"><i class="fa fa-laptop"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-tablet"><i class="fa fa-tablet"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-mobile"><i class="fa fa-mobile"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-circle-o"><i class="fa fa-circle-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-quote-left"><i class="fa fa-quote-left"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-quote-right"><i class="fa fa-quote-right"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-spinner"><i class="fa fa-spinner"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-circle"><i class="fa fa-circle"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-reply"><i class="fa fa-reply"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-github-alt"><i class="fa fa-github-alt"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-folder-o"><i class="fa fa-folder-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-folder-open-o"><i class="fa fa-folder-open-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-smile-o"><i class="fa fa-smile-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-frown-o"><i class="fa fa-frown-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-meh-o"><i class="fa fa-meh-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-gamepad"><i class="fa fa-gamepad"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-keyboard-o"><i class="fa fa-keyboard-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-flag-o"><i class="fa fa-flag-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-flag-checkered"><i class="fa fa-flag-checkered"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-terminal"><i class="fa fa-terminal"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-code"><i class="fa fa-code"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-reply-all"><i class="fa fa-reply-all"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-star-half-o"><i class="fa fa-star-half-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-location-arrow"><i class="fa fa-location-arrow"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-crop"><i class="fa fa-crop"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-code-fork"><i class="fa fa-code-fork"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-chain-broken"><i class="fa fa-chain-broken"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-question"><i class="fa fa-question"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-info"><i class="fa fa-info"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-exclamation"><i class="fa fa-exclamation"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-superscript"><i class="fa fa-superscript"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-subscript"><i class="fa fa-subscript"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-eraser"><i class="fa fa-eraser"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-puzzle-piece"><i class="fa fa-puzzle-piece"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-microphone"><i class="fa fa-microphone"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-microphone-slash"><i class="fa fa-microphone-slash"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-shield"><i class="fa fa-shield"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-calendar-o"><i class="fa fa-calendar-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-fire-extinguisher"><i class="fa fa-fire-extinguisher"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-rocket"><i class="fa fa-rocket"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-maxcdn"><i class="fa fa-maxcdn"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-chevron-circle-left"><i class="fa fa-chevron-circle-left"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-chevron-circle-right"><i class="fa fa-chevron-circle-right"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-chevron-circle-up"><i class="fa fa-chevron-circle-up"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-chevron-circle-down"><i class="fa fa-chevron-circle-down"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-html5"><i class="fa fa-html5"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-css3"><i class="fa fa-css3"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-anchor"><i class="fa fa-anchor"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-unlock-alt"><i class="fa fa-unlock-alt"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-bullseye"><i class="fa fa-bullseye"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-ellipsis-h"><i class="fa fa-ellipsis-h"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-ellipsis-v"><i class="fa fa-ellipsis-v"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-rss-square"><i class="fa fa-rss-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-play-circle"><i class="fa fa-play-circle"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-ticket"><i class="fa fa-ticket"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-minus-square"><i class="fa fa-minus-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-minus-square-o"><i class="fa fa-minus-square-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-level-up"><i class="fa fa-level-up"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-level-down"><i class="fa fa-level-down"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-check-square"><i class="fa fa-check-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-pencil-square"><i class="fa fa-pencil-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-external-link-square"><i class="fa fa-external-link-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-share-square"><i class="fa fa-share-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-compass"><i class="fa fa-compass"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-caret-square-o-down"><i class="fa fa-caret-square-o-down"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-caret-square-o-up"><i class="fa fa-caret-square-o-up"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-caret-square-o-right"><i class="fa fa-caret-square-o-right"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-eur"><i class="fa fa-eur"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-gbp"><i class="fa fa-gbp"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-usd"><i class="fa fa-usd"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-inr"><i class="fa fa-inr"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-jpy"><i class="fa fa-jpy"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-rub"><i class="fa fa-rub"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-krw"><i class="fa fa-krw"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-btc"><i class="fa fa-btc"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-file"><i class="fa fa-file"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-file-text"><i class="fa fa-file-text"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-sort-alpha-asc"><i class="fa fa-sort-alpha-asc"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-sort-alpha-desc"><i class="fa fa-sort-alpha-desc"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-sort-amount-asc"><i class="fa fa-sort-amount-asc"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-sort-amount-desc"><i class="fa fa-sort-amount-desc"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-sort-numeric-asc"><i class="fa fa-sort-numeric-asc"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-sort-numeric-desc"><i class="fa fa-sort-numeric-desc"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-thumbs-up"><i class="fa fa-thumbs-up"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-thumbs-down"><i class="fa fa-thumbs-down"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-youtube-square"><i class="fa fa-youtube-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-youtube"><i class="fa fa-youtube"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-xing"><i class="fa fa-xing"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-xing-square"><i class="fa fa-xing-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-youtube-play"><i class="fa fa-youtube-play"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-dropbox"><i class="fa fa-dropbox"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-stack-overflow"><i class="fa fa-stack-overflow"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-instagram"><i class="fa fa-instagram"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-flickr"><i class="fa fa-flickr"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-adn"><i class="fa fa-adn"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-bitbucket"><i class="fa fa-bitbucket"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-bitbucket-square"><i class="fa fa-bitbucket-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-tumblr"><i class="fa fa-tumblr"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-tumblr-square"><i class="fa fa-tumblr-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-long-arrow-down"><i class="fa fa-long-arrow-down"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-long-arrow-up"><i class="fa fa-long-arrow-up"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-long-arrow-left"><i class="fa fa-long-arrow-left"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-long-arrow-right"><i class="fa fa-long-arrow-right"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-apple"><i class="fa fa-apple"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-windows"><i class="fa fa-windows"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-android"><i class="fa fa-android"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-linux"><i class="fa fa-linux"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-dribbble"><i class="fa fa-dribbble"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-skype"><i class="fa fa-skype"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-foursquare"><i class="fa fa-foursquare"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-trello"><i class="fa fa-trello"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-female"><i class="fa fa-female"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-male"><i class="fa fa-male"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-gittip"><i class="fa fa-gittip"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-sun-o"><i class="fa fa-sun-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-moon-o"><i class="fa fa-moon-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-archive"><i class="fa fa-archive"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-bug"><i class="fa fa-bug"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-vk"><i class="fa fa-vk"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-weibo"><i class="fa fa-weibo"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-renren"><i class="fa fa-renren"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-pagelines"><i class="fa fa-pagelines"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-stack-exchange"><i class="fa fa-stack-exchange"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-arrow-circle-o-right"><i class="fa fa-arrow-circle-o-right"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-arrow-circle-o-left"><i class="fa fa-arrow-circle-o-left"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-caret-square-o-left"><i class="fa fa-caret-square-o-left"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-dot-circle-o"><i class="fa fa-dot-circle-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-wheelchair"><i class="fa fa-wheelchair"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-vimeo-square"><i class="fa fa-vimeo-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-try"><i class="fa fa-try"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-plus-square-o"><i class="fa fa-plus-square-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-space-shuttle"><i class="fa fa-space-shuttle"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-slack"><i class="fa fa-slack"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-envelope-square"><i class="fa fa-envelope-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-wordpress"><i class="fa fa-wordpress"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-openid"><i class="fa fa-openid"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-university"><i class="fa fa-university"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-graduation-cap"><i class="fa fa-graduation-cap"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-yahoo"><i class="fa fa-yahoo"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-google"><i class="fa fa-google"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-reddit"><i class="fa fa-reddit"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-reddit-square"><i class="fa fa-reddit-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-stumbleupon-circle"><i class="fa fa-stumbleupon-circle"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-stumbleupon"><i class="fa fa-stumbleupon"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-delicious"><i class="fa fa-delicious"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-digg"><i class="fa fa-digg"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-pied-piper"><i class="fa fa-pied-piper"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-pied-piper-alt"><i class="fa fa-pied-piper-alt"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-drupal"><i class="fa fa-drupal"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-joomla"><i class="fa fa-joomla"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-language"><i class="fa fa-language"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-fax"><i class="fa fa-fax"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-building"><i class="fa fa-building"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-child"><i class="fa fa-child"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-paw"><i class="fa fa-paw"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-spoon"><i class="fa fa-spoon"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-cube"><i class="fa fa-cube"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-cubes"><i class="fa fa-cubes"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-behance"><i class="fa fa-behance"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-behance-square"><i class="fa fa-behance-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-steam"><i class="fa fa-steam"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-steam-square"><i class="fa fa-steam-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-recycle"><i class="fa fa-recycle"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-car"><i class="fa fa-car"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-taxi"><i class="fa fa-taxi"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-tree"><i class="fa fa-tree"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-spotify"><i class="fa fa-spotify"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-deviantart"><i class="fa fa-deviantart"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-soundcloud"><i class="fa fa-soundcloud"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-database"><i class="fa fa-database"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-file-pdf-o"><i class="fa fa-file-pdf-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-file-word-o"><i class="fa fa-file-word-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-file-excel-o"><i class="fa fa-file-excel-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-file-powerpoint-o"><i class="fa fa-file-powerpoint-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-file-image-o"><i class="fa fa-file-image-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-file-archive-o"><i class="fa fa-file-archive-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-file-audio-o"><i class="fa fa-file-audio-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-file-video-o"><i class="fa fa-file-video-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-file-code-o"><i class="fa fa-file-code-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-vine"><i class="fa fa-vine"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-codepen"><i class="fa fa-codepen"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-jsfiddle"><i class="fa fa-jsfiddle"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-life-ring"><i class="fa fa-life-ring"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-circle-o-notch"><i class="fa fa-circle-o-notch"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-rebel"><i class="fa fa-rebel"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-empire"><i class="fa fa-empire"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-git-square"><i class="fa fa-git-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-git"><i class="fa fa-git"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-hacker-news"><i class="fa fa-hacker-news"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-tencent-weibo"><i class="fa fa-tencent-weibo"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-qq"><i class="fa fa-qq"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-weixin"><i class="fa fa-weixin"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-paper-plane"><i class="fa fa-paper-plane"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-paper-plane-o"><i class="fa fa-paper-plane-o"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-history"><i class="fa fa-history"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-circle-thin"><i class="fa fa-circle-thin"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-header"><i class="fa fa-header"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-paragraph"><i class="fa fa-paragraph"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-sliders"><i class="fa fa-sliders"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-share-alt"><i class="fa fa-share-alt"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-share-alt-square"><i class="fa fa-share-alt-square"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
									<li class="icon ng-scope" data-icon-class="fa fa-bomb"><i class="fa fa-bomb"></i></li><!-- end ngRepeat: icon in icons | filter:iconSearch -->
								</ul>
							</section>
						</div>
						<div class="hidden" id="link-details">
							<input class="form-control ng-pristine ng-untouched ng-valid" placeholder="Url..." type="text"> <input class="form-control ng-pristine ng-untouched ng-valid" placeholder="Title..." type="text"> <button class="btn btn-success" disabled="disabled" id="wrap-with-link" type="button">Go</button>
						</div>
						<div class="ui-selectmenu-menu ui-front">
							<ul aria-hidden="true" aria-labelledby="toolbar-size-button" class="ui-menu ui-widget ui-widget-content ui-corner-bottom" id="toolbar-size-menu" role="listbox" tabindex="0"></ul>
						</div>
						<div class="ui-selectmenu-menu ui-front">
							<ul aria-hidden="true" aria-labelledby="toolbar-font-button" class="ui-menu ui-widget ui-widget-content ui-corner-bottom" id="toolbar-font-menu" role="listbox" tabindex="0"></ul>
						</div>
					</div>
				</section><iframe class="full-width" frameborder="0" id="iframe" name="iframe" src="about:blank"></iframe>
				<div class="hidden" id="frame-overlay"></div>
				<div class="hidden" id="theme-loading">
					<span class="ng-binding">Loading......</span>
				</div>
			</div>
		</div>
		<div class="ng-scope ui-draggable ui-resizable" id="code-editor-wrapper">
			<div class="clearfix ui-draggable-handle" id="editor-header">
				<div class="pull-left">
					<select class="pretty-select ng-pristine ng-untouched ng-valid">
						<option label="chrome" value="string:chrome">
							chrome
						</option>
						<option label="clouds" value="string:clouds">
							clouds
						</option>
						<option label="crimson_editor" value="string:crimson_editor">
							crimson_editor
						</option>
						<option label="tomorrow_night" selected="selected" value="string:tomorrow_night">
							tomorrow_night
						</option>
						<option label="dawn" value="string:dawn">
							dawn
						</option>
						<option label="dreamweaver" value="string:dreamweaver">
							dreamweaver
						</option>
						<option label="eclipse" value="string:eclipse">
							eclipse
						</option>
						<option label="github" value="string:github">
							github
						</option>
						<option label="solarized_light" value="string:solarized_light">
							solarized_light
						</option>
						<option label="textmate" value="string:textmate">
							textmate
						</option>
						<option label="tomorrow" value="string:tomorrow">
							tomorrow
						</option>
						<option label="xcode" value="string:xcode">
							xcode
						</option>
						<option label="kuroir" value="string:kuroir">
							kuroir
						</option>
						<option label="katzen_milch" value="string:katzen_milch">
							katzen_milch
						</option>
						<option label="ambiance" value="string:ambiance">
							ambiance
						</option>
						<option label="chaos" value="string:chaos">
							chaos
						</option>
						<option label="clouds_midnight" value="string:clouds_midnight">
							clouds_midnight
						</option>
						<option label="cobalt" value="string:cobalt">
							cobalt
						</option>
						<option label="idle_fingers" value="string:idle_fingers">
							idle_fingers
						</option>
						<option label="kr_theme" value="string:kr_theme">
							kr_theme
						</option>
						<option label="merbivore" value="string:merbivore">
							merbivore
						</option>
						<option label="merbivore_soft" value="string:merbivore_soft">
							merbivore_soft
						</option>
						<option label="mono_industrial" value="string:mono_industrial">
							mono_industrial
						</option>
						<option label="monokai" value="string:monokai">
							monokai
						</option>
						<option label="pastel_on_dark" value="string:pastel_on_dark">
							pastel_on_dark
						</option>
						<option label="solarized_light" value="string:solarized_light">
							solarized_light
						</option>
						<option label="terminal" value="string:terminal">
							terminal
						</option>
						<option label="tomorrow_night_blue" value="string:tomorrow_night_blue">
							tomorrow_night_blue
						</option>
						<option label="tomorrow_night_bright" value="string:tomorrow_night_bright">
							tomorrow_night_bright
						</option>
						<option label="tomorrow_night_80s" value="string:tomorrow_night_80s">
							tomorrow_night_80s
						</option>
						<option label="twilight" value="string:twilight">
							twilight
						</option>
						<option label="vibrant_ink" value="string:vibrant_ink">
							vibrant_ink
						</option>
					</select>
				</div>
				<div class="pull-right" id="editor-icons">
					<button class="btn btn-success btn-sm ng-binding" type="button">HTML</button> <button class="btn btn-success btn-sm ng-binding" type="button">CSS</button> <button class="btn btn-success btn-sm ng-binding" type="button">JS</button> <button class="btn btn-sm with-icon expand-editor"><i class="icon icon-resize-full-alt"></i></button> <button class="btn btn-sm with-icon close-editor"><i class="icon icon-cancel"></i></button>
				</div>
			</div>
			<div class="code-editor ace_editor ace-tomorrow-night ace_dark" id="html-code-editor">
				<textarea class="ace_text-input" spellcheck="false" style="opacity: 0;" wrap="off"></textarea>
				<div class="ace_gutter">
					<div class="ace_layer ace_gutter-layer ace_folding-enabled"></div>
					<div class="ace_gutter-active-line"></div>
				</div>
				<div class="ace_scroller">
					<div class="ace_content">
						<div class="ace_layer ace_print-margin-layer">
							<div class="ace_print-margin" style="left: 4px; visibility: visible;"></div>
						</div>
						<div class="ace_layer ace_marker-layer"></div>
						<div class="ace_layer ace_text-layer" style="padding: 0px 4px;"></div>
						<div class="ace_layer ace_marker-layer"></div>
						<div class="ace_layer ace_cursor-layer ace_hidden-cursors">
							<div class="ace_cursor"></div>
						</div>
					</div>
				</div>
				<div class="ace_scrollbar ace_scrollbar-v" style="display: none; width: 22px;">
					<div class="ace_scrollbar-inner" style="width: 22px;"></div>
				</div>
				<div class="ace_scrollbar ace_scrollbar-h" style="display: none; height: 22px;">
					<div class="ace_scrollbar-inner" style="height: 22px;"></div>
				</div>
				<div style="height: auto; width: auto; top: -100px; left: -100px; visibility: hidden; position: fixed; white-space: pre; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; overflow: hidden;">
					<div style="height: auto; width: auto; top: -100px; left: -100px; visibility: hidden; position: fixed; white-space: pre; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; overflow: visible;"></div>
					<div style="height: auto; width: auto; top: -100px; left: -100px; visibility: hidden; position: fixed; white-space: pre; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; overflow: visible;">
						X
					</div>
				</div>
			</div>
			<div class="code-editor hidden ace_editor ace-tomorrow-night ace_dark" id="css-code-editor">
				<textarea class="ace_text-input" spellcheck="false" style="opacity: 0;" wrap="off"></textarea>
				<div class="ace_gutter">
					<div class="ace_layer ace_gutter-layer ace_folding-enabled"></div>
					<div class="ace_gutter-active-line"></div>
				</div>
				<div class="ace_scroller">
					<div class="ace_content">
						<div class="ace_layer ace_print-margin-layer">
							<div class="ace_print-margin" style="left: 4px; visibility: visible;"></div>
						</div>
						<div class="ace_layer ace_marker-layer"></div>
						<div class="ace_layer ace_text-layer" style="padding: 0px 4px;"></div>
						<div class="ace_layer ace_marker-layer"></div>
						<div class="ace_layer ace_cursor-layer ace_hidden-cursors">
							<div class="ace_cursor"></div>
						</div>
					</div>
				</div>
				<div class="ace_scrollbar ace_scrollbar-v" style="display: none; width: 22px;">
					<div class="ace_scrollbar-inner" style="width: 22px;"></div>
				</div>
				<div class="ace_scrollbar ace_scrollbar-h" style="display: none; height: 22px;">
					<div class="ace_scrollbar-inner" style="height: 22px;"></div>
				</div>
				<div style="height: auto; width: auto; top: -100px; left: -100px; visibility: hidden; position: fixed; white-space: pre; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; overflow: hidden;">
					<div style="height: auto; width: auto; top: -100px; left: -100px; visibility: hidden; position: fixed; white-space: pre; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; overflow: visible;"></div>
					<div style="height: auto; width: auto; top: -100px; left: -100px; visibility: hidden; position: fixed; white-space: pre; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; overflow: visible;">
						X
					</div>
				</div>
			</div>
			<div class="code-editor hidden clearfix" id="js-code-editor">
				<div class="editor-column ace_editor ace-tomorrow-night ace_dark" id="jscript-code-editor">
					<textarea class="ace_text-input" spellcheck="false" style="opacity: 0;" wrap="off"></textarea>
					<div class="ace_gutter">
						<div class="ace_layer ace_gutter-layer ace_folding-enabled"></div>
						<div class="ace_gutter-active-line"></div>
					</div>
					<div class="ace_scroller">
						<div class="ace_content">
							<div class="ace_layer ace_print-margin-layer">
								<div class="ace_print-margin" style="left: 4px; visibility: visible;"></div>
							</div>
							<div class="ace_layer ace_marker-layer"></div>
							<div class="ace_layer ace_text-layer" style="padding: 0px 4px;"></div>
							<div class="ace_layer ace_marker-layer"></div>
							<div class="ace_layer ace_cursor-layer ace_hidden-cursors">
								<div class="ace_cursor"></div>
							</div>
						</div>
					</div>
					<div class="ace_scrollbar ace_scrollbar-v" style="display: none; width: 22px;">
						<div class="ace_scrollbar-inner" style="width: 22px;"></div>
					</div>
					<div class="ace_scrollbar ace_scrollbar-h" style="display: none; height: 22px;">
						<div class="ace_scrollbar-inner" style="height: 22px;"></div>
					</div>
					<div style="height: auto; width: auto; top: -100px; left: -100px; visibility: hidden; position: fixed; white-space: pre; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; overflow: hidden;">
						<div style="height: auto; width: auto; top: -100px; left: -100px; visibility: hidden; position: fixed; white-space: pre; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; overflow: visible;"></div>
						<div style="height: auto; width: auto; top: -100px; left: -100px; visibility: hidden; position: fixed; white-space: pre; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; overflow: visible;">
							X
						</div>
					</div>
				</div>
				<div class="modal fade" id="new-library-modal">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button class="close pull-right" data-dismiss="modal" type="button"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
								<h4 class="modal-titlet ng-binding">Create new library</h4>
							</div>
							<div class="modal-body">
								<div class="form-group">
									<label class="ng-binding" for="name">Library Name</label> <input class="form-control ng-pristine ng-untouched ng-valid" name="name" type="text">
								</div>
								<div class="form-group">
									<label class="ng-binding" for="path">Library Path</label> <input class="form-control ng-pristine ng-untouched ng-valid" name="path" type="text">
									<p class="help-block ng-binding">Path to a library file, either a cdn on internet or local (relative to root folder)</p>
								</div>
								<p class="text-danger ng-binding"></p>
							</div>
							<div class="modal-footer">
								<button class="btn btn-danger close-modal ng-binding">Close</button> <button class="btn btn-success float-right save-library ng-binding">Save & Close</button>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div>
			<div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div>
			<div class="ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se" style="z-index: 90;"></div>
		</div>
		<div id="code-editor-resize-overlay"></div>
		<div class="modal fade" id="fonts-modal">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header clearfix">
						<div class="close-modal" data-dismiss="modal" title="Close Modal">
							<i class="icon icon-cancel-circled"></i>
						</div>
						<h4 class="modal-title pull-left ng-binding">Select one of 846 google fonts</h4>
						<div class="pagi-container pull-right">
							<ul class="pagination dark-theme simple-pagination">
								<li class="active"><span class="current prev">Prev</span></li>
								<li class="active"><span class="current">1</span></li>
								<li>
									<a class="page-link" href="#page-2">2</a>
								</li>
								<li>
									<a class="page-link" href="#page-3">3</a>
								</li>
								<li>
									<a class="page-link" href="#page-4">4</a>
								</li>
								<li>
									<a class="page-link" href="#page-5">5</a>
								</li>
								<li class="disabled"><span class="ellipse">…</span></li>
								<li>
									<a class="page-link" href="#page-70">70</a>
								</li>
								<li>
									<a class="page-link" href="#page-71">71</a>
								</li>
								<li>
									<a class="page-link next" href="#page-2">Next</a>
								</li>
							</ul>
						</div>
					</div>
					<div class="modal-body">
						<ul class="fonts-list">
							<!-- ngRepeat: font in fonts.paginator.currentItems -->
							<li class="ng-scope" style="font-family: Roboto;">
								<div class="font-preview ng-binding">
									Grumpy wizards make toxic brew for the evil Queen and Jack.
								</div>
								<div class="font-details clearfix">
									<div class="pull-left ng-binding">
										Roboto, sans-serif
									</div>
								</div>
							</li><!-- end ngRepeat: font in fonts.paginator.currentItems -->
							<li class="ng-scope" style="font-family: Open Sans">
								<div class="font-preview ng-binding">
									Grumpy wizards make toxic brew for the evil Queen and Jack.
								</div>
								<div class="font-details clearfix">
									<div class="pull-left ng-binding">
										Open Sans, sans-serif
									</div>
								</div>
							</li><!-- end ngRepeat: font in fonts.paginator.currentItems -->
							<li class="ng-scope" style="font-family: Lato">
								<div class="font-preview ng-binding">
									Grumpy wizards make toxic brew for the evil Queen and Jack.
								</div>
								<div class="font-details clearfix">
									<div class="pull-left ng-binding">
										Lato, sans-serif
									</div>
								</div>
							</li><!-- end ngRepeat: font in fonts.paginator.currentItems -->
							<li class="ng-scope" style="font-family: Slabo 27px">
								<div class="font-preview ng-binding">
									Grumpy wizards make toxic brew for the evil Queen and Jack.
								</div>
								<div class="font-details clearfix">
									<div class="pull-left ng-binding">
										Slabo 27px, serif
									</div>
								</div>
							</li><!-- end ngRepeat: font in fonts.paginator.currentItems -->
							<li class="ng-scope" style="font-family: Roboto Condensed">
								<div class="font-preview ng-binding">
									Grumpy wizards make toxic brew for the evil Queen and Jack.
								</div>
								<div class="font-details clearfix">
									<div class="pull-left ng-binding">
										Roboto Condensed, sans-serif
									</div>
								</div>
							</li><!-- end ngRepeat: font in fonts.paginator.currentItems -->
							<li class="ng-scope" style="font-family: Oswald">
								<div class="font-preview ng-binding">
									Grumpy wizards make toxic brew for the evil Queen and Jack.
								</div>
								<div class="font-details clearfix">
									<div class="pull-left ng-binding">
										Oswald, sans-serif
									</div>
								</div>
							</li><!-- end ngRepeat: font in fonts.paginator.currentItems -->
							<li class="ng-scope" style="font-family: Montserrat">
								<div class="font-preview ng-binding">
									Grumpy wizards make toxic brew for the evil Queen and Jack.
								</div>
								<div class="font-details clearfix">
									<div class="pull-left ng-binding">
										Montserrat, sans-serif
									</div>
								</div>
							</li><!-- end ngRepeat: font in fonts.paginator.currentItems -->
							<li class="ng-scope" style="font-family: Source Sans Pro">
								<div class="font-preview ng-binding">
									Grumpy wizards make toxic brew for the evil Queen and Jack.
								</div>
								<div class="font-details clearfix">
									<div class="pull-left ng-binding">
										Source Sans Pro, sans-serif
									</div>
								</div>
							</li><!-- end ngRepeat: font in fonts.paginator.currentItems -->
							<li class="ng-scope" style="font-family: Raleway">
								<div class="font-preview ng-binding">
									Grumpy wizards make toxic brew for the evil Queen and Jack.
								</div>
								<div class="font-details clearfix">
									<div class="pull-left ng-binding">
										Raleway, sans-serif
									</div>
								</div>
							</li><!-- end ngRepeat: font in fonts.paginator.currentItems -->
							<li class="ng-scope" style="font-family: PT Sans">
								<div class="font-preview ng-binding">
									Grumpy wizards make toxic brew for the evil Queen and Jack.
								</div>
								<div class="font-details clearfix">
									<div class="pull-left ng-binding">
										PT Sans, sans-serif
									</div>
								</div>
							</li><!-- end ngRepeat: font in fonts.paginator.currentItems -->
							<li class="ng-scope" style="font-family: Roboto Slab">
								<div class="font-preview ng-binding">
									Grumpy wizards make toxic brew for the evil Queen and Jack.
								</div>
								<div class="font-details clearfix">
									<div class="pull-left ng-binding">
										Roboto Slab, serif
									</div>
								</div>
							</li><!-- end ngRepeat: font in fonts.paginator.currentItems -->
							<li class="ng-scope" style="font-family: Merriweather">
								<div class="font-preview ng-binding">
									Grumpy wizards make toxic brew for the evil Queen and Jack.
								</div>
								<div class="font-details clearfix">
									<div class="pull-left ng-binding">
										Merriweather, serif
									</div>
								</div>
							</li><!-- end ngRepeat: font in fonts.paginator.currentItems -->
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
<div id="preview-closer" class="hidden" ng-click="closePreview()">
            <i class="icon icon-cancel"></i>
        </div>
<div class="modal fade" id="publish-modal">
		<div class="modal-dialog">
			<div class="modal-content demo">
				<div class="modal-header">
					<button class="close pull-right" data-dismiss="modal" type="button"><span aria-hidden="true">×</span><span class="sr-only ng-binding">Close</span></button>
					<h4 class="modal-title ng-binding">Publish project to remote FTP server.</h4>
				</div>
				<div class="modal-body">
					<!-- ngIf: isDemo -->
					<div class="alert alert-info demo-alert ng-scope">
						Publishing to remote ftp is disabled on demo site. Normally you would be able to enter your credentials and export the entire project with a single 'publish' click below.
					</div><!-- end ngIf: isDemo -->
					<!-- ngIf: !userCan('publish') && ! isDemo -->
					<div class="form-group">
						<label class="ng-binding" for="host">Host</label> <input class="form-control ng-pristine ng-untouched ng-valid" type="text">
					</div>
					<div class="form-group">
						<label class="ng-binding" for="username">Username</label> <input class="form-control ng-pristine ng-untouched ng-valid" type="text">
					</div>
					<div class="form-group">
						<label class="ng-binding" for="password">Password</label> <input class="form-control ng-pristine ng-untouched ng-valid" type="password">
					</div>
					<div class="form-group">
						<label class="ng-binding" for="folder">Folder</label> <input class="form-control ng-pristine ng-untouched ng-valid" type="text">
					</div>
					<div class="row">
						<div class="form-group col-sm-4 pull-left">
							<label class="ng-binding" for="port">Port</label> <input class="form-control ng-pristine ng-untouched ng-valid" type="text">
						</div>
						<div class="form-group col-sm-2 pull-right">
							<div class="checkbox">
								<label class="ng-binding"><input class="ng-pristine ng-untouched ng-valid" type="checkbox"> SSL</label>
							</div>
						</div>
					</div>
					<div class="alert alert-danger error"></div>
				</div>
				<div class="modal-footer">
					<button class="btn btn-danger close-modal ng-binding">Close</button> <button class="btn btn-success publish ng-binding" disabled="disabled">Publish</button>
				</div>
				<div class="loader">
					<div class="inner">
						<i class="fa fa-spinner fa-spin"></i>
						<div class="text ng-binding">
							Publishing...
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<!-- end -->
</div>

</body></html>