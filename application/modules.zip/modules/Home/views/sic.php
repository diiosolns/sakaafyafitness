<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Access extends MX_Controller
{

function __construct() {
parent::__construct();
		$this->load->helper('date');
		$this->load->helper('download');
		$this->load->helper('text');
		//modules
		$this->load->module('Home');
		$this->load->module('Users');
		$this->load->module('Admin');
		$this->load->module('Fuel');
		$this->load->module('Site');
		$this->load->module('Luku');
		$this->load->module('Access');
		$this->load->module('Genservice');
		$this->load->module('Pm');
}



function index(){
	$data['login_msg'] = "";
	$this->load->view('Home/login',$data);
}


function newAccessRequest(){
	# code...
	$pmreqBtn = $this->input->post('pmreqBtn', true);
	$gsreqBtn = $this->input->post('gsreqBtn', true);
	$rfreqBtn = $this->input->post('gsreqBtn', true);
	$openpmBtn = $this->input->post('openpmBtn', true);
	$opengsBtn = $this->input->post('opengsBtn', true);
	$openrfBtn = $this->input->post('openrfBtn', true);
	$editBtn = $this->input->post('editBtn', true);
	$deleteBtn = $this->input->post('deleteBtn', true);
	$today = mdate('%Y-%m-%d');

	
	if (!$pmreqBtn  == "") {
		# code...
		$siteid = $this->input->post('siteid', true);
		$siteInfo = $this->site->get_where_custom_tb('site', 'site_id', $siteid);
		if ($siteInfo->num_rows() > 0) {
			# code... calculate access code
			$access_code_res = $this->get_tb('accesscode', 'idnumber');
			$access_code = $access_code_res->row()->accessCode_number + 1;
			$cdata['accessCode_number'] = $access_code;
			$this->_update2('accesscode', '	idnumber', 	$access_code_res->row()->idnumber, $cdata);

			//prepare data and update accesscpdeall_pm table
			$pmdata['accessCode'] = "NTT40000-".str_pad( "$access_code", 6, "0", STR_PAD_LEFT );
			$pmdata['site_id'] = $siteInfo->row()->site_id;
			$pmdata['user_id'] = $this->session->userdata('user_id');
			$pmdata['log_in_time'] = mdate('%Y-%m-%d %H:%i:%s');
			$pmdata['date'] = mdate('%Y-%m-%d');
			$pmdata['status'] = "Open";
			$pmdata['cotegory'] = $this->input->post('category', true);
			$pmdata['element'] = $this->input->post('element', true);
			$pmdata['sub_element'] = $this->input->post('subelement', true);
			//$pmdata['cotegory'] = "PM";
			//$pmdata['sub_element'] = "Complete Site";
			$this->_insert_tb('accesscodeall_pm', $pmdata);

			$data['color'] = "blue";
			$data['msg'] = "Access Code => ".$pmdata['accessCode'];

		} else {
			# code...
			$data['msg'] = "SORRY.! Site not Found. Confirm Your Site ID and Try Again.";
			$data['color'] = "red";
		}
		
		//read data from db
		$data['pmres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['gsres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['pmDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);
		$data['gsDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);


		$data['middle_m']="Access";
		$data['middle_f']="newAccessRequest";
		

	} else if (!$gsreqBtn  == "") {
		# code...
		$siteid = $this->input->post('siteid', true);
		$siteInfo = $this->site->get_where_custom_tb('site', 'site_id', $siteid);
		if ($siteInfo->num_rows() > 0) {
			# code... calculate access code
			$access_code_res = $this->get_tb('accesscode', 'idnumber');
			$access_code = $access_code_res->row()->accessCode_number + 1;
			$cdata['accessCode_number'] = $access_code;
			$this->_update2('accesscode', 'idnumber', $access_code_res->row()->idnumber, $cdata);

			//prepare data and update accesscpdeall_pm table
			$pmdata['accessCode'] = "NTT40000-".str_pad( "$access_code", 6, "0", STR_PAD_LEFT );
			$pmdata['site_id'] = $siteInfo->row()->site_id;
			$pmdata['user_id'] = $this->session->userdata('user_id');
			$pmdata['log_in_time'] = mdate('%Y-%m-%d %H:%i:%s');
			$pmdata['date'] = mdate('%Y-%m-%d');
			$pmdata['status'] = "Open";
			$pmdata['cotegory'] = $this->input->post('category', true);
			$pmdata['element'] = $this->input->post('element', true);
			$pmdata['sub_element'] = $this->input->post('subelement', true);
			//$pmdata['cotegory'] = "GS";
			//$pmdata['sub_element'] = "Generator Service";
			$this->_insert_tb('accesscodeall_pm', $pmdata);

			$data['color'] = "blue";
			$data['msg'] = "Access Code => ".$pmdata['accessCode'];

		} else  {
			# code...
			$data['msg'] = "SORRY.! Site not Found. Confirm Your Site ID and Try Again.";
			$data['color'] = "red";
		}
		
		//read data from db
		$data['pmres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['gsres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['pmDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);
		$data['gsDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);


		$data['middle_m']="Access";
		$data['middle_f']="newAccessRequest";

	} else if (!$rfreqBtn  == "") {
		# code...
		$siteid = $this->input->post('siteid', true);
		$siteInfo = $this->site->get_where_custom_tb('site', 'site_id', $siteid);
		if ($siteInfo->num_rows() > 0) {
			# code... calculate access code
			$access_code_res = $this->get_tb('accesscode', 'idnumber');
			$access_code = $access_code_res->row()->accessCode_number + 1;
			$cdata['accessCode_number'] = $access_code;
			$this->_update2('accesscode', 'idnumber', $access_code_res->row()->idnumber, $cdata);

			//prepare data and update accesscpdeall_pm table
			$pmdata['accessCode'] = "NTT40000-".str_pad( "$access_code", 6, "0", STR_PAD_LEFT );
			$pmdata['site_id'] = $siteInfo->row()->site_id;
			$pmdata['user_id'] = $this->session->userdata('user_id');
			$pmdata['log_in_time'] = mdate('%Y-%m-%d %H:%i:%s');
			$pmdata['date'] = mdate('%Y-%m-%d');
			$pmdata['status'] = "Open";
			$pmdata['cotegory'] = $this->input->post('category', true);
			$pmdata['element'] = $this->input->post('element', true);
			$pmdata['sub_element'] = $this->input->post('subelement', true);
			//$pmdata['cotegory'] = "REFUELING";
			//$pmdata['sub_element'] = "Refueling";
			$this->_insert_tb('accesscodeall_pm', $pmdata);

			$data['color'] = "blue";
			$data['msg'] = "Access Code => ".$pmdata['accessCode'];

		} else  {
			# code...
			$data['msg'] = "SORRY.! Site not Found. Confirm Your Site ID and Try Again.";
			$data['color'] = "red";
		}
		
		//read data from db
		$data['pmres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['gsres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['pmDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);
		$data['gsDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);


		$data['middle_m']="Access";
		$data['middle_f']="newAccessRequest";

	} else if (!$openpmBtn  == "") {
		$accesscode = $openpmBtn;
		$data['pmres'] = $this->get_where_custom_tb('accesscodeall_pm', 'accessCode', $accesscode );
		$this->session->set_userdata('accesscode', $accesscode);
		
		$data['middle_m']="Access";
		/*$data['middle_f']="pmAccessUpdater";*/
		$data['middle_f']="accessUpdator";
		$data['msg'] = "";
		$data['color'] = "blue";

	} else if (!$opengsBtn  == "") {
		$accesscode = $opengsBtn;
		$data['gsres'] = $this->get_where_custom_tb('accesscodeall_pm', 'accessCode', $accesscode );
		$this->session->set_userdata('accesscode', $accesscode);

		$data['middle_m']="Access";
		$data['middle_f']="gsAccessUpdater";
		$data['msg'] = "";
		$data['color'] = "blue";


	} else if (!$openrfBtn  == "") {
		$accesscode = $openrfBtn;
		$data['gsres'] = $this->get_where_custom_tb('accesscodeall_pm', 'accessCode', $accesscode );
		$this->session->set_userdata('accesscode', $accesscode);

		$data['middle_m']="Access";
		$data['middle_f']="rfAccessUpdater";
		$data['msg'] = "";
		$data['color'] = "blue";


	} else if (!$editBtn  == "") {
		$accesscode = $editBtn;
		$data['requestres'] = $this->get_where_custom_tb('accesscodeall_pm', 'accessCode', $accesscode );
		$this->session->set_userdata('accesscode', $accesscode);

		//call require data
		$data['pmres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['gsres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['pmDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);
		$data['gsDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);

		//call edit form
		$data['middle_m']="Access";
		$data['middle_f']="newAccessRequest";
		$data['msg'] = "";
		$data['color'] = "blue";


	}else if (!$deleteBtn  == "") {
		$accesscode = $deleteBtn;
		//delete request
		$this->_delete_tb('accesscodeall_pm',  $accesscode );

		//call require data
		$data['pmres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['gsres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['pmDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);
		$data['gsDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);

		$data['middle_m']="Access";
		$data['middle_f']="newAccessRequest";
		$data['msg'] = "";
		$data['color'] = "blue";


	} else {
		$data['pmres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['gsres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['pmDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);
		$data['gsDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);

		$data['middle_m']="Access";
		$data['middle_f']="newAccessRequest";
		$data['msg'] = "";
		$data['color'] = "blue";

	}
	
	

	if ($this->session->userdata('logged_in')) {
		if ($this->session->userdata('user_role') == "admin") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "office") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "fs") { $this->load->view('Home/index',$data); } else if ($this->session->userdata('user_role') == "ft") { $this->load->view('Home/index',$data); } else { $this->load->view('Home/index',$data); }
	} else {
		$this->load->view('Home/loginerr',$data);
	}

	

}


function accessRequestUpdator($value='') {
	$today = mdate('%Y-%m-%d');
	# code...
	$pmupdateBtn = $this->input->post('pmupdateBtn', true);
	$gsupdateBtn = $this->input->post('gsupdateBtn', true);

	if (!$pmupdateBtn == "") {
		# code...
		$accesscode = $this->session->userdata('accesscode');

		//prepare data and update  pm request
		/*$pmdata['cotegory'] = $this->input->post('category', true);
		$pmdata['element'] = $this->input->post('element', true);
		$pmdata['sub_element'] = $this->input->post('subelement', true);*/
		$pmdata['dg_fuel'] = $this->input->post('dgfuel', true);
		$pmdata['hybridtype'] = $this->input->post('hybridtype', true);
		$pmdata['hybridstatus'] = $this->input->post('hybridstatus', true);
		$pmdata['generatorlowfuel'] = $this->input->post('generatorlowfuel', true);
		$pmdata['generatorrunng'] = $this->input->post('generatorrunng', true);
		$pmdata['luku_Balance'] = $this->input->post('luku_Balance', true);
		$pmdata['dgRunHour'] = $this->input->post('dgrunhrs', true);
		$pmdata['mainspowerfrailer'] = $this->input->post('mainspowerfrailer', true);
		$pmdata['batterydischarge'] = $this->input->post('batterydischarge', true);
		$pmdata['hightemperature'] = $this->input->post('hightemperature', true);
		$pmdata['commondgalarm'] = $this->input->post('commondgalarm', true);
		$pmdata['remarks'] = $this->input->post('remarks', true);
		$pmdata['log_out_time'] = mdate("%Y-%m-%d %H:%i:%s");
		$pmdata['closingAgent'] = $this->session->userdata('user_name');
		$pmdata['lotitude'] = "";
		$pmdata['longitude'] = "";
		$pmdata['type'] = "PASSIVE";
		$pmdata['status'] = "Closed";
        $pmdata['rectifierType'] = $this->input->post('rectifierType', true);
		$pmdata['moduleNo'] = $this->input->post('moduleNo', true);
		$pmdata['noWorking'] = $this->input->post('noWOrking', true);
		$pmdata['notWorking'] = $this->input->post('notWorking', true);
		$pmdata['loadCurrent'] = $this->input->post('loadCurrent', true);
		$pmdata['powerConfiguration'] = $this->input->post('powerConfiguration', true);
		$pmdata['shelterStatus'] = $this->input->post('shelterStatus', true);
		$this->_update2('accesscodeall_pm', 'accessCode', $accesscode, $pmdata);
		
		//read access records
		$data['pmres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['gsres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['pmDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);
		$data['gsDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);

		$data['middle_m']="Access";
		$data['middle_f']="newAccessRequest";
		$data['msg'] = "INFO.! Access Request has Been Closed successifully.";
		$data['color'] = "blue";

	} else if (!$gsupdateBtn == "") {
		# code...
		$accesscode = $this->session->userdata('accesscode');

		//prepare data and update  pm request
		/*$gsdata['cotegory'] = $this->input->post('category', true);
		$gsdata['element'] = $this->input->post('element', true);
		$gsdata['sub_element'] = $this->input->post('subelement', true);*/
		$gsdata['dg_fuel'] = $this->input->post('dgfuel', true);
		$gsdata['hybridtype'] = $this->input->post('hybridtype', true);
		$gsdata['hybridstatus'] = $this->input->post('hybridstatus', true);
		$gsdata['luku_Balance'] = $this->input->post('lukubalance', true);
		$gsdata['dgRunHour'] = $this->input->post('dgrunhrs', true);
		$pmdata['mainspowerfrailer'] = $this->input->post('mainspowerfrailer', true);
		$pmdata['batterydischarge'] = $this->input->post('batterydischarge', true);
		$pmdata['hightemperature'] = $this->input->post('hightemperature', true);
		$pmdata['commondgalarm'] = $this->input->post('commondgalarm', true);
		$gsdata['remarks'] = $this->input->post('remarks', true);
		$gsdata['log_out_time'] = mdate("%Y-%m-%d %H:%i:%s");
		$gsdata['closingAgent'] = $this->session->userdata('user_name');
		$gsdata['lotitude'] = "";
		$gsdata['longitude'] = "";
		$gsdata['type'] = "PASSIVE";
		$gsdata['status'] = "Closed";
		$this->_update2('accesscodeall_pm', 'accessCode', $accesscode, $gsdata);
		

		//read access records
		$data['pmres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['gsres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['pmDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);
		$data['gsDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);

		$data['middle_m']="Access";
		$data['middle_f']="newAccessRequest"; 
		$data['msg'] = "INFO.! Access Request has Been Closed successifully.";
		$data['color'] = "blue";


	} else {
		# code...
		//read access records
		$data['pmres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['gsres'] = $this->get_where_custom_tb('accesscodeall_pm', 'status', "Open");
		$data['pmDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);
		$data['gsDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);

		$data['middle_m']="Access";
		$data['middle_f']="newAccessRequest";
		$data['msg'] = "";
		$data['color'] = "blue";
	}

	if ($this->session->userdata('logged_in')) {
		if ($this->session->userdata('user_role') == "admin") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "office") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "fs") { $this->load->view('Home/index',$data); } else if ($this->session->userdata('user_role') == "ft") { $this->load->view('Home/index',$data); } else { $this->load->view('Home/index',$data); }
	} else {
		$this->load->view('Home/loginerr',$data);
	}
	
}



function filteredAccessRecords() {
	# code...
	$today = mdate('%Y-%m-%d');
	# code...
	$pmFilterBtn = $this->input->post('pmFilterBtn', true);
	$gsFilterBtn = $this->input->post('gsFilterBtn', true);

	//read access records
		$data['pmRes'] = $this->get_tb('accesscodeall_pm', 'accessCode' );
		$data['gsRes'] = $this->get_tb('accesscodeall_pm', 'accessCode' );
		$data['pmDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);
		$data['gsDailyres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);
		$data['pmFilterres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);
		$data['gsFilterres'] = $this->get_where_custom_tb('accesscodeall_pm', 'date', $today);
		//select date
		$data['dateRes'] = $this->get_col_where('accesscodeall_pm', 'date' );

	if (!$pmFilterBtn == "") {
		# code...
		$stdate = $this->input->post('stdate', true);
		$endate = $this->input->post('endate', true);
		$data['pmFilterres'] = $this->get_where_btndates2('accesscodeall_pm', 'date', $stdate, 'date', $endate);


		$data['middle_m']="Access";
		$data['middle_f']="filteredAccessRecords";
		$data['msg'] = "";
		$data['color'] = "blue";

	} else if (!$gsFilterBtn == "") {
		# code...
		$stdate = $this->input->post('stdate', true);
		$endate = $this->input->post('endate', true);
		$data['gsFilterres'] = $this->get_where_btndates2('accesscodeall_pm', 'date', $stdate, 'date', $endate);


		$data['middle_m']="Access";
		$data['middle_f']="filteredAccessRecords";
		$data['msg'] = "";
		$data['color'] = "blue";
	} else {
		# code...

		$data['middle_m']="Access";
		$data['middle_f']="filteredAccessRecords";
		$data['msg'] = "";
		$data['color'] = "blue";
	}
	 

	if ($this->session->userdata('logged_in')) {
		if ($this->session->userdata('user_role') == "admin") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "office") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "fs") { $this->load->view('Home/index',$data); } else if ($this->session->userdata('user_role') == "ft") { $this->load->view('Home/index',$data); } else { $this->load->view('Home/index',$data); }
	} else {
		$this->load->view('Home/loginerr',$data);
	}
}


function accessRequestsDownloader() {
	# code...
	$today = mdate('%Y-%m-%d');
	# code...
	$pmDownBtn= $this->input->post('pmDownBtn', true);
	$gsDownBtn = $this->input->post('gsDownBtn', true);
	$rfDownBtn = $this->input->post('rfDownBtn', true);
	$paDownBtn = $this->input->post('paDownBtn', true);
	//select date
	$data['dateRes'] = $this->get_col_where('accesscodeall_pm', 'date' );

	
	//read access records
		$data['pmRes'] = $this->get_tb('accesscodeall_pm', 'accessCode' );
		$data['gsRes'] = $this->get_tb('accesscodeall_pm', 'accessCode' );

	if (!$pmDownBtn == "") {
		# code...
		$stdate = $this->input->post('stdate', true);
		$endate = $this->input->post('endate', true);
		$pmFilterres = $this->get_where_btndates2('accesscodeall_pm', 'date', $stdate, 'date', $endate);

		//call excel downloader
		$this->downPMExcel($pmFilterres);

		$data['middle_m']="Access";
		$data['middle_f']="accessDownloader";
		$data['msg'] = "";
		$data['color'] = "blue";

	} else if (!$gsDownBtn == "") {
		# code...
		$stdate = $this->input->post('stdate', true);
		$endate = $this->input->post('endate', true);
		$gsFilterres = $this->get_where_btndates2('accesscodeall_pm', 'date', $stdate, 'date', $endate);

		//call excel downloader
		$this->downGSExcel($gsFilterres);


		$data['middle_m']="Access";
		$data['middle_f']="accessDownloader";
		$data['msg'] = "";
		$data['color'] = "blue";

	} else if (!$rfDownBtn == "") {
		# code...
		$stdate = $this->input->post('stdate', true);
		$endate = $this->input->post('endate', true);
		$rfFilterres = $this->get_where_btndates2('accesscodeall_pm', 'date', $stdate, 'date', $endate);

		//call excel downloader
		$this->downGSExcel($rfFilterres);


		$data['middle_m']="Access";
		$data['middle_f']="accessDownloader";
		$data['msg'] = "";
		$data['color'] = "blue";

	} else if (!$paDownBtn == "") {
		# code...
		$stdate = $this->input->post('stdate', true);
		$endate = $this->input->post('endate', true);
		//$paFilterres = $this->get_where_btndates2('table', 'date', $stdate, 'date', $endate);

		//call excel downloader

		$data['middle_m']="Access";
		$data['middle_f']="accessDownloader";
		$data['msg'] = "";
		$data['color'] = "blue";

	} else {
		$data['middle_m']="Access";
		$data['middle_f']="accessDownloader";
		$data['msg'] = "";
		$data['color'] = "blue";
	}


	if ($this->session->userdata('logged_in')) {
		if ($this->session->userdata('user_role') == "admin") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "office") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "fs") { $this->load->view('Home/index',$data); } else if ($this->session->userdata('user_role') == "ft") { $this->load->view('Home/index',$data); } else { $this->load->view('Home/index',$data); }
	} else {
		$this->load->view('Home/loginerr',$data);
	}

}


function newPlannedActivity() {
	# code...
	$today = mdate('%Y-%m-%d');
	# code...
	$paRegBtn = $this->input->post('paRegBtn', true);
	$paCloseBtn = $this->input->post('paCloseBtn', true);
	$paUpdateBtn = $this->input->post('paUpdateBtn', true);
	$openpaBtn = $this->input->post('openpaBtn', true);
	$paUpdateClosureBtn = $this->input->post('paUpdateClosureBtn', true);
	$crViewBtn = $this->input->post('crViewBtn', true);
	$crDownBtn = $this->input->post('crDownBtn', true);
	$paFilterBtn = $this->input->post('paFilterBtn', true);
	
	

	$data['pares'] = $this->get_where_custom_tb('planedactivity', 'status', "Open");;
	$data['paDailyres'] = $this->get_where_custom_tb('planedactivity', 'status', "Open");
	$data['paFilterres'] = $this->get_where_custom_tb('planedactivity', 'status', "Open");
	$data['paDateres'] = $this->get_tb('planedactivity', 'reqdate');
	
	if (!$paRegBtn == "") {
		# code...
		$siteid = $this->input->post('siteid', true);
		$siteInfo = $this->site->get_where_custom_tb('site', 'site_id', $siteid);
		if ($siteInfo->num_rows() > 0) {
			# code... calculate access code
			$access_code_res = $this->get_tb('accesscode', 'idnumber');
			$access_code = $access_code_res->row()->accessCode_number + 1;
			$cdata['accessCode_number'] = $access_code;
			$this->_update2('accesscode', '	idnumber', 	$access_code_res->row()->idnumber, $cdata);

			//prepare data and update accesscpdeall_pm table
			$accessCode = "NTT40000-".str_pad( "$access_code", 6, "0", STR_PAD_LEFT );
			$this->session->set_userdata('refno', $accessCode );

			//prepare data and save to db
			$padata['refno'] = $accessCode;
			$padata['site_id'] = $siteid;
			$padata['user_id'] = $this->session->userdata('user_id');
			$padata['reqdate'] = mdate('%Y-%m-%d %H:%i:%s');

			//read recorded request
			$data['pares'] = $this->get_where_custom_tb('planedactivity', 'refno', $accessCode);
			if ($data['pares']->num_rows() < 1) {
				# code... register
				$this->_insert_tb('planedactivity', $padata);
				$data['pares'] = $this->get_where_custom_tb('planedactivity', 'refno', $accessCode);
				//display
				$data['middle_m']="Access";
				$data['middle_f']="paUpdator";
				$data['msg'] = "";
				$data['color'] = "blue";
			} else {
				# code...
				//display
				$data['middle_m']="Access";
				$data['middle_f']="newPlannedActivity";
				$data['msg'] = "SORRY.! Please Make a New Request";
				$data['color'] = "red";
			}
			

			

		} else {

			//display
			$data['middle_m']="Access";
			$data['middle_f']="newPlannedActivity";
			$data['msg'] = "SORRY.! Site Not Found";
			$data['color'] = "red";

		}

		

	} else if (!$paCloseBtn == "") {
		# code...
		$this->session->set_userdata('refno', $paCloseBtn);
		$refno = $paCloseBtn;

		$data['pares'] = $this->get_where_custom_tb('planedactivity', 'refno', $refno);
		
		//display
		$data['middle_m']="Access";
		$data['middle_f']="paClosure";
		$data['msg'] = "";
		$data['color'] = "blue";
		


	} else if (!$paUpdateClosureBtn == "") {
		# code...
		$refno = $this->session->userdata('refno');
		$padata['failreason'] = $this->input->post('failreason', true);
		$padata['status'] = "Closed";
		//update planned activity
			$this->_update2('planedactivity', 'refno', $refno, $padata);

			//read open activities
			$data['pares'] = $this->get_where_custom_tb('planedactivity', 'status', "Open");;
			$data['paDailyres'] = $this->get_where_custom_tb('planedactivity', 'status', "Open");;
	
		//display
		$data['middle_m']="Access";
		$data['middle_f']="newPlannedActivity";
		$data['msg'] = "Your Activity Has  been Closed successifully";
		$data['color'] = "blue";
		


	} else if (!$paUpdateBtn == "") {
		$today = mdate('%Y-%m-%d %H:%i:%s'); 
		$refno = $this->session->userdata('refno');
		# code... read all form data ,,and store
		$padata['domain'] = $this->input->post('domain', true);
		$padata['reason'] = $this->input->post('reason', true);
		$padata['category'] = $this->input->post('category', true);
		$padata['effecttotraffic'] = $this->input->post('effecttotraffic', true);
		$padata['impact'] = $this->input->post('impact', true);
		$padata['week'] = $this->input->post('week', true);
		$padata['stdate'] = $this->input->post('stdate', true).' '.$this->input->post('sttime', true);
		$padata['endate'] = $this->input->post('endate', true).' '.$this->input->post('entime', true);
		$padata['downtime'] = timespan(strtotime($padata['stdate']),  strtotime($padata['stdate']));
		$padata['requester'] = $this->input->post('requester', true);
		$padata['requesterphone'] = $this->input->post('requesterphone', true);
		$padata['implementer'] = $this->input->post('implementer', true);
		$padata['implementerphone'] = $this->input->post('implementerphone', true);
		//$padata['cravailable'] = $this->input->post('cravailable', true);
		$padata['pt4crno'] = $this->input->post('pt4crno', true);
		//$padata['failreason'] = $this->input->post('failreason', true);
		$padata['work_desc'] = $this->input->post('work_desc', true);
		$padata['fallback_time'] = $this->input->post('fallback_time', true);
		$padata['affected_nodes'] = $this->input->post('affected_nodes', true);
		$padata['affected_customer'] = $this->input->post('affected_customer', true);
		$padata['moniteredby'] = $this->input->post('moniteredby', true);
		$padata['requirements'] = $this->input->post('requirements', true);
		$padata['implement_risk'] = $this->input->post('implement_risk', true);
		$padata['noimplement_risk'] = $this->input->post('noimplement_risk', true);
		$padata['alt_to_change'] = $this->input->post('alt_to_change', true);
		$padata['change_procedures'] = $this->input->post('change_procedures', true);
		$padata['fallback_procedures'] = $this->input->post('fallback_procedures', true);

		//update planned activity
			$this->_update2('planedactivity', 'refno', $refno, $padata);


		//display
		$data['middle_m']="Access";
		$data['middle_f']="newPlannedActivity";
		$data['msg'] = "INFO. Your Activity has Been Registered successifully";
		$data['color'] = "blue";
		


	}  else if (!$openpaBtn == "") {
		# code...
		$refno = $openpaBtn;

		$data['pares'] = $this->get_where_custom_tb('planedactivity', 'refno', $refno);
		//display
		$data['middle_m']="Access";
		$data['middle_f']="paModify";
		$data['msg'] = "";
		$data['color'] = "blue";
		

		
	}  else if (!$crViewBtn == "") {
		# code...
		$refno = $crViewBtn;

		$data['pares'] = $this->get_where_custom_tb('planedactivity', 'refno', $refno);
		$data['refno'] = $data['pares']->row()->refno;
		$data['siteid'] = $data['pares']->row()->site_id;
		$data['reason'] = $data['pares']->row()->reason;
		$data['requester'] = $data['pares']->row()->requester;
		$data['requesterphone'] = $data['pares']->row()->requesterphone;
		$data['implementer'] = $data['pares']->row()->implementer;
		$data['implementerphone'] = $data['pares']->row()->implementerphone;
		$data['stdate'] = $data['pares']->row()->stdate;
		$data['effecttotraffic'] = $data['pares']->row()->effecttotraffic;
		$data['downtime'] = $data['pares']->row()->downtime;
		//added
		$data['work_desc'] = $data['pares']->row()->work_desc;
		$data['fallback_time'] = $data['pares']->row()->fallback_time;
		$data['affected_nodes'] = $data['pares']->row()->affected_nodes;
		$data['affected_customer'] = $data['pares']->row()->affected_customer;
		$data['moniteredby'] = $data['pares']->row()->moniteredby;
		$data['requirements'] = $data['pares']->row()->requirements;
		$data['implement_risk'] = $data['pares']->row()->implement_risk;
		$data['noimplement_risk'] = $data['pares']->row()->noimplement_risk;
		$data['alt_to_change'] = $data['pares']->row()->alt_to_change;
		$data['change_procedures'] = $data['pares']->row()->change_procedures;
		$data['fallback_procedures'] = $data['pares']->row()->fallback_procedures;

		//display
		$data['middle_m']="Access";
		$data['middle_f']="paCrDoc";
		$data['msg'] = "";
		$data['color'] = "blue";
		

		
	}  else if (!$crDownBtn == "") {
		# code...
		$refno = $crDownBtn;

		$data['pares'] = $this->get_where_custom_tb('planedactivity', 'refno', $refno);
		$data['refno'] = $data['pares']->row()->refno;
		$data['siteid'] = $data['pares']->row()->site_id;
		$data['reason'] = $data['pares']->row()->reason;
		$data['requester'] = $data['pares']->row()->requester;
		$data['requesterphone'] = $data['pares']->row()->requesterphone;
		$data['implementer'] = $data['pares']->row()->implementer;
		$data['implementerphone'] = $data['pares']->row()->implementerphone;
		$data['stdate'] = $data['pares']->row()->stdate;
		$data['effecttotraffic'] = $data['pares']->row()->effecttotraffic;
		$data['downtime'] = $data['pares']->row()->downtime;
		//added
		$data['work_desc'] = $data['pares']->row()->work_desc;
		$data['fallback_time'] = $data['pares']->row()->fallback_time;
		$data['affected_nodes'] = $data['pares']->row()->affected_nodes;
		$data['affected_customer'] = $data['pares']->row()->affected_customer;
		$data['moniteredby'] = $data['pares']->row()->moniteredby;
		$data['requirements'] = $data['pares']->row()->requirements;
		$data['implement_risk'] = $data['pares']->row()->implement_risk;
		$data['noimplement_risk'] = $data['pares']->row()->noimplement_risk;
		$data['alt_to_change'] = $data['pares']->row()->alt_to_change;
		$data['change_procedures'] = $data['pares']->row()->change_procedures;
		$data['fallback_procedures'] = $data['pares']->row()->fallback_procedures;

		//Download pdf
		$dowView = "paCrDoc";
		$this->downloadPdf($dowView,$data);

		//display
		$data['middle_m']="Access";
		$data['middle_f']="paCrDoc";
		$data['msg'] = "";
		$data['color'] = "blue";
		

		
	} else if (!$paFilterBtn == "") {
		# code...
		# code...
		$stdate = $this->input->post('stdate', true);
		$endate = $this->input->post('endate', true);
		$data['paFilterres'] = $this->get_where_btndates2('planedactivity', 'reqdate', $stdate, 'reqdate', $endate);

		$data['middle_m']="Access";
		$data['middle_f']="newPlannedActivity";
		$data['msg'] = "";
		$data['color'] = "blue";

	}  else {
		# code...

		//display
		$data['middle_m']="Access";
		$data['middle_f']="newPlannedActivity";
		$data['msg'] = "";
		$data['color'] = "blue";
	}
	

	if ($this->session->userdata('logged_in')) {
		if ($this->session->userdata('user_role') == "admin") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "office") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "fs") { $this->load->view('Home/index',$data); } else if ($this->session->userdata('user_role') == "ft") { $this->load->view('Home/index',$data); } else { $this->load->view('Home/index',$data); }
	} else {
		$this->load->view('Home/loginerr',$data);
	}
}


function filteredPlannedActivity() {
	# code...
	$today = mdate('%Y-%m-%d');
	# code...
	$paFilterBtn = $this->input->post('paFilterBtn', true);

	if (!$paFilterBtn == "") {
		# code...
		# code...
		$stdate = $this->input->post('stdate', true);
		$endate = $this->input->post('endate', true);
		$paFilterres = $this->get_where_btndates2('planedactivity', 'reqdate', $stdate, 'reqdate', $endate);

		$data['middle_m']="Access";
		$data['middle_f']="filteredPlannedActivity";
		$data['msg'] = "";
		$data['color'] = "blue";
	} else {
		# code...
		$data['middle_m']="Access";
		$data['middle_f']="filteredPlannedActivity";
		$data['msg'] = "";
		$data['color'] = "blue";
	}
	

	if ($this->session->userdata('logged_in')) {
		if ($this->session->userdata('user_role') == "admin") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "office") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "fs") { $this->load->view('Home/index',$data); } else if ($this->session->userdata('user_role') == "ft") { $this->load->view('Home/index',$data); } else { $this->load->view('Home/index',$data); }
	} else {
		$this->load->view('Home/loginerr',$data);
	}
}





function downPMExcel($pmres){
//load our new PHPExcel library
$this->load->library('excel');	
//Dashboard (sheet 1)
$this->excel->setActiveSheetIndex(0);

//ORDERS SHEET
$h1 = "SITE ACCESS REQUESTS REPORT";
$h2 = "(Access Request Records - ".mdate('%Y/ %m/ %d').")";
// items (seet 2)
/*$this->excel->createSheet();
$this->excel->setActiveSheetIndex(1);*/
//Format second sheet
$this->excel->getActiveSheet()->setTitle('Site Access Report');
$this->excel->getActiveSheet()->getStyle('A1:X1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('F4B083');
$this->excel->getActiveSheet()->getStyle('A2:X2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('F4B083');
$this->excel->getActiveSheet()->setCellValue('A1', strtoupper($h1));
$this->excel->getActiveSheet()->setCellValue('A2', strtoupper($h2));
$this->excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(16);
$this->excel->getActiveSheet()->getStyle('A2')->getFont()->setSize(16);
$this->excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
$this->excel->getActiveSheet()->getStyle('A2')->getFont()->setBold(true);
$this->excel->getActiveSheet()->getStyle('A4:X4')->getFont()->setBold(true);
$this->excel->getActiveSheet()->mergeCells('A1:X1');
$this->excel->getActiveSheet()->mergeCells('A2:X2');
$this->excel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('G')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('H')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('I')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('J')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('K')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('L')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('M')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('N')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('O')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('P')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('Q')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('R')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('S')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('T')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('U')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('V')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('W')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('X')->setAutoSize(true);
//set aligment to center for that merged cell (A1 to T1)
$this->excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$this->excel->getActiveSheet()->getStyle('A2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
//set sheet title
$this->excel->getActiveSheet()->getStyle('A4:X4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('699CF1');
$this->excel->getActiveSheet()->setCellValue('A4', 'ACCESS CODE');
$this->excel->getActiveSheet()->setCellValue('B4', 'SITE ID');
$this->excel->getActiveSheet()->setCellValue('C4', 'SITE NAME');
$this->excel->getActiveSheet()->setCellValue('D4', 'REQUESTER');
$this->excel->getActiveSheet()->setCellValue('E4', 'DATE CREATED');
$this->excel->getActiveSheet()->setCellValue('F4', 'TYPE');
$this->excel->getActiveSheet()->setCellValue('G4', 'CATEGORY');
$this->excel->getActiveSheet()->setCellValue('H4', 'ELEMENT / SUB ELEMENT');
$this->excel->getActiveSheet()->setCellValue('I4', 'DG FUEL (Litters)');
$this->excel->getActiveSheet()->setCellValue('J4', 'HYBRID TYPE');
$this->excel->getActiveSheet()->setCellValue('K4', 'HYBRID STATUS');
$this->excel->getActiveSheet()->setCellValue('L4', 'LUKU BALANCE  (KWH)');
$this->excel->getActiveSheet()->setCellValue('M4', 'DG RUN HOURS (HRS)');
$this->excel->getActiveSheet()->setCellValue('N4', 'REMARKS');

$this->excel->getActiveSheet()->setCellValue('O4', 'MAINS POWER FAILURE');
$this->excel->getActiveSheet()->setCellValue('P4', 'BATERY DISCHARGE');
$this->excel->getActiveSheet()->setCellValue('Q4', 'HIGH TEMPERATURE');
$this->excel->getActiveSheet()->setCellValue('R4', 'COMMON DG ALARM');

$this->excel->getActiveSheet()->setCellValue('S4', 'CLOSURE DATE');
$this->excel->getActiveSheet()->setCellValue('T4', 'STATUS');
$this->excel->getActiveSheet()->setCellValue('U4', 'CLOSING AGENT');
$this->excel->getActiveSheet()->setCellValue('V4', 'LATITUDE');
$this->excel->getActiveSheet()->setCellValue('W4', 'LONGTUDE');
$this->excel->getActiveSheet()->setCellValue('X4', 'DATE');
//Print data from db
$count = 5;
$index = 1;
foreach ($pmres->result() as $row){
	$this->excel->getActiveSheet()->setCellValue('A'.$count, $row->accessCode);
	$this->excel->getActiveSheet()->setCellValue('B'.$count, $row->site_id);
	$this->excel->getActiveSheet()->setCellValue('C'.$count, $this->site->get_where_custom_tb('site', 'site_id', $row->site_id)->row()->site_name);
	$this->excel->getActiveSheet()->setCellValue('D'.$count, $this->users->get_where_custom('user_id', $row->user_id)->row()->fname.' '.$this->users->get_where_custom('user_id', $row->user_id)->row()->sname.' '.$this->users->get_where_custom('user_id', $row->user_id)->row()->lname);
	$this->excel->getActiveSheet()->setCellValue('E'.$count, $row->log_in_time);
	$this->excel->getActiveSheet()->setCellValue('F'.$count, $row->type);
	$this->excel->getActiveSheet()->setCellValue('G'.$count, $row->cotegory);
	$this->excel->getActiveSheet()->setCellValue('H'.$count, $row->element." / ".$row->sub_element);
	$this->excel->getActiveSheet()->setCellValue('I'.$count, $row->dg_fuel );
	$this->excel->getActiveSheet()->setCellValue('J'.$count, $row->hybridtype );
	$this->excel->getActiveSheet()->setCellValue('K'.$count, $row->hybridstatus );
	$this->excel->getActiveSheet()->setCellValue('L'.$count, $row->luku_Balance );
	$this->excel->getActiveSheet()->setCellValue('M'.$count, $row->dgRunHour );
	$this->excel->getActiveSheet()->setCellValue('N'.$count, $row->remarks );

	$this->excel->getActiveSheet()->setCellValue('O'.$count, $row->mainspowerfrailer );
	$this->excel->getActiveSheet()->setCellValue('P'.$count, $row->batterydischarge );
	$this->excel->getActiveSheet()->setCellValue('Q'.$count, $row->hightemperature );
	$this->excel->getActiveSheet()->setCellValue('R'.$count, $row->commondgalarm );


	$this->excel->getActiveSheet()->setCellValue('S'.$count, $row->log_out_time );
	$this->excel->getActiveSheet()->setCellValue('T'.$count, $row->status );
	$this->excel->getActiveSheet()->setCellValue('U'.$count, $row->closingAgent );
	$this->excel->getActiveSheet()->setCellValue('V'.$count, $row->lotitude );
	$this->excel->getActiveSheet()->setCellValue('W'.$count, $row->longitude );
	$this->excel->getActiveSheet()->setCellValue('X'.$count, $row->date );
$count++;
$index ++;
}


$filename='Site_Access_Report.xls'; //save our workbook as this file name
header('Content-Type: application/vnd.ms-excel'); //mime type
header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
header('Cache-Control: max-age=0'); //no cache
            
//save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
//if you want to save it as .XLSX Excel 2007 format
$objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');  
//force user to download the Excel file without writing it to server's HD
$objWriter->save('php://output');

}




function downGSExcel($gsres){
//load our new PHPExcel library
$this->load->library('excel');	
//Dashboard (sheet 1)
$this->excel->setActiveSheetIndex(0);

//ORDERS SHEET
$h1 = "GENERATOR SERVICE (GS) ACCESS REQUEST REPORT";
$h2 = "(Access Request Records - ".mdate('%Y/ %m/ %d').")";
// items (seet 2)
/*$this->excel->createSheet();
$this->excel->setActiveSheetIndex(1);*/
//Format second sheet
$this->excel->getActiveSheet()->setTitle('DG Access Report');
$this->excel->getActiveSheet()->getStyle('A1:X1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('F4B083');
$this->excel->getActiveSheet()->getStyle('A2:X2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('F4B083');
$this->excel->getActiveSheet()->setCellValue('A1', strtoupper($h1));
$this->excel->getActiveSheet()->setCellValue('A2', strtoupper($h2));
$this->excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(16);
$this->excel->getActiveSheet()->getStyle('A2')->getFont()->setSize(16);
$this->excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
$this->excel->getActiveSheet()->getStyle('A2')->getFont()->setBold(true);
$this->excel->getActiveSheet()->getStyle('A4:X4')->getFont()->setBold(true);
$this->excel->getActiveSheet()->mergeCells('A1:X1');
$this->excel->getActiveSheet()->mergeCells('A2:X2');
$this->excel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('G')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('H')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('I')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('J')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('K')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('L')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('M')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('N')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('O')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('P')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('Q')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('R')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('S')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('T')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('U')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('V')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('W')->setAutoSize(true);
$this->excel->getActiveSheet()->getColumnDimension('X')->setAutoSize(true);
//set aligment to center for that merged cell (A1 to T1)
$this->excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$this->excel->getActiveSheet()->getStyle('A2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
//set sheet title
$this->excel->getActiveSheet()->getStyle('A4:X4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('699CF1');
$this->excel->getActiveSheet()->setCellValue('A4', 'ACCESS CODE');
$this->excel->getActiveSheet()->setCellValue('B4', 'SITE ID');
$this->excel->getActiveSheet()->setCellValue('C4', 'SITE NAME');
$this->excel->getActiveSheet()->setCellValue('D4', 'REQUESTER');
$this->excel->getActiveSheet()->setCellValue('E4', 'DATE CREATED');
$this->excel->getActiveSheet()->setCellValue('F4', 'TYPE');
$this->excel->getActiveSheet()->setCellValue('G4', 'CATEGORY');
$this->excel->getActiveSheet()->setCellValue('H4', 'SUB ELEMENT');
$this->excel->getActiveSheet()->setCellValue('I4', 'DG FUEL (Litters)');
$this->excel->getActiveSheet()->setCellValue('J4', 'HYBRID TYPE');
$this->excel->getActiveSheet()->setCellValue('K4', 'HYBRID STATUS');
$this->excel->getActiveSheet()->setCellValue('L4', 'LUKU BALANCE (KWH)');
$this->excel->getActiveSheet()->setCellValue('M4', 'DG RUN HOURS (HRS)');
$this->excel->getActiveSheet()->setCellValue('N4', 'REMARKS');

$this->excel->getActiveSheet()->setCellValue('O4', 'MAINS POWER FAILURE');
$this->excel->getActiveSheet()->setCellValue('P4', 'BATERY DISCHARGE');
$this->excel->getActiveSheet()->setCellValue('Q4', 'HIGH TEMPERATURE');
$this->excel->getActiveSheet()->setCellValue('R4', 'COMMON DG ALARM');

$this->excel->getActiveSheet()->setCellValue('S4', 'CLOSURE DATE');
$this->excel->getActiveSheet()->setCellValue('T4', 'STATUS');
$this->excel->getActiveSheet()->setCellValue('U4', 'CLOSING AGENT');
$this->excel->getActiveSheet()->setCellValue('V4', 'LATITUDE');
$this->excel->getActiveSheet()->setCellValue('W4', 'LONGTUDE');
$this->excel->getActiveSheet()->setCellValue('X4', 'DATE');
//Print data from db
$count = 5;
$index = 1;
foreach ($gsres->result() as $row){
	$this->excel->getActiveSheet()->setCellValue('A'.$count, $row->accessCode);
	$this->excel->getActiveSheet()->setCellValue('B'.$count, $row->site_id);
	$this->excel->getActiveSheet()->setCellValue('C'.$count, $this->site->get_where_custom_tb('site', 'site_id', $row->site_id)->row()->site_name);
	$this->excel->getActiveSheet()->setCellValue('D'.$count, $this->users->get_where_custom('user_id', $row->user_id)->row()->fname.' '.$this->users->get_where_custom('user_id', $row->user_id)->row()->sname.' '.$this->users->get_where_custom('user_id', $row->user_id)->row()->lname);
	$this->excel->getActiveSheet()->setCellValue('E'.$count, $row->log_in_time);
	$this->excel->getActiveSheet()->setCellValue('F'.$count, $row->type);
	$this->excel->getActiveSheet()->setCellValue('G'.$count, $row->cotegory);
	$this->excel->getActiveSheet()->setCellValue('H'.$count, $row->sub_element);
	$this->excel->getActiveSheet()->setCellValue('I'.$count, $row->dg_fuel );
	$this->excel->getActiveSheet()->setCellValue('J'.$count, $row->hybridtype );
	$this->excel->getActiveSheet()->setCellValue('K'.$count, $row->hybridstatus );
	$this->excel->getActiveSheet()->setCellValue('L'.$count, $row->luku_Balance );
	$this->excel->getActiveSheet()->setCellValue('M'.$count, $row->dgRunHour );
	$this->excel->getActiveSheet()->setCellValue('N'.$count, $row->remarks );

	$this->excel->getActiveSheet()->setCellValue('O'.$count, $row->mainspowerfrailer );
	$this->excel->getActiveSheet()->setCellValue('P'.$count, $row->batterydischarge );
	$this->excel->getActiveSheet()->setCellValue('Q'.$count, $row->hightemperature );
	$this->excel->getActiveSheet()->setCellValue('R'.$count, $row->commondgalarm );


	$this->excel->getActiveSheet()->setCellValue('S'.$count, $row->log_out_time );
	$this->excel->getActiveSheet()->setCellValue('T'.$count, $row->status );
	$this->excel->getActiveSheet()->setCellValue('U'.$count, $row->closingAgent );
	$this->excel->getActiveSheet()->setCellValue('V'.$count, $row->lotitude );
	$this->excel->getActiveSheet()->setCellValue('W'.$count, $row->longitude );
	$this->excel->getActiveSheet()->setCellValue('X'.$count, $row->date );
$count++;
$index ++;
}

$filename='DG_Access_Report.xls'; //save our workbook as this file name
header('Content-Type: application/vnd.ms-excel'); //mime type
header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
header('Cache-Control: max-age=0'); //no cache
            
//save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
//if you want to save it as .XLSX Excel 2007 format
$objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');  
//force user to download the Excel file without writing it to server's HD
$objWriter->save('php://output');

}



/*================= PDF DOWNLOADER ===========*/
function downloadPdf($dowView,$data) {
	//download page
	$html=$this->load->view($dowView,$data,true);
	$pdfFilePath = "CHANGE_REQUEST.pdf";
	$this->load->library('m_pdf'); 
	$this->m_pdf->pdf->WriteHTML($html);
	$this->m_pdf->pdf->Output($pdfFilePath, "D");
}




/*================ end access =============*/


function dailyPmRecords(){

	$data['middle_m']="Pm";
	$data['middle_f']="dailyPmRecords";
	$data['msg'] = "";

	if ($this->session->userdata('logged_in')) {
		if ($this->session->userdata('user_role') == "admin") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "office") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "fs") { $this->load->view('Home/index',$data); } else if ($this->session->userdata('user_role') == "ft") { $this->load->view('Home/index',$data); } else { $this->load->view('Home/index',$data); }
	} else {
		$this->load->view('Home/loginerr',$data);
	}

}



function filteredPmRecords(){
	$viewBtn = $this->input->post('viewBtn', true);
	$pmfilter = $this->input->post('pmfilter', true);
	
	$data['pmRes'] = $this->get_tb('preventivemaintenance', 'accessCode');
	$data['siteRes'] = $this->get_tb('site', 'site_id');

	$today = mdate('%Y-%m-%d');
	$data['filteredpmRes'] = $this->get_where_custom_tb('preventivemaintenance', 'date', $today);
	

	if (!$pmfilter == "") {
		# code...
		//read filtered data from db
		$siteid = $this->input->post('siteid', true);
		$stdate = $this->input->post('stdate', true);
		$endate = $this->input->post('endate', true);

		if ($siteid == 'all') {
			# code...
			$data['filteredpmRes'] = $this->get_where_btndates2('preventivemaintenance', 'date', $stdate, 'date', $endate);
		} else {
			# code...
			$data['filteredpmRes'] = $this->get_where_btndates1('preventivemaintenance', 'site_id', $siteid, 'date', $stdate, 'date', $endate);
		}
		
		// display
		$data['middle_m']="Pm";
		$data['middle_f']="filteredPmRecords";
		$data['msg'] = "";

	} else if ((!$viewBtn == "")) {
		//read repport data from db
		$accesscode =  $viewBtn;
		//get pm recird from preventive maintainance table
		$data['pmres'] = $this->get_where_custom_tb('preventivemaintenance', 'accessCode', $accesscode);
		$siteInfo = $this->site->get_where_custom('site_id', $data['pmres']->row()->site_id);
			//read all questions from  qn table
			$data['pmdate'] = $data['pmres']->row()->date;
			$data['siteid'] = $data['pmres']->row()->site_id;
			$data['sitename'] = $siteInfo->row()->site_name;
			$data['ft'] = $siteInfo->row()->tech_name;
			$data['zone'] = $siteInfo->row()->zone_id; //read from zone table
			$data['fs'] = $siteInfo->row()->field_supervisor;
			$data['zom'] = $siteInfo->row()->zone_manager;
			$data['pmQns'] = $this->get_tb('pm_qn_airtel','Qns_Id');
		//put answers  into an array
			$data['ans'] = Array();
			$data['ans'][0] = $data['pmres']->row()->list1;
			$data['ans'][1] = $data['pmres']->row()->list2;
			$data['ans'][2] = $data['pmres']->row()->list3;
			$data['ans'][3] = $data['pmres']->row()->list4;
			$data['ans'][4] = $data['pmres']->row()->list5;
			$data['ans'][5] = $data['pmres']->row()->list6;
			$data['ans'][6] = $data['pmres']->row()->list7;
			$data['ans'][7] = $data['pmres']->row()->list8;
			$data['ans'][8] = $data['pmres']->row()->list9;
			$data['ans'][9] = $data['pmres']->row()->list10;
			$data['ans'][10] = $data['pmres']->row()->list11;
			$data['ans'][11] = $data['pmres']->row()->list12;
		// display
		$data['middle_m']="Pm";
		$data['middle_f']="pmReportSheet";
		$data['msg'] = "";

	}else {
		# code...
		$data['middle_m']="Pm";
		$data['middle_f']="filteredPmRecords";
		$data['msg'] = "";
	}
	

	if ($this->session->userdata('logged_in')) {
		if ($this->session->userdata('user_role') == "admin") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "office") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "fs") { $this->load->view('Home/index',$data); } else if ($this->session->userdata('user_role') == "ft") { $this->load->view('Home/index',$data); } else { $this->load->view('Home/index',$data); }
	} else {
		$this->load->view('Home/loginerr',$data);
	}

}





function pmActivityRecording(){
	$pmQuery = $this->input->post('pmQuery', true);
	$ansBtn = $this->input->post('ansBtn', true);

	

	if (!$pmQuery == "") {
		# code...
		
		$id = $this->input->post('siteid', true);
		//read repport data from db 
		$siteInfo = $this->site->get_where_custom('site_id', $id);
		if ($siteInfo->num_rows() > 0) {
			# code... store  id in session
			$this->session->set_userdata('siteid', $id);
			//get access code
			$access_code_res = $this->get_tb('accesscode', 'idnumber');
			$access_code = $access_code_res->row()->accessCode_number + 1;
			$this->session->set_userdata('access_code', $access_code);
			$cdata['accessCode_number'] = $access_code;
			//$this->_update_tb('accesscode', $cdata);
			$this->_update2('accesscode', '	idnumber', 	$access_code_res->row()->idnumber, $cdata);

			$siteInfo = $this->site->get_where_custom('site_id', $this->session->userdata('siteid'));
			//read all questions from  qn table
			$data['siteid'] = $id;
			$data['sitename'] = $siteInfo->row()->site_name;
			$data['ft'] = $siteInfo->row()->tech_name;
			$data['zone'] = $siteInfo->row()->zone_id; //read from zone table
			$data['fs'] = $siteInfo->row()->field_supervisor;
			$data['zom'] = $siteInfo->row()->zone_manager;
			$data['pmQns'] = $this->get_tb('pm_qn_airtel','Qns_Id');
			/*foreach ($pmQn as $key => $value) {
				# code...
			}*/
			// display
			$data['middle_m']="Pm";
			$data['middle_f']="pmQuestionaire";
			$data['color'] = "blue";
			$data['msg'] = "";

		} else {
			# code...
			$data['middle_m']="Pm";
			$data['middle_f']="newPmRecords";
			$data['color'] = "red";
			$data['msg'] = "SORRY.! Site not Found. Confirm Your Site ID and Try Again.";
		}
		
		
	} else if (!$ansBtn == "") {
		//collect answers and store them in specific lust in accesscode_pm table
		$pmQns = $this->get_tb('pm_qn_airtel','Qns_Id');
		$ans = array();
		$i = 0;
		foreach ($pmQns->result() as $pmQn){
			$index = 1;
            $keywords = explode('#', $pmQn->Qn);
            $ans_sub = "";
			foreach ($keywords as $keyword){
				$ans_sub = $ans_sub.$this->input->post($pmQn->Type.$index, true).'#';
				$index++;
			}
			
			$ans[$i] = $ans_sub;;
			$i++;
		}

		//insert into database
		$code = $this->session->userdata('access_code');
		$pmdata['accessCode'] = "NTT40000-".str_pad( "$code", 6, "0", STR_PAD_LEFT );
		$pmdata['site_id'] = $this->session->userdata('siteid');
		$pmdata['user_id'] = $this->session->userdata('user_id');
		$pmdata['date'] = mdate('%Y-%m-%d');
		$pmdata['list1'] = $ans[0] ;
		$pmdata['list2'] = $ans[1] ;
		$pmdata['list3'] = $ans[2] ;
		$pmdata['list4'] = $ans[3] ;
		$pmdata['list5'] = $ans[4] ;
		$pmdata['list6'] = $ans[5] ;
		$pmdata['list7'] = $ans[6] ;
		$pmdata['list8'] = $ans[7] ;
		$pmdata['list9'] = $ans[8] ;
		$pmdata['list10'] = $ans[9] ;
		$pmdata['list11'] = $ans[10] ;
		$pmdata['list12'] = $ans[11] ;
		$access_code_chk = $this->get_where_custom_tb('preventivemaintenance', 'accessCode', $pmdata['accessCode']);
		if ($access_code_chk->num_rows() < 1) {
			# code...
			$this->_insert_tb('preventivemaintenance', $pmdata);
			//back to request page
			$data['middle_m']="Pm";
			$data['middle_f']="newPmRecords";
			$data['color'] = "blue";
			$data['msg'] = "INFO. Your Questionaire has been Submitted successifully.!";


		} else {
			# code...
			//back to request page
			$data['middle_m']="Pm";
			$data['middle_f']="newPmRecords";
			$data['color'] = "red";
			$data['msg'] = "WARNING : Submission Failed. Please Make a New Request";

		}
		
		
		

	}  else {
		# code...
		$data['middle_m']="Pm";
		$data['middle_f']="newPmRecords";
		$data['color'] = "blue";
		$data['msg'] = "";
	}
	

	if ($this->session->userdata('logged_in')) {
		if ($this->session->userdata('user_role') == "admin") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "office") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "fs") { $this->load->view('Home/index',$data); } else if ($this->session->userdata('user_role') == "ft") { $this->load->view('Home/index',$data); } else { $this->load->view('Home/index',$data); }
	} else {
		$this->load->view('Home/loginerr',$data);
	}

}




function pmDownloader(){
	$pdfdownBtn = $this->input->post('downBtn', true);
	$viewBtn = $this->input->post('viewBtn', true);

	$data['pmRes'] = $this->get_tb('preventivemaintenance', 'accessCode');
	$data['siteRes'] = $this->get_tb('site', 'site_id');

	$today = mdate('%Y-%m-%d');
	$data['filteredpmRes'] = $this->get_where_custom_tb('preventivemaintenance', 'date', $today);
	
			//Read questions
			$data['pmQns'] = $this->get_tb('pm_qn_airtel','Qns_Id');
		
	if (!$pdfdownBtn == "") {
		# code...
		//read filtered data from db
		$siteid = $this->input->post('siteid', true);
		$stdate = $this->input->post('stdate', true);
		$endate = $this->input->post('endate', true);
		if ($siteid == 'all') {
			# code...
			$data['filteredpmRes'] = $this->get_where_btndates2('preventivemaintenance', 'date', $stdate, 'date', $endate);
		} else {
			# code...
			$data['filteredpmRes'] = $this->get_where_btndates1('preventivemaintenance', 'site_id', $siteid, 'date', $stdate, 'date', $endate);
		}


		$dowView ="downSheet";
		$data['msg'] = "";

		//rcall excel downloader
		$this->downloadPdf($dowView,$data);
		

	} else if (!$viewBtn == "") {

		//read filtered data from db
		$siteid = $this->input->post('siteid', true);
		$stdate = $this->input->post('stdate', true);
		$endate = $this->input->post('endate', true);
		if ($siteid == 'all') {
			# code...
			$data['filteredpmRes'] = $this->get_where_btndates2('preventivemaintenance', 'date', $stdate, 'date', $endate);
		} else {
			# code...
			$data['filteredpmRes'] = $this->get_where_btndates1('preventivemaintenance', 'site_id', $siteid, 'date', $stdate, 'date', $endate);
		}
		//display
		$data['middle_m']="Pm";
		$data['middle_f']="downSheet";
		$data['msg'] = "";

	}  else {
		# code...
		$data['middle_m']="Pm";
		$data['middle_f']="pmDownloader";
		$data['msg'] = "";
	}
	

	if ($this->session->userdata('logged_in')) {
		if ($this->session->userdata('user_role') == "admin") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "office") { $this->load->view('Admin/index',$data); } else if ($this->session->userdata('user_role') == "fs") { $this->load->view('Home/index',$data); } else if ($this->session->userdata('user_role') == "ft") { $this->load->view('Home/index',$data); } else { $this->load->view('Home/index',$data); }
	} else {
		$this->load->view('Home/loginerr',$data);
	}

}



function downloadExcel() {

	echo "Downloading Excel ...";
}






/*==================== end SIC ==============*/






//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
function get($order_by) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get($order_by);
return $query;
}

function get_with_limit($limit, $offset, $order_by) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_with_limit($limit, $offset, $order_by);
return $query;
}

function get_where($id) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_where($id);
return $query;
}

function get_where_email($email) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_where_email($email);
return $query;
}
function get_all($tb) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_all($tb);
return $query;
}


function get_col_where($tb, $col) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_col_where($tb, $col);
return $query;
}


function get_where_custom($col, $value) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_where_custom($col, $value);
return $query;
}

function get_where_custom1($tb, $col1, $value1) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_where_custom1($tb, $col1, $value1);
return $query;
}

function get_where_custom2($tb, $col1, $value1, $col2, $value2) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_where_custom2($tb, $col1, $value1, $col2, $value2);
return $query;
}

function get_where_custom3($tb, $col1, $value1, $col2, $value2, $col3, $value3) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_where_custom3($tb, $col1, $value1, $col2, $value2, $col3, $value3) ;
return $query;
}

function get_where_custom4($tb, $col1, $value1, $col2, $value2, $col3, $value3, $col4, $value4) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_where_custom4($tb, $col1, $value1, $col2, $value2, $col3, $value3, $col4, $value4) ;
return $query;
}


function _insert($data) {
$this->load->model('Mdl_access');
$this->Mdl_access->_insert($data);
}

function _update($id, $data) {
$this->load->model('Mdl_access');
$this->Mdl_access->_update($id, $data);
}

function _update2($tb, $col, $value, $data) {
$this->load->model('Mdl_access');
$this->Mdl_access->_update2($tb, $col, $value, $data);
}

function _delete($id) {
$this->load->model('Mdl_access');
$this->Mdl_access->_delete($id);
}

function count_where($column, $value) {
$this->load->model('Mdl_access');
$count = $this->Mdl_access->count_where($column, $value);
return $count;
}

function get_max() {
$this->load->model('Mdl_access');
$max_id = $this->Mdl_access->get_max();
return $max_id;
}

function _custom_query($mysql_query) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->_custom_query($mysql_query);
return $query;
}


//CODES
function getcode($order_by) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->getcode($order_by);
return $query;
}

function getcode_where($col,$code) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->getcode_where($col,$code);
return $query;
}

function getcode_wherenot($col,$code) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->getcode_wherenot($col,$code);
return $query;
}

function _insertcode($data) {
$this->load->model('Mdl_access');
$this->Mdl_access->_insertcode($data);
}

function _updatecode($col,$code, $data){
$this->load->model('Mdl_access');
$this->Mdl_access->_updatecode($col,$code, $data);
}



//xxxxxxxxxxxxxxxxxxxxxxx MULT TABLE XXXXXXXXXXXXXXXX
function get_tb($tb, $order_by) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_tb($tb, $order_by);
return $query;
}

function _insert_tb($tb,$data) {
$this->load->model('Mdl_access');
$this->Mdl_access->_insert_tb($tb,$data);
}

function _update_tb($tb, $id, $data) {
$this->load->model('Mdl_access');
$this->Mdl_access->_update_tb($tb,$id, $data);
}   

function _delete_tb($tb, $id) {
$this->load->model('Mdl_access');
$this->Mdl_access->_delete_tb($tb, $id);
}

function get_where_tb($tb, $id) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_where_tb($tb, $id);
return $query;
}

function get_where_custom_tb($tb, $col, $value) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_where_custom_tb($tb, $col, $value);
return $query;
}

function count_all_tb($tb) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->count_all_tb($tb);
return $query;
}


/*============== get btn ===================*/
//get between dates
function get_where_btndates1($tb, $col1, $value1, $datecol1, $datevalue1, $datecol2, $datevalue2) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_where_btndates1($tb, $col1, $value1, $datecol1, $datevalue1, $datecol2, $datevalue2);
return $query;
}

function get_where_btndates2($tb, $datecol1, $datevalue1, $datecol2, $datevalue2) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_where_btndates2($tb, $datecol1, $datevalue1, $datecol2, $datevalue2);
return $query;
}

//get between IDs
function get_where_btnID1($tb, $col1, $value1, $idcol1, $idvalue1, $idcol2, $idvalue2) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_where_btndates1($tb, $col1, $value1, $idcol1, $idvalue1, $idcol2, $idvalue2);
return $query;
}

function get_where_btnID2($tb, $idcol1, $idvalue1, $idcol2, $idvalue2) {
$this->load->model('Mdl_access');
$query = $this->Mdl_access->get_where_btndates2($tb, $idcol1, $idvalue1, $idcol2, $idvalue2);
return $query;
}
/*================ end btn =================*/


}




