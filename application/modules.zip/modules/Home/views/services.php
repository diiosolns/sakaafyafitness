<style type="text/css">

.box {
    border-radius: 3px;
    box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);
    padding: 10px 25px;
    text-align: right;
    display: block;
    margin-top: 60px;
}
.box-icon {
    background-color: #57a544;
    border-radius: 50%;
    display: table;
    height: 100px;
    margin: 0 auto;
    width: 100px;
    margin-top: -61px;
}
.box-icon span {
    color: #fff;
    display: table-cell;
    text-align: center;
    vertical-align: middle;
}
.info h4 {
    font-size: 26px;
    letter-spacing: 2px;
    text-transform: uppercase;
}
.info > p {
    color: #717171;
    font-size: 16px;
    padding-top: 10px;
    text-align: justify;
}
.info > a {
    background-color: #03a9f4;
    border-radius: 2px;
    box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);
    color: #fff;
    transition: all 0.5s ease 0s;
}
.info > a:hover {
    background-color: #0288d1;
    box-shadow: 0 2px 3px 0 rgba(0, 0, 0, 0.16), 0 2px 5px 0 rgba(0, 0, 0, 0.12);
    color: #fff;
    transition: all 0.5s ease 0s;
}

.serviceHeader {
  margin-left: 20px;
  padding: 15px 5px 10px 5px;
}
</style>

  <div class="serviceHeader time-label">
    <span class="bg-aqua" style="padding: 10px 15px 10px 15px;">
      <b style="font-size: 20px;">Our Services</b>
   </span>
 </div>


<div class="container">
    <div class="time-label" style="text-align: justify; font-size: 16px;">
          <p>This website is build on the primarily functions of simplifying the marketing strategies of entrepreneurs and professionals while providing service consumers an easy way of finding online for their specific services in need and make contact or appointments to meet the services providers. Therefore in brief, the following are the services one can benefit from this vibrant, potential and fast growing ecosystem.</p>
          <p>It is quite true that sometimes it is very hard to find the service that you want at a particular and convenient time. This site provides you with an easy way, with no need to sign up, one will have just to search in this website and find what they need, it be on urgency or otherwise. The site has been built on the idea the main purpose of simplifying the service provision process and making it easier, simpler and friendlier. </p>
          <p>We believe, you are going to enjoy using this site for personal benefits from which we can have a general development be it is true that a national development does not come as the whole but it starts with each one of us making a different and at the end large sectors can be observed as they have grown. </p>
    </div>


    <div class="row">
        <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 wow animated fadeInLeft">
            <div class="box">
                <div class="bg-aqua box-icon">
                    <span class="fa fa-4x fa-users"></span>
                </div>
                <div class="info">
                    <h4 class="text-center">User Profiles </h4>
                    <p>
                        These are profiles for our website users (service providers) that are created in order to enable visitors to locate them. A professional or an entrepreneur is capable of registering and create profile(s) according to the services they provide. You can find service providers particulars that can help you determine the perfect service provider you are looking for.  
                    <br>
                    </p>
                    <div style="text-align: left;">
                      <b>Benefits to User</b>
                      <ul>
                        <li>Meet your Target People</li>
                        <li>Find Business Profile Easly.</li>
                        <!-- <li>Advertise your Profile</li> -->
                        <!-- <li>Easy and Fast Service</li> -->
                      </ul>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 wow animated fadeInUp">
            <div class="box">
                <div class="bg-aqua box-icon">
                    <span class="fa fa-4x fa-shopping-cart"></span>
                </div>
                <div class="info">
                    <h4 class="text-center">Marketing services </h4>
                    <p>This site provides the best marketing platform for entrepreneurs and professionals. It is hard to increase the sales rate of the business without telling people what do you really sell. Therefore, it is simple, affordable, and convenient site to run your business marketing strategy.   </p>
                    <div style="text-align: left;">
                      <b>Benefits to service providers</b>
                      <ul>
                        <li>Marketing platform</li>
                        <li>Reach large number of people in a short time</li>
                        <li>Guarantee on return on investment </li>
                        <li>Free and valuable site to use </li>
                      </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 wow animated fadeInRight">
            <div class="box">
                <div class="bg-aqua box-icon">
                    <span class="fa fa-4x fa-calendar "></span>
                </div>
                <div class="info">
                    <h4 class="text-center">Profile Timetable </h4>
                    <p>eHuduma enables you to make an appointment with the service provider you are looking for. A service consumer (visitor) can search for a particular service provider and check his/her timetable to see if the time is convenient to book an official appointment ready for business proceedings.  </p>
                    <div style="text-align: left;">
                      <b>Benefits to User</b>
                      <ul>
                        <li>Marketing platform</li>
                        <li>Reach large number of people in a short time</li>
                        <li>Guarantee on return on investment </li>
                        <li>Free and valuable site to use </li>
                      </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 wow animated fadeInLeft">
            <div class="box">
                <div class="bg-aqua box-icon">
                    <span class="fa fa-4x fa-bullhorn "></span>
                </div>
                <div class="info">
                    <h4 class="text-center">Advertizements </h4>
                    <p>This site is designed to support entrepreneurs, companies, business executives and professionals to have the proper platform for easy, accessible and efficient marketing strategies. As the world is moving so fast, to have a business without a proper marketing strategy is like having business without a plan. One of our services is to give you opportunity to advertise through this website in order to reach many people in a very short period of time and increase your ROI. </p>
                    <div style="text-align: left;">
                      <b>Benefits to User</b>
                      <ul>
                        <li>...</li>
                        <li>...</li>
                        <li>...</li>
                       <!--  <li>...</li> -->
                      </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 wow animated fadeInUp">
            <div class="box">
                <div class="bg-aqua box-icon">
                    <span class="fa fa-4x fa-bullseye "></span>
                </div>
               <div class="info">
                    <h4 class="text-center">Business Profiles </h4>
                    <p>When a visitor searches for services will find a number of profiles that will be more according to the variables he/she searched. Through the business profiles he/she will be able to choose the service provider that is more likely to serve according to the needs. So, business executives who wish to expand their services can prepare the best business profiles that will be so helpful in locating them and their services.    </p>
                    <div style="text-align: left;">
                      <b>Benefits to User</b>
                      <ul>
                        <li>Marketing platform</li>
                        <li>Reach large number of people in a short time</li>
                        <li>Guarantee on return on investment </li>
                        <li>Free and valuable site to use </li>
                      </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 wow animated fadeInRight">
            <div class="box">
                <div class="bg-aqua box-icon">
                    <span class="fa fa-4x fa-clock-o"></span>
                </div>
                <div class="info">
                    <h4 class="text-center">Appointments </h4>
                    <p>eHuduma enables you to make an appointment with the service provider you are looking for. A service consumer (visitor) can search for a particular service provider and check his/her timetable to see if the time is convenient to book an official appointment ready for business proceedings. Then a service provider can see those appointments and schedule an official meeting with the requester.   </p>
                    <div style="text-align: left;">
                      <b>Benefits to User</b>
                      <ul>
                        <li>...</li>
                        <li>...</li>
                        <li>...</li>
                        <li>...</li>
                      </ul>
                    </div>
                </div>
            </div>
        </div>


  </div>

</div>