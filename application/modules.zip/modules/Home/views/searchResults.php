<section class="content" style="padding: 15px 2% 0 2%">

                    <!-- row -->
                    <div class="row">                        
                        <div class="col-md-12">
                            <!-- The time line -->
                            <ul class="timeline">
                                <!-- timeline time label -->
                                <li class="time-label">
                                    <span class="bg-aqua">
                                       <b style="font-size: 20px;">Search Results ...</b>
                                    </span>
                                </li>
                                <!-- /.timeline-label -->
                                <!-- timeline item -->
                                <li>
                                    <i class="fa fa-search bg-aqua"></i>
                                    <div class="timeline-item">
                                        <a href="<?php echo base_url('Home');?>" class="time"><i class="fa fa-users"></i> Easy Profile Search</a>
                                        <h3 class="timeline-header"><a href="#"></a><b>Search results for "<?php echo $searchKey;?>"</b></h3>
                                        <div class="timeline-body" style="text-align: center; color: lightgray; font-size: 26px; ">

                                            <b style="font-size: 26; color: light-gray;">Data Not Found</b>
                                       
                                        </div>
                                        <div class="timeline-footer">
                                            <!-- <a class="btn btn-primary btn-xs">Read more</a>
                                            <a class="btn btn-danger btn-xs">Delete</a> -->
                                        </div>
                                    </div>
                                </li>
                                <!-- END timeline item -->
                                <!-- timeline item -->
                               
                                <li>
                                    <i class="fa fa-search"></i>
                                    <div class="timeline-item"></div>
                                </li>



                                <li class="time-label">
                                    <span class="bg-aqua">
                                        <b style="font-size: 20px;"> Most Popular Search ... </b>
                                    </span>
                                </li>
                                <!-- /.timeline-label -->
                                <!-- timeline item -->
                               <li>
                                    <i class="fa fa-search bg-aqua"></i>
                                    <div class="timeline-item">
                                        <a href="<?php echo base_url('Home');?>" class="time"><i class="fa fa-users"></i> Easy Profile Search</a>
                                        <h3 class="timeline-header"><a href="#"></a><b>Search Links  </b></h3>
                                        <div class="timeline-body" style="font-size: 18px;">
                                           
                                            <!-- =========== quick links ============ -->
                                            <ul>
                                                <li><a href="<?php echo base_url('Home');?>">Quick Profile Search</a> <br> </li>
                                                <li><a href="<?php echo base_url('Home/FAQ');?>">Frequently Asked Questions (FAQ)</a> <br> </li>
                                                <li><a href="<?php echo base_url('Home/aboutUs');?>">Understanding Who we are and What we Do.</a> <br> </li>
                                                <li> <a href="<?php echo base_url('Home/contactUs');?>">Huduma Group Location and Contacts</a> <br> </li>
                                                <li><a href="<?php echo base_url('Home/contactUs');?>">How Can You Leach us.?</a> <br> </li>
                                                <li><a href="<?php echo base_url('Artical/articalPage');?>">Huduma Articals and Other Useful Readings</a> <br></li>
                                                <li><a href="<?php echo base_url('Artical/hudumaNews');?>">Huduma New Features and Other News</a> <br></li>
                                            </ul>
                                            <!-- =========== ./ end links =========== -->
                                        
                                        </div>
                                        <div class="timeline-footer">
                                            <!-- <a class="btn btn-warning btn-flat btn-xs">View comment</a> -->
                                        </div>
                                    </div>
                                </li>
                                <!-- END timeline item -->
                                <!-- timeline item -->
                                
                                <li>
                                    <i class="fa fa-search"></i>
                                </li>
                            </ul>
                        </div><!-- /.col -->
                    </div><!-- /.row -->

                </section>






