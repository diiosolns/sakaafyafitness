<!DOCTYPE html>

<html lang="en">
    <head>
    <meta charset="utf-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1">    
    <meta name="author" content="sumit kumar"> 
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <title>Huduma</title> 
    <!-- bootstrap 3.0.2 -->
        <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url('assets/css/bootstrap.css');?>" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="<?php echo base_url('assets/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css" />
        <!-- Ionicons -->
        <link href="<?php echo base_url('assets/css/ionicons.min.css');?>" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
        <link href="<?php echo base_url('assets/css/AdminLTE.css');?>" rel="stylesheet" type="text/css" />
        <!-- Sub_menu -->
        <link href="<?php echo base_url('assets/css/diiocss/submenu.css');?>" rel="stylesheet" type="text/css" />
        <!-- home page slider and footer -->
        <link href="<?php echo base_url('assets/css/diiocss/home.css');?>" rel="stylesheet" type="text/css" />
         <!-- animate -->
        <link href="<?php echo base_url('assets/css/diiocss/animate.css');?>" rel="stylesheet" type="text/css" />


        <!-- <script src="https://use.fontawesome.com/07b0ce5d10.js"></script> -->
        <style type="text/css">
           .mypadding {
              padding: 1% 4% 0 4%;
           }

           .card.hovercard .cardheader {
                 background: url("<?php echo base_url('assets/img/profilebg2.jpg');?>");
                /*background: url("../../img/profilebg3.jpg");*/
                background-size: cover;
                height: 135px;
            }

             .to-top {
                background-color: #f55353;
                 bottom: 20px;
               -o-transition: all 0.25s;
            }
           .to-top i {
                font-size: 18px;
                color: #fff;
            }
           .to-top.show-top {
               opacity: 0.6;
               visibility: visible;
            }
           .to-top:hover {
               opacity:1;
           }


          .fullwidth {
              margin-left: 0;
              margin-right: 0; 
              width: 100%;
          }

        .partialwidth {
           /* margin-left: 0;
            margin-right: 0; */
            width: 92%;
        }


        .diiosearch {
            /*width: 130px;*/
            box-sizing: border-box;
            border: 2px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            background-color: white;
            /*background-image: url('searchicon.png');*/
            /*background-position: 10px 10px;*/ 
            background-repeat: no-repeat;
            padding: 5px 20px 12px 40px;
            -webkit-transition: width 0.4s ease-in-out;
            transition: width 0.4s ease-in-out;
        }

        .diiosearch:focus {
            width: 130%;
        }

        </style>

        <!-- =============== LARGE DROPDOWN (MORE)========= -->
          <style type="text/css">
           /* @import url(http://fonts.googleapis.com/css?family=Open+Sans:400,700);
          body {
            font-family: 'Open Sans', 'sans-serif';
          }*/
          .mega-dropdown {
            position: static !important;
          }
          .mega-dropdown-menu {
              padding: 20px 0px;
              width: 100%;
              box-shadow: none;
              -webkit-box-shadow: none;
          }
          .mega-dropdown-menu > li > ul {
            padding: 0;
            margin: 0;
          }
          .mega-dropdown-menu > li > ul > li {
            list-style: none;
          }
          .mega-dropdown-menu > li > ul > li > a {
            display: block;
            color: #222;
            padding: 3px 5px;
          }
          .mega-dropdown-menu > li ul > li > a:hover,
          .mega-dropdown-menu > li ul > li > a:focus {
            text-decoration: none;
          }
          .mega-dropdown-menu .dropdown-header {
            font-size: 18px;
            color: #ff3546;
            padding: 5px 60px 5px 5px;
            line-height: 30px;
          }

          .diioHover: hover {
            color: red;
             background: yellow;
          }

          /*.carousel-control {
            width: 30px;
            height: 30px;
            top: -35px;

          }
          .left.carousel-control {
            right: 30px;
            left: inherit;
          }*/
          /*.carousel-control .glyphicon-chevron-left, 
          .carousel-control .glyphicon-chevron-right {
            font-size: 12px;
            background-color: #fff;
            line-height: 30px;
            text-shadow: none;
            color: #333;
            border: 1px solid #ddd;
          }*/
          </style>
          <!-- =================== END MORE==================== -->


    </head>

<body style="background-color: #F5F5F5;" >
    
    <nav class="top-bar">
      <div class="container">
        <div class="row">
        <div class="col-sm-4 hidden-xs">
            <span class="nav-text">
               <!--  <i class="fa fa-phone" aria-hidden="true"></i>  +123 4567 8910 
                <i class="fa fa-envelope" aria-hidden="true"></i> sumi9xm@gmail.com</span> -->
                <i class="fa fa-book" aria-hidden="true"></i>&nbsp;&nbsp;<b style="font-size: 16px;">eHuduma</b>
            </div>
        <div class="col-sm-4 text-center">
            <a href="https://www.facebook.com/" target="_blank" class="social"><i class="fa fa-facebook" aria-hidden="true"></i></a>
            <a href="https://twitter.com/signup?lang=en" target="_blank" class="social"><i class="fa fa-twitter" aria-hidden="true"></i></a>
            <a href="https://www.instagram.com/accounts/login/" target="_blank" class="social"><i class="fa fa-instagram" aria-hidden="true"></i></a>
            <a href="https://www.youtube.com/" target="_blank" class="social"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
            <a href="https://plus.google.com/discover" target="_blank" class="social"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
            <!-- <a href="#" class="social"><i class="fa fa-dribbble" aria-hidden="true"></i></a> -->
        </div>
        <div class="col-sm-4 text-right hidden-xs">
                <ul class="tools">  

                <?php if ($this->session->userdata('logged_in')) { ?>

                  <li class="">
                    <!-- <a href="<?php //echo base_url('Profile/createProfile');?>" class="btn btn-md btn-pill btn-info" ><b>Logged In As : <?php //echo $this->session->userdata('user_name');?></b></a> -->
                  <a href="<?php echo base_url('Admin');?>" class="btn btn-md btn-pill btn-info" ><b>My Account</b></a>
                  </li>

                <?php } else { ?>
                  <li class="">
                  <button type="button" class="btn btn-md btn-pill btn-outline btn-default" data-toggle="modal" data-target="#modal-login"><?php echo $this->lang->line('msg_login'); ?></button>
                  </li>
                  <li class="">
                   <button type="button" class="btn btn-md btn-pill btn-default" data-toggle="modal" data-target="#modal-register"><?php echo $this->lang->line('msg_register'); ?></button>
                  </li> 

                <?php } ?>
                
               
                <li class="dropdown">
                      <label style="color: #fff;" for=""><b><i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $this->lang->line('msg_language'); ?>:&nbsp;&nbsp;&nbsp;</i></b></label>
                      <select class="pull-right" onchange="javascript:window.location.href='<?php echo base_url(); ?>Home/switchLang/'+this.value;">
                          <option value="english" <?php if($this->session->userdata('site_lang') == 'english') echo 'selected="selected"'; ?>>English</option>
                          <option value="kiswahili" <?php if($this->session->userdata('site_lang') == 'kiswahili') echo 'selected="selected"'; ?>>Kiswahili</option> 
                      </select>
                </li>
                                      
                </ul>
              </div>
        </div>
      </div>
    </nav>   <!--TOP-NAVBAR-END-->
    
    
<!--====================== NAVBAR MENU START===================-->
    
  
<nav class="navbar navbar-inverse">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
     <!--  <a class="navbar-brand" href="#"><img src="https://lh3.googleusercontent.com/-N4NB2F966TU/WM7V1KYusRI/AAAAAAAADtA/fPvGVNzOkCo7ZMqLI6pPITE9ZF7NONmawCJoC/w185-h40-p-rw/logo.png"></a> -->
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
    <div class="row">
      <div class="col-md-9">
        <ul class="nav navbar-nav navbar-left">
          <li class=""><a href="<?php echo base_url('Home');?>"><b><?php echo $this->lang->line('msg_home'); ?></b></a></li>
          <!-- <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="<?php //echo base_url('Artical/articalPage');?>"><b>ARTICALS </b><span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="<?php //echo base_url('Artical/articalPage');?>">Huduma Articals</a></li>
              <li><a href="#">Artical - 2</a></li>
              <li><a href="#">Artical - 3</a></li>
            </ul>
          </li> -->
            <li><a href="<?php echo base_url('Artical/articalPage');?>"><b><?php echo $this->lang->line('msg_blog'); ?></b></a></li>
            <li><a href="<?php echo base_url('Home/FAQ');?>"><b><?php echo $this->lang->line('msg_faq'); ?></b></a></li>
            <li><a href="<?php echo base_url('Artical/hudumaNews');?>"><b><?php echo $this->lang->line('msg_quick_deals'); ?></b></a></li>

            <!-- =============== LARGE DROPDOWN (MORE)========= -->
            <li class="dropdown mega-dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><b><?php echo $this->lang->line('msg_profiles_title'); ?> </b><span class="caret"></span></a>        
            <ul class="dropdown-menu mega-dropdown-menu" >
              <li class="col-sm-3">
                  <ul>
                  <li class="dropdown-header"><?php echo $this->lang->line('msg_professionals'); ?></li>
                  <li class="diioHover"><a href="<?php echo base_url('Profile/profileList/');?>cat/Teacher"><?php echo $this->lang->line('msg_teacher'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Doctor"><?php echo $this->lang->line('msg_doctor'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Techinician"><?php echo $this->lang->line('msg_technician'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Animal Keeping"><?php echo $this->lang->line('msg_animal_keeper'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Agriculturist"><?php echo $this->lang->line('msg_farming_expert'); ?></a></li>

                  <li class="divider"></li>
                  <li class="dropdown-header"><?php echo $this->lang->line('msg_professionals'); ?><!-- </li><?php //echo $this->lang->line('msg_'); ?> -->
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Lawyor"><?php echo $this->lang->line('msg_lawyer'); ?> </a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Nurse"><?php echo $this->lang->line('msg_nurse'); ?> </a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Burser"><?php echo $this->lang->line('msg_bursar'); ?> </a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Sychologist"><?php echo $this->lang->line('msg_psychologist'); ?> </a></li>
                  
                </ul>
              </li>
              <li class="col-sm-3">
                <ul>
                  <li class="dropdown-header"><?php echo $this->lang->line('msg_professionals'); ?></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Interpreter"><?php echo $this->lang->line('msg_interpreter'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/translator"><?php echo $this->lang->line('msg_translator'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/programmer"><?php echo $this->lang->line('msg_programmer'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Master Ceremony"><?php echo $this->lang->line('msg_master_of_ceremony'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Driver"><?php echo $this->lang->line('msg_driver'); ?></a></li>
                  <li class="divider"></li>
                  <li class="dropdown-header"><?php echo $this->lang->line('msg_professionals'); ?></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Blocker"><?php echo $this->lang->line('msg_brocker'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Security Guard"><?php echo $this->lang->line('msg_security_guard'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Blogger"><?php echo $this->lang->line('msg_blogger'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Others"><?php echo $this->lang->line('msg_other_works'); ?></a></li>

                </ul>
              </li>
              <li class="col-sm-3">
                <ul>
                  <li class="dropdown-header"><?php echo $this->lang->line('msg_entrepreneurs'); ?></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Archtect"><?php echo $this->lang->line('msg_archtect'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Shop/ Market"><?php echo $this->lang->line('msg_shop'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Packing"><?php echo $this->lang->line('msg_parking'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Car Wash"><?php echo $this->lang->line('msg_car_wash'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Garage"><?php echo $this->lang->line('msg_garage'); ?></a></li>

                  <li class="divider"></li>
                  <li class="dropdown-header"><?php echo $this->lang->line('msg_entrepreneurs'); ?></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Bar"><?php echo $this->lang->line('msg_bar'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Saloon"><?php echo $this->lang->line('msg_salon'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Bakery"><?php echo $this->lang->line('msg_bakery'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Tution Center"><?php echo $this->lang->line('msg_tuition_centre'); ?></a></li>
      
                </ul>
              </li>
              <li class="col-sm-3">
                <ul>
                  <li class="dropdown-header"><?php echo $this->lang->line('msg_entrepreneurs'); ?></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/School"><?php echo $this->lang->line('msg_school'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Guest House"><?php echo $this->lang->line('msg_guest_house'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Hotel"><?php echo $this->lang->line('msg_hotel'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Cafe"><?php echo $this->lang->line('msg_restaurant'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Butcher"><?php echo $this->lang->line('msg_butcher'); ?></a></li> 

                  <li class="divider"></li>
                  <li class="dropdown-header"><?php echo $this->lang->line('msg_entrepreneurs'); ?></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Day care"><?php echo $this->lang->line('msg_day_care'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Online Marketer"><?php echo $this->lang->line('msg_online_marketers'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Insurance"><?php echo $this->lang->line('msg_insurance'); ?></a></li>
                  <li><a href="<?php echo base_url('Profile/profileList/');?>cat/Others"><?php echo $this->lang->line('msg_other_business_works'); ?></a></li>

      
                </ul>
              </li>

               <!-- <li class="col-sm-3">
                  <ul>
                  <li class="dropdown-header">eHuduma Services</li>                            
                                <div id="womenCollection" class="carousel slide" data-ride="carousel">
                                  <div class="carousel-inner">
                                    <div class="item active">
                                        <a href="#"><img src="http://placehold.it/254x150/3498db/f5f5f5/&text=New+Collection" class="img-responsive" alt="product 1"></a>
                                        <h4><small>Summer dress floral prints</small></h4>                                        
                                        <button class="btn btn-primary" type="button">49,99 €</button> <button href="#" class="btn btn-default" type="button"><span class="glyphicon glyphicon-heart"></span> Add to Wishlist</button>       
                                    </div>
                                    <div class="item">
                                        <a href="#"><img src="http://placehold.it/254x150/ff3546/f5f5f5/&text=New+Collection" class="img-responsive" alt="product 2"></a>
                                        <h4><small>Gold sandals with shiny touch</small></h4>                                        
                                        <button class="btn btn-primary" type="button">9,99 €</button> <button href="#" class="btn btn-default" type="button"><span class="glyphicon glyphicon-heart"></span> Add to Wishlist</button>        
                                    </div>
                                    <div class="item">
                                        <a href="#"><img src="http://placehold.it/254x150/2ecc71/f5f5f5/&text=New+Collection" class="img-responsive" alt="product 3"></a>
                                        <h4><small>Denin jacket stamped</small></h4>                                        
                                        <button class="btn btn-primary" type="button">49,99 €</button> <button href="#" class="btn btn-default" type="button"><span class="glyphicon glyphicon-heart"></span> Add to Wishlist</button>      
                                    </div>                            
                                  </div>
                                 
                                  <a class="left carousel-control" href="#womenCollection" role="button" data-slide="prev">
                                    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                    <span class="sr-only">Previous</span>
                                  </a>
                                  <a class="right carousel-control" href="#womenCollection" role="button" data-slide="next">
                                    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                    <span class="sr-only">Next</span>
                                  </a>
                                </div>
                                <li class="divider"></li>
                                <li><a href="#">View all Collection <span class="glyphicon glyphicon-chevron-right pull-right"></span></a></li>
                </ul>
              </li> -->


            </ul>       
          </li>
          <!-- =================== END MORE==================== -->

          <!-- <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#"><b>NEWS</b> <span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="<?php //echo base_url('Profile');?>">All Profiles</a></li>
              <li><a href="#">News - 2</a></li>
              <li><a href="#">News - 3</a></li>
            </ul>
          </li> -->
          <li><a href="<?php echo base_url('Home/aboutUs');?>"><b style="color: blue;"><?php echo $this->lang->line('msg_about_us'); ?></b></a></li>
          <li><a href="<?php echo base_url('Home/contactUs');?>"><b style="color: red;"><?php echo $this->lang->line('msg_contact_us'); ?></b></a></li>
          <?php if ($this->session->userdata('logged_in')) { ?>
            <li class="hidden-md hidden-lg" ><a href="<?php echo base_url('Admin');?>"><b style="color: ;"><?php echo $this->lang->line('msg_myaccount'); ?></b></a></li>
          <?php } else { ?>
            <li class="hidden-md hidden-lg"><a href="" data-toggle="modal" data-target="#modal-login"><b style="color: ;"><?php echo $this->lang->line('msg_login'); ?></b></a></li>
            <li class="hidden-md hidden-lg"><a href="" data-toggle="modal" data-target="#modal-register" ><b style="color: ;"><?php echo $this->lang->line('msg_register'); ?></b></a></li>
          <?php } ?>
        </ul>
      </div>

       <div class="col-md-3">
           <form class="navbar-form navbar-right" action="<?php echo base_url('Home/searchResults');?>" method="post" enctype="multipart/form-data">
            <div class="input-group">  
              <div class="input-group-btn">
                <button class="btn btn-default-1" name="searchBtn" value="ok" type="submit">
                  <i class="glyphicon glyphicon-search"></i>
                </button>
              </div>
              <input type="text" name="search" class="form-control diiosearch" style="" placeholder="<?php echo $this->lang->line('msg_search'); ?>" required="">      
            </div>
                
             <!--  <span class="cart-heart  hidden-sm hidden-xs"> 
                  <a href="#"><i class="fa fa-user" aria-hidden="true"></i></a>
                  <a href="#"><i class="fa fa-cart-plus" aria-hidden="true"></i></a>
              </span> 
              <span class="cart-heart  hidden-md hidden-lg">          
                  <a href="#"><i class="fa fa-heart" aria-hidden="true"></i></a>
                  <a href="#"><i class="fa fa-cart-plus" aria-hidden="true"></i></a>
                  <a href="#"><i class="fa fa-user" aria-hidden="true"></i></a>
                  <a href="#"><i class="fa fa-globe" aria-hidden="true"></i></a>
                  <a href="#"><i class="fa fa-usd" aria-hidden="true"></i></a>
              </span>    -->

          </form>
      </div>
      
    </div>
      
     
        
    </div>
  </div>
</nav>


<!-- ============= PAGE MIDDLE CONTENT ========== -->
  <?php 
     $this->load->view($middle_m.'/'.$middle_f);
   ?>        

<!-- ============= END MIDDLE CONTENTS =========== -->


<!-- ============== PAGE BEFORE FOOTER ============ -->
 <?php 
     $this->load->view($bfooter_m.'/'.$bfooter_f);
   ?> 
<!-- =============== END BEFORE FOOTER ============ -->



<!-- =============== ABOUT HUDUMA ============ -->
<div class="row" style="padding: 20px 50px 20px 50px; background-color: #fff;">
  <div class="col-md-12" style="text-align: center;">
    <h1><b><?php echo $this->lang->line('msg_about_huduma'); ?></b></h1>
    <p style="font-size: 20px;"><?php echo $this->lang->line('msg_about_simple_text'); ?></p>
      <b style="font-size: 24px;"><a href="<?php echo base_url('Home/aboutUs');?>"><?php echo $this->lang->line('msg_read_more'); ?><i class="fa fa-arrow-circle-right"></i></a></b>
    <hr>
  </div>
</div>
<!-- =============== END ABOUT HUDUMA ============ -->


<!-- =============== HUDUMA SERVICES ============ -->
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css"> -->
<!-- <link rel="stylesheet" href="http://cdn.bootcss.com/animate.css/3.5.1/animate.min.css"> -->
<div class="row" style="text-align: center;">
  
  <h1><b><?php echo $this->lang->line('msg_our_services'); ?></b></h1>
  
  <div class="col-md-4 wow animated fadeInLeft" style="text-align: center;">
  <a href="<?php echo base_url('Home/ourServices');?>">
    <span><i style="color: #00C0EF;" class="fa fa-users fa-fw fa-5x"></i></span>
    <h3><?php echo $this->lang->line('msg_user_profiles'); ?></h3>
    <hr>
  </a>
  </div>

  <div class="col-md-4 animated swing infinite" style="text-align: center;">
  <a href="<?php echo base_url('Home/ourServices');?>">
    <span><i style="color: #00C0EF;" class="fa fa-shopping-cart fa-fw fa-5x"></i></span>
    <h3><?php echo $this->lang->line('msg_business_profiles'); ?></h3>
    <hr>
  </a>
  </div>

  <div  class="col-md-4 wow animated fadeInRight"  style="text-align: center;">
  <a href="<?php echo base_url('Home/ourServices');?>">
    <span><i style="color: #00C0EF;" class="fa fa-calendar fa-fw fa-5x"></i></span>
    <h3><?php echo $this->lang->line('msg_profile_timetable'); ?></h3>
    <hr>
  </a>
  </div>

  <div class="col-md-4 wow animated fadeInLeft" style="text-align: center;">
  <a href="<?php echo base_url('Home/ourServices');?>">
    <span><i style="color: #00C0EF;" class="fa fa-bullhorn fa-fw fa-5x"></i></span>
    <h3><?php echo $this->lang->line('msg_advertisements'); ?></h3>
    <hr>
  </a>
  </div>

  <div class="col-md-4 animated swing infinite" style="text-align: center;">
  <a href="<?php echo base_url('Home/ourServices');?>">
    <span><i style="color: #00C0EF;" class="fa fa-bullseye fa-fw fa-5x"></i></span>
    <h3><?php echo $this->lang->line('msg_marketing'); ?></h3>
    <hr>
  </a>
  </div>

  <div class="col-md-4 wow animated fadeInRight" style="text-align: center;">
    <a href="<?php echo base_url('Home/ourServices');?>">
      <span><i style="color: #00C0EF;" class="fa fa-clock-o fa-fw fa-5x"></i></span>
      <h3><?php echo $this->lang->line('msg_appointments'); ?></h3>
      <hr>
    </a>
  </div>

</div>
<!-- =============== END HUDUMA SERVICES ============ -->
    
    
<!--  ================ FOOTER START================== -->
    
    <footer class="footer">
    <div class="container">
        <div class="row">
        <div class="col-sm-3" style="text-align: justify;" >
            <h4 class="title">eHuduma</h4>
            <p><?php echo $this->lang->line('msg_this_site_text'); ?></p>
            <ul class="social-icon">
            <a href="https://www.facebook.com/" target="_blank" class="social"><i class="fa fa-facebook" aria-hidden="true"></i></a>
            <a href="https://twitter.com/signup?lang=en" target="_blank" class="social"><i class="fa fa-twitter" aria-hidden="true"></i></a>
            <a href="https://www.instagram.com/accounts/login/" target="_blank" class="social"><i class="fa fa-instagram" aria-hidden="true"></i></a>
            <a href="https://www.youtube.com/" target="_blank" class="social"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
            <a href="https://plus.google.com/discover" target="_blank" class="social"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
            <!-- <a href="#" class="social"><i class="fa fa-dribbble" aria-hidden="true"></i></a> -->
            </ul>
            </div>
        <div class="col-sm-3 center">
            <h4 class="title"><?php echo $this->lang->line('msg_profile_types'); ?></h4>
            <span class="acount-icon">          
              <a href="<?php echo base_url('Profile/profileList/');?>type/PROFESSIONAL"><i class="fa fa-user" aria-hidden="true"></i> <?php echo $this->lang->line('msg_professionals'); ?></a>
              <a href="<?php echo base_url('Profile/profileList/');?>type/INTERPRENOUR"><i class="fa fa-shopping-cart" aria-hidden="true"></i> <?php echo $this->lang->line('msg_entrepreneurs'); ?></a>
              <!-- <a href="<?php //echo base_url('Profile/profileList/');?>type/BUSINESS MAN"><i class="fa fa-heart" aria-hidden="true"></i> Business Man</a>
              <a href="<?php //echo base_url('Profile/profileList/');?>type/POLITICIAN"><i class="fa fa-globe" aria-hidden="true"></i> Politicians</a>    -->
              <a href="<?php echo base_url('Profile/profileList/');?>type/OTHERS"><i class="fa fa-tasks" aria-hidden="true"></i> <?php echo $this->lang->line('msg_others'); ?></a>         
            </span>
        </div>
        <div class="col-sm-3">
            <h4 class="title"> <?php echo $this->lang->line('msg_profile_category'); ?></h4>
            <div class="category">
              <a href="<?php echo base_url('Profile/profileList/');?>cat/Teacher"><?php echo $this->lang->line('msg_teacher'); ?></a>
              <a href="<?php echo base_url('Profile/profileList/');?>cat/Doctor"><?php echo $this->lang->line('msg_doctor'); ?></a>
              <a href="<?php echo base_url('Profile/profileList/');?>cat/Psychologist"><?php echo $this->lang->line('msg_psychologist'); ?></a>
              <a href="<?php echo base_url('Profile/profileList/');?>cat/Translator"><?php echo $this->lang->line('msg_translator'); ?></a>
              <a href="<?php echo base_url('Profile/profileList/');?>cat/Lawyor"><?php echo $this->lang->line('msg_lawyer'); ?></a>
              <a href="<?php echo base_url('Profile/profileList/');?>cat/Nurse"><?php echo $this->lang->line('msg_nurse'); ?></a>
              <!-- <a href="<?php //echo base_url('Profile/profileList/');?>cat/Burser">Burser</a> -->
              <a href="<?php echo base_url('Profile/profileList/');?>cat/Interpreter"><?php echo $this->lang->line('msg_interpreter'); ?></a>
              <a href="<?php echo base_url('Profile/profileList/');?>cat/Blogger"><?php echo $this->lang->line('msg_blogger'); ?></a>
              <a href="<?php echo base_url('Profile/profileList/');?>cat/Master Ceremony"><?php echo $this->lang->line('msg_master_of_ceremony'); ?></a>
              <a href="<?php echo base_url('Profile/profileList/');?>cat/Techinician"><?php echo $this->lang->line('msg_technician'); ?></a>
              <a href="<?php echo base_url('Profile/profileList/');?>cat/Agriculturist"><?php echo $this->lang->line('msg_farming_expert'); ?></a>
              <a href="<?php echo base_url('Profile/profileList/');?>cat/Programmer"><?php echo $this->lang->line('msg_programmer'); ?></a>
              <a href="<?php echo base_url('Profile/profileList/');?>cat/Blocker"><?php echo $this->lang->line('msg_blocker'); ?></a>
              <!-- <a href="Interpreter">Interpreter</a>
              <a href="Journalist">Journalist</a>
              <a href="Press">Press</a>
              <a href="Driver">Driver</a>
              <a href="Dalali">Dalali</a>
              <a href="Archtect">Archtect</a>
              <a href="Packing">Packing</a>
              <a href="Garage">Garage</a>
              <a href="Bar">Bar</a>
              <a href="Saloon">Saloon</a>
              <a href="Bakery">Bakery</a>
              <a href="School">School</a>
              <a href="Hotel">Hotel</a>
              <a href="Cafe">Cafe</a>
              <a href="Company">Company</a>
              <a href="Butcher">Butcher</a>
              <a href="Institute">Institute</a>
              <a href="President">President</a> -->      
            </div>
        </div>
        <div class="col-sm-3" style="text-align: center;">
            <h4 class="title"><?php echo $this->lang->line('msg_social_media'); ?></h4>
            <p><b><?php echo $this->lang->line('msg_visit_our_pages'); ?></b></p>
            <ul class="social-icon">
            <a href="https://www.facebook.com/" target="_blank" class="social"><i class="fa fa-facebook" aria-hidden="true"></i></a>
            <a href="https://twitter.com/signup?lang=en" target="_blank" class="social"><i class="fa fa-twitter" aria-hidden="true"></i></a>
            <a href="https://www.instagram.com/accounts/login/" target="_blank" class="social"><i class="fa fa-instagram" aria-hidden="true"></i></a>
            <a href="https://www.youtube.com/" target="_blank" class="social"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
            <a href="https://plus.google.com/discover" target="_blank" class="social"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
            <!-- <a href="#" class="social"><i class="fa fa-dribbble" aria-hidden="true"></i></a> -->
            </ul>

            <h4 class="title"><?php echo $this->lang->line('msg_our_contacts'); ?></h4>
            <ul style="text-align: left;" >
               <b><?php echo $this->lang->line('msg_pobox'); ?></b><br>
               <b><?php echo $this->lang->line('msg_phone'); ?></b><br>
               <b><?php echo $this->lang->line('msg_email'); ?></b><br>
            </ul>

            </div>
        </div>
        <hr>
        <a href="javascript:;" class="to-top pull-right"><i class="fa fa-chevron-up"></i></a>
        <div class="row text-center"><a href="<?php echo base_url('Home/ourPrivacy');?>">Privacy</a> | <a href="<?php echo base_url('Home/ourTerms');?>">Terms</a><br> © Uwezomedia Limited 2018 - All Rights Reserved   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Developer; Diio (+255-684-670-270 | +255-684-544-167)<!-- 2017. by Dionizi France (+255-752-194-092 | +255-684-544-167) --></div>
        </div>
        
        
    </footer>
    
   


<!-- jQuery 2.0.2 -->
 <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
        <script src="<?php echo base_url('assets/ajax/jquery.min.js');?>" type="text/javascript"></script>
       <!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script> -->
        <!-- Bootstrap -->
        <script src="<?php echo base_url('assets/js/bootstrap.min.js');?>" type="text/javascript"></script>
        <!-- AdminLTE App -->
        <script src="<?php echo base_url('assets/js/AdminLTE/app.js');?>" type="text/javascript"></script>
        <!--  scroll to top -->
        <script src="<?php echo base_url('assets/js/scrolltotop.js');?>" type="text/javascript"></script>
        <!--  wow for animation -->
        <script src="<?php echo base_url('assets/js/myjs/wow.js');?>" type="text/javascript"></script>
        <!--  search inputs top -->
        <!-- <script src="<?php //echo base_url('assets/js/myJs/profilesch.js');?>" type="text/javascript"></script> -->
        <!-- submit a form without refresh  -->
        <script type="text/javascript">
            $("#signup_btn").click(function (e) {
                  e.preventDefault();
                  // code
                }
        </script>

        <!-- Popover -->
        <script>

          $(document).ready(function(){
              $('[data-toggle="popover"]').popover(); 
          });
        </script>

        <script>
            function SignIn(){
              //Login form
            $('form.jsloginform').on('submit', function(form){
                  form.preventDefault();
                  var url = '<?php echo base_url('Home/login')?>';
                  var username = $('#login_username').val();
                  var password = $('#login_password').val();
                  if (username != '' && password != '') {
                    $.ajax({
                      url: url,
                      method: "POST",
                      data: {username:username, password:password},
                      success: function(data){
                        if(data=='go'){
                          $('#loginModal').hide();
                          window.location="<?php echo base_url('Admin/login')?>";
                        }else{
                          $('div.errordiv').html(data);
                          $('div.errordiv').show();
                        }
                      }
                    });
                    }else{
                      alert('Both username and password are required');
                    }
              });
            };

            //End of Login form scripts

             function SignUp(){
              //Login form
            $('form.jssignupform').on('submit', function(form){
                  form.preventDefault();
                  var url = '<?php echo base_url('Home/login')?>';
                  
                    $.ajax({
                      url: url,
                      method: "POST",
                      success: function(data){
                        if(data=='go'){
                          $('#loginModal').hide();
                          window.location="<?php echo base_url('Admin/login')?>";
                        }else{
                          $('div.errordiv').html(data);
                          $('div.errordiv').show();
                        }
                      }
                    });
                    

              });
            };

            //End of signup form scripts
        </script> 

       <!--  =============== TOP DROPDOWN========= -->
        <script type="text/javascript">
          $(document).ready(function(){
            $(".dropdown").hover(            
                function() {
                    $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideDown("400");
                    $(this).toggleClass('open');        
                },
                function() {
                    $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideUp("400");
                    $(this).toggleClass('open');       
                }
            );
        });
        </script>
       <!--  ==========END DROPDOWN============ -->

        

</body>
</html>






<!-- ===================== MODALS ==================== -->
<!-- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx- -->
<style type="text/css">
    
.modal-content {
    -webkit-border-radius: 0;
    -webkit-background-clip: padding-box;
    -moz-border-radius: 0;
    -moz-background-clip: padding;
    border-radius: 6px;
    background-clip: padding-box;
    -webkit-box-shadow: 0 0 40px rgba(0,0,0,.5);
    -moz-box-shadow: 0 0 40px rgba(0,0,0,.5);
    box-shadow: 0 0 40px rgba(0,0,0,.5);
    color: #000;
    background-color: #fff;
    border: rgba(0,0,0,0);
}
.modal-message .modal-dialog {
    width: 300px;
}
.modal-message .modal-body, .modal-message .modal-footer, .modal-message .modal-header, .modal-message .modal-title {
    background: 0 0;
    border: none;
    margin: 0;
    padding: 0 30px;
    text-align: center!important;
}

.modal-message .modal-title {
    font-size: 17px;
    color: #737373;
    margin-bottom: 3px;
}

.modal-message .modal-body {
    color: #737373;
}

.modal-message .modal-header {
    color: #fff;
    margin-bottom: 10px;
    padding: 15px 0 8px;
}
.modal-message .modal-header .fa, 
.modal-message .modal-header 
.glyphicon, .modal-message 
.modal-header .typcn, .modal-message .modal-header .wi {
    font-size: 30px;
}

.modal-message .modal-footer {
    margin: 25px 0 20px;
    padding-bottom: 10px;
}

.modal-backdrop.in {
    zoom: 1;
    filter: alpha(opacity=75);
    -webkit-opacity: .75;
    -moz-opacity: .75;
    opacity: .75;
}
.modal-backdrop {
    background-color: #fff;
}
.modal-message.modal-success .modal-header {
    color: #53a93f;
    border-bottom: 3px solid #a0d468;
}

.modal-message.modal-info .modal-header {
    color: #57b5e3;
    border-bottom: 3px solid #57b5e3;
}

.modal-message.modal-danger .modal-header {
    color: #d73d32;
    border-bottom: 3px solid #e46f61;
}

.modal-message.modal-warning .modal-header {
    color: #f4b400;
    border-bottom: 3px solid #ffce55;
}

</style>

<!-- ===================== LOOGIN MODAL STARTS ============== -->
    <!--Info Modal Templates-->
    <div id="modal-login" class="modal modal-message modal-info fade" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <i class="fa fa-login"></i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b style="font-size: 24px;"><?php echo $this->lang->line('msg_login'); ?></b>
                </div>
                <div class="modal-title"></div>

                <div class="modal-body">
                     <form action="<?php echo base_url('Home/login')?>" method="post">
                              <div class="form-group">
                                  <label for="username" class="control-label"><?php echo $this->lang->line('msg_mdl_username'); ?></label>
                                  <input type="text" class="form-control" id="username" name="username" value="" required="" title="Please enter you username" placeholder="<?php echo $this->lang->line('msg_mdl_username'); ?>">
                                  <span class="help-block"></span>
                              </div>
                              <div class="form-group">
                                  <label for="password" class="control-label"><?php echo $this->lang->line('msg_mdl_password'); ?></label>
                                  <input type="password" class="form-control" id="password" name="password" value="" required="" title="Please enter your password" placeholder="<?php echo $this->lang->line('msg_mdl_password'); ?>">
                                  <span class="help-block"></span>
                              </div>
                              <div id="loginErrorMsg" class="alert alert-error hide">Wrong username oR password</div>
                              <div class="checkbox">
                                  <label>
                                      <input type="checkbox" name="remember" id="remember"> <?php echo $this->lang->line('msg_mdl_remember'); ?>
                                  </label>
                              </div>
                              <button type="submit" name="loginBtn" value="ok" class="btn btn-info btn-block"><?php echo $this->lang->line('msg_mdl_login'); ?></button>
                              <br>
                              <a href="<?php echo base_url('Home/ourPrivacy'); ?>"   class=""><b><?php echo $this->lang->line('msg_mdl_privacy'); ?></b></a> | <a href="<?php echo base_url('Home/ourTerms'); ?>"  class=""><b><?php echo $this->lang->line('msg_mdl_terms'); ?></b></a>
                              <br>
                              <a href="" data-dismiss="modal" data-toggle="modal" data-target="#modal-register" class=""><b><?php echo $this->lang->line('msg_mdl_dont_have_account'); ?></b></a>
                          </form>
                </div>

                <div class="modal-footer">
                    <!-- <button type="button" class="btn btn-danger" data-dismiss="modal">OK</button> -->
                </div>
                
            </div> <!-- / .modal-content -->
        </div> <!-- / .modal-dialog -->
    </div>
    <!--End Info Modal Templates-->
<!-- ====================== END LOGIN MODAL ================ -->


<!-- ====================== REFIGSTER MODAL STARTS ============ -->
 
    <!--Info Modal Templates-->
    <div id="modal-register" class="modal modal-message modal-info fade" style="display: none;" aria-hidden="true">
        <div class="modal-dialog  modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <i class="fa fa-login"></i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b style="font-size: 24px;"><?php echo $this->lang->line('msg_register'); ?></b>
                </div>
                <div class="modal-title"></div>

                <div class="modal-body">
                     <form action="<?php echo base_url('Users/userReg')?>" method="post">
                              <div class="form-group">
                                  <!-- <label for="username" class="control-label">Full Name</label> -->
                                  <input type="text" class="form-control" id="name" name="name" value="" required="" title="Please enter you username" placeholder="<?php echo $this->lang->line('msg_mdl_name'); ?>">
                                  <span class="help-block"></span>
                              </div>
                              <div class="form-group">
                                  <!-- <label for="username" class="control-label">Username</label> -->
                                  <input type="text" class="form-control" id="username" name="username" value="" required="" title="Please enter you username" placeholder="<?php echo $this->lang->line('msg_mdl_username'); ?>">
                                  <span class="help-block"></span>
                              </div>
                              <div class="form-group">
                                 <!--  <label for="username" class="control-label">Email Adress</label> -->
                                  <input type="email" class="form-control" id="email" name="email" value=""  title="Please enter you username" placeholder="<?php echo $this->lang->line('msg_mdl_email'); ?>">
                                  <span class="help-block"></span>
                              </div>
                              <div class="form-group">
                                  <!-- <label for="password" class="control-label">Password</label> -->
                                  <input type="password" class="form-control" id="password" name="password" value="" required="" placeholder="<?php echo $this->lang->line('msg_mdl_password'); ?>">
                                  <span class="help-block"></span>
                              </div>
                              <div class="form-group">
                                  <!-- <label for="password" class="control-label">Confirm Password</label> -->
                                  <input type="password" class="form-control" id="cpassword" name="cpassword" value="" required="" placeholder="<?php echo $this->lang->line('msg_mdl_cpassword'); ?>">
                                  <span class="help-block"></span>
                              </div>

                              <div id="regErrorMsg" class="alert alert-error hide">Registration Complete.!</div>
                             
                              <button type="submit" class="btn btn-info btn-block"><?php echo $this->lang->line('msg_mdl_register'); ?></button>
                              <br>
                              <a href="<?php echo base_url('Home/ourPrivacy'); ?>"   class=""><b><?php echo $this->lang->line('msg_mdl_privacy'); ?></b></a> | <a href="<?php echo base_url('Home/ourTerms'); ?>"  class=""><b><?php echo $this->lang->line('msg_mdl_terms'); ?></b></a>
                              <br>
                              <a href="" data-dismiss="modal" data-toggle="modal" data-target="#modal-login" class=""><b><?php echo $this->lang->line('msg_mdl_arlead_registered'); ?></b></a>
                          </form>
                </div>

                <div class="modal-footer">
                    <!-- <button type="button" class="btn btn-danger" data-dismiss="modal">OK</button> -->
                </div>
                
            </div> <!-- / .modal-content -->
        </div> <!-- / .modal-dialog -->
    </div>
    <!--End Info Modal Templates-->
<!-- ====================== END REGISTER MODAL ================ -->







<!-- xxxxxxxxxxxxxxxxxxxxxxxx other modals xxxxxxxxxxxxxxxxxxxxxxxx -->
<!-- <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<div class="buttons-preview">
    <button class="btn btn-success" data-toggle="modal" data-target="#modal-success">Success</button>
    <button class="btn btn-info" data-toggle="modal" data-target="#modal-info">Info</button>
    <button class="btn btn-danger" data-toggle="modal" data-target="#modal-danger">Danger</button>
    <button class="btn btn-warning" data-toggle="modal" data-target="#modal-warning">Warning</button>
</div>
 -->
 <!--Success Modal Templates-->
    <div id="modal-success" class="modal modal-message modal-success fade" style="display: none;" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <i class="glyphicon glyphicon-check"></i>
                </div>
                <div class="modal-title">Success</div>
                <div class="modal-body">You have done great!</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" data-dismiss="modal">OK</button>
                </div>
            </div> <!-- / .modal-content -->
        </div> <!-- / .modal-dialog -->
    </div>
    <!--End Success Modal Templates-->
        <!--Danger Modal Templates-->
    <div id="modal-danger" class="modal modal-message modal-danger fade" style="display: none;" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <i class="glyphicon glyphicon-fire"></i>
                </div>
                <div class="modal-title">Alert</div>

                <div class="modal-body">You've done bad!</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">OK</button>
                </div>
            </div> <!-- / .modal-content -->
        </div> <!-- / .modal-dialog -->
    </div>
    <!--End Danger Modal Templates-->




    <!--Danger Modal Templates-->
    <div id="modal-warning" class="modal modal-message modal-warning fade" style="display: none;" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <i class="fa fa-warning"></i>
                </div>
                <div class="modal-title">Warning</div>

                <div class="modal-body">Is something wrong?</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-dismiss="modal">OK</button>
                </div>
            </div> <!-- / .modal-content -->
        </div> <!-- / .modal-dialog -->
    </div>
    <!--End Danger Modal Templates-->



    <!-- ========== animate script========= -->
    <script type="text/javascript">
      new WOW().init();
    </script>