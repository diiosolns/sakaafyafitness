<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<!--  search inputs top -->
<script src="<?php echo base_url('assets/js/myJs/profilesch.js');?>" type="text/javascript"></script> 

<!-- <?php echo $this->lang->line('msg_'); ?> -->

<!-- =================CAROUSELE START (LARGE DEVICES)==================== --> 
 <div id="myCarousel" class="carousel slide hidden-xs hidden-sm" data-ride="carousel" data-interval="false">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
    
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
       <img src="<?php echo base_url('assets/img/slider/slider_01.jpg');?>" width="1366px" height="700px">
      <!-- <div class="carousel-caption hidden-xs" style="text-align: center;"> -->
        <div class="carousel-caption  animated fadeInUp" style="text-align: center;">
        <h3><?php echo $this->lang->line('msg_large_caption'); ?></h3>
        <p><?php echo $this->lang->line('msg_small_caption'); ?></p>
        <div class="homesch">
         <form class="form-style-1" action="<?php echo base_url('Profile/profileList')?>" method="post">
          <div class="row">
           <div class="col-md-4" style="opacity: 1;">
              <select  class="form-control input-md" name="type" id="type" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_type'); ?></option>
                <option value="PROFESSIONAL"><?php echo $this->lang->line('msg_professionals'); ?></option>
                <option value="INTERPRENOUR"><?php echo $this->lang->line('msg_entrepreneurs'); ?></option>
                <!-- <option value="BUSINESS MAN"><?php //echo $this->lang->line('msg_businessman'); ?></option> -->
                <!-- <option value="POLITICIAN">POLITICIAN</option> -->
                <option value="OTHERS"><?php echo $this->lang->line('msg_others'); ?></option>
              </select>
            </div>  
            <div class="col-md-4">
              <select class="form-control input-md" name="category" id="category" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_category'); ?></option>
              </select>
            </div> 
            <div class="col-md-4 ">
              <select class="form-control input-md" name="subcategory" id="subcategory" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_subcategory'); ?></option>
              </select>
            </div> 
            <div class="col-md-12" style="margin-top: 20px;">
              <button style="opacity: 1 !important;" type="submit" class="btn btn-danger btn-md">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $this->lang->line('msg_search_profile'); ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-search"></i></button>
            </div>
        </div>
        </form>
       </div>
      </div>
    </div>


    <div class="item">
       <img src="<?php echo base_url('assets/img/slider/slider_02.jpg');?>" width="1366px" height="700px">
      <!-- <div class="carousel-caption hidden-xs" style="text-align: center;"> -->
        <div class="carousel-caption  animated fadeInUp" style="text-align: center;">
        <h3><?php echo $this->lang->line('msg_large_caption'); ?></h3>
        <p><?php echo $this->lang->line('msg_small_caption'); ?></p>
        <div class="homesch">
         <form class="form-style-1" action="<?php echo base_url('Profile/profileList')?>" method="post">
          <div class="row">
           <div class="col-md-4" style="opacity: 1;">
              <select  class="form-control input-md" name="type" id="type1" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_type'); ?></option>
                <option value="PROFESSIONAL"><?php echo $this->lang->line('msg_professionals'); ?></option>
                <option value="INTERPRENOUR"><?php echo $this->lang->line('msg_entrepreneurs'); ?></option>
                <!-- <option value="BUSINESS MAN"><?php //echo $this->lang->line('msg_businessman'); ?></option> -->
                <!-- <option value="POLITICIAN">POLITICIAN</option> -->
                <option value="OTHERS"><?php echo $this->lang->line('msg_others'); ?></option>
              </select>
            </div>  
            <div class="col-md-4">
              <select class="form-control input-md" name="category" id="category1" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_category'); ?></option>
              </select>
            </div> 
            <div class="col-md-4 ">
              <select class="form-control input-md" name="subcategory" id="subcategory1" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_subcategory'); ?></option>
              </select>
            </div> 
            <div class="col-md-12" style="margin-top: 20px;">
              <button style="opacity: 1 !important;" type="submit" class="btn btn-danger btn-md">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $this->lang->line('msg_search_profile'); ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-search"></i></button>
            </div>
        </div>
        </form>
       </div>
      </div>
    </div>



    <div class="item ">
       <img src="<?php echo base_url('assets/img/slider/slider_03.jpg');?>" width="1366px" height="700px">
      <!-- <div class="carousel-caption hidden-xs" style="text-align: center;"> -->
        <div class="carousel-caption  animated fadeInUp" style="text-align: center;">
        <h3><?php echo $this->lang->line('msg_large_caption'); ?></h3>
        <p><?php echo $this->lang->line('msg_small_caption'); ?></p>
        <div class="homesch">
         <form class="form-style-1" action="<?php echo base_url('Profile/profileList')?>" method="post">
          <div class="row">
           <div class="col-md-4" style="opacity: 1;">
              <select  class="form-control input-md" name="type" id="type2" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_type'); ?></option>
                <option value="PROFESSIONAL"><?php echo $this->lang->line('msg_professionals'); ?></option>
                <option value="INTERPRENOUR"><?php echo $this->lang->line('msg_entrepreneurs'); ?></option>
                <!-- <option value="BUSINESS MAN"><?php //echo $this->lang->line('msg_businessman'); ?></option> -->
                <!-- <option value="POLITICIAN">POLITICIAN</option> -->
                <option value="OTHERS"><?php echo $this->lang->line('msg_others'); ?></option>
              </select>
            </div>  
            <div class="col-md-4">
              <select class="form-control input-md" name="category" id="category2" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_category'); ?></option>
              </select>
            </div> 
            <div class="col-md-4 ">
              <select class="form-control input-md" name="subcategory" id="subcategory2" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_subcategory'); ?></option>
              </select>
            </div> 
            <div class="col-md-12" style="margin-top: 20px;">
              <button style="opacity: 1 !important;" type="submit" class="btn btn-danger btn-md">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $this->lang->line('msg_search_profile'); ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-search"></i></button>
            </div>
        </div>
        </form>
       </div>
      </div>
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<!-- ==============  LARGE DEVICES END================= -->



<!-- =================CAROUSELE START (SMALL DEVICES)==================== --> 
 <div id="mysCarousel" class="carousel slide hidden-md hidden-lg" data-ride="carousel" data-interval="false">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#mysCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#mysCarousel" data-slide-to="1"></li>
    <li data-target="#mysCarousel" data-slide-to="2"></li>
    
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
       <img src="<?php echo base_url('assets/img/slider/slider_01s.jpg');?>" width="100%" height="auto">
      <!-- <div class="carousel-caption hidden-xs" style="text-align: center;"> -->
        <div class="carousel-caption  animated fadeInUp" style="text-align: center;">
        <h3><?php echo $this->lang->line('msg_large_caption'); ?></h3>
        <p><?php echo $this->lang->line('msg_small_caption'); ?></p>
        <div class="homesch">
         <form class="form-style-1" action="<?php echo base_url('Profile/profileList')?>" method="post">
          <div class="row">
           <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12" style="opacity: 1; padding-bottom: 10px;">
              <select  class="form-control input-md" name="type" id="stype" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_type'); ?></option>
                <option value="PROFESSIONAL"><?php echo $this->lang->line('msg_professionals'); ?></option>
                <option value="INTERPRENOUR"><?php echo $this->lang->line('msg_entrepreneurs'); ?></option>
                <!-- <option value="BUSINESS MAN"><?php //echo $this->lang->line('msg_businessman'); ?></option> -->
                <!-- <option value="POLITICIAN">POLITICIAN</option> -->
                <option value="OTHERS"><?php echo $this->lang->line('msg_others'); ?></option>
              </select>
            </div>  
            <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12" style="opacity: 1; padding-bottom: 10px;">
              <select class="form-control input-md" name="category" id="scategory" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_category'); ?></option>
              </select>
            </div> 
            <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12" style="opacity: 1; padding-bottom: 10px;">
              <select class="form-control input-md" name="subcategory" id="ssubcategory" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_subcategory'); ?></option>
              </select>
            </div> 
            <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12" style="margin-top: 20px;">
              <button style="opacity: 1 !important;" type="submit" class="btn btn-danger btn-md">&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $this->lang->line('msg_search_profile'); ?></b>&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-search"></i></button>
            </div>
        </div>
        </form>
       </div>
      </div>
    </div>


    <div class="item">
       <img src="<?php echo base_url('assets/img/slider/slider_02s.jpg');?>" width="100%" height="auto">
      <!-- <div class="carousel-caption hidden-xs" style="text-align: center;"> -->
        <div class="carousel-caption  animated fadeInUp" style="text-align: center;">
        <h3><?php echo $this->lang->line('msg_large_caption'); ?></h3>
        <p><?php echo $this->lang->line('msg_small_caption'); ?></p>
        <div class="homesch">
         <form class="form-style-1" action="<?php echo base_url('Profile/profileList')?>" method="post">
          <div class="row">
           <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12" style="opacity: 1; padding-bottom: 10px;">
              <select  class="form-control input-md" name="type" id="stype1" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_type'); ?></option>
                <option value="PROFESSIONAL"><?php echo $this->lang->line('msg_professionals'); ?></option>
                <option value="INTERPRENOUR"><?php echo $this->lang->line('msg_entrepreneurs'); ?></option>
                <!-- <option value="BUSINESS MAN"><?php //echo $this->lang->line('msg_businessman'); ?></option> -->
                <!-- <option value="POLITICIAN">POLITICIAN</option> -->
                <option value="OTHERS"><?php echo $this->lang->line('msg_others'); ?></option>
              </select>
            </div>  
            <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12" style="opacity: 1; padding-bottom: 10px;">
              <select class="form-control input-md" name="category" id="scategory1" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_category'); ?></option>
              </select>
            </div> 
            <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12" style="opacity: 1; padding-bottom: 10px;">
              <select class="form-control input-md" name="subcategory" id="ssubcategory1" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_subcategory'); ?></option>
              </select>
            </div> 
            <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12" style="margin-top: 20px;">
              <button style="opacity: 1 !important;" type="submit" class="btn btn-danger btn-md">&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $this->lang->line('msg_search_profile'); ?></b>&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-search"></i></button>
            </div>
        </div>
        </form>
       </div>
      </div>
    </div>



    <div class="item ">
       <img src="<?php echo base_url('assets/img/slider/slider_03s.jpg');?>" width="100%" height="auto">
      <!-- <div class="carousel-caption hidden-xs" style="text-align: center;"> -->
        <div class="carousel-caption  animated fadeInUp" style="text-align: center;">
        <h3><?php echo $this->lang->line('msg_large_caption'); ?></h3>
        <p><?php echo $this->lang->line('msg_small_caption'); ?></p>
        <div class="homesch">
         <form class="form-style-1" action="<?php echo base_url('Profile/profileList')?>" method="post">
          <div class="row">
           <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12" style="opacity: 1; padding-bottom: 10px;">
              <select  class="form-control input-md" name="type" id="stype2" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_type'); ?></option>
                <option value="PROFESSIONAL"><?php echo $this->lang->line('msg_professionals'); ?></option>
                <option value="INTERPRENOUR"><?php echo $this->lang->line('msg_entrepreneurs'); ?></option>
                <!-- <option value="BUSINESS MAN"><?php //echo $this->lang->line('msg_businessman'); ?></option> -->
                <!-- <option value="POLITICIAN">POLITICIAN</option> -->
                <option value="OTHERS"><?php echo $this->lang->line('msg_others'); ?></option>
              </select>
            </div>  
            <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12" style="opacity: 1; padding-bottom: 10px;">
              <select class="form-control input-md" name="category" id="scategory2" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_category'); ?></option>
              </select>
            </div> 
            <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12" style="opacity: 1; padding-bottom: 10px;">
              <select class="form-control input-md" name="subcategory" id="ssubcategory2" required="">
                <option value="N/A"><?php echo $this->lang->line('msg_select_profile_subcategory'); ?></option>
              </select>
            </div> 
            <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12" style="margin-top: 20px;">
              <button style="opacity: 1 !important;" type="submit" class="btn btn-danger btn-md">&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $this->lang->line('msg_search_profile'); ?></b>&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-search"></i></button>
            </div>
        </div>
        </form>
       </div>
      </div>
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#mysCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#mysCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<!-- ==============  SMALL DEVICES END================= -->









<!-- =============== select input script (LARGE DEVICES) ============ -->
<script type="text/javascript">
    $(document).ready(function() {

    $("#type1").change(function() {
        var val = $(this).val();
        if (val == "PROFESSIONAL") {
            $("#category1").html("<option value='Teacher'>Teacher</option><option value='Doctor'>Doctor</option><option value='Techinician'>Techinician</option><option value='Animal Keeping'>Animal Keeping</option><option value='Agriculturist'>Agriculturist</option><option value='Lawyor'>Lawyor</option><option value='Nurse'>Nurse</option><option value='Burser'>Burser</option><option value='Sychologist'>Sychologist</option><option value='Mfasiri:'>Mfasiri:</option><option value='Interpreter'>Interpreter</option><option value='Journalist'>Journalist</option><option value='Press'>Press</option><option value='Master Ceremony (MC)'>Master Ceremony (MC)</option><option value='Driver'>Driver</option><option value='Dalali'>Dalali</option><option value='Security Guard'>Security Guard</option><option value='Other Works'>Other Works</option>");
        } else if (val == "INTERPRENOUR") {
            $("#category1").html("<option value='Archtect'>Archtect</option><option value='Shop/ Market'>Shop/ Market</option><option value='Packing'>Packing</option><option value='Car Wash'>Car Wash</option><option value='Garage'>Garage</option><option value='Bar'>Bar</option><option value='Saloon'>Saloon</option><option value='Bakery'>Bakery</option><option value='Tution Center'>Tution Center</option><option value='Day care'>Day care</option><option value='School'>School</option><option value='Guest House'>Guest House</option><option value='Hotel'>Hotel</option><option value='Cafe'>Cafe</option><option value='Company'>Company</option><option value='Butcher'>Butcher</option><option value='Institute'>Institute</option><option value='Other Business Works'>Other Business Works</option>");

        } else if (val == "POLITICIAN") {
            $("#category1").html("<option value='President'>President</option><option value='Member of Pariament (MP)'>Member of Pariament (MP)</option><option value='Diwani'>Diwani</option><option value='Chairman'>Chairman</option><option value='Periament Speaker'>Periament Speaker</option><option value='Other Position'>Other Position</option>");

        } else if (val == "OTHERS") {
            $("#category1").html("<option value='N/A'>N/A</option>");

        } else if (val == "N/A") {
            $("#category1").html("<option value='N/A'>Select category1</option>");

        }
    });


   //===========sub element ===========
    $("#category1").change(function() {
        var val2 = $(this).val();
        if (val2 == "Teacher") {
            $("#subcategory1").html("<option value='Mathematics'>Mathematics</option><option value='Physics'>Physics</option><option value='Chemistry'>Chemistry</option><option value='Biology'>Biology</option><option value='History'>History</option><option value='Kiswahili'>Kiswahili</option><option value='English'>English</option><option value='Kiswahili for Foreigners'>Kiswahili for Foreigners</option><option value='Geography'>Geography</option><option value='Accounts'>Accounts</option><option value='Uchumi'>Uchumi</option><option value='Other Subjects'>Other Subjects</option>");
        } else if (val2 == "Doctor") {
            $("#subcategory1").html("<option value='one Specialist'>None Specialist</option><option value='Children'>Children</option><option value='Mothers'>Mothers</option><option value='Skin'>Skin</option><option value='Bones'>Bones</option><option value='Muscles'>Muscles</option><option value='Hearts'>Hearts</option><option value='Operations'>Operations</option>");

        } else if (val2 == "Techinician") {
            $("#subcategory1").html("<option value='Water Pumps'>Water Pumps</option><option value='Electronics'>Electronics</option><option value='Mechanics'>Mechanics</option><option value='Electrical'>Electrical</option><option value='Clothes'>Clothes</option>");

        } else if (val2 == "Animal Keeping") {
            $("#subcategory1").html("<option value='Beef'>Beef</option><option value='Milk'>Milk</option><option value='Chickens (Kuku)'>Chickens (Kuku)</option>");

        } else if (val2 == "Shop/ Market") {
            $("#subcategory1").html("<option value='Clothes'>Clothes</option><option value='Shoes'>Shoes</option><option value='Electronics'>Electronics</option><option value='Others'>Others</option>");

        } else if (val2 == "Saloon") {
            $("#subcategory1").html("<option value='Baba Shop'>Baba Shop</option><option value='Ladies Saloon'>Ladies Saloon</option>");

        } else if (val2 == "School") {
            $("#subcategory1").html("<option value='Primary'>Primary</option><option value='Secondary'>Secondary</option>");

        } else  {
            $("#subcategory1").html("<option value='N/A'>N/A</option>");

        }
    });

});

</script>

<script type="text/javascript">
    $(document).ready(function() {

    $("#type2").change(function() {
        var val = $(this).val();
        if (val == "PROFESSIONAL") {
            $("#category2").html("<option value='Teacher'>Teacher</option><option value='Doctor'>Doctor</option><option value='Techinician'>Techinician</option><option value='Animal Keeping'>Animal Keeping</option><option value='Agriculturist'>Agriculturist</option><option value='Lawyor'>Lawyor</option><option value='Nurse'>Nurse</option><option value='Burser'>Burser</option><option value='Sychologist'>Sychologist</option><option value='Mfasiri:'>Mfasiri:</option><option value='Interpreter'>Interpreter</option><option value='Journalist'>Journalist</option><option value='Press'>Press</option><option value='Master Ceremony (MC)'>Master Ceremony (MC)</option><option value='Driver'>Driver</option><option value='Dalali'>Dalali</option><option value='Security Guard'>Security Guard</option><option value='Other Works'>Other Works</option>");
        } else if (val == "INTERPRENOUR") {
            $("#category2").html("<option value='Archtect'>Archtect</option><option value='Shop/ Market'>Shop/ Market</option><option value='Packing'>Packing</option><option value='Car Wash'>Car Wash</option><option value='Garage'>Garage</option><option value='Bar'>Bar</option><option value='Saloon'>Saloon</option><option value='Bakery'>Bakery</option><option value='Tution Center'>Tution Center</option><option value='Day care'>Day care</option><option value='School'>School</option><option value='Guest House'>Guest House</option><option value='Hotel'>Hotel</option><option value='Cafe'>Cafe</option><option value='Company'>Company</option><option value='Butcher'>Butcher</option><option value='Institute'>Institute</option><option value='Other Business Works'>Other Business Works</option>");

        } else if (val == "POLITICIAN") {
            $("#category2").html("<option value='President'>President</option><option value='Member of Pariament (MP)'>Member of Pariament (MP)</option><option value='Diwani'>Diwani</option><option value='Chairman'>Chairman</option><option value='Periament Speaker'>Periament Speaker</option><option value='Other Position'>Other Position</option>");

        } else if (val == "OTHERS") {
            $("#category2").html("<option value='N/A'>N/A</option>");

        } else if (val == "N/A") {
            $("#category2").html("<option value='N/A'>Select category2</option>");

        }
    });


   //===========sub element ===========
    $("#category2").change(function() {
        var val2 = $(this).val();
        if (val2 == "Teacher") {
            $("#subcategory2").html("<option value='Mathematics'>Mathematics</option><option value='Physics'>Physics</option><option value='Chemistry'>Chemistry</option><option value='Biology'>Biology</option><option value='History'>History</option><option value='Kiswahili'>Kiswahili</option><option value='English'>English</option><option value='Kiswahili for Foreigners'>Kiswahili for Foreigners</option><option value='Geography'>Geography</option><option value='Accounts'>Accounts</option><option value='Uchumi'>Uchumi</option><option value='Other Subjects'>Other Subjects</option>");
        } else if (val2 == "Doctor") {
            $("#subcategory2").html("<option value='one Specialist'>None Specialist</option><option value='Children'>Children</option><option value='Mothers'>Mothers</option><option value='Skin'>Skin</option><option value='Bones'>Bones</option><option value='Muscles'>Muscles</option><option value='Hearts'>Hearts</option><option value='Operations'>Operations</option>");

        } else if (val2 == "Techinician") {
            $("#subcategory2").html("<option value='Water Pumps'>Water Pumps</option><option value='Electronics'>Electronics</option><option value='Mechanics'>Mechanics</option><option value='Electrical'>Electrical</option><option value='Clothes'>Clothes</option>");

        } else if (val2 == "Animal Keeping") {
            $("#subcategory2").html("<option value='Beef'>Beef</option><option value='Milk'>Milk</option><option value='Chickens (Kuku)'>Chickens (Kuku)</option>");

        } else if (val2 == "Shop/ Market") {
            $("#subcategory2").html("<option value='Clothes'>Clothes</option><option value='Shoes'>Shoes</option><option value='Electronics'>Electronics</option><option value='Others'>Others</option>");

        } else if (val2 == "Saloon") {
            $("#subcategory2").html("<option value='Baba Shop'>Baba Shop</option><option value='Ladies Saloon'>Ladies Saloon</option>");

        } else if (val2 == "School") {
            $("#subcategory2").html("<option value='Primary'>Primary</option><option value='Secondary'>Secondary</option>");

        } else  {
            $("#subcategory2").html("<option value='N/A'>N/A</option>");

        }
    });

});

</script>
<!-- ================ end select inout script (LARGE DEVICES) ===========  -->








<!-- =============== select input script (SMALL DEVICES) ============ -->
<script type="text/javascript">
    $(document).ready(function() {

    $("#stype").change(function() {
        var val = $(this).val();
        if (val == "PROFESSIONAL") {
            $("#scategory").html("<option value='Teacher'>Teacher</option><option value='Doctor'>Doctor</option><option value='Techinician'>Techinician</option><option value='Animal Keeping'>Animal Keeping</option><option value='Agriculturist'>Agriculturist</option><option value='Lawyor'>Lawyor</option><option value='Nurse'>Nurse</option><option value='Burser'>Burser</option><option value='Sychologist'>Sychologist</option><option value='Mfasiri:'>Mfasiri:</option><option value='Interpreter'>Interpreter</option><option value='Journalist'>Journalist</option><option value='Press'>Press</option><option value='Master Ceremony (MC)'>Master Ceremony (MC)</option><option value='Driver'>Driver</option><option value='Dalali'>Dalali</option><option value='Security Guard'>Security Guard</option><option value='Other Works'>Other Works</option>");
        } else if (val == "INTERPRENOUR") {
            $("#scategory").html("<option value='Archtect'>Archtect</option><option value='Shop/ Market'>Shop/ Market</option><option value='Packing'>Packing</option><option value='Car Wash'>Car Wash</option><option value='Garage'>Garage</option><option value='Bar'>Bar</option><option value='Saloon'>Saloon</option><option value='Bakery'>Bakery</option><option value='Tution Center'>Tution Center</option><option value='Day care'>Day care</option><option value='School'>School</option><option value='Guest House'>Guest House</option><option value='Hotel'>Hotel</option><option value='Cafe'>Cafe</option><option value='Company'>Company</option><option value='Butcher'>Butcher</option><option value='Institute'>Institute</option><option value='Other Business Works'>Other Business Works</option>");

        } else if (val == "POLITICIAN") {
            $("#scategory").html("<option value='President'>President</option><option value='Member of Pariament (MP)'>Member of Pariament (MP)</option><option value='Diwani'>Diwani</option><option value='Chairman'>Chairman</option><option value='Periament Speaker'>Periament Speaker</option><option value='Other Position'>Other Position</option>");

        } else if (val == "OTHERS") {
            $("#scategory").html("<option value='N/A'>N/A</option>");

        } else if (val == "N/A") {
            $("#scategory").html("<option value='N/A'>Select scategory</option>");

        }
    });


   //===========sub element ===========
    $("#scategory").change(function() {
        var val2 = $(this).val();
        if (val2 == "Teacher") {
            $("#ssubcategory").html("<option value='Mathematics'>Mathematics</option><option value='Physics'>Physics</option><option value='Chemistry'>Chemistry</option><option value='Biology'>Biology</option><option value='History'>History</option><option value='Kiswahili'>Kiswahili</option><option value='English'>English</option><option value='Kiswahili for Foreigners'>Kiswahili for Foreigners</option><option value='Geography'>Geography</option><option value='Accounts'>Accounts</option><option value='Uchumi'>Uchumi</option><option value='Other Subjects'>Other Subjects</option>");
        } else if (val2 == "Doctor") {
            $("#ssubcategory").html("<option value='one Specialist'>None Specialist</option><option value='Children'>Children</option><option value='Mothers'>Mothers</option><option value='Skin'>Skin</option><option value='Bones'>Bones</option><option value='Muscles'>Muscles</option><option value='Hearts'>Hearts</option><option value='Operations'>Operations</option>");

        } else if (val2 == "Techinician") {
            $("#ssubcategory").html("<option value='Water Pumps'>Water Pumps</option><option value='Electronics'>Electronics</option><option value='Mechanics'>Mechanics</option><option value='Electrical'>Electrical</option><option value='Clothes'>Clothes</option>");

        } else if (val2 == "Animal Keeping") {
            $("#ssubcategory").html("<option value='Beef'>Beef</option><option value='Milk'>Milk</option><option value='Chickens (Kuku)'>Chickens (Kuku)</option>");

        } else if (val2 == "Shop/ Market") {
            $("#ssubcategory").html("<option value='Clothes'>Clothes</option><option value='Shoes'>Shoes</option><option value='Electronics'>Electronics</option><option value='Others'>Others</option>");

        } else if (val2 == "Saloon") {
            $("#ssubcategory").html("<option value='Baba Shop'>Baba Shop</option><option value='Ladies Saloon'>Ladies Saloon</option>");

        } else if (val2 == "School") {
            $("#ssubcategory").html("<option value='Primary'>Primary</option><option value='Secondary'>Secondary</option>");

        } else  {
            $("#ssubcategory").html("<option value='N/A'>N/A</option>");

        }
    });

});

</script>

<script type="text/javascript">
    $(document).ready(function() {

    $("#stype1").change(function() {
        var val = $(this).val();
        if (val == "PROFESSIONAL") {
            $("#scategory1").html("<option value='Teacher'>Teacher</option><option value='Doctor'>Doctor</option><option value='Techinician'>Techinician</option><option value='Animal Keeping'>Animal Keeping</option><option value='Agriculturist'>Agriculturist</option><option value='Lawyor'>Lawyor</option><option value='Nurse'>Nurse</option><option value='Burser'>Burser</option><option value='Sychologist'>Sychologist</option><option value='Mfasiri:'>Mfasiri:</option><option value='Interpreter'>Interpreter</option><option value='Journalist'>Journalist</option><option value='Press'>Press</option><option value='Master Ceremony (MC)'>Master Ceremony (MC)</option><option value='Driver'>Driver</option><option value='Dalali'>Dalali</option><option value='Security Guard'>Security Guard</option><option value='Other Works'>Other Works</option>");
        } else if (val == "INTERPRENOUR") {
            $("#scategory1").html("<option value='Archtect'>Archtect</option><option value='Shop/ Market'>Shop/ Market</option><option value='Packing'>Packing</option><option value='Car Wash'>Car Wash</option><option value='Garage'>Garage</option><option value='Bar'>Bar</option><option value='Saloon'>Saloon</option><option value='Bakery'>Bakery</option><option value='Tution Center'>Tution Center</option><option value='Day care'>Day care</option><option value='School'>School</option><option value='Guest House'>Guest House</option><option value='Hotel'>Hotel</option><option value='Cafe'>Cafe</option><option value='Company'>Company</option><option value='Butcher'>Butcher</option><option value='Institute'>Institute</option><option value='Other Business Works'>Other Business Works</option>");

        } else if (val == "POLITICIAN") {
            $("#scategory1").html("<option value='President'>President</option><option value='Member of Pariament (MP)'>Member of Pariament (MP)</option><option value='Diwani'>Diwani</option><option value='Chairman'>Chairman</option><option value='Periament Speaker'>Periament Speaker</option><option value='Other Position'>Other Position</option>");

        } else if (val == "OTHERS") {
            $("#scategory1").html("<option value='N/A'>N/A</option>");

        } else if (val == "N/A") {
            $("#scategory1").html("<option value='N/A'>Select scategory1</option>");

        }
    });


   //===========sub element ===========
    $("#scategory1").change(function() {
        var val2 = $(this).val();
        if (val2 == "Teacher") {
            $("#ssubcategory1").html("<option value='Mathematics'>Mathematics</option><option value='Physics'>Physics</option><option value='Chemistry'>Chemistry</option><option value='Biology'>Biology</option><option value='History'>History</option><option value='Kiswahili'>Kiswahili</option><option value='English'>English</option><option value='Kiswahili for Foreigners'>Kiswahili for Foreigners</option><option value='Geography'>Geography</option><option value='Accounts'>Accounts</option><option value='Uchumi'>Uchumi</option><option value='Other Subjects'>Other Subjects</option>");
        } else if (val2 == "Doctor") {
            $("#ssubcategory1").html("<option value='one Specialist'>None Specialist</option><option value='Children'>Children</option><option value='Mothers'>Mothers</option><option value='Skin'>Skin</option><option value='Bones'>Bones</option><option value='Muscles'>Muscles</option><option value='Hearts'>Hearts</option><option value='Operations'>Operations</option>");

        } else if (val2 == "Techinician") {
            $("#ssubcategory1").html("<option value='Water Pumps'>Water Pumps</option><option value='Electronics'>Electronics</option><option value='Mechanics'>Mechanics</option><option value='Electrical'>Electrical</option><option value='Clothes'>Clothes</option>");

        } else if (val2 == "Animal Keeping") {
            $("#ssubcategory1").html("<option value='Beef'>Beef</option><option value='Milk'>Milk</option><option value='Chickens (Kuku)'>Chickens (Kuku)</option>");

        } else if (val2 == "Shop/ Market") {
            $("#ssubcategory1").html("<option value='Clothes'>Clothes</option><option value='Shoes'>Shoes</option><option value='Electronics'>Electronics</option><option value='Others'>Others</option>");

        } else if (val2 == "Saloon") {
            $("#ssubcategory1").html("<option value='Baba Shop'>Baba Shop</option><option value='Ladies Saloon'>Ladies Saloon</option>");

        } else if (val2 == "School") {
            $("#ssubcategory1").html("<option value='Primary'>Primary</option><option value='Secondary'>Secondary</option>");

        } else  {
            $("#ssubcategory1").html("<option value='N/A'>N/A</option>");

        }
    });

});

</script>

<script type="text/javascript">
    $(document).ready(function() {

    $("#stype2").change(function() {
        var val = $(this).val();
        if (val == "PROFESSIONAL") {
            $("#scategory2").html("<option value='Teacher'>Teacher</option><option value='Doctor'>Doctor</option><option value='Techinician'>Techinician</option><option value='Animal Keeping'>Animal Keeping</option><option value='Agriculturist'>Agriculturist</option><option value='Lawyor'>Lawyor</option><option value='Nurse'>Nurse</option><option value='Burser'>Burser</option><option value='Sychologist'>Sychologist</option><option value='Mfasiri:'>Mfasiri:</option><option value='Interpreter'>Interpreter</option><option value='Journalist'>Journalist</option><option value='Press'>Press</option><option value='Master Ceremony (MC)'>Master Ceremony (MC)</option><option value='Driver'>Driver</option><option value='Dalali'>Dalali</option><option value='Security Guard'>Security Guard</option><option value='Other Works'>Other Works</option>");
        } else if (val == "INTERPRENOUR") {
            $("#scategory2").html("<option value='Archtect'>Archtect</option><option value='Shop/ Market'>Shop/ Market</option><option value='Packing'>Packing</option><option value='Car Wash'>Car Wash</option><option value='Garage'>Garage</option><option value='Bar'>Bar</option><option value='Saloon'>Saloon</option><option value='Bakery'>Bakery</option><option value='Tution Center'>Tution Center</option><option value='Day care'>Day care</option><option value='School'>School</option><option value='Guest House'>Guest House</option><option value='Hotel'>Hotel</option><option value='Cafe'>Cafe</option><option value='Company'>Company</option><option value='Butcher'>Butcher</option><option value='Institute'>Institute</option><option value='Other Business Works'>Other Business Works</option>");

        } else if (val == "POLITICIAN") {
            $("#scategory2").html("<option value='President'>President</option><option value='Member of Pariament (MP)'>Member of Pariament (MP)</option><option value='Diwani'>Diwani</option><option value='Chairman'>Chairman</option><option value='Periament Speaker'>Periament Speaker</option><option value='Other Position'>Other Position</option>");

        } else if (val == "OTHERS") {
            $("#scategory2").html("<option value='N/A'>N/A</option>");

        } else if (val == "N/A") {
            $("#scategory2").html("<option value='N/A'>Select scategory2</option>");

        }
    });


   //===========sub element ===========
    $("#scategory2").change(function() {
        var val2 = $(this).val();
        if (val2 == "Teacher") {
            $("#ssubcategory2").html("<option value='Mathematics'>Mathematics</option><option value='Physics'>Physics</option><option value='Chemistry'>Chemistry</option><option value='Biology'>Biology</option><option value='History'>History</option><option value='Kiswahili'>Kiswahili</option><option value='English'>English</option><option value='Kiswahili for Foreigners'>Kiswahili for Foreigners</option><option value='Geography'>Geography</option><option value='Accounts'>Accounts</option><option value='Uchumi'>Uchumi</option><option value='Other Subjects'>Other Subjects</option>");
        } else if (val2 == "Doctor") {
            $("#ssubcategory2").html("<option value='one Specialist'>None Specialist</option><option value='Children'>Children</option><option value='Mothers'>Mothers</option><option value='Skin'>Skin</option><option value='Bones'>Bones</option><option value='Muscles'>Muscles</option><option value='Hearts'>Hearts</option><option value='Operations'>Operations</option>");

        } else if (val2 == "Techinician") {
            $("#ssubcategory2").html("<option value='Water Pumps'>Water Pumps</option><option value='Electronics'>Electronics</option><option value='Mechanics'>Mechanics</option><option value='Electrical'>Electrical</option><option value='Clothes'>Clothes</option>");

        } else if (val2 == "Animal Keeping") {
            $("#ssubcategory2").html("<option value='Beef'>Beef</option><option value='Milk'>Milk</option><option value='Chickens (Kuku)'>Chickens (Kuku)</option>");

        } else if (val2 == "Shop/ Market") {
            $("#ssubcategory2").html("<option value='Clothes'>Clothes</option><option value='Shoes'>Shoes</option><option value='Electronics'>Electronics</option><option value='Others'>Others</option>");

        } else if (val2 == "Saloon") {
            $("#ssubcategory2").html("<option value='Baba Shop'>Baba Shop</option><option value='Ladies Saloon'>Ladies Saloon</option>");

        } else if (val2 == "School") {
            $("#ssubcategory2").html("<option value='Primary'>Primary</option><option value='Secondary'>Secondary</option>");

        } else  {
            $("#ssubcategory2").html("<option value='N/A'>N/A</option>");

        }
    });

});

</script>
<!-- ================ end select inout script (SMALL DEVICES) ===========  -->