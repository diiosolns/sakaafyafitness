<section class="content" style="padding: 15px 5% 0 5%">

    <!-- row -->
    <div class="row">                        
         <div class="col-md-12">
         	<div id="pdf" >
			  <object  width="100%" height="550" type="application/pdf" data="<?php echo base_url('uploads/terms/eng/terms.pdf'); ?>?#page=5&zoom=130&scrollbar=0&toolbar=0&navpanes=0" id="pdf_content" >
			     <p><b>WARNING.! </b>: This browser does not support PDFs. Please download the PDF to view it: <a href="<?php echo base_url('uploads/terms/eng/terms.pdf'); ?>">Download PDF</a>.</p>
			  </object>
			</div>
         </div>             
    </div><!-- /.row -->

</section>

<!-- =================== PAGE ENDS HERE ============= -->






<!-- PDF DSP LINK: https://stackoverflow.com/questions/291813/recommended-way-to-embed-pdf-in-html -->

<!-- <iframe src="<?php //echo base_url('uploads/terms/eng/terms.pdf'); ?>#page=2" width="100%" height="100%">
This browser does not support PDFs. Please download the PDF to view it: <a href="<?php //echo base_url('uploads/terms/eng/terms.pdf'); ?>">Download PDF</a>
</iframe>


<embed src="<?php //echo base_url('uploads/terms/eng/terms.pdf'); ?>#page=2" type="application/pdf" width="100%" height="100%">



<object data="<?php //echo base_url('uploads/terms/eng/terms.pdf'); ?>#page=2" type="application/pdf" width="100%" height="600px">
   <p><b>WARNING.! </b>: This browser does not support PDFs. Please download the PDF to view it: <a href="<?php //echo base_url('uploads/terms/eng/terms.pdf'); ?>">Download PDF</a>.</p>
</object>

<div id="pdf">
  <object width="400" height="500" type="application/pdf" data="<?php //echo base_url('uploads/terms/eng/terms.pdf'); ?>?#zoom=85&scrollbar=0&toolbar=0&navpanes=0" id="pdf_content">
     <p><b>WARNING.! </b>: This browser does not support PDFs. Please download the PDF to view it: <a href="<?php //echo base_url('uploads/terms/eng/terms.pdf'); ?>">Download PDF</a>.</p>
  </object>
</div> -->