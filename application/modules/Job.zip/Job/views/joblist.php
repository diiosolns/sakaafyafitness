<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/tabs.css');?>" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/tabstyles.css');?>" />
<script src="<?php echo base_url('assets/js/modernizr.custom.js');?>"></script>
<!--  search inputs top -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="<?php echo base_url('assets/js/myJs/profilesch.js');?>" type="text/javascript"></script> 
<style type="text/css">
  .profileout{
    margin-top: 2%;
    margin-bottom: 3%;
  }
  .profile{
    background-color: #fff;
    margin-bottom: 5%;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  }
  .lightpan{
    background-color: #fff;
    margin-top: 2%;
    margin-bottom: 3%;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  }
  .myul {
      padding-bottom: 50px;
  }
  .myli {
    font-size: 18px;
    padding-bottom: 10px;
  }

  .cardheader_sm {
       background: url("<?php echo base_url('assets/img/profilebg2.jpg');?>");
      /*background: url("../../img/profilebg3.jpg");*/
       background-size: cover;
       height: 60px;
    }
</style>

 <?php
     $services = modules::load('Profile')->get_where_custom_tb('services', 'status', "Active");
  ?>

<!-- =================  SLIDING PROFILES ==================== -->

 

<!--  ==========================Need work done?============== -->
<section class=" wow animated fadeInUp " 1style="padding: 40px 20px 40px 20px; background-color: #fff !important;">
<div class="row padding" style="margin-left: 5% !important; margin-right: 5% !important;">
  
  <div class="col-md-8 profileout pull-left ">
     <!-- ==========incase no job ============ -->
    <?php if ($jobRes->num_rows()==0) { ?>
      <div class="row profile">
        <div class="col-md-12" style="height: 10px;"></div>
        <div class="col-md-2" style="text-align: center;"><img src="<?php echo base_url('assets/img/profile/0/def.png');?>" class="avater" alt="service" style="width: 90%;" ></div>
        <div class="col-md-10">
          <a href="" class="pull-right"><i style="font-size: 17px;" class="fa fa-ellipsis-v pull-right"></i></a>
          <h2 style="color: lightgray;"><b>No jobs to display! </b></h2>
          <h4 style="color: lightgray;">Currently we don't have any project under this category. Comming soon!</h4>
          <hr>
        </div>
      </div>
    <?php } ?>
    <!-- =========end no job ================ -->
    <?php foreach ($jobRes->result() as $row1): ?>
      <?php $imgUrl = 'assets/img/profile/0/def.png'; ?>
    <div class="row profile">
      <div class="col-md-12" style="height: 10px;"></div>
      <div class="col-md-2" style="text-align: center;"><img src="<?php echo base_url($imgUrl);?>" class="avater" alt="service" style="width: 90%;" ></div>
      <div class="col-md-10">
        <a href="" class="pull-right"><i style="font-size: 17px;" class="fa fa-ellipsis-v pull-right"></i></a>
        <h4><b><?php echo $row1->jobtitle ;?></b></h4>
        <span><i>Category : <?php echo $row1->cat ;?></i></span>
        <hr>
      </div>
      <div class="col-md-12" >
        <p style="font-size: 16px;">
          <?php echo $row1->description ;?>
        </p>
      </div>
      <div class="col-md-12" style="padding-bottom: 20px; font-size: 18px;" >
        <hr>
        <a href="<?php echo base_url('Job/jobview/');?><?php echo $row1->id;?>" class="pull-right">View more&nbsp;&nbsp;<i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  

  <!-- <div class="col-md-1 padding lightpan"></div> -->

  <div class="col-md-4 padding lightpan pull-right" style="width: 30%;">
    <h3>Available categories</h3>
    <hr>
    <ul class="myul">
      <?php foreach ($services->result() as $row): ?>
        <li class="myli"><a href="<?php echo base_url('Job/findjob/');?><?php echo $row->id;?>"><?php echo $row->service;?></a></li>
      <?php endforeach; ?>
    </ul>
  </div>
</div>
</section>
<!--  =======================end panel done?============= -->