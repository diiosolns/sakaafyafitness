<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Job extends MX_Controller
{

function __construct() {
parent::__construct();
        $this->load->library('pagination'); //for pagination
        //$this->load->helper('url'); //load url helper

		$this->load->helper('number');
		$this->load->helper('date');
		$this->load->helper('download');
		$this->load->helper('text');
		//My Modules
		$this->load->module('Profile');
		$this->load->module('Appointment');
		$this->load->module('Artical');
		$this->load->module('Admin');
		$this->load->module('Chat');
		$this->load->module('Home');
		$this->load->module('Users');
		$this->load->module('Job');
}


function index(){ 
	$data['middle_m'] ="";
	$data['mpanel_m'] = "";
	$data['mpanel_f'] = "";
	$data['bfooter_m'] ="";
	$data['bfooter_f'] ="";
	$data['color'] = "";
	$data['msg'] ='';
	if ($this->session->userdata('logged_in')) {
		if ($this->session->userdata('user_role') == "Admin") { $this->load->view('Admin/indexa',$data); } else if ($this->session->userdata('user_role') == "Freelancer") { $this->load->view('Admin/indexf',$data); } else if ($this->session->userdata('user_role') == "User") { $this->load->view('Admin/indexu',$data); } else {  $this->load->view('Admin/indexu',$data); }
	} else {
		redirect('Home');
	}
}

function freelancer(){ 
	$data['middle_m'] ="";
	$data['mpanel_m'] = "";
	$data['mpanel_f'] = "";
	$data['bfooter_m'] ="";
	$data['bfooter_f'] ="";
	$data['color'] = "";
	$data['msg'] ='';
	if ($this->session->userdata('logged_in')) {
		if ($this->session->userdata('user_role') == "Admin") { $this->load->view('Admin/indexa',$data); } else if ($this->session->userdata('user_role') == "Freelancer") { $this->load->view('Admin/indexf',$data); } else if ($this->session->userdata('user_role') == "User") { $this->load->view('Admin/indexu',$data); } else {  $this->load->view('Admin/indexu',$data); }
	} else {
		redirect('Home');
	}
}

function findjob(){ 
  $data['middle_m'] ="Job";
  $data['mpanel_m'] = "Job";
  $data['mpanel_f'] = "joblist";
  $data['middle_f'] ="joblist";
  $data['bfooter_m'] ="Home";
  $data['bfooter_f'] ="blank";
  $data['color'] = "";
  $data['msg'] ='';
  $serviceid = $this->uri->segment(3);
  if ($serviceid == 0) {
    $data['jobRes'] = $this->job->get_where_custom('status', "Open");
  } else {
    $data['jobRes'] = $this->job->get_where_custom2('serviceid', $serviceid,'status', "Open");
  }
  
  if ($this->session->userdata('logged_in')) {
    if ($this->session->userdata('user_role') == "Admin") { $this->load->view('Admin/indexa',$data); } else if ($this->session->userdata('user_role') == "Freelancer") { $this->load->view('Admin/indexf',$data); } else if ($this->session->userdata('user_role') == "User") { $this->load->view('Admin/indexu',$data); } else {  $this->load->view('Admin/indexu',$data); }
  } else {
    $this->load->view('Home/index',$data);
  }
}



function post(){ 
  $data['middle_m'] ="Job";
  $data['mpanel_m'] = "Job";
  $data['mpanel_f'] = "job";
  $data['middle_f'] ="job";
  $data['bfooter_m'] ="Home";
  $data['bfooter_f'] ="blank";
  $data['color'] = "";
  $data['msg'] ='';
  $serviceid = $this->uri->segment(3);
  $data['jobRes'] = $this->job->get_where_custom('serviceid', $serviceid);
  if ($this->session->userdata('logged_in')) {
    if ($this->session->userdata('user_role') == "Admin") { $this->load->view('Admin/indexa',$data); } else if ($this->session->userdata('user_role') == "Freelancer") { $this->load->view('Admin/indexf',$data); } else if ($this->session->userdata('user_role') == "User") { $this->load->view('Admin/indexu',$data); } else {  $this->load->view('Admin/indexu',$data); }
  } else {
    $this->load->view('Home/index',$data);
  }
}


function myjobs(){ 
  $data['middle_m'] ="Job";
  $data['mpanel_m'] = "Job";
  $data['mpanel_f'] = "myjobs";
  $data['middle_f'] ="myjobs";
  $data['bfooter_m'] ="Home";
  $data['bfooter_f'] ="blank";
  $data['color'] = "";
  $data['msg'] ='';
  $serviceid = $this->uri->segment(3);
  $data['jobRes'] = $this->job->get_where_custom('serviceid', $serviceid);
  if ($this->session->userdata('logged_in')) {
    if ($this->session->userdata('user_role') == "Admin") { $this->load->view('Admin/indexa',$data); } else if ($this->session->userdata('user_role') == "Freelancer") { $this->load->view('Admin/indexf',$data); } else if ($this->session->userdata('user_role') == "User") { $this->load->view('Admin/indexu',$data); } else {  $this->load->view('Admin/indexu',$data); }
  } else {
    $this->load->view('Home/index',$data);
  }
}


/*
id  
jobid 
jobtitle  
serviceid 
cat 
description 
budget  
totalcost 
paystatus 
filename  
img 
remarks 
skills  
additional1 
additional2 
postedby  
assignedto  
acceptedby  
doneby  
closedby  
status  
postedon  
paidon  
acceptedon  
closedon  
date  
udate 
*/




//NOTIFICATIONS
//================== NOTIFICATIONS ===============
function emailSender($recepient, $subject, $messagetxt){
        $snet=false;
       /* $config = Array(
         'protocol' => 'smtp',
          'smtp_host' => 'ssl://smtp.googlemail.com', 
          'smtp_port' => 465,
          'smtp_user' => 'sic.info17@gmail.com', // change it to yours
          'smtp_pass' => 'System.123', // change it to yours
          'mailtype' => 'html',
          'charset' => 'iso-8859-1',
          'wordwrap' => TRUE
        );*/
        
         $config = Array(
         'protocol' => 'smtp',
          'smtp_host' => 'ssl://secure238.inmotionhosting.com', 
          'smtp_port' => 465,
          'smtp_user' => 'ehuduma@uwezomedia.com', // change it to yours
          'smtp_pass' => 'Hoja@255.com', // change it to yours
          'mailtype' => 'html',
          'charset' => 'iso-8859-1',
          'wordwrap' => TRUE
        );

          $message = $messagetxt;
          $this->load->library('email', $config);
          $this->email->set_newline("\r\n");
          $this->email->from('ehuduma@uwezomedia.com','eHuduma'); // change it to yours
          $this->email->to($recepient);// change it to yours
          $this->email->subject($subject);
          $this->email->message($message);
        if($this->email->send()){
            $sent=true;
            return $sent;
         }
         else{
            show_error($this->email->print_debugger());
        }
}


public function smsSender($to,$message){
  # code...
  $phone=$to;
  $textSMS=$message;

    $url='api.infobip.com/sms/1/text/single';

    $send='{  
      "from":"SIC",
      "to":"'.$phone.'",
      "text":"'.$textSMS.'"
    }';

    $sms = curl_init($url);
    curl_setopt( $sms, CURLOPT_POST, 1);
    curl_setopt( $sms, CURLOPT_POSTFIELDS, $send);
    curl_setopt( $sms, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt( $sms, CURLOPT_HTTPHEADER,array (
    'Authorization: Basic RGlvbkFkbWluOiNGcmFuazE2QCM=',
    'Content-Type: application/json',
    'accept: application/json',
    ));
    curl_setopt( $sms, CURLOPT_RETURNTRANSFER, 1);

    $response = curl_exec($sms);
    //echo $response;
  
}
//========================X===X==================

/*==================  end huduma ================*/


//default codes xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

function get($order_by) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get($order_by);
return $query;
}

function get_dist($col) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_dist($col);
return $query;
}

function get_with_limit($limit, $offset, $order_by) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_with_limit($limit, $offset, $order_by);
return $query;
}

function get_where($id) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_where($id);
return $query;
}

function get_where_custom($col, $value) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_where_custom($col, $value);
return $query;
}

function get_col_where($tb, $col) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_col_where($tb, $col);
return $query;
}

function get_col_where2($tb, $col, $col1, $val1) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_col_where2($tb, $col, $col1, $val1);
return $query;
}

function get_where_custom_tb($tb, $col, $value) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_where_custom_tb($tb, $col, $value);
return $query;
}

function get_where_custom2($col1, $value1, $col2, $value2) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_where_custom2($col1, $value1, $col2, $value2);
return $query;
}

function get_where_custom3($col1, $value1, $col2, $value2, $col3, $value3) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_where_custom3($col1, $value1, $col2, $value2, $col3, $value3);
return $query;
}

/*=============  pagination =============*/
function get_where_custom0_limit($limit, $offset) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_where_custom0_limit($limit, $offset);
return $query;
}

function get_where_custom_limit($col, $value, $limit, $offset) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_where_custom_limit($col, $value, $limit, $offset);
return $query;
}

function get_where_custom2_limit($col1, $value1, $col2, $value2, $limit, $offset) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_where_custom2_limit($col1, $value1, $col2, $value2, $limit, $offset);
return $query;
}

function get_where_custom3_limit($col1, $value1, $col2, $value2, $col3, $value3, $limit, $offset) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_where_custom3_limit($col1, $value1, $col2, $value2, $col3, $value3, $limit, $offset);
return $query;
}
/*================ end pagination ============*/

function _insert($data) {
$this->load->model('Mdl_job');
$this->Mdl_job->_insert($data);
}

function _insert_tb($tb, $data) {
$this->load->model('Mdl_job');
$this->Mdl_job->_insert_tb($tb, $data);
}

function _update($id, $data) {
$this->load->model('Mdl_job');
$this->Mdl_job->_update($id, $data);
}

function _update_custome($col, $value, $data) {
$this->load->model('Mdl_job');
$this->Mdl_job->_update_custome($col, $value, $data);
}

function _delete($id) {
$this->load->model('Mdl_job');
$this->Mdl_job->_delete($id);
}

function _delete_custome($col, $value) {
$this->load->model('Mdl_job');
$this->Mdl_job->_delete_custome($col, $value);
}

function count_where($column, $value) {
$this->load->model('Mdl_job');
$count = $this->Mdl_job->count_where($column, $value);
return $count;
}

function count_all() {
$this->load->model('Mdl_job');
$count = $this->Mdl_job->count_all();
return $count;
}



function get_max() {
$this->load->model('Mdl_job');
$max_id = $this->Mdl_job->get_max();
return $max_id;
}

function _custom_query($mysql_query) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->_custom_query($mysql_query);
return $query;
}

/*=============== LIKE (SEARCH) =========================*/
function get_like_custom($tb, $col1, $value1) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_like_custom($tb, $col1, $value1);
return $query;
}

function get_like_custom1($tb, $col1, $value1, $col2, $value2) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_like_custom1($tb, $col1, $value1, $col2, $value2);
return $query;
}

function get_like_custom_limit($tb, $col1, $value1,  $limit, $offset) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_like_custom_limit($tb, $col1, $value1, $limit, $offset);
return $query;
}

function get_like_custom1_limit($tb, $col1, $value1, $col2, $value2, $limit, $offset) {
$this->load->model('Mdl_job');
$query = $this->Mdl_job->get_like_custom1_limit($tb, $col1, $value1, $col2, $value2, $limit, $offset);
return $query;
}
/*================ END LIKE =============================*/


}